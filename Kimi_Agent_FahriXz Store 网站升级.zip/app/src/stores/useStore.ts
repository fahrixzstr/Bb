import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type {
  User,
  CartItem,
  Notification,
  ChatMessage,
  Transaction,
  UserMission,
  KTAInfo,
  SiteConfig,
} from '@/types';

interface AppState {
  // Auth
  user: User | null;
  isLoggedIn: boolean;
  isAdmin: boolean;
  loading: boolean;
  setUser: (user: User | null) => void;
  setLoading: (loading: boolean) => void;
  logout: () => void;

  // Theme
  theme: 'dark' | 'light';
  toggleTheme: () => void;
  setTheme: (theme: 'dark' | 'light') => void;

  // Language
  language: 'id' | 'en';
  setLanguage: (lang: 'id' | 'en') => void;

  // Cart
  cart: CartItem[];
  addToCart: (item: CartItem) => void;
  removeFromCart: (productId: string, variantId?: string) => void;
  updateQuantity: (productId: string, quantity: number, variantId?: string) => void;
  clearCart: () => void;
  getCartTotal: () => number;
  getCartCount: () => number;

  // Notifications
  notifications: Notification[];
  unreadCount: number;
  addNotification: (notification: Notification) => void;
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
  clearNotifications: () => void;

  // Chat
  chatMessages: ChatMessage[];
  addChatMessage: (message: ChatMessage) => void;
  clearChat: () => void;
  isChatOpen: boolean;
  toggleChat: () => void;

  // Wallet
  transactions: Transaction[];
  addTransaction: (transaction: Transaction) => void;

  // Missions
  userMissions: UserMission[];
  setUserMissions: (missions: UserMission[]) => void;

  // KTA
  ktaInfo: KTAInfo | null;
  setKtaInfo: (info: KTAInfo | null) => void;

  // Admin
  adminClicks: number;
  lastAdminClick: number | null;
  incrementAdminClick: () => void;
  resetAdminClicks: () => void;

  // Site Config
  siteConfig: SiteConfig;
  setSiteConfig: (config: Partial<SiteConfig>) => void;
}

const useStore = create<AppState>()(
  persist(
    (set, get) => ({
      // Auth
      user: null,
      isLoggedIn: false,
      isAdmin: false,
      loading: true,
      setUser: (user) =>
        set({
          user,
          isLoggedIn: !!user,
          isAdmin: user?.role === 'admin',
        }),
      setLoading: (loading) => set({ loading }),
      logout: () =>
        set({
          user: null,
          isLoggedIn: false,
          isAdmin: false,
          cart: [],
          notifications: [],
        }),

      // Theme
      theme: 'dark',
      toggleTheme: () =>
        set((state) => ({ theme: state.theme === 'dark' ? 'light' : 'dark' })),
      setTheme: (theme) => set({ theme }),

      // Language
      language: 'id',
      setLanguage: (language) => set({ language }),

      // Cart
      cart: [],
      addToCart: (item) =>
        set((state) => {
          const existing = state.cart.find(
            (i) =>
              i.productId === item.productId && i.variantId === item.variantId
          );
          if (existing) {
            return {
              cart: state.cart.map((i) =>
                i.productId === item.productId && i.variantId === item.variantId
                  ? { ...i, quantity: i.quantity + item.quantity }
                  : i
              ),
            };
          }
          return { cart: [...state.cart, item] };
        }),
      removeFromCart: (productId, variantId) =>
        set((state) => ({
          cart: state.cart.filter(
            (i) =>
              !(i.productId === productId && i.variantId === variantId)
          ),
        })),
      updateQuantity: (productId, quantity, variantId) =>
        set((state) => ({
          cart: state.cart.map((i) =>
            i.productId === productId && i.variantId === variantId
              ? { ...i, quantity: Math.max(1, quantity) }
              : i
          ),
        })),
      clearCart: () => set({ cart: [] }),
      getCartTotal: () => {
        return get().cart.reduce(
          (total, item) =>
            total +
            (item.variant?.price || item.product.price) * item.quantity,
          0
        );
      },
      getCartCount: () => {
        return get().cart.reduce((count, item) => count + item.quantity, 0);
      },

      // Notifications
      notifications: [],
      unreadCount: 0,
      addNotification: (notification) =>
        set((state) => ({
          notifications: [notification, ...state.notifications],
          unreadCount: state.unreadCount + 1,
        })),
      markAsRead: (id) =>
        set((state) => ({
          notifications: state.notifications.map((n) =>
            n.id === id ? { ...n, isRead: true } : n
          ),
          unreadCount: Math.max(0, state.unreadCount - 1),
        })),
      markAllAsRead: () =>
        set((state) => ({
          notifications: state.notifications.map((n) => ({
            ...n,
            isRead: true,
          })),
          unreadCount: 0,
        })),
      clearNotifications: () => set({ notifications: [], unreadCount: 0 }),

      // Chat
      chatMessages: [
        {
          id: 'welcome',
          role: 'assistant',
          content: 'Halo! Saya asisten AI FahriXz Store. Ada yang bisa saya bantu?',
          timestamp: new Date(),
        },
      ],
      addChatMessage: (message) =>
        set((state) => ({
          chatMessages: [...state.chatMessages, message],
        })),
      clearChat: () =>
        set({
          chatMessages: [
            {
              id: 'welcome',
              role: 'assistant',
              content: 'Halo! Saya asisten AI FahriXz Store. Ada yang bisa saya bantu?',
              timestamp: new Date(),
            },
          ],
        }),
      isChatOpen: false,
      toggleChat: () => set((state) => ({ isChatOpen: !state.isChatOpen })),

      // Wallet
      transactions: [],
      addTransaction: (transaction) =>
        set((state) => ({
          transactions: [transaction, ...state.transactions],
        })),

      // Missions
      userMissions: [],
      setUserMissions: (missions) => set({ userMissions: missions }),

      // KTA
      ktaInfo: null,
      setKtaInfo: (info) => set({ ktaInfo: info }),

      // Admin
      adminClicks: 0,
      lastAdminClick: null,
      incrementAdminClick: () =>
        set((state) => ({
          adminClicks: state.adminClicks + 1,
          lastAdminClick: Date.now(),
        })),
      resetAdminClicks: () =>
        set({ adminClicks: 0, lastAdminClick: null }),

      // Site Config
      siteConfig: {
        siteName: 'FahriXz Store',
        siteDescription: 'Toko Digital & Mission Marketplace Terpercaya',
        contactEmail: 'support@fahrixzstore.com',
        contactPhone: '+62 812-3456-7890',
        maintenanceMode: false,
        commissionRate: 0.05,
        withdrawalFee: 5000,
        minWithdrawal: 50000,
      },
      setSiteConfig: (config) =>
        set((state) => ({
          siteConfig: { ...state.siteConfig, ...config },
        })),
    }),
    {
      name: 'fahrixz-store',
      partialize: (state) => ({
        theme: state.theme,
        language: state.language,
        cart: state.cart,
        notifications: state.notifications,
        chatMessages: state.chatMessages,
        siteConfig: state.siteConfig,
      }),
    }
  )
);

export default useStore;
