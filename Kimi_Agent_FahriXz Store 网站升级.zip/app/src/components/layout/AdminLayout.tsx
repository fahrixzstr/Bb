import { Outlet, Navigate, useLocation } from 'react-router-dom';
import { useEffect } from 'react';
import AdminSidebar from './AdminSidebar';
import AdminHeader from './AdminHeader';
import useStore from '@/stores/useStore';
import { Toaster } from '@/components/ui/sonner';

export default function AdminLayout() {
  const { isLoggedIn, user } = useStore();
  const location = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location.pathname]);

  // For demo purposes, allow access or redirect
  // In production, check isAdmin properly
  if (!isLoggedIn && !user) {
    return <Navigate to="/login" replace />;
  }

  return (
    <div className="min-h-screen bg-background text-foreground flex">
      <AdminSidebar />
      <div className="flex-1 flex flex-col lg:ml-64">
        <AdminHeader />
        <main className="flex-1 p-4 md:p-6 overflow-auto">
          <Outlet />
        </main>
      </div>
      <Toaster position="top-right" richColors />
    </div>
  );
}
