import { Link, useLocation } from 'react-router-dom';
import { Home, ShoppingBag, Gift, Wallet, User } from 'lucide-react';
import useStore from '@/stores/useStore';
import { Badge } from '@/components/ui/badge';

export default function BottomNav() {
  const location = useLocation();
  const { cart, isLoggedIn } = useStore();
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const navItems = [
    { href: '/', icon: Home, label: 'Beranda' },
    { href: '/products', icon: ShoppingBag, label: 'Toko' },
    { href: '/missions', icon: Gift, label: 'Misi' },
    { href: '/wallet', icon: Wallet, label: 'Dompet' },
    { href: isLoggedIn ? '/dashboard' : '/login', icon: User, label: 'Akun' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-xl border-t border-border md:hidden">
      <div className="flex items-center justify-around h-16">
        {navItems.map((item) => {
          const isActive = item.href === '/' ? location.pathname === '/' : location.pathname.startsWith(item.href);
          return (
            <Link
              key={item.href}
              to={item.href}
              className={`flex flex-col items-center gap-1 py-2 px-3 rounded-lg transition-colors relative ${
                isActive ? 'text-primary' : 'text-muted-foreground'
              }`}
            >
              <div className="relative">
                <item.icon className="w-5 h-5" />
                {item.href === '/products' && cartCount > 0 && (
                  <Badge
                    variant="destructive"
                    className="absolute -top-2 -right-3 h-4 min-w-4 flex items-center justify-center p-0 text-[10px]"
                  >
                    {cartCount}
                  </Badge>
                )}
              </div>
              <span className="text-[10px] font-medium">{item.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
