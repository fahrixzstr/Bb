import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Headphones, MessageSquare, FileText, Mail } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';

export default function Support() {
  const [ticket, setTicket] = useState({ subject: '', category: '', message: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success('Tiket berhasil dibuat! Tim support akan segera merespons.');
    setTicket({ subject: '', category: '', message: '' });
  };

  const channels = [
    { icon: MessageSquare, title: 'Live Chat', desc: 'Respons instan 24/7', action: 'Mulai Chat' },
    { icon: Mail, title: 'Email', desc: 'support@fahrixzstore.com', action: 'Kirim Email' },
    { icon: FileText, title: 'FAQ', desc: 'Jawaban untuk pertanyaan umum', action: 'Lihat FAQ', href: '/faq' },
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <div className="text-center mb-8">
        <Headphones className="w-12 h-12 mx-auto text-primary mb-4" />
        <h1 className="text-3xl font-bold mb-2">Pusat Bantuan</h1>
        <p className="text-muted-foreground">Kami siap membantu Anda 24 jam sehari, 7 hari seminggu</p>
      </div>

      <div className="grid sm:grid-cols-3 gap-4 mb-8">
        {channels.map((ch) => (
          <Card key={ch.title} className="text-center">
            <CardContent className="p-6">
              <ch.icon className="w-8 h-8 mx-auto text-primary mb-3" />
              <p className="font-semibold">{ch.title}</p>
              <p className="text-sm text-muted-foreground mb-3">{ch.desc}</p>
              {ch.href ? (
                <Link to={ch.href}>
                  <Button variant="outline" size="sm">{ch.action}</Button>
                </Link>
              ) : (
                <Button variant="outline" size="sm">{ch.action}</Button>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardContent className="p-6">
          <h2 className="text-lg font-semibold mb-4">Buat Tiket Baru</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Subjek</Label>
                <Input
                  value={ticket.subject}
                  onChange={(e) => setTicket({ ...ticket, subject: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label>Kategori</Label>
                <Input
                  value={ticket.category}
                  onChange={(e) => setTicket({ ...ticket, category: e.target.value })}
                  placeholder="Pembelian, Misi, Akun, dll"
                  required
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Pesan</Label>
              <Textarea
                rows={5}
                value={ticket.message}
                onChange={(e) => setTicket({ ...ticket, message: e.target.value })}
                required
              />
            </div>
            <Button type="submit">Kirim Tiket</Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
