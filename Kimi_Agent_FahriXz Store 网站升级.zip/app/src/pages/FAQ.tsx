import { HelpCircle } from 'lucide-react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

const faqs = [
  {
    q: 'Bagaimana cara membeli produk?',
    a: 'Pilih produk yang Anda inginkan, tambahkan ke keranjang, lalu lakukan checkout dan pembayaran melalui metode yang tersedia.',
  },
  {
    q: 'Metode pembayaran apa saja yang tersedia?',
    a: 'Kami menerima QRIS, Virtual Account (BCA, BNI, BRI, Mandiri), E-Wallet (GoPay, ShopeePay, DANA, OVO), Kartu Kredit, dan pembayaran di Alfamart/Indomaret.',
  },
  {
    q: 'Berapa lama proses pengiriman produk?',
    a: 'Produk digital akan dikirim secara instant setelah pembayaran berhasil dikonfirmasi.',
  },
  {
    q: 'Bagaimana cara kerja sistem misi?',
    a: 'Claim misi yang tersedia, selesaikan tugas sesuai persyaratan, submit bukti, dan dapatkan reward setelah diverifikasi admin.',
  },
  {
    q: 'Berapa minimal withdraw?',
    a: 'Minimal withdraw adalah Rp 50.000 dengan biaya admin Rp 5.000.',
  },
  {
    q: 'Apakah ada garansi untuk produk?',
    a: 'Ya, kami memberikan garansi untuk semua produk. Jika ada masalah, silakan hubungi support kami.',
  },
  {
    q: 'Bagaimana cara daftar KTA?',
    a: 'Login ke akun Anda, buka halaman KTA, isi data dan upload KTP, tunggu verifikasi dari admin.',
  },
  {
    q: 'Apakah data saya aman?',
    a: 'Ya, kami menggunakan enkripsi SSL dan sistem keamanan enterprise-grade untuk melindungi data Anda.',
  },
];

export default function FAQ() {
  return (
    <div className="max-w-3xl mx-auto px-4 py-6">
      <div className="text-center mb-8">
        <HelpCircle className="w-12 h-12 mx-auto text-primary mb-4" />
        <h1 className="text-3xl font-bold mb-2">Pertanyaan Umum</h1>
        <p className="text-muted-foreground">Temukan jawaban untuk pertanyaan yang sering diajukan</p>
      </div>

      <Accordion type="single" collapsible className="space-y-3">
        {faqs.map((faq, i) => (
          <AccordionItem key={i} value={`item-${i}`} className="border rounded-xl px-4">
            <AccordionTrigger className="text-left hover:no-underline py-4">
              {faq.q}
            </AccordionTrigger>
            <AccordionContent className="text-muted-foreground pb-4">
              {faq.a}
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </div>
  );
}
