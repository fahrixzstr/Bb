import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Target, Zap, Shield, Heart } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

export default function About() {
  const values = [
    { icon: Target, title: 'Visi', desc: 'Menjadi platform digital marketplace terpercaya #1 di Indonesia' },
    { icon: Zap, title: 'Misi', desc: 'Memberikan akses mudah ke produk digital dengan harga terbaik' },
    { icon: Shield, title: 'Integritas', desc: 'Transaksi aman dan transparan untuk semua pengguna' },
    { icon: Heart, title: 'Kepuasan', desc: 'Kepuasan pelanggan adalah prioritas utama kami' },
  ];

  const stats = [
    { value: '10,000+', label: 'Pengguna Aktif' },
    { value: '50,000+', label: 'Transaksi' },
    { value: '99.9%', label: 'Uptime' },
    { value: '4.9/5', label: 'Rating' },
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <h1 className="text-3xl font-bold mb-4">Tentang FahriXz Store</h1>
      <p className="text-muted-foreground text-lg mb-8">
        FahriXz Store adalah platform e-commerce digital dan mission marketplace terpercaya di
        Indonesia. Kami menyediakan berbagai produk digital berkualitas dengan harga terbaik.
      </p>

      <div className="grid sm:grid-cols-2 gap-6 mb-12">
        {values.map((item, i) => (
          <motion.div
            key={item.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <Card className="h-full">
              <CardContent className="p-6">
                <item.icon className="w-8 h-8 text-primary mb-3" />
                <h3 className="font-semibold text-lg mb-2">{item.title}</h3>
                <p className="text-muted-foreground text-sm">{item.desc}</p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
        {stats.map((stat) => (
          <Card key={stat.label} className="text-center">
            <CardContent className="p-4">
              <p className="text-2xl font-bold text-primary">{stat.value}</p>
              <p className="text-sm text-muted-foreground">{stat.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="text-center">
        <p className="text-muted-foreground mb-4">
          Punya pertanyaan? Hubungi tim support kami.
        </p>
        <Link to="/support">
          <button className="px-6 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors">
            Hubungi Kami
          </button>
        </Link>
      </div>
    </div>
  );
}
