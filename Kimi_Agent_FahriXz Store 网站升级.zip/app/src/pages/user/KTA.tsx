import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowLeft,
  Shield,
  Upload,
  CheckCircle,
  AlertCircle,
  QrCode,
  User,
  Award,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import useStore from '@/stores/useStore';
import { toast } from 'sonner';

export default function KTA() {
  const navigate = useNavigate();
  const { user, ktaInfo, setKtaInfo } = useStore();
  const [formData, setFormData] = useState({
    fullName: user?.displayName || '',
    idCardNumber: '',
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = () => {
    if (!formData.fullName || !formData.idCardNumber) {
      toast.error('Lengkapi semua field');
      return;
    }
    setSubmitted(true);
    setKtaInfo({
      id: 'KTA-2024-' + Math.random().toString(36).substring(2, 6).toUpperCase(),
      userId: user?.id || '',
      ktaId: 'KTA-2024-' + Math.random().toString(36).substring(2, 6).toUpperCase(),
      fullName: formData.fullName,
      status: 'pending_verification',
      createdAt: new Date(),
    });
    toast.success('Pengajuan KTA berhasil! Menunggu verifikasi admin.');
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-6">
      <Button variant="ghost" className="mb-4" onClick={() => navigate(-1)}>
        <ArrowLeft className="w-4 h-4 mr-2" />
        Kembali
      </Button>

      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
          <Award className="w-5 h-5 text-primary" />
        </div>
        <div>
          <h1 className="text-2xl font-bold">Kartu Tanda Anggota</h1>
          <p className="text-muted-foreground">Verifikasi identitas Anda</p>
        </div>
      </div>

      {ktaInfo?.status === 'verified' ? (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <Card className="overflow-hidden">
            <div className="bg-gradient-to-br from-primary to-cyan-600 p-8 text-white">
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-2">
                  <Shield className="w-6 h-6" />
                  <span className="font-bold text-lg">FahriXz Store</span>
                </div>
                <Badge className="bg-white/20 text-white border-0">Anggota Terverifikasi</Badge>
              </div>
              <div className="flex items-center gap-6">
                <div className="w-20 h-20 rounded-full bg-white/20 flex items-center justify-center">
                  <User className="w-10 h-10" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{ktaInfo.fullName}</p>
                  <p className="text-white/80 font-mono">{ktaInfo.ktaId}</p>
                </div>
              </div>
            </div>
            <CardContent className="p-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Tanggal Daftar</p>
                  <p className="font-medium">{ktaInfo.createdAt?.toLocaleDateString('id-ID')}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Status</p>
                  <Badge variant="default" className="mt-1">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Terverifikasi
                  </Badge>
                </div>
              </div>
              <Separator className="my-4" />
              <div className="flex items-center justify-center">
                <QrCode className="w-32 h-32 text-muted-foreground" />
              </div>
              <p className="text-center text-sm text-muted-foreground mt-2">
                Scan QR code untuk verifikasi
              </p>
            </CardContent>
          </Card>
        </motion.div>
      ) : submitted || ktaInfo?.status === 'pending_verification' ? (
        <Card>
          <CardContent className="p-8 text-center">
            <div className="w-16 h-16 rounded-full bg-yellow-500/10 flex items-center justify-center mx-auto mb-4">
              <AlertCircle className="w-8 h-8 text-yellow-500" />
            </div>
            <h3 className="text-lg font-semibold mb-2">Menunggu Verifikasi</h3>
            <p className="text-muted-foreground">
              Pengajuan KTA Anda sedang direview oleh tim admin. Proses verifikasi membutuhkan
              waktu 1-3 hari kerja.
            </p>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="p-6 space-y-4">
            <div className="space-y-2">
              <Label>Nama Lengkap (sesuai KTP)</Label>
              <Input
                value={formData.fullName}
                onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                placeholder="Nama lengkap sesuai KTP"
              />
            </div>
            <div className="space-y-2">
              <Label>Nomor KTP/NIK</Label>
              <Input
                value={formData.idCardNumber}
                onChange={(e) => setFormData({ ...formData, idCardNumber: e.target.value })}
                placeholder="16 digit NIK"
                maxLength={16}
              />
            </div>
            <div className="space-y-2">
              <Label>Upload KTP</Label>
              <div className="border-2 border-dashed border-border rounded-xl p-8 text-center hover:border-primary/50 transition-colors cursor-pointer">
                <Upload className="w-8 h-8 mx-auto text-muted-foreground mb-2" />
                <p className="text-sm text-muted-foreground">Klik untuk upload KTP</p>
                <p className="text-xs text-muted-foreground mt-1">JPG, PNG up to 5MB</p>
              </div>
            </div>
            <Button className="w-full" onClick={handleSubmit}>
              Ajukan Verifikasi KTA
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
