import { useState } from 'react';
import { ArrowLeft, Package, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useNavigate } from 'react-router-dom';

const allOrders = [
  { id: 'ORD-001', product: 'Netflix Premium (1 Bulan)', price: 55000, status: 'completed', date: '2024-06-18', category: 'Streaming' },
  { id: 'ORD-002', product: 'ChatGPT Plus (1 Bulan)', price: 45000, status: 'processing', date: '2024-06-17', category: 'AI' },
  { id: 'ORD-003', product: 'Canva Pro (3 Bulan)', price: 95000, status: 'pending', date: '2024-06-16', category: 'Design' },
  { id: 'ORD-004', product: 'Spotify Premium (1 Bulan)', price: 25000, status: 'completed', date: '2024-06-15', category: 'Music' },
  { id: 'ORD-005', product: 'Steam Wallet Rp 100.000', price: 95000, status: 'completed', date: '2024-06-14', category: 'Gaming' },
  { id: 'ORD-006', product: 'VPS Basic (1 Bulan)', price: 75000, status: 'cancelled', date: '2024-06-13', category: 'Hosting' },
];

export default function Orders() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('all');

  const filteredOrders = allOrders.filter((order) => {
    const matchesSearch = order.product.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesTab = activeTab === 'all' || order.status === activeTab;
    return matchesSearch && matchesTab;
  });

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <Button variant="ghost" className="mb-4" onClick={() => navigate(-1)}>
        <ArrowLeft className="w-4 h-4 mr-2" />
        Kembali
      </Button>

      <h1 className="text-2xl font-bold mb-6">Pesanan Saya</h1>

      {/* Search */}
      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Cari pesanan..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="w-full justify-start mb-6">
          <TabsTrigger value="all">Semua</TabsTrigger>
          <TabsTrigger value="pending">Pending</TabsTrigger>
          <TabsTrigger value="processing">Diproses</TabsTrigger>
          <TabsTrigger value="completed">Selesai</TabsTrigger>
          <TabsTrigger value="cancelled">Dibatalkan</TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab}>
          {filteredOrders.length === 0 ? (
            <div className="text-center py-12">
              <Package className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-muted-foreground">Tidak ada pesanan</p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredOrders.map((order) => (
                <Card key={order.id}>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                        <Package className="w-5 h-5 text-primary" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium">{order.product}</p>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <span>{order.id}</span>
                          <span>•</span>
                          <span>{order.date}</span>
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <p className="font-semibold">Rp {order.price.toLocaleString('id-ID')}</p>
                        <Badge
                          variant={
                            order.status === 'completed'
                              ? 'default'
                              : order.status === 'processing'
                              ? 'secondary'
                              : order.status === 'pending'
                              ? 'outline'
                              : 'destructive'
                          }
                          className="text-[10px]"
                        >
                          {order.status === 'completed'
                            ? 'Selesai'
                            : order.status === 'processing'
                            ? 'Diproses'
                            : order.status === 'pending'
                            ? 'Pending'
                            : 'Dibatalkan'}
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
