import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  User,
  ShoppingBag,
  Gift,
  ChevronRight,
  Shield,
  Package,
  CreditCard,
  Settings,
  LogOut,
  Award,
  Heart,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import useStore from '@/stores/useStore';

const menuItems = [
  { icon: ShoppingBag, label: 'Pesanan Saya', href: '/orders', desc: 'Lihat riwayat pembelian' },
  { icon: Gift, label: 'Misi Saya', href: '/my-missions', desc: 'Track progress misi' },
  { icon: CreditCard, label: 'Transaksi', href: '/wallet/history', desc: 'Riwayat keuangan' },
  { icon: Award, label: 'KTA Saya', href: '/kta', desc: 'Kartu Tanda Anggota' },
  { icon: Heart, label: 'Wishlist', href: '/wishlist', desc: 'Produk favorit' },
  { icon: Settings, label: 'Pengaturan', href: '/settings', desc: 'Edit profil & akun' },
];

const recentOrders = [
  { id: 'ORD-001', product: 'Netflix Premium', price: 55000, status: 'completed', date: '2024-06-18' },
  { id: 'ORD-002', product: 'ChatGPT Plus', price: 45000, status: 'processing', date: '2024-06-17' },
  { id: 'ORD-003', product: 'Canva Pro', price: 35000, status: 'pending', date: '2024-06-16' },
];

export default function Dashboard() {
  const { user, logout } = useStore();

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Profile Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center overflow-hidden">
                {user?.photoURL ? (
                  <img src={user.photoURL} alt="" className="w-full h-full object-cover" />
                ) : (
                  <User className="w-8 h-8 text-primary" />
                )}
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <h1 className="text-xl font-bold">{user?.displayName || 'Pengguna'}</h1>
                  {user?.ktaVerified && (
                    <Badge variant="secondary" className="text-xs">
                      <Shield className="w-3 h-3 mr-1" />
                      Terverifikasi
                    </Badge>
                  )}
                </div>
                <p className="text-sm text-muted-foreground">{user?.email}</p>
                <div className="flex items-center gap-4 mt-2">
                  <span className="text-xs text-muted-foreground">
                    Kode Referral: <span className="font-mono text-primary">{user?.referralCode}</span>
                  </span>
                </div>
              </div>
              <Link to="/settings">
                <Button variant="ghost" size="icon">
                  <Settings className="w-5 h-5" />
                </Button>
              </Link>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-3 gap-4 mt-6">
              <div className="text-center p-3 bg-muted/50 rounded-xl">
                <p className="text-lg font-bold text-primary">
                  Rp {(user?.saldo || 0).toLocaleString('id-ID')}
                </p>
                <p className="text-xs text-muted-foreground">Saldo</p>
              </div>
              <div className="text-center p-3 bg-muted/50 rounded-xl">
                <p className="text-lg font-bold">12</p>
                <p className="text-xs text-muted-foreground">Pesanan</p>
              </div>
              <div className="text-center p-3 bg-muted/50 rounded-xl">
                <p className="text-lg font-bold">5</p>
                <p className="text-xs text-muted-foreground">Misi</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Menu Grid */}
      <div className="grid sm:grid-cols-2 gap-3 mb-8">
        {menuItems.map((item, index) => (
          <motion.div
            key={item.href}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
          >
            <Link to={item.href}>
              <Card className="hover:border-primary/50 transition-colors group">
                <CardContent className="p-4 flex items-center gap-4">
                  <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                    <item.icon className="w-5 h-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">{item.label}</p>
                    <p className="text-xs text-muted-foreground">{item.desc}</p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-muted-foreground" />
                </CardContent>
              </Card>
            </Link>
          </motion.div>
        ))}
      </div>

      {/* Recent Orders */}
      <Card className="mb-8">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Pesanan Terakhir</h2>
            <Link to="/orders">
              <Button variant="ghost" size="sm">
                Lihat Semua
                <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </Link>
          </div>

          <div className="space-y-3">
            {recentOrders.map((order) => (
              <div
                key={order.id}
                className="flex items-center gap-4 p-3 rounded-xl hover:bg-muted/50 transition-colors"
              >
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                  <Package className="w-5 h-5 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm">{order.product}</p>
                  <p className="text-xs text-muted-foreground">
                    {order.id} • {order.date}
                  </p>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-sm font-medium">Rp {order.price.toLocaleString('id-ID')}</p>
                  <Badge
                    variant={
                      order.status === 'completed'
                        ? 'default'
                        : order.status === 'processing'
                        ? 'secondary'
                        : 'outline'
                    }
                    className="text-[10px]"
                  >
                    {order.status === 'completed'
                      ? 'Selesai'
                      : order.status === 'processing'
                      ? 'Diproses'
                      : 'Pending'}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Logout */}
      <Button variant="outline" className="w-full text-destructive hover:text-destructive" onClick={logout}>
        <LogOut className="w-4 h-4 mr-2" />
        Keluar
      </Button>
    </div>
  );
}
