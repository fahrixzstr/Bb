import { useState } from 'react';
import { Search, Shield, Ban, Eye, MoreHorizontal, Mail } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { toast } from 'sonner';

const allUsers = [
  { id: 'USR-001', name: 'Ahmad Fauzi', email: 'ahmad@email.com', role: 'user', saldo: 150000, status: 'active', joinDate: '2024-01-15', kta: true },
  { id: 'USR-002', name: 'Budi Santoso', email: 'budi@email.com', role: 'user', saldo: 75000, status: 'active', joinDate: '2024-02-20', kta: false },
  { id: 'USR-003', name: 'Citra Dewi', email: 'citra@email.com', role: 'user', saldo: 320000, status: 'active', joinDate: '2024-03-10', kta: true },
  { id: 'USR-004', name: 'Dedi Kurniawan', email: 'dedi@email.com', role: 'user', saldo: 50000, status: 'banned', joinDate: '2024-01-05', kta: false },
  { id: 'USR-005', name: 'Eka Putri', email: 'eka@email.com', role: 'admin', saldo: 0, status: 'active', joinDate: '2023-12-01', kta: true },
  { id: 'USR-006', name: 'Fajar Pratama', email: 'fajar@email.com', role: 'user', saldo: 200000, status: 'active', joinDate: '2024-04-18', kta: true },
];

export default function AdminUsers() {
  const [searchQuery, setSearchQuery] = useState('');
  const [userList, setUserList] = useState(allUsers);

  const filteredUsers = userList.filter(
    (u) =>
      u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleToggleStatus = (id: string) => {
    setUserList(
      userList.map((u) =>
        u.id === id ? { ...u, status: u.status === 'active' ? 'banned' : 'active' } : u
      )
    );
    toast.success('Status pengguna diperbarui');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Kelola Pengguna</h1>
          <p className="text-muted-foreground">{filteredUsers.length} pengguna</p>
        </div>
      </div>

      <div className="flex gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Cari pengguna..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Pengguna</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead>Saldo</TableHead>
                  <TableHead>KTA</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Bergabung</TableHead>
                  <TableHead className="w-[50px]"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredUsers.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell>
                      <div>
                        <p className="font-medium">{user.name}</p>
                        <p className="text-xs text-muted-foreground">{user.email}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant={user.role === 'admin' ? 'default' : 'secondary'}
                        className="text-[10px] capitalize"
                      >
                        {user.role === 'admin' && <Shield className="w-3 h-3 mr-1" />}
                        {user.role}
                      </Badge>
                    </TableCell>
                    <TableCell>Rp {user.saldo.toLocaleString('id-ID')}</TableCell>
                    <TableCell>
                      <Badge
                        variant={user.kta ? 'default' : 'outline'}
                        className="text-[10px]"
                      >
                        {user.kta ? 'Terverifikasi' : 'Belum'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant={user.status === 'active' ? 'default' : 'destructive'}
                        className="text-[10px] capitalize"
                      >
                        {user.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {user.joinDate}
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>
                            <Eye className="w-4 h-4 mr-2" />
                            Detail
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Mail className="w-4 h-4 mr-2" />
                            Kirim Email
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            className={user.status === 'active' ? 'text-destructive' : ''}
                            onClick={() => handleToggleStatus(user.id)}
                          >
                            <Ban className="w-4 h-4 mr-2" />
                            {user.status === 'active' ? 'Ban User' : 'Unban User'}
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
