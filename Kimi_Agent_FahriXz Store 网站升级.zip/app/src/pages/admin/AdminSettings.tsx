import { useState } from 'react';
import { Save, Store, Bell, Shield, CreditCard } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import useStore from '@/stores/useStore';
import { toast } from 'sonner';

export default function AdminSettings() {
  const { siteConfig, setSiteConfig } = useStore();
  const [config, setConfig] = useState({ ...siteConfig });

  const handleSave = () => {
    setSiteConfig(config);
    toast.success('Pengaturan berhasil disimpan');
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Pengaturan</h1>
        <p className="text-muted-foreground">Konfigurasi website</p>
      </div>

      <Tabs defaultValue="general">
        <TabsList>
          <TabsTrigger value="general">Umum</TabsTrigger>
          <TabsTrigger value="payment">Pembayaran</TabsTrigger>
          <TabsTrigger value="notifications">Notifikasi</TabsTrigger>
          <TabsTrigger value="security">Keamanan</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Store className="w-5 h-5" />
                Informasi Toko
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Nama Toko</Label>
                  <Input
                    value={config.siteName}
                    onChange={(e) => setConfig({ ...config, siteName: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Deskripsi</Label>
                  <Input
                    value={config.siteDescription}
                    onChange={(e) => setConfig({ ...config, siteDescription: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Email Kontak</Label>
                  <Input
                    type="email"
                    value={config.contactEmail}
                    onChange={(e) => setConfig({ ...config, contactEmail: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Nomor Telepon</Label>
                  <Input
                    value={config.contactPhone}
                    onChange={(e) => setConfig({ ...config, contactPhone: e.target.value })}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Maintenance Mode</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Mode Pemeliharaan</p>
                  <p className="text-sm text-muted-foreground">
                    Aktifkan untuk menampilkan halaman maintenance
                  </p>
                </div>
                <Switch
                  checked={config.maintenanceMode}
                  onCheckedChange={(checked) =>
                    setConfig({ ...config, maintenanceMode: checked })
                  }
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="payment" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <CreditCard className="w-5 h-5" />
                Konfigurasi Pembayaran
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Komisi (%)</Label>
                  <Input
                    type="number"
                    value={config.commissionRate * 100}
                    onChange={(e) =>
                      setConfig({ ...config, commissionRate: Number(e.target.value) / 100 })
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label>Biaya Withdraw (Rp)</Label>
                  <Input
                    type="number"
                    value={config.withdrawalFee}
                    onChange={(e) =>
                      setConfig({ ...config, withdrawalFee: Number(e.target.value) })
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label>Minimal Withdraw (Rp)</Label>
                  <Input
                    type="number"
                    value={config.minWithdrawal}
                    onChange={(e) =>
                      setConfig({ ...config, minWithdrawal: Number(e.target.value) })
                    }
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Bell className="w-5 h-5" />
                Notifikasi
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {[
                { label: 'Notifikasi Pesanan Baru', desc: 'Kirim email saat ada pesanan baru' },
                { label: 'Notifikasi Withdraw', desc: 'Kirim email saat ada permintaan withdraw' },
                { label: 'Notifikasi Misi', desc: 'Kirim email saat ada submit misi baru' },
              ].map((item) => (
                <div key={item.label} className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">{item.label}</p>
                    <p className="text-sm text-muted-foreground">{item.desc}</p>
                  </div>
                  <Switch defaultChecked />
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Shield className="w-5 h-5" />
                Keamanan
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {[
                { label: 'Autentikasi 2FA', desc: 'Wajibkan 2FA untuk admin' },
                { label: 'Rate Limiting', desc: 'Batasi request API' },
                { label: 'Log Aktivitas', desc: 'Catat semua aktivitas admin' },
              ].map((item) => (
                <div key={item.label} className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">{item.label}</p>
                    <p className="text-sm text-muted-foreground">{item.desc}</p>
                  </div>
                  <Switch defaultChecked />
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Button onClick={handleSave}>
        <Save className="w-4 h-4 mr-2" />
        Simpan Pengaturan
      </Button>
    </div>
  );
}
