import { motion } from 'framer-motion';
import {
  Users,
  ShoppingCart,
  DollarSign,
  Gift,
  Package,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';

const stats = [
  { title: 'Total Pengguna', value: '1,234', change: '+12%', up: true, icon: Users },
  { title: 'Total Pesanan', value: '5,678', change: '+8%', up: true, icon: ShoppingCart },
  { title: 'Pendapatan', value: 'Rp 89M', change: '+23%', up: true, icon: DollarSign },
  { title: 'Misi Aktif', value: '156', change: '-3%', up: false, icon: Gift },
];

const revenueData = [
  { name: 'Jan', revenue: 4000000, orders: 240 },
  { name: 'Feb', revenue: 5500000, orders: 300 },
  { name: 'Mar', revenue: 4800000, orders: 280 },
  { name: 'Apr', revenue: 7200000, orders: 390 },
  { name: 'May', revenue: 8500000, orders: 450 },
  { name: 'Jun', revenue: 9200000, orders: 480 },
];

const categoryData = [
  { name: 'Streaming', value: 35, color: '#3b82f6' },
  { name: 'AI/Tools', value: 25, color: '#06b6d4' },
  { name: 'Gaming', value: 20, color: '#8b5cf6' },
  { name: 'Hosting', value: 12, color: '#10b981' },
  { name: 'Lainnya', value: 8, color: '#f59e0b' },
];

const recentOrders = [
  { id: 'ORD-7891', customer: 'Ahmad Fauzi', product: 'Netflix Premium', amount: 55000, status: 'completed' },
  { id: 'ORD-7892', customer: 'Budi Santoso', product: 'ChatGPT Plus', amount: 45000, status: 'processing' },
  { id: 'ORD-7893', customer: 'Citra Dewi', product: 'Canva Pro 3Bln', amount: 95000, status: 'pending' },
  { id: 'ORD-7894', customer: 'Dedi Kurniawan', product: 'Spotify 6Bln', amount: 135000, status: 'completed' },
  { id: 'ORD-7895', customer: 'Eka Putri', product: 'VPS Basic', amount: 75000, status: 'processing' },
];

const topProducts = [
  { name: 'Netflix Premium', sales: 234, revenue: 12870000 },
  { name: 'ChatGPT Plus', sales: 189, revenue: 8505000 },
  { name: 'Canva Pro', sales: 156, revenue: 5460000 },
  { name: 'Spotify Premium', sales: 134, revenue: 3350000 },
  { name: 'Steam Wallet', sales: 112, revenue: 10640000 },
];

export default function AdminDashboard() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <p className="text-muted-foreground">Ringkasan performa toko</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, index) => (
          <motion.div
            key={stat.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                    <stat.icon className="w-5 h-5 text-primary" />
                  </div>
                  <Badge
                    variant={stat.up ? 'default' : 'destructive'}
                    className="text-xs"
                  >
                    {stat.up ? '+' : ''}{stat.change}
                  </Badge>
                </div>
                <p className="text-2xl font-bold mt-4">{stat.value}</p>
                <p className="text-sm text-muted-foreground">{stat.title}</p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Revenue Chart */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-lg">Pendapatan Bulanan</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={revenueData}>
                <defs>
                  <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="name" stroke="#9ca3af" fontSize={12} />
                <YAxis stroke="#9ca3af" fontSize={12} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#1f2937',
                    border: '1px solid #374151',
                    borderRadius: '8px',
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="revenue"
                  stroke="#3b82f6"
                  fillOpacity={1}
                  fill="url(#colorRevenue)"
                  name="Pendapatan"
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Category Pie Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Penjualan per Kategori</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={90}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="space-y-2 mt-4">
              {categoryData.map((cat) => (
                <div key={cat.name} className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <div
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: cat.color }}
                    />
                    <span>{cat.name}</span>
                  </div>
                  <span className="text-muted-foreground">{cat.value}%</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bottom Row */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Recent Orders */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Pesanan Terbaru</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentOrders.map((order) => (
                <div
                  key={order.id}
                  className="flex items-center gap-4 p-3 rounded-xl hover:bg-muted/50 transition-colors"
                >
                  <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                    <Package className="w-4 h-4 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium">{order.product}</p>
                    <p className="text-xs text-muted-foreground">
                      {order.id} • {order.customer}
                    </p>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="text-sm font-medium">
                      Rp {order.amount.toLocaleString('id-ID')}
                    </p>
                    <Badge
                      variant={
                        order.status === 'completed'
                          ? 'default'
                          : order.status === 'processing'
                          ? 'secondary'
                          : 'outline'
                      }
                      className="text-[10px]"
                    >
                      {order.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Top Products */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Produk Terlaris</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {topProducts.map((product, index) => (
                <div key={product.name}>
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-3">
                      <span className="text-sm text-muted-foreground w-4">
                        {index + 1}
                      </span>
                      <span className="text-sm font-medium">{product.name}</span>
                    </div>
                    <span className="text-sm text-muted-foreground">
                      {product.sales} terjual
                    </span>
                  </div>
                  <Progress value={(product.sales / 250) * 100} className="h-2" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
