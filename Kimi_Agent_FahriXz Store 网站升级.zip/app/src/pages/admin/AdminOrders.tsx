import { useState } from 'react';
import {
  Search,
  Eye,
  CheckCircle,
  XCircle,
  Clock,
  Truck,
  MoreHorizontal,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { toast } from 'sonner';

const allOrders = [
  { id: 'ORD-7891', customer: 'Ahmad Fauzi', email: 'ahmad@email.com', product: 'Netflix Premium', amount: 55000, status: 'completed', date: '2024-06-18 14:30' },
  { id: 'ORD-7892', customer: 'Budi Santoso', email: 'budi@email.com', product: 'ChatGPT Plus', amount: 45000, status: 'processing', date: '2024-06-18 13:15' },
  { id: 'ORD-7893', customer: 'Citra Dewi', email: 'citra@email.com', product: 'Canva Pro 3Bln', amount: 95000, status: 'pending', date: '2024-06-18 12:00' },
  { id: 'ORD-7894', customer: 'Dedi Kurniawan', email: 'dedi@email.com', product: 'Spotify 6Bln', amount: 135000, status: 'completed', date: '2024-06-17 16:45' },
  { id: 'ORD-7895', customer: 'Eka Putri', email: 'eka@email.com', product: 'VPS Basic', amount: 75000, status: 'processing', date: '2024-06-17 11:20' },
  { id: 'ORD-7896', customer: 'Fajar Pratama', email: 'fajar@email.com', product: 'Steam Wallet 100k', amount: 95000, status: 'cancelled', date: '2024-06-17 09:10' },
  { id: 'ORD-7897', customer: 'Gita Maharani', email: 'gita@email.com', product: 'YouTube Premium', amount: 35000, status: 'completed', date: '2024-06-16 20:00' },
  { id: 'ORD-7898', customer: 'Hadi Wijaya', email: 'hadi@email.com', product: 'Domain .COM', amount: 135000, status: 'pending', date: '2024-06-16 15:30' },
];

export default function AdminOrders() {
  const [searchQuery, setSearchQuery] = useState('');
  const [orders, setOrders] = useState(allOrders);

  const filteredOrders = orders.filter(
    (o) =>
      o.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.customer.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.product.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleUpdateStatus = (id: string, status: string) => {
    setOrders(orders.map((o) => (o.id === id ? { ...o, status } : o)));
    toast.success(`Status pesanan ${id} diperbarui`);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Kelola Pesanan</h1>
          <p className="text-muted-foreground">{filteredOrders.length} pesanan</p>
        </div>
      </div>

      <div className="flex gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Cari pesanan..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Pelanggan</TableHead>
                  <TableHead>Produk</TableHead>
                  <TableHead>Total</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Tanggal</TableHead>
                  <TableHead className="w-[50px]"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredOrders.map((order) => (
                  <TableRow key={order.id}>
                    <TableCell className="font-mono text-sm">{order.id}</TableCell>
                    <TableCell>
                      <div>
                        <p className="font-medium">{order.customer}</p>
                        <p className="text-xs text-muted-foreground">{order.email}</p>
                      </div>
                    </TableCell>
                    <TableCell>{order.product}</TableCell>
                    <TableCell>Rp {order.amount.toLocaleString('id-ID')}</TableCell>
                    <TableCell>
                      <Badge
                        variant={
                          order.status === 'completed'
                            ? 'default'
                            : order.status === 'processing'
                            ? 'secondary'
                            : order.status === 'pending'
                            ? 'outline'
                            : 'destructive'
                        }
                        className="text-[10px] capitalize"
                      >
                        {order.status === 'completed' && <CheckCircle className="w-3 h-3 mr-1" />}
                        {order.status === 'processing' && <Truck className="w-3 h-3 mr-1" />}
                        {order.status === 'pending' && <Clock className="w-3 h-3 mr-1" />}
                        {order.status === 'cancelled' && <XCircle className="w-3 h-3 mr-1" />}
                        {order.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">{order.date}</TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>
                            <Eye className="w-4 h-4 mr-2" />
                            Detail
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleUpdateStatus(order.id, 'processing')}>
                            <Truck className="w-4 h-4 mr-2" />
                            Proses
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleUpdateStatus(order.id, 'completed')}>
                            <CheckCircle className="w-4 h-4 mr-2" />
                            Selesai
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            className="text-destructive"
                            onClick={() => handleUpdateStatus(order.id, 'cancelled')}
                          >
                            <XCircle className="w-4 h-4 mr-2" />
                            Batalkan
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
