import { useState } from 'react';
import { Mail, Phone, MapPin, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';

export default function Contact() {
  const [formData, setFormData] = useState({ name: '', email: '', subject: '', message: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success('Pesan berhasil dikirim! Kami akan membalas segera.');
    setFormData({ name: '', email: '', subject: '', message: '' });
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <h1 className="text-3xl font-bold mb-4">Hubungi Kami</h1>
      <p className="text-muted-foreground mb-8">
        Punya pertanyaan atau butuh bantuan? Tim kami siap membantu Anda.
      </p>

      <div className="grid md:grid-cols-3 gap-6 mb-8">
        <Card className="text-center">
          <CardContent className="p-6">
            <Mail className="w-8 h-8 mx-auto text-primary mb-3" />
            <p className="font-medium">Email</p>
            <p className="text-sm text-muted-foreground">support@fahrixzstore.com</p>
          </CardContent>
        </Card>
        <Card className="text-center">
          <CardContent className="p-6">
            <Phone className="w-8 h-8 mx-auto text-primary mb-3" />
            <p className="font-medium">Telepon</p>
            <p className="text-sm text-muted-foreground">+62 812-3456-7890</p>
          </CardContent>
        </Card>
        <Card className="text-center">
          <CardContent className="p-6">
            <MapPin className="w-8 h-8 mx-auto text-primary mb-3" />
            <p className="font-medium">Alamat</p>
            <p className="text-sm text-muted-foreground">Jakarta, Indonesia</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardContent className="p-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Nama</Label>
                <Input
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label>Email</Label>
                <Input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  required
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Subjek</Label>
              <Input
                value={formData.subject}
                onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                required
              />
            </div>
            <div className="space-y-2">
              <Label>Pesan</Label>
              <Textarea
                rows={5}
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                required
              />
            </div>
            <Button type="submit">
              <Send className="w-4 h-4 mr-2" />
              Kirim Pesan
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
