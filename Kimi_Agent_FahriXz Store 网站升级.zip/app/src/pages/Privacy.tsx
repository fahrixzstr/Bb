import { Shield } from 'lucide-react';

export default function Privacy() {
  return (
    <div className="max-w-3xl mx-auto px-4 py-6">
      <div className="flex items-center gap-3 mb-6">
        <Shield className="w-8 h-8 text-primary" />
        <h1 className="text-3xl font-bold">Kebijakan Privasi</h1>
      </div>

      <div className="prose max-w-none space-y-6 text-muted-foreground">
        <section>
          <h2 className="text-xl font-semibold text-foreground mb-2">1. Informasi yang Kami Kumpulkan</h2>
          <p>
            Kami mengumpulkan informasi yang Anda berikan saat mendaftar, melakukan pembelian,
            atau mengisi formulir di website kami. Ini termasuk nama, email, nomor telepon,
            dan informasi pembayaran.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-foreground mb-2">2. Penggunaan Informasi</h2>
          <p>
            Informasi Anda digunakan untuk memproses pesanan, mengelola akun, mengirim notifikasi
            penting, dan meningkatkan layanan kami.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-foreground mb-2">3. Keamanan Data</h2>
          <p>
            Kami menggunakan enkripsi SSL dan protokol keamanan enterprise-grade untuk melindungi
            data Anda. Semua data disimpan di server dengan akses terbatas.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-foreground mb-2">4. Berbagi Informasi</h2>
          <p>
            Kami tidak menjual atau menyewakan informasi pribadi Anda kepada pihak ketiga.
            Informasi hanya dibagikan dengan penyedia layanan yang diperlukan untuk operasional.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-foreground mb-2">5. Cookie</h2>
          <p>
            Kami menggunakan cookie untuk meningkatkan pengalaman browsing Anda. Anda dapat
            menonaktifkan cookie melalui pengaturan browser Anda.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-foreground mb-2">6. Hak Anda</h2>
          <p>
            Anda berhak mengakses, mengubah, atau menghapus informasi pribadi Anda kapan saja.
            Hubungi kami untuk permintaan terkait data pribadi.
          </p>
        </section>
      </div>
    </div>
  );
}
