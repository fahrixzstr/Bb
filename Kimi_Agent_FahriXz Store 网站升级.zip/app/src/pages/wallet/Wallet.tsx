import { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Wallet,
  ArrowUpRight,
  ArrowDownLeft,
  History,
  CreditCard,
  Shield,
  ChevronRight,
  TrendingUp,
  TrendingDown,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import useStore from '@/stores/useStore';

const quickActions = [
  { icon: ArrowUpRight, label: 'Top Up', href: '/wallet/topup', color: 'text-green-500', bg: 'bg-green-500/10' },
  { icon: ArrowDownLeft, label: 'Withdraw', href: '/wallet/withdraw', color: 'text-blue-500', bg: 'bg-blue-500/10' },
  { icon: History, label: 'Riwayat', href: '/wallet/history', color: 'text-purple-500', bg: 'bg-purple-500/10' },
  { icon: CreditCard, label: 'Metode', href: '/wallet/methods', color: 'text-orange-500', bg: 'bg-orange-500/10' },
];

const recentTransactions = [
  { id: '1', type: 'topup', amount: 100000, status: 'success', date: '2024-06-18', description: 'Top Up via QRIS' },
  { id: '2', type: 'purchase', amount: -45000, status: 'success', date: '2024-06-17', description: 'Pembelian ChatGPT Plus' },
  { id: '3', type: 'reward', amount: 25000, status: 'success', date: '2024-06-16', description: 'Reward Misi #1234' },
  { id: '4', type: 'withdraw', amount: -50000, status: 'pending', date: '2024-06-15', description: 'Withdraw ke BCA' },
  { id: '5', type: 'referral', amount: 10000, status: 'success', date: '2024-06-14', description: 'Bonus Referral' },
];

export default function WalletPage() {
  const { user } = useStore();
  const [showBalance, setShowBalance] = useState(true);

  const saldo = user?.saldo || 0;
  const totalIn = recentTransactions.filter((t) => t.amount > 0).reduce((sum, t) => sum + t.amount, 0);
  const totalOut = recentTransactions.filter((t) => t.amount < 0).reduce((sum, t) => sum + Math.abs(t.amount), 0);

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Header */}
      <div className="flex items-center gap-3 mb-8">
        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
          <Wallet className="w-5 h-5 text-primary" />
        </div>
        <div>
          <h1 className="text-2xl md:text-3xl font-bold">Dompet</h1>
          <p className="text-muted-foreground">Kelola saldo dan transaksi Anda</p>
        </div>
      </div>

      {/* Balance Card */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <Card className="bg-gradient-to-br from-primary to-cyan-600 text-white border-0 overflow-hidden relative">
          <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10" />
          <CardContent className="p-6 md:p-8 relative">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-2">
                <Wallet className="w-5 h-5" />
                <span className="text-sm font-medium text-white/80">Total Saldo</span>
              </div>
              <Button
                variant="ghost"
                size="sm"
                className="text-white/80 hover:text-white hover:bg-white/10"
                onClick={() => setShowBalance(!showBalance)}
              >
                {showBalance ? 'Sembunyikan' : 'Tampilkan'}
              </Button>
            </div>

            <p className="text-3xl md:text-4xl font-bold mb-6">
              {showBalance ? `Rp ${saldo.toLocaleString('id-ID')}` : 'Rp ••••••'}
            </p>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white/10 rounded-xl p-3">
                <div className="flex items-center gap-2 text-white/80 text-sm mb-1">
                  <TrendingUp className="w-4 h-4" />
                  <span>Masuk</span>
                </div>
                <p className="font-semibold">Rp {totalIn.toLocaleString('id-ID')}</p>
              </div>
              <div className="bg-white/10 rounded-xl p-3">
                <div className="flex items-center gap-2 text-white/80 text-sm mb-1">
                  <TrendingDown className="w-4 h-4" />
                  <span>Keluar</span>
                </div>
                <p className="font-semibold">Rp {totalOut.toLocaleString('id-ID')}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Quick Actions */}
      <div className="grid grid-cols-4 gap-3 mb-8">
        {quickActions.map((action) => (
          <Link key={action.label} to={action.href}>
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex flex-col items-center gap-2 p-4 rounded-xl bg-card border border-border hover:border-primary/50 transition-colors text-center"
            >
              <div className={`w-10 h-10 rounded-xl ${action.bg} flex items-center justify-center`}>
                <action.icon className={`w-5 h-5 ${action.color}`} />
              </div>
              <span className="text-xs font-medium">{action.label}</span>
            </motion.div>
          </Link>
        ))}
      </div>

      {/* Transaction History */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold">Riwayat Transaksi</h2>
            <Link to="/wallet/history">
              <Button variant="ghost" size="sm">
                Lihat Semua
                <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </Link>
          </div>

          <div className="space-y-4">
            {recentTransactions.map((transaction) => (
              <div
                key={transaction.id}
                className="flex items-center gap-4 p-3 rounded-xl hover:bg-muted/50 transition-colors"
              >
                <div
                  className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                    transaction.amount > 0 ? 'bg-green-500/10' : 'bg-red-500/10'
                  }`}
                >
                  {transaction.amount > 0 ? (
                    <ArrowDownLeft className="w-5 h-5 text-green-500" />
                  ) : (
                    <ArrowUpRight className="w-5 h-5 text-red-500" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm">{transaction.description}</p>
                  <p className="text-xs text-muted-foreground">{transaction.date}</p>
                </div>
                <div className="text-right shrink-0">
                  <p
                    className={`font-semibold text-sm ${
                      transaction.amount > 0 ? 'text-green-500' : 'text-red-500'
                    }`}
                  >
                    {transaction.amount > 0 ? '+' : ''}Rp{' '}
                    {Math.abs(transaction.amount).toLocaleString('id-ID')}
                  </p>
                  <Badge
                    variant={
                      transaction.status === 'success' ? 'default' : 'secondary'
                    }
                    className="text-[10px]"
                  >
                    {transaction.status === 'success' ? 'Berhasil' : 'Pending'}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Security Note */}
      <div className="flex items-center gap-3 p-4 bg-muted/50 rounded-xl mt-6">
        <Shield className="w-5 h-5 text-green-500 shrink-0" />
        <p className="text-sm text-muted-foreground">
          Semua transaksi dilindungi oleh enkripsi SSL. Dana Anda aman bersama kami.
        </p>
      </div>
    </div>
  );
}
