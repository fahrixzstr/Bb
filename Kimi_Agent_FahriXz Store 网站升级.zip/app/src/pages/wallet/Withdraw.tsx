import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, ChevronRight, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import useStore from '@/stores/useStore';
import { toast } from 'sonner';

const banks = [
  { id: 'bca', name: 'BCA', fee: 6500 },
  { id: 'bni', name: 'BNI', fee: 6500 },
  { id: 'bri', name: 'BRI', fee: 6500 },
  { id: 'mandiri', name: 'Mandiri', fee: 6500 },
  { id: 'btn', name: 'BTN', fee: 5500 },
  { id: 'cimb', name: 'CIMB Niaga', fee: 6600 },
  { id: 'danamon', name: 'Danamon', fee: 7500 },
  { id: 'permata', name: 'Permata Bank', fee: 7000 },
];

const quickAmounts = [50000, 100000, 250000, 500000, 1000000];

export default function Withdraw() {
  const navigate = useNavigate();
  const { user } = useStore();
  const [amount, setAmount] = useState('');
  const [selectedBank, setSelectedBank] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [accountName, setAccountName] = useState('');
  const [loading, setLoading] = useState(false);

  const saldo = user?.saldo || 0;
  const bankFee = banks.find((b) => b.id === selectedBank)?.fee || 0;
  const totalAmount = parseInt(amount || '0') + bankFee;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseInt(amount.replace(/\D/g, ''));

    if (!numAmount || numAmount < 50000) {
      toast.error('Minimal withdraw Rp 50.000');
      return;
    }

    if (numAmount > saldo) {
      toast.error('Saldo tidak mencukupi');
      return;
    }

    if (!selectedBank) {
      toast.error('Pilih bank tujuan');
      return;
    }

    if (!accountNumber || !accountName) {
      toast.error('Lengkapi data rekening');
      return;
    }

    setLoading(true);
    setTimeout(() => {
      toast.success('Permintaan withdraw berhasil dibuat!');
      navigate('/wallet');
    }, 1500);
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-6">
      <Button variant="ghost" className="mb-4" onClick={() => navigate(-1)}>
        <ArrowLeft className="w-4 h-4 mr-2" />
        Kembali
      </Button>

      <h1 className="text-2xl font-bold mb-6">Withdraw</h1>

      {/* Balance Info */}
      <Card className="mb-6">
        <CardContent className="p-4 flex items-center justify-between">
          <div>
            <p className="text-sm text-muted-foreground">Saldo Tersedia</p>
            <p className="text-2xl font-bold">Rp {saldo.toLocaleString('id-ID')}</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-muted-foreground">Min. Withdraw</p>
            <p className="font-semibold">Rp 50.000</p>
          </div>
        </CardContent>
      </Card>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Amount */}
        <Card>
          <CardContent className="p-6 space-y-4">
            <Label className="text-base font-semibold">Nominal Withdraw</Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground font-medium">
                Rp
              </span>
              <Input
                type="text"
                placeholder="0"
                value={amount}
                onChange={(e) => setAmount(e.target.value.replace(/\D/g, ''))}
                className="pl-10 text-lg"
              />
            </div>
            <div className="grid grid-cols-5 gap-2">
              {quickAmounts.map((value) => (
                <button
                  key={value}
                  type="button"
                  onClick={() => setAmount(value.toString())}
                  className={`px-2 py-2 rounded-lg text-sm font-medium transition-colors ${
                    amount === value.toString()
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-muted text-muted-foreground hover:text-foreground'
                  }`}
                >
                  {value >= 1000 ? `${(value / 1000).toFixed(0)}k` : value}
                </button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Bank Selection */}
        <Card>
          <CardContent className="p-6 space-y-4">
            <Label className="text-base font-semibold">Bank Tujuan</Label>
            <Select value={selectedBank} onValueChange={setSelectedBank}>
              <SelectTrigger>
                <SelectValue placeholder="Pilih bank" />
              </SelectTrigger>
              <SelectContent>
                {banks.map((bank) => (
                  <SelectItem key={bank.id} value={bank.id}>
                    {bank.name} (Fee: Rp {bank.fee.toLocaleString('id-ID')})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <div className="space-y-2">
              <Label htmlFor="accountNumber">Nomor Rekening</Label>
              <Input
                id="accountNumber"
                placeholder="1234567890"
                value={accountNumber}
                onChange={(e) => setAccountNumber(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="accountName">Nama Pemilik Rekening</Label>
              <Input
                id="accountName"
                placeholder="Nama sesuai rekening"
                value={accountName}
                onChange={(e) => setAccountName(e.target.value)}
              />
            </div>
          </CardContent>
        </Card>

        {/* Summary */}
        <Card>
          <CardContent className="p-6 space-y-4">
            <h3 className="font-semibold">Ringkasan</h3>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Nominal</span>
              <span>Rp {parseInt(amount || '0').toLocaleString('id-ID')}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Biaya Admin</span>
              <span>Rp {bankFee.toLocaleString('id-ID')}</span>
            </div>
            <Separator />
            <div className="flex justify-between items-center">
              <span className="font-semibold">Total Diterima</span>
              <span className="text-xl font-bold text-primary">
                Rp {Math.max(0, totalAmount - bankFee * 2).toLocaleString('id-ID')}
              </span>
            </div>

            <div className="flex items-start gap-2 p-3 bg-yellow-500/10 rounded-lg">
              <AlertCircle className="w-4 h-4 text-yellow-500 shrink-0 mt-0.5" />
              <p className="text-xs text-muted-foreground">
                Proses withdraw membutuhkan waktu 1-3 hari kerja. Pastikan data rekening sudah
                benar.
              </p>
            </div>

            <Button type="submit" className="w-full" size="lg" disabled={loading || !amount}>
              {loading ? 'Memproses...' : 'Ajukan Withdraw'}
              <ChevronRight className="w-4 h-4 ml-2" />
            </Button>
          </CardContent>
        </Card>
      </form>
    </div>
  );
}
