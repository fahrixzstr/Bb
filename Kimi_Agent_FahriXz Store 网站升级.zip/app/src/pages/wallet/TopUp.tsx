import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, QrCode, Building2, Wallet, Store, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { toast } from 'sonner';

const quickAmounts = [50000, 100000, 250000, 500000, 1000000];

const paymentMethods = [
  { id: 'qris', name: 'QRIS', icon: QrCode, desc: 'Scan QRIS dari semua e-wallet & bank' },
  { id: 'va_bca', name: 'BCA Virtual Account', icon: Building2, desc: 'Transfer ke Virtual Account BCA' },
  { id: 'va_bni', name: 'BNI Virtual Account', icon: Building2, desc: 'Transfer ke Virtual Account BNI' },
  { id: 'va_bri', name: 'BRI Virtual Account', icon: Building2, desc: 'Transfer ke Virtual Account BRI' },
  { id: 'gopay', name: 'GoPay', icon: Wallet, desc: 'Pembayaran via GoPay' },
  { id: 'shopeepay', name: 'ShopeePay', icon: Wallet, desc: 'Pembayaran via ShopeePay' },
  { id: 'dana', name: 'DANA', icon: Wallet, desc: 'Pembayaran via DANA' },
  { id: 'ovo', name: 'OVO', icon: Wallet, desc: 'Pembayaran via OVO' },
  { id: 'alfamart', name: 'Alfamart', icon: Store, desc: 'Bayar di outlet Alfamart' },
  { id: 'indomaret', name: 'Indomaret', icon: Store, desc: 'Bayar di outlet Indomaret' },
];

export default function TopUp() {
  const navigate = useNavigate();
  // User from store
  const [amount, setAmount] = useState('');
  const [selectedMethod, setSelectedMethod] = useState('qris');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseInt(amount.replace(/\D/g, ''));
    if (!numAmount || numAmount < 10000) {
      toast.error('Minimal top up Rp 10.000');
      return;
    }

    setLoading(true);
    // Simulate payment
    setTimeout(() => {
      toast.success(`Top up Rp ${numAmount.toLocaleString('id-ID')} berhasil!`);
      navigate('/wallet');
    }, 1500);
  };

  const handleQuickAmount = (value: number) => {
    setAmount(value.toString());
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-6">
      <Button variant="ghost" className="mb-4" onClick={() => navigate(-1)}>
        <ArrowLeft className="w-4 h-4 mr-2" />
        Kembali
      </Button>

      <h1 className="text-2xl font-bold mb-6">Top Up Saldo</h1>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Amount */}
        <Card>
          <CardContent className="p-6 space-y-4">
            <Label className="text-base font-semibold">Nominal Top Up</Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground font-medium">
                Rp
              </span>
              <Input
                type="text"
                placeholder="0"
                value={amount}
                onChange={(e) => {
                  const value = e.target.value.replace(/\D/g, '');
                  setAmount(value);
                }}
                className="pl-10 text-lg"
              />
            </div>

            {/* Quick Amounts */}
            <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
              {quickAmounts.map((value) => (
                <button
                  key={value}
                  type="button"
                  onClick={() => handleQuickAmount(value)}
                  className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                    amount === value.toString()
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-muted text-muted-foreground hover:text-foreground'
                  }`}
                >
                  {value >= 1000000
                    ? '1jt'
                    : value >= 1000
                    ? `${(value / 1000).toFixed(0)}k`
                    : value}
                </button>
              ))}
            </div>

            <p className="text-xs text-muted-foreground">
              Minimal top up: Rp 10.000 | Maksimal: Rp 10.000.000
            </p>
          </CardContent>
        </Card>

        {/* Payment Method */}
        <Card>
          <CardContent className="p-6">
            <Label className="text-base font-semibold mb-4 block">Metode Pembayaran</Label>
            <RadioGroup value={selectedMethod} onValueChange={setSelectedMethod} className="space-y-3">
              {paymentMethods.map((method) => (
                <div
                  key={method.id}
                  className={`flex items-center gap-4 p-4 rounded-xl border transition-colors cursor-pointer ${
                    selectedMethod === method.id
                      ? 'border-primary bg-primary/5'
                      : 'border-border hover:border-primary/50'
                  }`}
                  onClick={() => setSelectedMethod(method.id)}
                >
                  <RadioGroupItem value={method.id} id={method.id} className="sr-only" />
                  <div
                    className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                      selectedMethod === method.id ? 'bg-primary/20' : 'bg-muted'
                    }`}
                  >
                    <method.icon
                      className={`w-5 h-5 ${
                        selectedMethod === method.id ? 'text-primary' : 'text-muted-foreground'
                      }`}
                    />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">{method.name}</p>
                    <p className="text-sm text-muted-foreground">{method.desc}</p>
                  </div>
                </div>
              ))}
            </RadioGroup>
          </CardContent>
        </Card>

        {/* Summary */}
        <Card>
          <CardContent className="p-6 space-y-4">
            <h3 className="font-semibold">Ringkasan</h3>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Nominal</span>
              <span>Rp {parseInt(amount || '0').toLocaleString('id-ID')}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Biaya Admin</span>
              <span>Rp 0</span>
            </div>
            <Separator />
            <div className="flex justify-between items-center">
              <span className="font-semibold">Total</span>
              <span className="text-xl font-bold text-primary">
                Rp {parseInt(amount || '0').toLocaleString('id-ID')}
              </span>
            </div>
            <Button type="submit" className="w-full" size="lg" disabled={loading || !amount}>
              {loading ? 'Memproses...' : 'Lanjutkan Pembayaran'}
              <ChevronRight className="w-4 h-4 ml-2" />
            </Button>
          </CardContent>
        </Card>
      </form>
    </div>
  );
}
