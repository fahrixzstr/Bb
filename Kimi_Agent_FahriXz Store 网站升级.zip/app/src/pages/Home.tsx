import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ShoppingBag,
  Gift,
  Wallet,
  Users,
  ArrowRight,
  Star,
  Zap,
  Shield,
  Clock,
  TrendingUp,
  ChevronRight,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { getFeaturedProducts } from '@/data/products';
import { missions } from '@/data/missions';
import useStore from '@/stores/useStore';

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.5 },
};

const staggerContainer = {
  animate: { transition: { staggerChildren: 0.1 } },
};

export default function Home() {
  const { isLoggedIn } = useStore();
  const featuredProducts = getFeaturedProducts();
  const featuredMissions = missions.slice(0, 3);

  const stats = [
    { icon: Users, label: 'Pengguna Aktif', value: '10,000+' },
    { icon: ShoppingBag, label: 'Produk Tersedia', value: '500+' },
    { icon: Gift, label: 'Misi Selesai', value: '50,000+' },
    { icon: Wallet, label: 'Total Reward', value: 'Rp 1M+' },
  ];

  const features = [
    {
      icon: Zap,
      title: 'Pengiriman Instant',
      desc: 'Produk digital dikirim otomatis setelah pembayaran',
    },
    {
      icon: Shield,
      title: 'Transaksi Aman',
      desc: 'Dilindungi enkripsi SSL dan sistem keamanan terbaik',
    },
    {
      icon: Clock,
      title: 'Support 24/7',
      desc: 'Tim support siap membantu kapan saja',
    },
    {
      icon: TrendingUp,
      title: 'Harga Terbaik',
      desc: 'Harga kompetitif dengan garansi uang kembali',
    },
  ];

  return (
    <div className="space-y-16 md:space-y-24">
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-8 md:pt-16 pb-12 md:pb-20">
        {/* Background effects */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute -top-40 -right-40 w-80 h-80 bg-primary/20 rounded-full blur-[100px]" />
          <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-cyan-500/10 rounded-full blur-[100px]" />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center lg:text-left"
            >
              <Badge variant="secondary" className="mb-4 text-sm">
                <Star className="w-3 h-3 mr-1 fill-current" />
                Marketplace Digital #1 Indonesia
              </Badge>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6">
                Beli Produk Digital &{' '}
                <span className="gradient-text">Dapatkan Reward</span>
              </h1>
              <p className="text-lg text-muted-foreground mb-8 max-w-xl mx-auto lg:mx-0">
                FahriXz Store adalah platform terpercaya untuk pembelian produk digital dan
                penyelesaian misi berbayar. Mulai dari Netflix, Spotify, hingga Canva Pro.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                <Link to="/products">
                  <Button size="lg" className="w-full sm:w-auto">
                    <ShoppingBag className="w-5 h-5 mr-2" />
                    Belanja Sekarang
                  </Button>
                </Link>
                <Link to="/missions">
                  <Button size="lg" variant="outline" className="w-full sm:w-auto">
                    <Gift className="w-5 h-5 mr-2" />
                    Kerjakan Misi
                  </Button>
                </Link>
              </div>

              {/* Trust badges */}
              <div className="flex flex-wrap items-center gap-6 mt-10 justify-center lg:justify-start">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Shield className="w-4 h-4 text-green-500" />
                  100% Aman
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Clock className="w-4 h-4 text-blue-500" />
                  Instant Delivery
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Star className="w-4 h-4 text-yellow-500" />
                  4.9 Rating
                </div>
              </div>
            </motion.div>

            {/* Right Visual */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="hidden lg:block"
            >
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-cyan-500/20 rounded-3xl blur-2xl" />
                <div className="relative grid grid-cols-2 gap-4">
                  {featuredProducts.slice(0, 4).map((product, i) => (
                    <motion.div
                      key={product.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.3 + i * 0.1 }}
                      className={`bg-card rounded-2xl border border-border p-4 shadow-lg ${
                        i === 0 ? 'col-span-2' : ''
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <img
                          src={product.images[0]}
                          alt={product.name}
                          className="w-12 h-12 rounded-xl object-cover"
                        />
                        <div>
                          <h3 className="font-semibold text-sm">{product.name}</h3>
                          <p className="text-primary font-bold">
                            Rp {product.price.toLocaleString('id-ID')}
                          </p>
                        </div>
                        {product.originalPrice && (
                          <Badge variant="destructive" className="ml-auto text-xs">
                            {Math.round((1 - product.price / product.originalPrice) * 100)}% OFF
                          </Badge>
                        )}
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          variants={staggerContainer}
          initial="initial"
          whileInView="animate"
          viewport={{ once: true }}
          className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6"
        >
          {stats.map((stat) => (
            <motion.div key={stat.label} variants={fadeInUp}>
              <Card className="text-center p-6">
                <stat.icon className="w-8 h-8 mx-auto mb-3 text-primary" />
                <p className="text-2xl md:text-3xl font-bold">{stat.value}</p>
                <p className="text-sm text-muted-foreground mt-1">{stat.label}</p>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </section>

      {/* Featured Products */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-2xl md:text-3xl font-bold">Produk Unggulan</h2>
            <p className="text-muted-foreground mt-1">Produk digital terpopuler minggu ini</p>
          </div>
          <Link to="/products">
            <Button variant="ghost" className="hidden sm:flex">
              Lihat Semua
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </div>

        <motion.div
          variants={staggerContainer}
          initial="initial"
          whileInView="animate"
          viewport={{ once: true }}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6"
        >
          {featuredProducts.map((product) => (
            <motion.div key={product.id} variants={fadeInUp}>
              <Link to={`/products/${product.id}`}>
                <Card className="group overflow-hidden hover:shadow-lg transition-all duration-300 h-full">
                  <div className="relative aspect-square overflow-hidden">
                    <img
                      src={product.images[0]}
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    {product.originalPrice && (
                      <Badge className="absolute top-3 left-3 bg-destructive">
                        {Math.round((1 - product.price / product.originalPrice) * 100)}% OFF
                      </Badge>
                    )}
                    {product.isFeatured && (
                      <Badge variant="secondary" className="absolute top-3 right-3">
                        <Star className="w-3 h-3 mr-1 fill-current" />
                        Unggulan
                      </Badge>
                    )}
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-semibold truncate">{product.name}</h3>
                    <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                      {product.description}
                    </p>
                    <div className="flex items-center gap-2 mt-3">
                      <span className="text-lg font-bold text-primary">
                        Rp {product.price.toLocaleString('id-ID')}
                      </span>
                      {product.originalPrice && (
                        <span className="text-sm text-muted-foreground line-through">
                          Rp {product.originalPrice.toLocaleString('id-ID')}
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-1 mt-2">
                      <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      <span className="text-sm font-medium">{product.rating}</span>
                      <span className="text-xs text-muted-foreground">
                        ({product.reviewCount} ulasan)
                      </span>
                      <span className="text-xs text-muted-foreground ml-auto">
                        {product.soldCount} terjual
                      </span>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            </motion.div>
          ))}
        </motion.div>

        <div className="text-center mt-6 sm:hidden">
          <Link to="/products">
            <Button variant="outline">
              Lihat Semua Produk
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </div>
      </section>

      {/* Features */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <h2 className="text-2xl md:text-3xl font-bold">Kenapa Memilih Kami?</h2>
          <p className="text-muted-foreground mt-2">Keunggulan yang kami tawarkan</p>
        </div>

        <motion.div
          variants={staggerContainer}
          initial="initial"
          whileInView="animate"
          viewport={{ once: true }}
          className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {features.map((feature) => (
            <motion.div key={feature.title} variants={fadeInUp}>
              <Card className="text-center p-6 h-full hover:shadow-md transition-shadow">
                <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <feature.icon className="w-7 h-7 text-primary" />
                </div>
                <h3 className="font-semibold mb-2">{feature.title}</h3>
                <p className="text-sm text-muted-foreground">{feature.desc}</p>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </section>

      {/* Missions Preview */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-2xl md:text-3xl font-bold">Misi Berbayar</h2>
            <p className="text-muted-foreground mt-1">Selesaikan misi dan dapatkan reward</p>
          </div>
          <Link to="/missions">
            <Button variant="ghost" className="hidden sm:flex">
              Lihat Semua
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </div>

        <motion.div
          variants={staggerContainer}
          initial="initial"
          whileInView="animate"
          viewport={{ once: true }}
          className="grid md:grid-cols-3 gap-6"
        >
          {featuredMissions.map((mission) => (
            <motion.div key={mission.id} variants={fadeInUp}>
              <Link to={`/missions/${mission.id}`}>
                <Card className="group overflow-hidden hover:shadow-lg transition-all duration-300 h-full">
                  <div className="relative h-40 overflow-hidden">
                    <img
                      src={mission.image}
                      alt={mission.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                    <div className="absolute bottom-3 left-3 right-3">
                      <Badge className="bg-primary text-white">
                        Rp {mission.rewardAmount.toLocaleString('id-ID')}
                      </Badge>
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-semibold">{mission.title}</h3>
                    <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                      {mission.description}
                    </p>
                    <div className="mt-3">
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className="text-muted-foreground">
                          {mission.currentParticipants}/{mission.maxParticipants} peserta
                        </span>
                        <span className="text-primary">
                          {Math.round(
                            (mission.currentParticipants / mission.maxParticipants) * 100
                          )}
                          %
                        </span>
                      </div>
                      <Progress
                        value={(mission.currentParticipants / mission.maxParticipants) * 100}
                        className="h-2"
                      />
                    </div>
                  </CardContent>
                </Card>
              </Link>
            </motion.div>
          ))}
        </motion.div>

        <div className="text-center mt-6 sm:hidden">
          <Link to="/missions">
            <Button variant="outline">
              Lihat Semua Misi
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </div>
      </section>

      {/* CTA Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-primary to-cyan-600 p-8 md:p-12 text-center"
        >
          <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10" />
          <div className="relative">
            <h2 className="text-2xl md:text-4xl font-bold text-white mb-4">
              Siap Memulai?
            </h2>
            <p className="text-primary-foreground/90 mb-8 max-w-2xl mx-auto">
              Bergabung dengan ribuan pengguna FahriXz Store dan mulai belanja produk digital atau
              kerjakan misi berbayar sekarang.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              {!isLoggedIn ? (
                <>
                  <Link to="/register">
                    <Button size="lg" variant="secondary" className="w-full sm:w-auto">
                      Daftar Gratis
                      <ChevronRight className="w-4 h-4 ml-2" />
                    </Button>
                  </Link>
                  <Link to="/login">
                    <Button
                      size="lg"
                      variant="outline"
                      className="w-full sm:w-auto border-white text-white hover:bg-white/10"
                    >
                      Sudah Punya Akun?
                    </Button>
                  </Link>
                </>
              ) : (
                <>
                  <Link to="/products">
                    <Button size="lg" variant="secondary" className="w-full sm:w-auto">
                      <ShoppingBag className="w-5 h-5 mr-2" />
                      Belanja
                    </Button>
                  </Link>
                  <Link to="/missions">
                    <Button
                      size="lg"
                      variant="outline"
                      className="w-full sm:w-auto border-white text-white hover:bg-white/10"
                    >
                      <Gift className="w-5 h-5 mr-2" />
                      Kerjakan Misi
                    </Button>
                  </Link>
                </>
              )}
            </div>
          </div>
        </motion.div>
      </section>
    </div>
  );
}
