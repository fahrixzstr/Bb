import { FileText } from 'lucide-react';

export default function Terms() {
  return (
    <div className="max-w-3xl mx-auto px-4 py-6">
      <div className="flex items-center gap-3 mb-6">
        <FileText className="w-8 h-8 text-primary" />
        <h1 className="text-3xl font-bold">Syarat & Ketentuan</h1>
      </div>

      <div className="prose max-w-none space-y-6 text-muted-foreground">
        <section>
          <h2 className="text-xl font-semibold text-foreground mb-2">1. Ketentuan Umum</h2>
          <p>
            Dengan mengakses dan menggunakan FahriXz Store, Anda menyetujui untuk terikat oleh syarat
            dan ketentuan ini. Jika Anda tidak setuju dengan bagian mana pun, Anda tidak diperkenankan
            menggunakan layanan kami.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-foreground mb-2">2. Akun Pengguna</h2>
          <p>
            Anda bertanggung jawab untuk menjaga kerahasiaan akun dan password Anda. FahriXz Store
            tidak bertanggung jawab atas kerugian yang timbul dari kelalaian Anda dalam menjaga
            keamanan akun.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-foreground mb-2">3. Pembelian Produk</h2>
          <p>
            Semua pembelian produk digital bersifat final. Setelah pembayaran dikonfirmasi, produk
            akan dikirim secara otomatis ke akun Anda.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-foreground mb-2">4. Sistem Misi</h2>
          <p>
            Pengguna harus mengikuti semua persyaratan misi dengan jujur. Penipuan atau manipulasi
            akan mengakibatkan pemblokiran akun permanen.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-foreground mb-2">5. Pembatasan Tanggung Jawab</h2>
          <p>
            FahriXz Store tidak bertanggung jawab atas kerugian tidak langsung yang timbul dari
            penggunaan layanan kami.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-foreground mb-2">6. Perubahan Ketentuan</h2>
          <p>
            Kami berhak mengubah syarat dan ketentuan ini kapan saja. Perubahan akan efektif
            segera setelah diposting di website.
          </p>
        </section>
      </div>
    </div>
  );
}
