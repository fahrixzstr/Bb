import { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Mail, ArrowRight, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import authService from '@/services/auth';
import { toast } from 'sonner';

export default function ForgotPassword() {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      toast.error('Email wajib diisi');
      return;
    }

    setLoading(true);
    try {
      await authService.resetPassword(email);
      setSent(true);
      toast.success('Email reset password telah dikirim!');
    } catch (error: any) {
      toast.error(error.message || 'Gagal mengirim email reset.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-12 bg-muted/30">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        {/* Logo */}
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2">
            <img
              src="/logo.png"
              alt="FahriXz Store"
              className="w-12 h-12 rounded-lg object-contain"
              onError={(e) => {
                (e.target as HTMLImageElement).style.display = 'none';
              }}
            />
            <span className="text-2xl font-bold gradient-text">FahriXz Store</span>
          </Link>
          <p className="mt-2 text-muted-foreground">Reset password Anda</p>
        </div>

        {/* Form Card */}
        <div className="bg-card rounded-2xl border border-border p-6 md:p-8 shadow-sm">
          {sent ? (
            <div className="text-center py-6">
              <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">Email Terkirim!</h3>
              <p className="text-sm text-muted-foreground mb-6">
                Kami telah mengirimkan link reset password ke{' '}
                <span className="font-medium text-foreground">{email}</span>. Silakan periksa inbox
                Anda.
              </p>
              <Link to="/login">
                <Button variant="outline" className="w-full">
                  Kembali ke Login
                </Button>
              </Link>
            </div>
          ) : (
            <>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="nama@email.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="pl-10"
                      required
                    />
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Masukkan email yang terdaftar pada akun Anda.
                  </p>
                </div>

                <Button type="submit" className="w-full" disabled={loading}>
                  {loading ? 'Mengirim...' : 'Kirim Link Reset'}
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </form>

              <p className="mt-6 text-center text-sm text-muted-foreground">
                Ingat password Anda?{' '}
                <Link to="/login" className="text-primary hover:underline font-medium">
                  Masuk
                </Link>
              </p>
            </>
          )}
        </div>
      </motion.div>
    </div>
  );
}
