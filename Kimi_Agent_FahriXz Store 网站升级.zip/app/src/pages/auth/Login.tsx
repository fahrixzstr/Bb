import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Eye, EyeOff, Mail, Lock, ArrowRight, Chrome } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Checkbox } from '@/components/ui/checkbox';
import authService from '@/services/auth';
import useStore from '@/stores/useStore';
import { toast } from 'sonner';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { setUser } = useStore();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      toast.error('Email dan password wajib diisi');
      return;
    }

    setLoading(true);
    try {
      const user = await authService.login(email, password);
      setUser(user);
      toast.success('Berhasil masuk!');
      navigate('/');
    } catch (error: any) {
      toast.error(error.message || 'Gagal masuk. Periksa kredensial Anda.');
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setLoading(true);
    try {
      const user = await authService.loginWithGoogle();
      setUser(user);
      toast.success('Berhasil masuk dengan Google!');
      navigate('/');
    } catch (error: any) {
      toast.error(error.message || 'Gagal masuk dengan Google.');
    } finally {
      setLoading(false);
    }
  };

  // Demo login shortcut
  const handleDemoLogin = async () => {
    setLoading(true);
    try {
      const user = await authService.login('demo@fahrixzstore.com', 'demo123');
      setUser(user);
      toast.success('Demo login berhasil!');
      navigate('/');
    } catch {
      // If demo user doesn't exist, create a mock user
      const mockUser = {
        id: 'demo-user',
        uid: 'demo-user',
        email: 'demo@fahrixzstore.com',
        displayName: 'Demo User',
        photoURL: '',
        role: 'user' as const,
        saldo: 500000,
        referralCode: 'FZ12345',
        ktaVerified: false,
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      setUser(mockUser);
      toast.success('Demo login berhasil!');
      navigate('/');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-12 bg-muted/30">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        {/* Logo */}
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2">
            <img
              src="/logo.png"
              alt="FahriXz Store"
              className="w-12 h-12 rounded-lg object-contain"
              onError={(e) => {
                (e.target as HTMLImageElement).style.display = 'none';
              }}
            />
            <span className="text-2xl font-bold gradient-text">FahriXz Store</span>
          </Link>
          <p className="mt-2 text-muted-foreground">Masuk ke akun Anda</p>
        </div>

        {/* Form Card */}
        <div className="bg-card rounded-2xl border border-border p-6 md:p-8 shadow-sm">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="email"
                  type="email"
                  placeholder="nama@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-10"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pl-10 pr-10"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Checkbox
                  id="remember"
                  checked={rememberMe}
                  onCheckedChange={(checked) => setRememberMe(checked as boolean)}
                />
                <Label htmlFor="remember" className="text-sm font-normal">
                  Ingat saya
                </Label>
              </div>
              <Link
                to="/forgot-password"
                className="text-sm text-primary hover:underline"
              >
                Lupa password?
              </Link>
            </div>

            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? 'Memuat...' : 'Masuk'}
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </form>

          <div className="relative my-6">
            <Separator />
            <span className="absolute left-1/2 -translate-x-1/2 -translate-y-1/2 bg-card px-3 text-xs text-muted-foreground">
              atau
            </span>
          </div>

          <Button
            variant="outline"
            className="w-full"
            onClick={handleGoogleLogin}
            disabled={loading}
          >
            <Chrome className="w-4 h-4 mr-2" />
            Masuk dengan Google
          </Button>

          {/* Demo Login */}
          <Button
            variant="ghost"
            className="w-full mt-2 text-muted-foreground"
            onClick={handleDemoLogin}
            disabled={loading}
          >
            Demo Login (Tanpa Akun)
          </Button>

          <p className="mt-6 text-center text-sm text-muted-foreground">
            Belum punya akun?{' '}
            <Link to="/register" className="text-primary hover:underline font-medium">
              Daftar sekarang
            </Link>
          </p>
        </div>

        {/* Back to home */}
        <p className="mt-6 text-center text-sm">
          <Link to="/" className="text-muted-foreground hover:text-foreground">
            Kembali ke beranda
          </Link>
        </p>
      </motion.div>
    </div>
  );
}
