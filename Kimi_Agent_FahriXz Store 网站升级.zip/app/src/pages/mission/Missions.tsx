import { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Gift,
  Search,
  Clock,
  Users,
  Coins,
  SlidersHorizontal,
  ArrowRight,
  Trophy,
  Target,
  Zap,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { missions, missionCategoryLabels } from '@/data/missions';

type SortOption = 'reward' | 'newest' | 'participants';

export default function Missions() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [sortBy, setSortBy] = useState<SortOption>('newest');

  const filteredMissions = (() => {
    let result = [...missions];

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(
        (m) =>
          m.title.toLowerCase().includes(q) ||
          m.description.toLowerCase().includes(q)
      );
    }

    if (selectedCategory) {
      result = result.filter((m) => m.category === selectedCategory);
    }

    switch (sortBy) {
      case 'reward':
        result.sort((a, b) => b.rewardAmount - a.rewardAmount);
        break;
      case 'participants':
        result.sort(
          (a, b) => b.currentParticipants - a.currentParticipants
        );
        break;
      default:
        result.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    }

    return result;
  })();

  const categories = Object.entries(missionCategoryLabels);

  const stats = [
    { icon: Target, label: 'Misi Aktif', value: missions.length },
    { icon: Trophy, label: 'Total Reward', value: `Rp ${missions.reduce((sum, m) => sum + m.rewardAmount, 0).toLocaleString('id-ID')}` },
    { icon: Users, label: 'Peserta', value: missions.reduce((sum, m) => sum + m.currentParticipants, 0).toLocaleString('id-ID') },
    { icon: Zap, label: 'Selesai Hari Ini', value: '24' },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
            <Gift className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl md:text-3xl font-bold">Mission Center</h1>
            <p className="text-muted-foreground">Selesaikan misi dan dapatkan reward</p>
          </div>
        </div>
      </div>

      {/* Stats */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8"
      >
        {stats.map((stat) => (
          <Card key={stat.label}>
            <CardContent className="p-4 flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                <stat.icon className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-lg font-bold">{stat.value}</p>
                <p className="text-xs text-muted-foreground">{stat.label}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </motion.div>

      {/* Search and Filter */}
      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Cari misi..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={sortBy} onValueChange={(v) => setSortBy(v as SortOption)}>
          <SelectTrigger className="w-[180px]">
            <SlidersHorizontal className="w-4 h-4 mr-2" />
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="newest">Terbaru</SelectItem>
            <SelectItem value="reward">Reward Tertinggi</SelectItem>
            <SelectItem value="participants">Paling Populer</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Category Pills */}
      <div className="flex flex-wrap gap-2 mb-8">
        <button
          onClick={() => setSelectedCategory('')}
          className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
            !selectedCategory
              ? 'bg-primary text-primary-foreground'
              : 'bg-muted text-muted-foreground hover:text-foreground'
          }`}
        >
          Semua
        </button>
        {categories.map(([key, label]) => (
          <button
            key={key}
            onClick={() => setSelectedCategory(selectedCategory === key ? '' : key)}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
              selectedCategory === key
                ? 'bg-primary text-primary-foreground'
                : 'bg-muted text-muted-foreground hover:text-foreground'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {/* Missions Grid */}
      {filteredMissions.length === 0 ? (
        <div className="text-center py-20">
          <Gift className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
          <h3 className="text-lg font-semibold mb-2">Tidak ada misi</h3>
          <p className="text-muted-foreground">
            Coba ubah filter atau kata kunci pencarian Anda.
          </p>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredMissions.map((mission, index) => (
            <motion.div
              key={mission.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <Link to={`/missions/${mission.id}`}>
                <Card className="group overflow-hidden hover:shadow-lg transition-all duration-300 h-full flex flex-col">
                  <div className="relative h-44 overflow-hidden">
                    <img
                      src={mission.image}
                      alt={mission.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                    <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between">
                      <Badge className="bg-primary text-white font-bold">
                        <Coins className="w-3 h-3 mr-1" />
                        Rp {mission.rewardAmount.toLocaleString('id-ID')}
                      </Badge>
                      <Badge variant="secondary" className="text-xs">
                        {missionCategoryLabels[mission.category]}
                      </Badge>
                    </div>
                  </div>
                  <CardContent className="p-4 flex-1 flex flex-col">
                    <h3 className="font-semibold text-lg mb-1">{mission.title}</h3>
                    <p className="text-sm text-muted-foreground line-clamp-2 mb-4">
                      {mission.description}
                    </p>

                    <div className="mt-auto space-y-3">
                      <div className="flex items-center justify-between text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Users className="w-3 h-3" />
                          {mission.currentParticipants}/{mission.maxParticipants}
                        </span>
                        {mission.endDate && (
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {Math.ceil(
                              (mission.endDate.getTime() - Date.now()) / (1000 * 60 * 60 * 24)
                            )}{' '}
                            hari
                          </span>
                        )}
                      </div>
                      <Progress
                        value={(mission.currentParticipants / mission.maxParticipants) * 100}
                        className="h-2"
                      />
                      <Button variant="outline" className="w-full group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                        Lihat Detail
                        <ArrowRight className="w-4 h-4 ml-2" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
