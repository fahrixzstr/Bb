import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowLeft,
  Gift,
  Clock,
  Users,
  Coins,
  CheckCircle,
  AlertCircle,
  Upload,
  Send,
  Target,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { getMissionById, missionCategoryLabels } from '@/data/missions';
import useStore from '@/stores/useStore';
import { toast } from 'sonner';

export default function MissionDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const mission = getMissionById(id || '');
  const { isLoggedIn, addNotification } = useStore();
  const [isClaimed, setIsClaimed] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [proofData, setProofData] = useState<Record<string, string>>({});

  if (!mission) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <Gift className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
        <h2 className="text-xl font-semibold mb-2">Misi tidak ditemukan</h2>
        <Button onClick={() => navigate('/missions')}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Kembali
        </Button>
      </div>
    );
  }

  const handleClaim = () => {
    if (!isLoggedIn) {
      toast.error('Silakan login terlebih dahulu');
      navigate('/login');
      return;
    }
    setIsClaimed(true);
    toast.success('Misi berhasil di-claim!');
    addNotification({
      id: Date.now().toString(),
      userId: 'user',
      title: 'Misi Di-claim',
      message: `Anda telah mengclaim misi "${mission.title}"`,
      type: 'mission',
      isRead: false,
      createdAt: new Date(),
    });
  };

  const handleSubmit = () => {
    const allFieldsFilled = mission.proofFields.every(
      (f) => !f.required || proofData[f.name]
    );
    if (!allFieldsFilled) {
      toast.error('Harap isi semua field yang wajib');
      return;
    }
    setIsSubmitted(true);
    toast.success('Bukti berhasil dikirim! Menunggu review admin.');
  };

  const progressPercent = (mission.currentParticipants / mission.maxParticipants) * 100;
  const daysLeft = mission.endDate
    ? Math.ceil((mission.endDate.getTime() - Date.now()) / (1000 * 60 * 60 * 24))
    : null;

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      {/* Back Button */}
      <Button variant="ghost" className="mb-4" onClick={() => navigate(-1)}>
        <ArrowLeft className="w-4 h-4 mr-2" />
        Kembali
      </Button>

      {/* Mission Header */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <div className="relative h-56 md:h-72 rounded-2xl overflow-hidden mb-6">
          <img
            src={mission.image}
            alt={mission.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent" />
          <div className="absolute bottom-4 left-4 right-4">
            <div className="flex flex-wrap gap-2 mb-3">
              <Badge className="bg-primary text-white text-sm px-3 py-1">
                <Coins className="w-3 h-3 mr-1" />
                Rp {mission.rewardAmount.toLocaleString('id-ID')}
              </Badge>
              <Badge variant="secondary">
                {missionCategoryLabels[mission.category]}
              </Badge>
              <Badge
                variant="outline"
                className={
                  mission.status === 'active'
                    ? 'border-green-500 text-green-500'
                    : 'border-gray-500'
                }
              >
                {mission.status === 'active' ? 'Aktif' : mission.status}
              </Badge>
            </div>
            <h1 className="text-2xl md:text-3xl font-bold text-white">{mission.title}</h1>
          </div>
        </div>
      </motion.div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Info Cards */}
          <div className="grid grid-cols-3 gap-3">
            <Card>
              <CardContent className="p-3 text-center">
                <Users className="w-5 h-5 mx-auto text-primary mb-1" />
                <p className="text-sm font-bold">
                  {mission.currentParticipants}/{mission.maxParticipants}
                </p>
                <p className="text-xs text-muted-foreground">Peserta</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-3 text-center">
                <Coins className="w-5 h-5 mx-auto text-primary mb-1" />
                <p className="text-sm font-bold">
                  Rp {mission.rewardAmount.toLocaleString('id-ID')}
                </p>
                <p className="text-xs text-muted-foreground">Reward</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-3 text-center">
                <Clock className="w-5 h-5 mx-auto text-primary mb-1" />
                <p className="text-sm font-bold">{daysLeft || '∞'}</p>
                <p className="text-xs text-muted-foreground">Hari Tersisa</p>
              </CardContent>
            </Card>
          </div>

          {/* Progress */}
          <div>
            <div className="flex items-center justify-between text-sm mb-2">
              <span className="text-muted-foreground">Progress</span>
              <span className="font-medium">{Math.round(progressPercent)}%</span>
            </div>
            <Progress value={progressPercent} className="h-3" />
          </div>

          {/* Tabs */}
          <Tabs defaultValue="description" className="w-full">
            <TabsList className="w-full justify-start">
              <TabsTrigger value="description">Deskripsi</TabsTrigger>
              <TabsTrigger value="requirements">Persyaratan</TabsTrigger>
              <TabsTrigger value="submit">Kirim Bukti</TabsTrigger>
            </TabsList>

            <TabsContent value="description" className="mt-4">
              <Card>
                <CardContent className="p-6">
                  <p className="text-muted-foreground leading-relaxed">
                    {mission.description}
                  </p>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="requirements" className="mt-4">
              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-4">Persyaratan Misi</h3>
                  <ul className="space-y-3">
                    {mission.requirements.map((req, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <CheckCircle className="w-5 h-5 text-green-500 shrink-0 mt-0.5" />
                        <span className="text-muted-foreground">{req}</span>
                      </li>
                    ))}
                  </ul>

                  <Separator className="my-6" />

                  <h3 className="font-semibold mb-4">Bukti yang Diperlukan</h3>
                  <ul className="space-y-3">
                    {mission.proofFields.map((field, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <AlertCircle className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                        <div>
                          <span className="font-medium">{field.label}</span>
                          {field.required && (
                            <Badge variant="destructive" className="ml-2 text-xs">
                              Wajib
                            </Badge>
                          )}
                          <p className="text-xs text-muted-foreground capitalize">
                            Tipe: {field.type}
                          </p>
                        </div>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="submit" className="mt-4">
              <Card>
                <CardContent className="p-6 space-y-4">
                  {!isClaimed ? (
                    <div className="text-center py-6">
                      <Target className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
                      <p className="text-muted-foreground mb-4">
                        Claim misi ini terlebih dahulu untuk mengirim bukti
                      </p>
                      <Button onClick={handleClaim}>
                        <Gift className="w-4 h-4 mr-2" />
                        Claim Misi
                      </Button>
                    </div>
                  ) : isSubmitted ? (
                    <div className="text-center py-6">
                      <CheckCircle className="w-12 h-12 mx-auto text-green-500 mb-3" />
                      <h3 className="font-semibold mb-2">Bukti Terkirim!</h3>
                      <p className="text-muted-foreground">
                        Bukti Anda sedang direview oleh tim kami. Reward akan dikirim setelah
                        disetujui.
                      </p>
                    </div>
                  ) : (
                    <>
                      <h3 className="font-semibold">Kirim Bukti</h3>
                      {mission.proofFields.map((field) => (
                        <div key={field.name} className="space-y-2">
                          <Label htmlFor={field.name}>
                            {field.label}
                            {field.required && <span className="text-destructive"> *</span>}
                          </Label>
                          {field.type === 'image' || field.type === 'screenshot' ? (
                            <div className="border-2 border-dashed border-border rounded-xl p-8 text-center hover:border-primary/50 transition-colors cursor-pointer">
                              <Upload className="w-8 h-8 mx-auto text-muted-foreground mb-2" />
                              <p className="text-sm text-muted-foreground">
                                Klik untuk upload {field.label}
                              </p>
                              <p className="text-xs text-muted-foreground mt-1">
                                PNG, JPG up to 5MB
                              </p>
                            </div>
                          ) : (
                            <Textarea
                              id={field.name}
                              placeholder={`Masukkan ${field.label.toLowerCase()}...`}
                              value={proofData[field.name] || ''}
                              onChange={(e) =>
                                setProofData({ ...proofData, [field.name]: e.target.value })
                              }
                            />
                          )}
                        </div>
                      ))}
                      <Button className="w-full" onClick={handleSubmit}>
                        <Send className="w-4 h-4 mr-2" />
                        Kirim Bukti
                      </Button>
                    </>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        {/* Sidebar */}
        <div className="space-y-4">
          <Card className="sticky top-24">
            <CardContent className="p-6 space-y-4">
              <div className="text-center">
                <p className="text-sm text-muted-foreground mb-1">Reward</p>
                <p className="text-3xl font-bold text-primary">
                  Rp {mission.rewardAmount.toLocaleString('id-ID')}
                </p>
              </div>

              <Separator />

              {!isClaimed ? (
                <Button className="w-full" size="lg" onClick={handleClaim}>
                  <Gift className="w-5 h-5 mr-2" />
                  Claim Misi
                </Button>
              ) : isSubmitted ? (
                <Button className="w-full" size="lg" disabled variant="outline">
                  <CheckCircle className="w-5 h-5 mr-2" />
                  Menunggu Review
                </Button>
              ) : (
                <Button className="w-full" size="lg" variant="outline" disabled>
                  <CheckCircle className="w-5 h-5 mr-2" />
                  Misi Di-claim
                </Button>
              )}

              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Clock className="w-4 h-4" />
                  <span>Dibuat: {mission.createdAt.toLocaleDateString('id-ID')}</span>
                </div>
                {mission.endDate && (
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Clock className="w-4 h-4" />
                    <span>Berakhir: {mission.endDate.toLocaleDateString('id-ID')}</span>
                  </div>
                )}
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Users className="w-4 h-4" />
                  <span>
                    {mission.maxParticipants - mission.currentParticipants} slot tersisa
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
