import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import {
  ArrowLeft,
  CreditCard,
  Wallet,
  Building2,
  QrCode,
  Store,
  Check,
  Shield,
  ChevronRight,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { faspayService } from '@/services/faspay';
import useStore from '@/stores/useStore';
import { toast } from 'sonner';

const paymentChannels = [
  { id: 'qris', name: 'QRIS', icon: QrCode, description: 'Scan QRIS dari semua e-wallet' },
  { id: 'va_bca', name: 'BCA Virtual Account', icon: Building2, description: 'Transfer ke VA BCA' },
  { id: 'va_bni', name: 'BNI Virtual Account', icon: Building2, description: 'Transfer ke VA BNI' },
  { id: 'va_bri', name: 'BRI Virtual Account', icon: Building2, description: 'Transfer ke VA BRI' },
  { id: 'gopay', name: 'GoPay', icon: Wallet, description: 'Bayar dengan GoPay' },
  { id: 'shopeepay', name: 'ShopeePay', icon: Wallet, description: 'Bayar dengan ShopeePay' },
  { id: 'dana', name: 'DANA', icon: Wallet, description: 'Bayar dengan DANA' },
  { id: 'ovo', name: 'OVO', icon: Wallet, description: 'Bayar dengan OVO' },
  { id: 'credit_card', name: 'Kartu Kredit', icon: CreditCard, description: 'Visa/Mastercard/JCB' },
  { id: 'alfamart', name: 'Alfamart', icon: Store, description: 'Bayar di Alfamart' },
  { id: 'indomaret', name: 'Indomaret', icon: Store, description: 'Bayar di Indomaret' },
];

export default function Checkout() {
  const navigate = useNavigate();
  const { cart, getCartTotal, user, clearCart } = useStore();
  const [selectedPayment, setSelectedPayment] = useState('qris');
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    fullName: user?.displayName || '',
    email: user?.email || '',
    phone: user?.phone || '',
  });

  if (cart.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <h2 className="text-xl font-semibold mb-2">Keranjang Kosong</h2>
        <p className="text-muted-foreground mb-6">
          Tambahkan produk ke keranjang terlebih dahulu.
        </p>
        <Link to="/products">
          <Button>Lanjutkan Belanja</Button>
        </Link>
      </div>
    );
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.fullName || !formData.email) {
      toast.error('Nama dan email wajib diisi');
      return;
    }

    setLoading(true);
    try {
      const transactionId = `TRX-${Date.now()}`;
      const result = await faspayService.createPayment({
        transactionId,
        amount: getCartTotal(),
        customerName: formData.fullName,
        customerEmail: formData.email,
        customerPhone: formData.phone,
        description: `Pembelian ${cart.length} produk di FahriXz Store`,
        returnUrl: `${window.location.origin}/payment/success`,
        callbackUrl: `${window.location.origin}/api/payment/callback`,
        paymentChannel: selectedPayment,
      });

      if (result.responseCode === '00') {
        toast.success('Pembayaran berhasil dibuat!');
        clearCart();
        navigate('/payment/success', { state: { transactionId, amount: getCartTotal() } });
      } else {
        toast.error(result.responseDesc || 'Gagal membuat pembayaran');
      }
    } catch (error) {
      // Mock success for demo
      toast.success('Pembayaran berhasil (Demo Mode)');
      clearCart();
      navigate('/payment/success', {
        state: { transactionId: `TRX-${Date.now()}`, amount: getCartTotal() },
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Header */}
      <div className="flex items-center gap-4 mb-8">
        <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div>
          <h1 className="text-2xl md:text-3xl font-bold">Checkout</h1>
          <p className="text-sm text-muted-foreground">Lengkapi data untuk melanjutkan pembayaran</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="grid lg:grid-cols-3 gap-8">
        {/* Left Column - Form */}
        <div className="lg:col-span-2 space-y-6">
          {/* Customer Info */}
          <Card>
            <CardContent className="p-6 space-y-4">
              <h2 className="text-lg font-semibold">Informasi Pembeli</h2>
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="fullName">Nama Lengkap *</Label>
                  <Input
                    id="fullName"
                    value={formData.fullName}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                    placeholder="Nama lengkap Anda"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="nama@email.com"
                    required
                  />
                </div>
                <div className="space-y-2 sm:col-span-2">
                  <Label htmlFor="phone">Nomor HP (opsional)</Label>
                  <Input
                    id="phone"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="+62 812-3456-7890"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Payment Method */}
          <Card>
            <CardContent className="p-6">
              <h2 className="text-lg font-semibold mb-4">Metode Pembayaran</h2>
              <RadioGroup
                value={selectedPayment}
                onValueChange={setSelectedPayment}
                className="space-y-3"
              >
                {paymentChannels.map((channel) => (
                  <div
                    key={channel.id}
                    className={`flex items-center gap-4 p-4 rounded-xl border transition-colors cursor-pointer ${
                      selectedPayment === channel.id
                        ? 'border-primary bg-primary/5'
                        : 'border-border hover:border-primary/50'
                    }`}
                    onClick={() => setSelectedPayment(channel.id)}
                  >
                    <RadioGroupItem value={channel.id} id={channel.id} className="sr-only" />
                    <div
                      className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                        selectedPayment === channel.id ? 'bg-primary/20' : 'bg-muted'
                      }`}
                    >
                      <channel.icon
                        className={`w-5 h-5 ${
                          selectedPayment === channel.id ? 'text-primary' : 'text-muted-foreground'
                        }`}
                      />
                    </div>
                    <div className="flex-1">
                      <p className="font-medium">{channel.name}</p>
                      <p className="text-sm text-muted-foreground">{channel.description}</p>
                    </div>
                    {selectedPayment === channel.id && (
                      <Check className="w-5 h-5 text-primary" />
                    )}
                  </div>
                ))}
              </RadioGroup>
            </CardContent>
          </Card>

          {/* Security Note */}
          <div className="flex items-center gap-3 p-4 bg-muted/50 rounded-xl">
            <Shield className="w-5 h-5 text-green-500 shrink-0" />
            <p className="text-sm text-muted-foreground">
              Pembayaran Anda dilindungi oleh enkripsi SSL 256-bit. Data pribadi Anda aman.
            </p>
          </div>
        </div>

        {/* Right Column - Summary */}
        <div>
          <Card className="sticky top-24">
            <CardContent className="p-6 space-y-4">
              <h2 className="text-lg font-semibold">Ringkasan Pesanan</h2>

              {/* Items */}
              <div className="space-y-3 max-h-60 overflow-y-auto">
                {cart.map((item) => (
                  <div key={`${item.productId}-${item.variantId}`} className="flex gap-3">
                    <div className="w-14 h-14 rounded-lg overflow-hidden bg-muted shrink-0">
                      <img
                        src={item.product.images[0]}
                        alt={item.product.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{item.product.name}</p>
                      {item.variant && (
                        <p className="text-xs text-muted-foreground">{item.variant.name}</p>
                      )}
                      <div className="flex items-center justify-between mt-1">
                        <span className="text-xs text-muted-foreground">x{item.quantity}</span>
                        <span className="text-sm font-medium">
                          Rp{' '}
                          {(
                            (item.variant?.price || item.product.price) * item.quantity
                          ).toLocaleString('id-ID')}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <Separator />

              {/* Totals */}
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span>Rp {getCartTotal().toLocaleString('id-ID')}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Biaya Admin</span>
                  <span>Rp 0</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Diskon</span>
                  <span className="text-green-500">- Rp 0</span>
                </div>
              </div>

              <Separator />

              <div className="flex justify-between items-center">
                <span className="font-semibold">Total</span>
                <span className="text-xl font-bold text-primary">
                  Rp {getCartTotal().toLocaleString('id-ID')}
                </span>
              </div>

              <Button type="submit" className="w-full" size="lg" disabled={loading}>
                {loading ? 'Memproses...' : 'Bayar Sekarang'}
                <ChevronRight className="w-4 h-4 ml-2" />
              </Button>

              <Badge variant="outline" className="w-full justify-center py-2">
                <Shield className="w-3 h-3 mr-1" />
                Pembayaran Aman & Terenkripsi
              </Badge>
            </CardContent>
          </Card>
        </div>
      </form>
    </div>
  );
}
