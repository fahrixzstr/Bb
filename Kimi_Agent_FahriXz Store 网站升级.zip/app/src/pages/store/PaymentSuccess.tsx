import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CheckCircle, ShoppingBag, FileText, Home } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';

export default function PaymentSuccess() {
  const location = useLocation();
  const { transactionId, amount } = location.state || {
    transactionId: `TRX-${Date.now()}`,
    amount: 0,
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-12">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="text-center"
      >
        {/* Success Icon */}
        <div className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-6">
          <CheckCircle className="w-12 h-12 text-green-500" />
        </div>

        <h1 className="text-2xl md:text-3xl font-bold mb-2">Pembayaran Berhasil!</h1>
        <p className="text-muted-foreground mb-8">
          Terima kasih telah berbelanja di FahriXz Store. Pesanan Anda sedang diproses.
        </p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <Card>
          <CardContent className="p-6">
            <h2 className="font-semibold mb-4">Detail Transaksi</h2>
            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">ID Transaksi</span>
                <span className="font-mono">{transactionId}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Tanggal</span>
                <span>{new Date().toLocaleDateString('id-ID')}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Status</span>
                <span className="text-green-500 font-medium">Berhasil</span>
              </div>
              <Separator />
              <div className="flex justify-between items-center">
                <span className="font-semibold">Total Pembayaran</span>
                <span className="text-xl font-bold text-primary">
                  Rp {amount.toLocaleString('id-ID')}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Actions */}
        <div className="grid sm:grid-cols-3 gap-3 mt-6">
          <Link to="/products" className="sm:col-span-1">
            <Button variant="outline" className="w-full">
              <ShoppingBag className="w-4 h-4 mr-2" />
              Belanja Lagi
            </Button>
          </Link>
          <Link to="/orders" className="sm:col-span-1">
            <Button variant="outline" className="w-full">
              <FileText className="w-4 h-4 mr-2" />
              Pesanan Saya
            </Button>
          </Link>
          <Link to="/" className="sm:col-span-1">
            <Button className="w-full">
              <Home className="w-4 h-4 mr-2" />
              Beranda
            </Button>
          </Link>
        </div>

        <p className="text-center text-sm text-muted-foreground mt-8">
          Konfirmasi pembayaran telah dikirim ke email Anda.
          <br />
          Jika ada pertanyaan, hubungi{' '}
          <Link to="/support" className="text-primary hover:underline">
            Support Center
          </Link>
          .
        </p>
      </motion.div>
    </div>
  );
}
