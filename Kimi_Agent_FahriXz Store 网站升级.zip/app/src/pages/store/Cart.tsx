import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ShoppingCart, Minus, Plus, Trash2, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import useStore from '@/stores/useStore';
import { toast } from 'sonner';

export default function Cart() {
  const { cart, removeFromCart, updateQuantity, getCartTotal, clearCart } = useStore();
  const navigate = useNavigate();

  const handleCheckout = () => {
    if (cart.length === 0) {
      toast.error('Keranjang belanja kosong');
      return;
    }
    navigate('/checkout');
  };

  if (cart.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <ShoppingCart className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
        <h2 className="text-xl font-semibold mb-2">Keranjang Kosong</h2>
        <p className="text-muted-foreground mb-6">
          Anda belum menambahkan produk ke keranjang.
        </p>
        <Link to="/products">
          <Button>
            <ArrowRight className="w-4 h-4 mr-2" />
            Mulai Belanja
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <h1 className="text-2xl md:text-3xl font-bold mb-6">Keranjang Belanja</h1>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Cart Items */}
        <div className="lg:col-span-2 space-y-4">
          {cart.map((item, index) => (
            <motion.div
              key={`${item.productId}-${item.variantId}`}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <Card>
                <CardContent className="p-4 flex gap-4">
                  {/* Image */}
                  <Link
                    to={`/products/${item.productId}`}
                    className="w-24 h-24 rounded-lg overflow-hidden bg-muted shrink-0"
                  >
                    <img
                      src={item.product.images[0]}
                      alt={item.product.name}
                      className="w-full h-full object-cover"
                    />
                  </Link>

                  {/* Details */}
                  <div className="flex-1 min-w-0">
                    <Link to={`/products/${item.productId}`}>
                      <h3 className="font-semibold truncate hover:text-primary transition-colors">
                        {item.product.name}
                      </h3>
                    </Link>
                    {item.variant && (
                      <p className="text-sm text-muted-foreground">
                        Varian: {item.variant.name}
                      </p>
                    )}
                    <p className="text-primary font-bold mt-1">
                      Rp{' '}
                      {(item.variant?.price || item.product.price).toLocaleString('id-ID')}
                    </p>

                    <div className="flex items-center justify-between mt-3">
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="icon"
                          className="w-8 h-8"
                          onClick={() =>
                            updateQuantity(
                              item.productId,
                              item.quantity - 1,
                              item.variantId
                            )
                          }
                          disabled={item.quantity <= 1}
                        >
                          <Minus className="w-3 h-3" />
                        </Button>
                        <span className="w-8 text-center font-medium">{item.quantity}</span>
                        <Button
                          variant="outline"
                          size="icon"
                          className="w-8 h-8"
                          onClick={() =>
                            updateQuantity(
                              item.productId,
                              item.quantity + 1,
                              item.variantId
                            )
                          }
                        >
                          <Plus className="w-3 h-3" />
                        </Button>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-destructive hover:text-destructive"
                        onClick={() => {
                          removeFromCart(item.productId, item.variantId);
                          toast.success('Produk dihapus dari keranjang');
                        }}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}

          <Button variant="ghost" className="text-destructive" onClick={clearCart}>
            <Trash2 className="w-4 h-4 mr-2" />
            Kosongkan Keranjang
          </Button>
        </div>

        {/* Summary */}
        <div>
          <Card className="sticky top-24">
            <CardContent className="p-6 space-y-4">
              <h2 className="text-lg font-semibold">Ringkasan Pesanan</h2>

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">
                    Subtotal ({cart.length} item)
                  </span>
                  <span>Rp {getCartTotal().toLocaleString('id-ID')}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Biaya Admin</span>
                  <span>Rp 0</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Diskon</span>
                  <span className="text-green-500">- Rp 0</span>
                </div>
              </div>

              <Separator />

              <div className="flex justify-between items-center">
                <span className="font-semibold">Total</span>
                <span className="text-xl font-bold text-primary">
                  Rp {getCartTotal().toLocaleString('id-ID')}
                </span>
              </div>

              <Button className="w-full" size="lg" onClick={handleCheckout}>
                Lanjutkan ke Pembayaran
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>

              <Link to="/products">
                <Button variant="outline" className="w-full mt-2">
                  Lanjutkan Belanja
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
