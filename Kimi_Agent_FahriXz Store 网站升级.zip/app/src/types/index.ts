// ============================================
// FahriXz Store - Type Definitions
// ============================================

export interface User {
  id: string;
  uid: string;
  email: string;
  displayName: string;
  photoURL: string;
  role: 'user' | 'admin';
  saldo: number;
  referralCode: string;
  ktaVerified: boolean;
  ktaId?: string;
  phone?: string;
  address?: string;
  createdAt: Date;
  updatedAt: Date;
  isBanned?: boolean;
  lastLogin?: Date;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  stock: number;
  category: ProductCategory;
  subcategory?: string;
  images: string[];
  rating: number;
  reviewCount: number;
  variants?: ProductVariant[];
  tags: string[];
  isActive: boolean;
  isFeatured: boolean;
  soldCount: number;
  createdAt: Date;
  updatedAt: Date;
}

export type ProductCategory =
  | 'canva'
  | 'chatgpt'
  | 'domain'
  | 'google-play'
  | 'netflix'
  | 'panel'
  | 'spotify'
  | 'steam'
  | 'vps'
  | 'whatsapp-bot'
  | 'youtube'
  | 'software'
  | 'game'
  | 'ebook'
  | 'other';

export interface ProductVariant {
  id: string;
  name: string;
  price: number;
  stock: number;
}

export interface CartItem {
  productId: string;
  variantId?: string;
  quantity: number;
  product: Product;
  variant?: ProductVariant;
}

export interface Order {
  id: string;
  userId: string;
  items: OrderItem[];
  totalPrice: number;
  status: OrderStatus;
  paymentStatus: PaymentStatus;
  paymentMethod?: string;
  shippingAddress?: Address;
  createdAt: Date;
  updatedAt: Date;
}

export type OrderStatus = 'pending' | 'processing' | 'completed' | 'cancelled' | 'refunded';
export type PaymentStatus = 'pending' | 'paid' | 'failed' | 'expired';

export interface OrderItem {
  productId: string;
  productName: string;
  price: number;
  quantity: number;
  variantName?: string;
}

export interface Mission {
  id: string;
  title: string;
  description: string;
  category: MissionCategory;
  rewardAmount: number;
  maxParticipants: number;
  currentParticipants: number;
  requirements: string[];
  proofFields: ProofField[];
  status: 'active' | 'inactive' | 'completed';
  startDate: Date;
  endDate?: Date;
  createdAt: Date;
  image?: string;
}

export type MissionCategory =
  | 'registrasi'
  | 'review'
  | 'download'
  | 'game'
  | 'survey'
  | 'pinjaman'
  | 'social_media'
  | 'voting'
  | 'google_maps'
  | 'video'
  | 'app_install'
  | 'content_creation'
  | 'referral';

export interface ProofField {
  name: string;
  type: 'text' | 'image' | 'link' | 'screenshot';
  required: boolean;
  label: string;
}

export interface UserMission {
  id: string;
  userId: string;
  missionId: string;
  mission: Mission;
  status: UserMissionStatus;
  proofData: Record<string, string>;
  submittedAt?: Date;
  reviewedAt?: Date;
  reviewNote?: string;
  rewardPaid: boolean;
  createdAt: Date;
}

export type UserMissionStatus = 'claimed' | 'submitted' | 'processing' | 'completed' | 'rejected' | 'expired';

export interface Transaction {
  id: string;
  userId: string;
  type: TransactionType;
  amount: number;
  fee: number;
  netAmount: number;
  status: TransactionStatus;
  description: string;
  referenceId?: string;
  metadata?: Record<string, any>;
  createdAt: Date;
}

export type TransactionType = 'topup' | 'withdraw' | 'reward' | 'purchase' | 'refund' | 'referral';
export type TransactionStatus = 'pending' | 'success' | 'failed' | 'cancelled';

export interface Referral {
  id: string;
  referrerId: string;
  refereeId: string;
  rewardAmount: number;
  status: 'pending' | 'completed';
  createdAt: Date;
  completedAt?: Date;
}

export interface Review {
  id: string;
  productId: string;
  userId: string;
  userName: string;
  userPhoto?: string;
  rating: number;
  comment: string;
  images?: string[];
  createdAt: Date;
}

export interface Address {
  fullName: string;
  phone: string;
  address: string;
  city: string;
  province: string;
  postalCode: string;
  notes?: string;
}

export interface KTAInfo {
  id: string;
  userId: string;
  ktaId: string;
  fullName: string;
  photoURL?: string;
  idCardNumber?: string;
  status: KTAStatus;
  verifiedAt?: Date;
  createdAt: Date;
}

export type KTAStatus = 'unverified' | 'pending_verification' | 'verified' | 'rejected';

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'order' | 'payment' | 'mission' | 'system' | 'referral';
  isRead: boolean;
  link?: string;
  createdAt: Date;
}

export interface SiteConfig {
  siteName: string;
  siteDescription: string;
  contactEmail: string;
  contactPhone: string;
  maintenanceMode: boolean;
  commissionRate: number;
  withdrawalFee: number;
  minWithdrawal: number;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export interface FaspayPaymentRequest {
  transactionId: string;
  amount: number;
  customerName: string;
  customerEmail: string;
  customerPhone?: string;
  description: string;
  returnUrl: string;
  callbackUrl: string;
  paymentChannel?: string;
}

export interface FaspayPaymentResponse {
  responseCode: string;
  responseDesc: string;
  merchantId: string;
  merchant: string;
  trxId: string;
  transactionId: string;
  amount: number;
  redirectUrl?: string;
}

export interface DashboardStats {
  totalUsers: number;
  totalOrders: number;
  totalRevenue: number;
  totalMissions: number;
  pendingWithdrawals: number;
  recentOrders: Order[];
  recentUsers: User[];
}

export interface AnalyticsData {
  labels: string[];
  revenue: number[];
  orders: number[];
  users: number[];
  missions: number[];
}
