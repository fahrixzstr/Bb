import { auth, googleProvider } from '@/lib/firebase';
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut,
  sendPasswordResetEmail,
  updateProfile,
  onAuthStateChanged,
  type User as FirebaseUser,
} from 'firebase/auth';
import useStore from '@/stores/useStore';
import type { User } from '@/types';

export const authService = {
  // Register with email/password
  register: async (email: string, password: string, displayName: string): Promise<User> => {
    if (!auth) throw new Error('Firebase not initialized');
    const { user: fbUser } = await createUserWithEmailAndPassword(auth, email, password);
    await updateProfile(fbUser, { displayName });
    return mapFirebaseUser(fbUser);
  },

  // Login with email/password
  login: async (email: string, password: string): Promise<User> => {
    if (!auth) throw new Error('Firebase not initialized');
    const { user: fbUser } = await signInWithEmailAndPassword(auth, email, password);
    return mapFirebaseUser(fbUser);
  },

  // Login with Google
  loginWithGoogle: async (): Promise<User> => {
    if (!auth) throw new Error('Firebase not initialized');
    const { user: fbUser } = await signInWithPopup(auth, googleProvider);
    return mapFirebaseUser(fbUser);
  },

  // Logout
  logout: async (): Promise<void> => {
    if (!auth) throw new Error('Firebase not initialized');
    await signOut(auth);
    useStore.getState().logout();
  },

  // Reset password
  resetPassword: async (email: string): Promise<void> => {
    if (!auth) throw new Error('Firebase not initialized');
    await sendPasswordResetEmail(auth, email);
  },

  // Update profile
  updateUserProfile: async (data: { displayName?: string; photoURL?: string }): Promise<void> => {
    if (!auth?.currentUser) throw new Error('Not authenticated');
    await updateProfile(auth.currentUser, data);
  },

  // Listen to auth state
  onAuthChange: (callback: (user: User | null) => void) => {
    if (!auth) return () => {};
    return onAuthStateChanged(auth, (fbUser) => {
      if (fbUser) {
        callback(mapFirebaseUser(fbUser));
      } else {
        callback(null);
      }
    });
  },

  // Get current user
  getCurrentUser: (): User | null => {
    if (!auth?.currentUser) return null;
    return mapFirebaseUser(auth.currentUser);
  },
};

// Helper to map Firebase user to app User
function mapFirebaseUser(fbUser: FirebaseUser): User {
  // Check if email matches admin pattern
  const isAdmin = fbUser.email?.endsWith('@admin.fahrixzstore.com') || false;

  return {
    id: fbUser.uid,
    uid: fbUser.uid,
    email: fbUser.email || '',
    displayName: fbUser.displayName || 'User',
    photoURL: fbUser.photoURL || '',
    role: isAdmin ? 'admin' : 'user',
    saldo: 0,
    referralCode: generateReferralCode(),
    ktaVerified: false,
    createdAt: new Date(fbUser.metadata.creationTime || Date.now()),
    updatedAt: new Date(),
  };
}

function generateReferralCode(): string {
  return 'FZ' + Math.random().toString(36).substring(2, 7).toUpperCase();
}

export default authService;
