import type { FaspayPaymentRequest, FaspayPaymentResponse } from '@/types';

const FASPAY_API_URL = import.meta.env.VITE_FASPAY_API_URL || 'https://web.faspay.co.id';
const MERCHANT_ID = import.meta.env.VITE_FASPAY_MERCHANT_ID || '';
const MERCHANT_NAME = import.meta.env.VITE_FASPAY_MERCHANT_NAME || 'FahriXz Store';
const USER_ID = import.meta.env.VITE_FASPAY_USER_ID || '';
const PASSWORD = import.meta.env.VITE_FASPAY_PASSWORD || '';

export const faspayService = {
  // Create payment
  createPayment: async (request: FaspayPaymentRequest): Promise<FaspayPaymentResponse> => {
    try {
      const response = await fetch(`${FASPAY_API_URL}/api/v1/payment`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          merchant_id: MERCHANT_ID,
          merchant: MERCHANT_NAME,
          user_id: USER_ID,
          password: PASSWORD,
          transaction_id: request.transactionId,
          amount: request.amount,
          customer_name: request.customerName,
          customer_email: request.customerEmail,
          customer_phone: request.customerPhone,
          description: request.description,
          return_url: request.returnUrl,
          callback_url: request.callbackUrl,
          payment_channel: request.paymentChannel || 'qris',
        }),
      });

      if (!response.ok) {
        throw new Error(`Payment creation failed: ${response.statusText}`);
      }

      const data = await response.json();
      return {
        responseCode: data.response_code,
        responseDesc: data.response_desc,
        merchantId: data.merchant_id,
        merchant: data.merchant,
        trxId: data.trx_id,
        transactionId: data.transaction_id,
        amount: data.amount,
        redirectUrl: data.redirect_url,
      };
    } catch (error) {
      console.error('Faspay payment error:', error);
      // Return mock response for development
      return {
        responseCode: '00',
        responseDesc: 'Success (Mock)',
        merchantId: MERCHANT_ID,
        merchant: MERCHANT_NAME,
        trxId: 'TRX-' + Date.now(),
        transactionId: request.transactionId,
        amount: request.amount,
        redirectUrl: '#',
      };
    }
  },

  // Check payment status
  checkStatus: async (transactionId: string): Promise<{ status: string; message: string }> => {
    try {
      const response = await fetch(`${FASPAY_API_URL}/api/v1/payment/status`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          merchant_id: MERCHANT_ID,
          user_id: USER_ID,
          password: PASSWORD,
          transaction_id: transactionId,
        }),
      });

      if (!response.ok) {
        throw new Error(`Status check failed: ${response.statusText}`);
      }

      const data = await response.json();
      return {
        status: data.payment_status,
        message: data.payment_status_desc,
      };
    } catch (error) {
      console.error('Faspay status check error:', error);
      return { status: 'pending', message: 'Status check unavailable (mock)' };
    }
  },

  // Get available payment channels
  getPaymentChannels: () => [
    { id: 'qris', name: 'QRIS', icon: 'QrCode', description: 'Bayar dengan QRIS' },
    { id: 'va_bca', name: 'BCA Virtual Account', icon: 'Building2', description: 'Transfer ke VA BCA' },
    { id: 'va_bni', name: 'BNI Virtual Account', icon: 'Building2', description: 'Transfer ke VA BNI' },
    { id: 'va_bri', name: 'BRI Virtual Account', icon: 'Building2', description: 'Transfer ke VA BRI' },
    { id: 'va_mandiri', name: 'Mandiri Virtual Account', icon: 'Building2', description: 'Transfer ke VA Mandiri' },
    { id: 'gopay', name: 'GoPay', icon: 'Wallet', description: 'Bayar dengan GoPay' },
    { id: 'shopeepay', name: 'ShopeePay', icon: 'Wallet', description: 'Bayar dengan ShopeePay' },
    { id: 'dana', name: 'DANA', icon: 'Wallet', description: 'Bayar dengan DANA' },
    { id: 'ovo', name: 'OVO', icon: 'Wallet', description: 'Bayar dengan OVO' },
    { id: 'credit_card', name: 'Kartu Kredit', icon: 'CreditCard', description: 'Visa/Mastercard/JCB' },
    { id: 'alfamart', name: 'Alfamart', icon: 'Store', description: 'Bayar di Alfamart' },
    { id: 'indomaret', name: 'Indomaret', icon: 'Store', description: 'Bayar di Indomaret' },
  ],
};

export default faspayService;
