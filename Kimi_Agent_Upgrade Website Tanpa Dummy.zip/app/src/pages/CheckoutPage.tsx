import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { ArrowLeft, ChevronRight, Wallet, Landmark, CreditCard, QrCode, CircleDot, Check } from 'lucide-react';
import { useStore } from '@/stores/useStore';
import { formatPrice } from '@/lib/utils';

const paymentMethods = [
  { key: 'saldo', label: 'Saldo FahriXz Store', icon: Wallet, promo: 'Isi Saldo Gratis' },
  { key: 'bank_transfer', label: 'Transfer Bank', icon: Landmark, promo: null },
  { key: 'credit_card', label: 'Kartu Kredit/Debit', icon: CreditCard, promo: 'Cashback 2%' },
  { key: 'qris', label: 'QRIS', icon: QrCode, promo: 'Cashback 1%' },
];

export default function CheckoutPage() {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const { cart, getCartTotal } = useStore();
  const [selectedPayment, setSelectedPayment] = useState('saldo');
  const [agreeTerms, setAgreeTerms] = useState(false);
  const [processing, setProcessing] = useState(false);

  const subtotal = getCartTotal();
  const serviceFee = 2500;
  const total = subtotal + serviceFee;

  const handleCheckout = async () => {
    if (!agreeTerms) return;
    setProcessing(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    setProcessing(false);
    navigate('/orders');
  };

  if (cart.length === 0) {
    return (
      <div className="min-h-screen bg-[#080C14] flex items-center justify-center text-white">
        <div className="text-center">
          <p className="text-gray-500 mb-4">Keranjang Anda kosong</p>
          <button onClick={() => navigate('/products')} className="px-6 py-2.5 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white rounded-xl">
            Mulai Belanja
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#080C14] text-white pt-16 pb-32">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-[#1C2A45]">
        <button onClick={() => navigate(-1)}><ArrowLeft className="w-5 h-5 text-gray-400" /></button>
        <h1 className="text-lg font-bold">{t('checkout')}</h1>
      </div>

      <div className="px-4 py-4 max-w-2xl mx-auto space-y-4">
        {/* Products */}
        <div className="bg-[#131B2D] border border-[#1C2A45] rounded-xl p-4">
          <h3 className="text-sm font-semibold text-white mb-3">Produk ({cart.length})</h3>
          {cart.map(item => (
            <div key={item.productId} className="flex gap-3 py-2 border-b border-[#1C2A45] last:border-0">
              <img src={item.image} alt={item.name} className="w-14 h-14 rounded-lg object-cover" />
              <div className="flex-1 min-w-0">
                <p className="text-sm text-white line-clamp-1">{item.name}</p>
                {item.variant && <p className="text-xs text-gray-500">{item.variant}</p>}
                <p className="text-xs text-gray-500">x{item.quantity}</p>
              </div>
              <p className="text-sm text-[#00F0FF] font-medium">{formatPrice(item.price * item.quantity)}</p>
            </div>
          ))}
        </div>

        {/* Payment Method */}
        <div className="bg-[#131B2D] border border-[#1C2A45] rounded-xl p-4">
          <h3 className="text-sm font-semibold text-white mb-3">{t('payment_method')}</h3>
          {paymentMethods.map(method => {
            const Icon = method.icon;
            return (
              <button
                key={method.key}
                onClick={() => setSelectedPayment(method.key)}
                className={`w-full flex items-center gap-3 p-3 rounded-xl mb-2 transition-colors ${
                  selectedPayment === method.key
                    ? 'bg-gradient-to-r from-[#7C3AED]/20 to-[#3B82F6]/20 border border-[#00F0FF]/30'
                    : 'bg-[#080C14] border border-[#1C2A45]'
                }`}
              >
                <div className="w-10 h-10 rounded-lg bg-[#131B2D] flex items-center justify-center">
                  <Icon className="w-5 h-5 text-[#00F0FF]" />
                </div>
                <div className="flex-1 text-left">
                  <p className="text-sm text-white">{method.label}</p>
                  {method.promo && <p className="text-xs text-green-400">{method.promo}</p>}
                </div>
                {selectedPayment === method.key ? (
                  <div className="w-5 h-5 rounded-full bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] flex items-center justify-center">
                    <Check className="w-3 h-3 text-white" />
                  </div>
                ) : (
                  <CircleDot className="w-5 h-5 text-gray-600" />
                )}
              </button>
            );
          })}
        </div>

        {/* Payment Summary */}
        <div className="bg-[#131B2D] border border-[#1C2A45] rounded-xl p-4">
          <h3 className="text-sm font-semibold text-white mb-3">{t('payment')}</h3>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">{t('subtotal')}</span>
              <span className="text-white">{formatPrice(subtotal)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">{t('fee')}</span>
              <span className="text-white">{formatPrice(serviceFee)}</span>
            </div>
            <div className="border-t border-[#1C2A45] pt-2 flex justify-between">
              <span className="text-white font-semibold">{t('total')}</span>
              <span className="text-[#00F0FF] font-bold text-lg">{formatPrice(total)}</span>
            </div>
          </div>
        </div>

        {/* Terms */}
        <div className="flex items-start gap-2">
          <button
            onClick={() => setAgreeTerms(!agreeTerms)}
            className={`w-5 h-5 rounded border-2 flex-shrink-0 flex items-center justify-center mt-0.5 transition-colors ${
              agreeTerms ? 'bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] border-transparent' : 'border-gray-500'
            }`}
          >
            {agreeTerms && <Check className="w-3 h-3 text-white" />}
          </button>
          <p className="text-xs text-gray-400">
            Saya menyetujui <span className="text-[#00F0FF] cursor-pointer">Syarat & Ketentuan</span> dan <span className="text-[#00F0FF] cursor-pointer">Kebijakan Privasi</span>
          </p>
        </div>
      </div>

      {/* Sticky Checkout Button */}
      <div className="fixed bottom-0 left-0 right-0 bg-[#080C14] border-t border-[#1C2A45] p-4 z-40">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-center justify-between mb-3">
            <div>
              <p className="text-xs text-gray-400">{t('total')}</p>
              <p className="text-xl font-bold text-[#00F0FF]">{formatPrice(total)}</p>
            </div>
          </div>
          <button
            onClick={handleCheckout}
            disabled={!agreeTerms || processing}
            className="w-full py-3.5 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white rounded-xl font-medium disabled:opacity-50 disabled:cursor-not-allowed hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
          >
            {processing ? (
              <>
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Memproses...
              </>
            ) : (
              `Bayar ${formatPrice(total)}`
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
