import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, QrCode, Wallet, CreditCard, Landmark, Check } from 'lucide-react';
import { formatPrice } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';

const methods = [
  { key: 'qris', label: 'QRIS', icon: QrCode, desc: 'Scan QR code untuk bayar' },
  { key: 'dana', label: 'DANA', icon: Wallet, desc: 'Pembayaran via DANA' },
  { key: 'gopay', label: 'GoPay', icon: Wallet, desc: 'Pembayaran via GoPay' },
  { key: 'bank_transfer', label: 'Transfer Bank', icon: Landmark, desc: 'BCA, BNI, Mandiri' },
  { key: 'credit_card', label: 'Kartu Kredit/Debit', icon: CreditCard, desc: 'Visa, Mastercard, JCB' },
];

const amounts = [10000, 20000, 50000, 100000, 200000, 500000];

export default function TopupPage() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [selectedAmount, setSelectedAmount] = useState(50000);
  const [selectedMethod, setSelectedMethod] = useState('qris');
  const [processing, setProcessing] = useState(false);

  const handleTopup = async () => {
    setProcessing(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    setProcessing(false);
    toast({ title: 'Top Up Berhasil', description: `Saldo Rp ${selectedAmount.toLocaleString('id-ID')} telah ditambahkan` });
    navigate('/wallet');
  };

  return (
    <div className="min-h-screen bg-[#080C14] text-white pt-16 pb-8">
      <div className="flex items-center gap-3 px-4 py-3 border-b border-[#1C2A45]">
        <button onClick={() => navigate(-1)}><ArrowLeft className="w-5 h-5 text-gray-400" /></button>
        <h1 className="text-lg font-bold">Isi Saldo</h1>
      </div>

      <div className="px-4 py-4 max-w-lg mx-auto space-y-6">
        {/* Amount Selection */}
        <div>
          <label className="text-sm text-gray-400 mb-3 block">Pilih Nominal</label>
          <div className="grid grid-cols-3 gap-2">
            {amounts.map(amt => (
              <button
                key={amt}
                onClick={() => setSelectedAmount(amt)}
                className={`py-3 rounded-xl text-sm font-medium transition-colors ${
                  selectedAmount === amt
                    ? 'bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white'
                    : 'bg-[#131B2D] border border-[#1C2A45] text-gray-400 hover:border-[#00F0FF]/40'
                }`}
              >
                {formatPrice(amt)}
              </button>
            ))}
          </div>
          <div className="mt-3">
            <label className="text-sm text-gray-400 mb-1 block">Nominal Lain</label>
            <input
              type="number"
              value={selectedAmount || ''}
              onChange={e => setSelectedAmount(Number(e.target.value))}
              className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl py-3 px-4 text-white text-sm focus:outline-none focus:border-[#00F0FF]"
            />
          </div>
        </div>

        {/* Payment Method */}
        <div>
          <label className="text-sm text-gray-400 mb-3 block">Metode Pembayaran</label>
          <div className="space-y-2">
            {methods.map(method => {
              const Icon = method.icon;
              return (
                <button
                  key={method.key}
                  onClick={() => setSelectedMethod(method.key)}
                  className={`w-full flex items-center gap-3 p-3 rounded-xl transition-colors ${
                    selectedMethod === method.key
                      ? 'bg-gradient-to-r from-[#7C3AED]/20 to-[#3B82F6]/20 border border-[#00F0FF]/30'
                      : 'bg-[#131B2D] border border-[#1C2A45]'
                  }`}
                >
                  <div className="w-10 h-10 rounded-xl bg-[#080C14] flex items-center justify-center">
                    <Icon className="w-5 h-5 text-[#00F0FF]" />
                  </div>
                  <div className="flex-1 text-left">
                    <p className="text-sm text-white">{method.label}</p>
                    <p className="text-xs text-gray-500">{method.desc}</p>
                  </div>
                  {selectedMethod === method.key && (
                    <div className="w-5 h-5 rounded-full bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] flex items-center justify-center">
                      <Check className="w-3 h-3 text-white" />
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Summary */}
        <div className="bg-[#131B2D] border border-[#1C2A45] rounded-xl p-4">
          <div className="flex justify-between">
            <span className="text-gray-400">Total Top Up</span>
            <span className="text-[#00F0FF] font-bold text-lg">{formatPrice(selectedAmount)}</span>
          </div>
        </div>

        <button
          onClick={handleTopup}
          disabled={processing || selectedAmount <= 0}
          className="w-full py-3.5 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white rounded-xl font-medium disabled:opacity-50 hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
        >
          {processing ? (
            <>
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              Memproses...
            </>
          ) : (
            `Bayar ${formatPrice(selectedAmount)}`
          )}
        </button>
      </div>
    </div>
  );
}
