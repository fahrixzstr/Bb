import { useState, useMemo } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Search, SlidersHorizontal, Crown, Server, Globe, Ticket, Wrench, Smartphone, MoreHorizontal, X } from 'lucide-react';
import ProductCard from '@/components/shared/ProductCard';
import type { Product } from '@/types';

const categories = [
  { key: 'all', label: 'Semua', icon: null },
  { key: 'subscription', label: 'Subscription', icon: Crown },
  { key: 'panel', label: 'Panel', icon: Server },
  { key: 'hosting', label: 'Hosting', icon: Globe },
  { key: 'voucher', label: 'Voucher', icon: Ticket },
  { key: 'jasa', label: 'Jasa', icon: Wrench },
  { key: 'digital', label: 'Digital', icon: Smartphone },
  { key: 'other', label: 'Lainnya', icon: MoreHorizontal },
];

const sortOptions = [
  { key: 'recommended', label: 'Rekomendasi' },
  { key: 'newest', label: 'Terbaru' },
  { key: 'lowest_price', label: 'Harga Terendah' },
  { key: 'highest_price', label: 'Harga Tertinggi' },
  { key: 'best_seller', label: 'Terlaris' },
];

const sampleProducts: Product[] = [
  { id: '1', name: 'Netflix Premium 4K - 1 Bulan', description: 'Akun Netflix sharing 1 profile', price: 45000, originalPrice: 65000, category: 'subscription', image: '/assets/media/products/netflix.jpg', rating: 4.8, reviewCount: 1250, soldCount: 8500, stock: 100, isBestSeller: true, discount: 30 },
  { id: '2', name: 'Spotify Premium Family - 1 Bulan', description: 'Spotify Premium Family Plan', price: 25000, originalPrice: 35000, category: 'subscription', image: '/assets/media/products/spotify.jpg', rating: 4.7, reviewCount: 890, soldCount: 6200, stock: 80, isBestSeller: true, discount: 28 },
  { id: '3', name: 'Panel Pterodactyl - Basic', description: 'Panel game hosting basic', price: 35000, category: 'panel', image: '/assets/media/products/panel.jpg', rating: 4.6, reviewCount: 450, soldCount: 3100, stock: 50 },
  { id: '4', name: 'Hosting VPS - 2GB RAM', description: 'VPS Cloud 2GB RAM SSD', price: 85000, originalPrice: 120000, category: 'hosting', image: '/assets/media/products/vps.jpg', rating: 4.9, reviewCount: 320, soldCount: 1800, stock: 30, discount: 29 },
  { id: '5', name: 'YouTube Premium - 1 Bulan', description: 'YouTube Premium individual', price: 20000, originalPrice: 30000, category: 'subscription', image: '/assets/media/products/youtube.jpg', rating: 4.7, reviewCount: 670, soldCount: 4500, stock: 90, discount: 33 },
  { id: '6', name: 'Canva Pro - 1 Bulan', description: 'Canva Pro akun sharing', price: 15000, originalPrice: 25000, category: 'subscription', image: '/assets/media/products/canva.jpg', rating: 4.5, reviewCount: 280, soldCount: 2100, stock: 60, discount: 40 },
  { id: '7', name: 'Voucher Google Play $10', description: 'Voucher Google Play US Region', price: 155000, category: 'voucher', image: '/assets/media/products/googleplay.jpg', rating: 4.8, reviewCount: 520, soldCount: 3400, stock: 40 },
  { id: '8', name: 'Bot WhatsApp - Basic', description: 'Bot WhatsApp auto reply + menu', price: 50000, originalPrice: 75000, category: 'digital', image: '/assets/media/products/wabot.jpg', rating: 4.6, reviewCount: 180, soldCount: 950, stock: 25, discount: 33 },
  { id: '9', name: 'Jasa Edit Video - Basic', description: 'Edit video up to 5 menit', price: 100000, category: 'jasa', image: '/assets/media/products/videoedit.jpg', rating: 4.8, reviewCount: 95, soldCount: 420, stock: 15 },
  { id: '10', name: 'Steam Wallet $20', description: 'Voucher Steam Wallet US', price: 310000, category: 'voucher', image: '/assets/media/products/steam.jpg', rating: 4.9, reviewCount: 780, soldCount: 5600, stock: 35 },
  { id: '11', name: 'Domain .COM - 1 Tahun', description: 'Domain .COM dengan DNS management', price: 135000, originalPrice: 175000, category: 'hosting', image: '/assets/media/products/domain.jpg', rating: 4.7, reviewCount: 210, soldCount: 1300, stock: 100, discount: 23 },
  { id: '12', name: 'ChatGPT Plus - 1 Bulan', description: 'ChatGPT Plus akun sharing', price: 75000, originalPrice: 100000, category: 'subscription', image: '/assets/media/products/chatgpt.jpg', rating: 4.8, reviewCount: 890, soldCount: 5200, stock: 45, discount: 25 },
];

export default function ProductsPage() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { t } = useTranslation();
  const urlCategory = searchParams.get('category');
  const urlFlashSale = searchParams.get('flashsale');

  const [activeCategory, setActiveCategory] = useState(urlCategory || 'all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('recommended');
  const [showSortSheet, setShowSortSheet] = useState(false);
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 500000]);
  const [showFilter, setShowFilter] = useState(false);

  const filteredProducts = useMemo(() => {
    let products = [...sampleProducts];

    if (urlFlashSale === 'true') {
      products = products.filter(p => p.discount && p.discount > 0);
    }

    if (activeCategory !== 'all') {
      products = products.filter(p => p.category === activeCategory);
    }

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      products = products.filter(p =>
        p.name.toLowerCase().includes(q) || p.description.toLowerCase().includes(q)
      );
    }

    products = products.filter(p => p.price >= priceRange[0] && p.price <= priceRange[1]);

    switch (sortBy) {
      case 'lowest_price': products.sort((a, b) => a.price - b.price); break;
      case 'highest_price': products.sort((a, b) => b.price - a.price); break;
      case 'best_seller': products.sort((a, b) => b.soldCount - a.soldCount); break;
      case 'newest': products.sort((a, b) => b.id.localeCompare(a.id)); break;
      default: break;
    }

    return products;
  }, [activeCategory, searchQuery, sortBy, priceRange, urlFlashSale]);

  return (
    <div className="min-h-screen bg-[#080C14] text-white pt-16 pb-24 md:pb-8">
      {/* Search Header */}
      <div className="sticky top-16 z-40 bg-[#080C14]/95 backdrop-blur-md border-b border-[#1C2A45] px-4 py-3">
        <div className="max-w-7xl mx-auto flex items-center gap-3">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <input
              type="text"
              placeholder={t('search_placeholder')}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl py-2.5 pl-10 pr-4 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]"
            />
          </div>
          <button
            onClick={() => setShowFilter(true)}
            className="p-2.5 rounded-xl bg-[#131B2D] border border-[#1C2A45] hover:border-[#00F0FF]/40 transition-colors"
          >
            <SlidersHorizontal className="w-5 h-5 text-gray-400" />
          </button>
        </div>

        {/* Category Tabs */}
        <div className="max-w-7xl mx-auto mt-3 flex gap-2 overflow-x-auto scrollbar-hide pb-1">
          {categories.map(cat => {
            const Icon = cat.icon;
            return (
              <button
                key={cat.key}
                onClick={() => setActiveCategory(cat.key)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-all ${
                  activeCategory === cat.key
                    ? 'bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white'
                    : 'bg-[#131B2D] text-gray-400 border border-[#1C2A45] hover:border-[#00F0FF]/40'
                }`}
              >
                {Icon && <Icon className="w-3.5 h-3.5" />}
                {cat.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Sort Bar */}
      <div className="px-4 py-2 max-w-7xl mx-auto flex items-center justify-between">
        <span className="text-xs text-gray-500">{filteredProducts.length} produk</span>
        <button onClick={() => setShowSortSheet(true)} className="text-xs text-gray-400 flex items-center gap-1 hover:text-white">
          {sortOptions.find(s => s.key === sortBy)?.label} <SlidersHorizontal className="w-3 h-3" />
        </button>
      </div>

      {/* Product Grid */}
      <div className="px-4 max-w-7xl mx-auto">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
          {filteredProducts.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
        {filteredProducts.length === 0 && (
          <div className="text-center py-16">
            <p className="text-gray-500">{t('no_results')}</p>
          </div>
        )}
      </div>

      {/* Sort Bottom Sheet */}
      {showSortSheet && (
        <div className="fixed inset-0 z-50 flex items-end" onClick={() => setShowSortSheet(false)}>
          <div className="absolute inset-0 bg-black/60" />
          <div className="relative w-full bg-[#131B2D] rounded-t-2xl p-4 animate-slide-up" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-white font-semibold">{t('sort')}</h3>
              <button onClick={() => setShowSortSheet(false)}><X className="w-5 h-5 text-gray-400" /></button>
            </div>
            {sortOptions.map(opt => (
              <button
                key={opt.key}
                onClick={() => { setSortBy(opt.key); setShowSortSheet(false); }}
                className={`w-full text-left px-4 py-3 rounded-xl mb-1 text-sm transition-colors ${
                  sortBy === opt.key ? 'bg-gradient-to-r from-[#7C3AED]/20 to-[#3B82F6]/20 text-white' : 'text-gray-400 hover:bg-white/5'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Filter Bottom Sheet */}
      {showFilter && (
        <div className="fixed inset-0 z-50 flex items-end" onClick={() => setShowFilter(false)}>
          <div className="absolute inset-0 bg-black/60" />
          <div className="relative w-full bg-[#131B2D] rounded-t-2xl p-4 animate-slide-up" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-white font-semibold">{t('filter')}</h3>
              <button onClick={() => setShowFilter(false)}><X className="w-5 h-5 text-gray-400" /></button>
            </div>
            <div className="mb-4">
              <label className="text-sm text-gray-400 mb-2 block">Harga</label>
              <div className="flex items-center gap-3">
                <input
                  type="number"
                  value={priceRange[0]}
                  onChange={e => setPriceRange([Number(e.target.value), priceRange[1]])}
                  className="flex-1 bg-[#080C14] border border-[#1C2A45] rounded-lg px-3 py-2 text-sm text-white"
                  placeholder="Min"
                />
                <span className="text-gray-500">-</span>
                <input
                  type="number"
                  value={priceRange[1]}
                  onChange={e => setPriceRange([priceRange[0], Number(e.target.value)])}
                  className="flex-1 bg-[#080C14] border border-[#1C2A45] rounded-lg px-3 py-2 text-sm text-white"
                  placeholder="Max"
                />
              </div>
            </div>
            <button
              onClick={() => setShowFilter(false)}
              className="w-full py-3 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white rounded-xl font-medium"
            >
              {t('apply')}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
