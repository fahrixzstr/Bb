import { useState, useMemo } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Search, Clock, TrendingUp } from 'lucide-react';
import ProductCard from '@/components/shared/ProductCard';

const sampleProducts = [
  { id: '1', name: 'Netflix Premium 4K - 1 Bulan', description: 'Akun Netflix sharing', price: 45000, originalPrice: 65000, category: 'subscription' as const, image: '/assets/media/products/netflix.jpg', rating: 4.8, reviewCount: 1250, soldCount: 8500, stock: 100, isBestSeller: true, discount: 30 },
  { id: '2', name: 'Spotify Premium Family - 1 Bulan', description: 'Spotify Premium Family', price: 25000, originalPrice: 35000, category: 'subscription' as const, image: '/assets/media/products/spotify.jpg', rating: 4.7, reviewCount: 890, soldCount: 6200, stock: 80, isBestSeller: true, discount: 28 },
  { id: '3', name: 'Panel Pterodactyl - Basic', description: 'Panel game hosting', price: 35000, category: 'panel' as const, image: '/assets/media/products/panel.jpg', rating: 4.6, reviewCount: 450, soldCount: 3100, stock: 50 },
  { id: '4', name: 'Bot WhatsApp - Basic', description: 'Bot WhatsApp auto reply', price: 50000, originalPrice: 75000, category: 'digital' as const, image: '/assets/media/products/wabot.jpg', rating: 4.6, reviewCount: 180, soldCount: 950, stock: 25, discount: 33 },
  { id: '5', name: 'ChatGPT Plus - 1 Bulan', description: 'ChatGPT Plus sharing', price: 75000, originalPrice: 100000, category: 'subscription' as const, image: '/assets/media/products/chatgpt.jpg', rating: 4.8, reviewCount: 890, soldCount: 5200, stock: 45, discount: 25 },
];

const trendingSearches = ['Bot WhatsApp', 'Netflix', 'Panel Pterodactyl', 'Spotify', 'VPS'];
const searchHistory = ['Netflix Premium', 'Spotify Family', 'Panel Game'];

export default function SearchPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const query = searchParams.get('q') || '';
  const [searchQuery, setSearchQuery] = useState(query);

  const results = useMemo(() => {
    if (!searchQuery.trim()) return [];
    const q = searchQuery.toLowerCase();
    return sampleProducts.filter(p =>
      p.name.toLowerCase().includes(q) || p.description.toLowerCase().includes(q) || p.category.toLowerCase().includes(q)
    );
  }, [searchQuery]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setSearchParams({ q: searchQuery });
    }
  };

  return (
    <div className="min-h-screen bg-[#080C14] text-white pt-16 pb-8">
      {/* Search Header */}
      <div className="px-4 py-3 border-b border-[#1C2A45]">
        <form onSubmit={handleSearch} className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <input
            type="text"
            placeholder="Cari produk..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            autoFocus
            className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl py-2.5 pl-10 pr-4 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]"
          />
        </form>
      </div>

      {!searchQuery ? (
        <div className="px-4 py-4">
          {/* Search History */}
          <div className="mb-6">
            <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
              <Clock className="w-4 h-4 text-gray-400" /> Riwayat Pencarian
            </h3>
            <div className="flex flex-wrap gap-2">
              {searchHistory.map((term, i) => (
                <button
                  key={i}
                  onClick={() => { setSearchQuery(term); setSearchParams({ q: term }); }}
                  className="px-3 py-1.5 bg-[#131B2D] border border-[#1C2A45] rounded-full text-xs text-gray-400 hover:border-[#00F0FF]/40 transition-colors"
                >
                  {term}
                </button>
              ))}
            </div>
          </div>

          {/* Trending */}
          <div>
            <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-gray-400" /> Paling Banyak Dicari
            </h3>
            <div className="flex flex-wrap gap-2">
              {trendingSearches.map((term, i) => (
                <button
                  key={i}
                  onClick={() => { setSearchQuery(term); setSearchParams({ q: term }); }}
                  className="px-3 py-1.5 bg-gradient-to-r from-[#7C3AED]/10 to-[#3B82F6]/10 border border-[#00F0FF]/20 rounded-full text-xs text-[#00F0FF]"
                >
                  {term}
                </button>
              ))}
            </div>
          </div>
        </div>
      ) : (
        <div className="px-4 py-4">
          <p className="text-sm text-gray-500 mb-4">{results.length} hasil untuk &quot;{searchQuery}&quot;</p>
          {results.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-500">Tidak ada hasil untuk &quot;{searchQuery}&quot;</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-3">
              {results.map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
