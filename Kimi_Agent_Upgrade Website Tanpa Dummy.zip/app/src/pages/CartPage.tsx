import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { ArrowLeft, Minus, Plus, Trash2, Ticket, ChevronRight } from 'lucide-react';
import { useStore } from '@/stores/useStore';
import { formatPrice } from '@/lib/utils';
import EmptyState from '@/components/shared/EmptyState';

export default function CartPage() {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const { cart, removeFromCart, updateCartQuantity, addToCart } = useStore();
  const [selectedAll, setSelectedAll] = useState(true);
  const [voucherCode, setVoucherCode] = useState('');

  const selectedItems = cart.filter(item => item.selected !== false);
  const totalSelected = selectedItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const selectedCount = selectedItems.reduce((sum, item) => sum + item.quantity, 0);

  const handleSelectAll = () => {
    setSelectedAll(!selectedAll);
  };

  const handleCheckout = () => {
    navigate('/checkout');
  };

  if (cart.length === 0) {
    return (
      <div className="min-h-screen bg-[#080C14] text-white pt-16">
        <div className="flex items-center gap-3 px-4 py-3 border-b border-[#1C2A45]">
          <button onClick={() => navigate(-1)}><ArrowLeft className="w-5 h-5 text-gray-400" /></button>
          <h1 className="text-lg font-bold">{t('cart')}</h1>
        </div>
        <EmptyState
          type="cart"
          actionLabel="Mulai Belanja"
          onAction={() => navigate('/products')}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#080C14] text-white pt-16 pb-28">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-[#1C2A45] sticky top-16 bg-[#080C14] z-30">
        <button onClick={() => navigate(-1)}><ArrowLeft className="w-5 h-5 text-gray-400" /></button>
        <h1 className="text-lg font-bold">{t('cart')} ({cart.length})</h1>
      </div>

      {/* Select All */}
      <div className="px-4 py-3 flex items-center gap-2">
        <button
          onClick={handleSelectAll}
          className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-colors ${
            selectedAll ? 'bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] border-transparent' : 'border-gray-500'
          }`}
        >
          {selectedAll && <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" /></svg>}
        </button>
        <span className="text-sm text-gray-400">{t('all')}</span>
      </div>

      {/* Cart Items */}
      <div className="px-4 space-y-3">
        {cart.map((item) => (
          <div key={item.productId} className="flex gap-3 p-3 bg-[#131B2D] border border-[#1C2A45] rounded-xl">
            <button
              className={`w-5 h-5 rounded border-2 flex-shrink-0 flex items-center justify-center mt-4 transition-colors ${
                item.selected !== false ? 'bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] border-transparent' : 'border-gray-500'
              }`}
            >
              {item.selected !== false && <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" /></svg>}
            </button>
            <img src={item.image} alt={item.name} className="w-20 h-20 rounded-xl object-cover flex-shrink-0" />
            <div className="flex-1 min-w-0">
              <h3 className="text-sm text-white line-clamp-2 mb-1">{item.name}</h3>
              {item.variant && <p className="text-xs text-gray-500 mb-1">{item.variant}</p>}
              <p className="text-[#00F0FF] font-bold text-sm">{formatPrice(item.price * item.quantity)}</p>
              <div className="flex items-center justify-between mt-2">
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => updateCartQuantity(item.productId, item.quantity - 1)}
                    className="w-7 h-7 rounded-lg bg-[#080C14] border border-[#1C2A45] flex items-center justify-center"
                  >
                    <Minus className="w-3 h-3 text-gray-400" />
                  </button>
                  <span className="text-sm text-white w-6 text-center">{item.quantity}</span>
                  <button
                    onClick={() => updateCartQuantity(item.productId, item.quantity + 1)}
                    className="w-7 h-7 rounded-lg bg-[#080C14] border border-[#1C2A45] flex items-center justify-center"
                  >
                    <Plus className="w-3 h-3 text-gray-400" />
                  </button>
                </div>
                <button
                  onClick={() => removeFromCart(item.productId)}
                  className="p-1.5 rounded-lg hover:bg-red-500/10 transition-colors"
                >
                  <Trash2 className="w-4 h-4 text-red-400" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Voucher Section */}
      <div className="px-4 mt-4">
        <button className="w-full flex items-center justify-between p-3 bg-[#131B2D] border border-[#1C2A45] rounded-xl">
          <div className="flex items-center gap-2">
            <Ticket className="w-5 h-5 text-[#00F0FF]" />
            <span className="text-sm text-gray-400">Gunakan Voucher</span>
          </div>
          <ChevronRight className="w-5 h-5 text-gray-500" />
        </button>
      </div>

      {/* Sticky Checkout Bar */}
      <div className="fixed bottom-0 left-0 right-0 bg-[#080C14] border-t border-[#1C2A45] p-4 z-40">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-400">{t('total')}</span>
            <span className="text-lg font-bold text-[#00F0FF]">{formatPrice(totalSelected)}</span>
          </div>
        </div>
        <button
          onClick={handleCheckout}
          disabled={selectedCount === 0}
          className="w-full py-3.5 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white rounded-xl font-medium disabled:opacity-50 disabled:cursor-not-allowed hover:opacity-90 transition-opacity"
        >
          {t('checkout')} ({selectedCount})
        </button>
      </div>
    </div>
  );
}
