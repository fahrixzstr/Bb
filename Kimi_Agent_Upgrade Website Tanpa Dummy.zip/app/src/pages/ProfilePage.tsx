import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  ArrowLeft, Settings, CreditCard, Package, Star, ChevronRight,
  Wallet, Coins, Ticket, Share2, Heart, Clock, HelpCircle,
  MessageCircle, Bug, LogOut, Crown
} from 'lucide-react';
import { useStore } from '@/stores/useStore';
import { formatPrice, getInitials } from '@/lib/utils';

export default function ProfilePage() {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const { user, isLoggedIn, reset } = useStore();

  const handleLogout = () => {
    if (confirm(t('logout_confirm'))) {
      reset();
      navigate('/login');
    }
  };

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-[#080C14] text-white flex items-center justify-center">
        <div className="text-center">
          <div className="w-20 h-20 rounded-full bg-[#131B2D] border border-[#1C2A45] flex items-center justify-center mx-auto mb-4">
            <Settings className="w-8 h-8 text-gray-500" />
          </div>
          <p className="text-gray-400 mb-4">Silakan login untuk melihat profil</p>
          <button
            onClick={() => navigate('/login')}
            className="px-6 py-2.5 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white rounded-xl font-medium"
          >
            {t('login')}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#080C14] text-white pb-8">
      {/* Header Background */}
      <div className="bg-gradient-to-br from-[#7C3AED] to-[#3B82F6] pt-16 pb-20 px-4 relative">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-lg font-bold text-white">{t('profile')}</h1>
          <button
            onClick={() => navigate('/settings')}
            className="p-2 rounded-full bg-white/20 backdrop-blur-sm"
          >
            <Settings className="w-5 h-5 text-white" />
          </button>
        </div>
        <div className="flex items-center gap-4">
          {user?.photoURL ? (
            <img src={user.photoURL} alt="" className="w-16 h-16 rounded-full border-4 border-white object-cover" />
          ) : (
            <div className="w-16 h-16 rounded-full border-4 border-white bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] flex items-center justify-center text-white text-xl font-bold">
              {getInitials(user?.displayName || 'U')}
            </div>
          )}
          <div>
            <h2 className="text-white font-bold text-lg">{user?.displayName || 'User'}</h2>
            <div className="flex items-center gap-1">
              <Crown className="w-3.5 h-3.5 text-yellow-300" />
              <span className="text-white/80 text-sm">Member</span>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="px-4 -mt-10 relative z-10">
        <div className="bg-[#131B2D] border border-[#1C2A45] rounded-2xl p-4 flex justify-around">
          {[
            { icon: CreditCard, label: 'Belum Bayar', count: 1, path: '/orders?status=pending' },
            { icon: Package, label: 'Proses', count: 2, path: '/orders?status=processing' },
            { icon: Star, label: 'Beri Nilai', count: 3, path: '/orders?status=completed' },
          ].map((stat) => (
            <button
              key={stat.label}
              onClick={() => navigate(stat.path)}
              className="flex flex-col items-center gap-1"
            >
              <div className="relative">
                <stat.icon className="w-6 h-6 text-gray-400" />
                {stat.count > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 w-4 h-4 bg-red-500 rounded-full text-[9px] text-white flex items-center justify-center">
                    {stat.count}
                  </span>
                )}
              </div>
              <span className="text-xs text-gray-400">{stat.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Menu List */}
      <div className="px-4 mt-4 space-y-2">
        {/* Wallet */}
        <div className="bg-[#131B2D] border border-[#1C2A45] rounded-2xl divide-y divide-[#1C2A45]">
          <button onClick={() => navigate('/wallet')} className="w-full flex items-center gap-3 p-4 hover:bg-white/5 transition-colors rounded-t-2xl">
            <Wallet className="w-5 h-5 text-[#00F0FF]" />
            <div className="flex-1 text-left">
              <p className="text-sm text-white">Dompet Saya</p>
              <p className="text-xs text-gray-500">Rp 185.000</p>
            </div>
            <ChevronRight className="w-4 h-4 text-gray-500" />
          </button>
          <button onClick={() => navigate('/coins')} className="w-full flex items-center gap-3 p-4 hover:bg-white/5 transition-colors">
            <Coins className="w-5 h-5 text-yellow-400" />
            <div className="flex-1 text-left">
              <p className="text-sm text-white">Koin FahriXz</p>
              <p className="text-xs text-gray-500">1.250 Koin</p>
            </div>
            <ChevronRight className="w-4 h-4 text-gray-500" />
          </button>
          <button onClick={() => navigate('/vouchers')} className="w-full flex items-center gap-3 p-4 hover:bg-white/5 transition-colors rounded-b-2xl">
            <Ticket className="w-5 h-5 text-purple-400" />
            <div className="flex-1 text-left">
              <p className="text-sm text-white">Voucher Saya</p>
              <p className="text-xs text-gray-500">5 Voucher aktif</p>
            </div>
            <ChevronRight className="w-4 h-4 text-gray-500" />
          </button>
        </div>

        {/* Activities */}
        <div className="bg-[#131B2D] border border-[#1C2A45] rounded-2xl divide-y divide-[#1C2A45]">
          <button onClick={() => navigate('/affiliate')} className="w-full flex items-center gap-3 p-4 hover:bg-white/5 transition-colors rounded-t-2xl">
            <Share2 className="w-5 h-5 text-green-400" />
            <div className="flex-1 text-left">
              <p className="text-sm text-white">Affiliate Program</p>
              <p className="text-xs text-gray-500">Dapatkan komisi</p>
            </div>
            <ChevronRight className="w-4 h-4 text-gray-500" />
          </button>
          <button onClick={() => navigate('/favorites')} className="w-full flex items-center gap-3 p-4 hover:bg-white/5 transition-colors">
            <Heart className="w-5 h-5 text-red-400" />
            <div className="flex-1 text-left">
              <p className="text-sm text-white">Favorit Saya</p>
              <p className="text-xs text-gray-500">12 Produk</p>
            </div>
            <ChevronRight className="w-4 h-4 text-gray-500" />
          </button>
          <button onClick={() => navigate('/recently-viewed')} className="w-full flex items-center gap-3 p-4 hover:bg-white/5 transition-colors rounded-b-2xl">
            <Clock className="w-5 h-5 text-blue-400" />
            <div className="flex-1 text-left">
              <p className="text-sm text-white">Terakhir Dilihat</p>
              <p className="text-xs text-gray-500">8 Produk</p>
            </div>
            <ChevronRight className="w-4 h-4 text-gray-500" />
          </button>
        </div>

        {/* Help */}
        <div className="bg-[#131B2D] border border-[#1C2A45] rounded-2xl divide-y divide-[#1C2A45]">
          <button onClick={() => navigate('/help')} className="w-full flex items-center gap-3 p-4 hover:bg-white/5 transition-colors rounded-t-2xl">
            <HelpCircle className="w-5 h-5 text-blue-400" />
            <span className="flex-1 text-left text-sm text-white">Pusat Bantuan</span>
            <ChevronRight className="w-4 h-4 text-gray-500" />
          </button>
          <button onClick={() => navigate('/customer-service')} className="w-full flex items-center gap-3 p-4 hover:bg-white/5 transition-colors">
            <MessageCircle className="w-5 h-5 text-green-400" />
            <span className="flex-1 text-left text-sm text-white">Customer Service</span>
            <ChevronRight className="w-4 h-4 text-gray-500" />
          </button>
          <button onClick={() => navigate('/report-bug')} className="w-full flex items-center gap-3 p-4 hover:bg-white/5 transition-colors rounded-b-2xl">
            <Bug className="w-5 h-5 text-orange-400" />
            <span className="flex-1 text-left text-sm text-white">Lapor Bug</span>
            <ChevronRight className="w-4 h-4 text-gray-500" />
          </button>
        </div>

        {/* Logout */}
        <button
          onClick={handleLogout}
          className="w-full flex items-center justify-center gap-2 p-4 border border-red-500/30 rounded-2xl text-red-400 hover:bg-red-500/10 transition-colors"
        >
          <LogOut className="w-5 h-5" />
          <span className="text-sm font-medium">Ganti Akun / Keluar</span>
        </button>
      </div>
    </div>
  );
}
