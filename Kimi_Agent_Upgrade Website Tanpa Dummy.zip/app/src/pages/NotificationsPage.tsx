import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { ArrowLeft, Package, Target, Gift, Info, Trash2 } from 'lucide-react';
import { useStore } from '@/stores/useStore';

const sampleNotifications = [
  { notificationId: '1', title: 'Pesanan Dikirim', body: 'Pesanan #ORD-001 sedang dalam perjalanan', type: 'order' as const, read: false, createdAt: '2026-06-17T10:30:00' },
  { notificationId: '2', title: 'Misi Selesai', body: 'Misi review aplikasi telah disetujui. Reward Rp 15.000', type: 'mission' as const, read: false, createdAt: '2026-06-17T09:15:00' },
  { notificationId: '3', title: 'Flash Sale!', body: 'Netflix Premium diskon 50% hanya hari ini', type: 'promo' as const, read: true, createdAt: '2026-06-16T20:00:00' },
  { notificationId: '4', title: 'Update Aplikasi', body: 'Versi terbaru telah tersedia dengan fitur baru', type: 'system' as const, read: true, createdAt: '2026-06-15T14:00:00' },
  { notificationId: '5', title: 'Withdraw Berhasil', body: 'Penarikan Rp 50.000 ke DANA berhasil', type: 'order' as const, read: true, createdAt: '2026-06-14T16:30:00' },
];

const typeConfig: Record<string, { icon: React.ElementType; bg: string }> = {
  order: { icon: Package, bg: 'bg-blue-500/10 text-blue-400' },
  mission: { icon: Target, bg: 'bg-green-500/10 text-green-400' },
  promo: { icon: Gift, bg: 'bg-orange-500/10 text-orange-400' },
  system: { icon: Info, bg: 'bg-gray-500/10 text-gray-400' },
};

export default function NotificationsPage() {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const { markAsRead, markAllAsRead } = useStore();

  return (
    <div className="min-h-screen bg-[#080C14] text-white pt-16 pb-8">
      <div className="flex items-center justify-between px-4 py-3 border-b border-[#1C2A45]">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate(-1)}><ArrowLeft className="w-5 h-5 text-gray-400" /></button>
          <h1 className="text-lg font-bold">{t('notifications')}</h1>
        </div>
        <button onClick={markAllAsRead} className="text-xs text-[#00F0FF]">
          {t('mark_all_read')}
        </button>
      </div>

      <div className="px-4 mt-4 space-y-2">
        {sampleNotifications.map(notif => {
          const config = typeConfig[notif.type] || typeConfig.system;
          const Icon = config.icon;
          return (
            <button
              key={notif.notificationId}
              onClick={() => markAsRead(notif.notificationId)}
              className={`w-full flex items-start gap-3 p-4 rounded-xl transition-colors ${
                notif.read ? 'bg-[#080C14]' : 'bg-[#131B2D] border border-[#1C2A45]'
              }`}
            >
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${config.bg}`}>
                <Icon className="w-5 h-5" />
              </div>
              <div className="flex-1 text-left min-w-0">
                <div className="flex items-start justify-between gap-2">
                  <h3 className={`text-sm ${notif.read ? 'text-gray-400' : 'text-white font-medium'}`}>{notif.title}</h3>
                  {!notif.read && <span className="w-2 h-2 bg-[#00F0FF] rounded-full flex-shrink-0 mt-1" />}
                </div>
                <p className="text-xs text-gray-500 line-clamp-2 mt-0.5">{notif.body}</p>
                <p className="text-[10px] text-gray-600 mt-1">
                  {new Date(notif.createdAt).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
