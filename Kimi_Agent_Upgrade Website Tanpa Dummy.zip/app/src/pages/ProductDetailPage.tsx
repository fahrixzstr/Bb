import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { ArrowLeft, Star, ShoppingCart, MessageCircle, Heart, Share2, ChevronRight, Minus, Plus, Shield, Package } from 'lucide-react';
import { useStore } from '@/stores/useStore';
import { formatPrice, calculateDiscount, truncateText } from '@/lib/utils';
import ProductCard from '@/components/shared/ProductCard';

const sampleProducts = [
  { id: '1', name: 'Netflix Premium 4K - 1 Bulan', description: 'Akun Netflix sharing 1 profile. Dapatkan akses ke ribuan film, serial TV, dan konten original Netflix dalam kualitas Ultra HD 4K. Support perangkat: Smart TV, HP, Laptop, Tablet.', price: 45000, originalPrice: 65000, category: 'subscription' as const, image: '/assets/media/products/netflix.jpg', images: ['/assets/media/products/netflix.jpg', '/assets/media/products/netflix-2.jpg'], rating: 4.8, reviewCount: 1250, soldCount: 8500, stock: 100, isBestSeller: true, discount: 30, minOrder: 1, tags: ['Streaming', 'Movie', 'Series'] },
  { id: '2', name: 'Spotify Premium Family - 1 Bulan', description: 'Spotify Premium Family Plan. Dengarkan musik tanpa iklan, mode offline, dan kualitas audio tinggi. Berbagi dengan hingga 5 anggota keluarga.', price: 25000, originalPrice: 35000, category: 'subscription' as const, image: '/assets/media/products/spotify.jpg', rating: 4.7, reviewCount: 890, soldCount: 6200, stock: 80, isBestSeller: true, discount: 28 },
  { id: '3', name: 'Panel Pterodactyl - Basic', description: 'Panel game hosting basic dengan Pterodactyl. Support Minecraft, CS:GO, dan banyak game lainnya.', price: 35000, category: 'panel' as const, image: '/assets/media/products/panel.jpg', rating: 4.6, reviewCount: 450, soldCount: 3100, stock: 50 },
  { id: '4', name: 'Hosting VPS - 2GB RAM', description: 'VPS Cloud 2GB RAM dengan SSD storage. Cocok untuk website, bot, dan aplikasi kecil.', price: 85000, originalPrice: 120000, category: 'hosting' as const, image: '/assets/media/products/vps.jpg', rating: 4.9, reviewCount: 320, soldCount: 1800, stock: 30, discount: 29 },
];

const relatedProducts = [
  { id: '5', name: 'YouTube Premium - 1 Bulan', description: 'YouTube Premium', price: 20000, originalPrice: 30000, category: 'subscription' as const, image: '/assets/media/products/youtube.jpg', rating: 4.7, reviewCount: 670, soldCount: 4500, stock: 90, discount: 33 },
  { id: '6', name: 'Canva Pro - 1 Bulan', description: 'Canva Pro', price: 15000, originalPrice: 25000, category: 'subscription' as const, image: '/assets/media/products/canva.jpg', rating: 4.5, reviewCount: 280, soldCount: 2100, stock: 60, discount: 40 },
  { id: '7', name: 'ChatGPT Plus - 1 Bulan', description: 'ChatGPT Plus', price: 75000, originalPrice: 100000, category: 'subscription' as const, image: '/assets/media/products/chatgpt.jpg', rating: 4.8, reviewCount: 890, soldCount: 5200, stock: 45, discount: 25 },
];

const reviews = [
  { reviewId: '1', userId: 'u1', userName: 'Ahmad Fauzi', productId: '1', rating: 5, text: 'Sangat memuaskan! Proses cepat dan akun berfungsi dengan baik. Recommended seller!', variant: '1 Bulan', helpful: 24, createdAt: '2026-06-15' },
  { reviewId: '2', userId: 'u2', userName: 'Siti Nurhaliza', productId: '1', rating: 4, text: 'Bagus sih, cuma kadang ada buffering di jam sibuk. Overall worth it untuk harga segini.', variant: '1 Bulan', helpful: 12, createdAt: '2026-06-10' },
  { reviewId: '3', userId: 'u3', userName: 'Budi Santoso', productId: '1', rating: 5, text: 'Sudah langganan 3 bulan di sini, belum pernah ada masalah. Top markotop!', variant: '1 Bulan', helpful: 18, createdAt: '2026-06-05' },
];

export default function ProductDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { t } = useTranslation();
  const { addToCart } = useStore();
  const [isFavorite, setIsFavorite] = useState(false);
  const [quantity, setQuantity] = useState(1);
  const [selectedVariant, setSelectedVariant] = useState('1 Bulan');
  const [showVariantSheet, setShowVariantSheet] = useState(false);

  const product = sampleProducts.find(p => p.id === id);
  if (!product) {
    return (
      <div className="min-h-screen bg-[#080C14] flex items-center justify-center text-white">
        <p>Produk tidak ditemukan</p>
      </div>
    );
  }

  const discount = calculateDiscount(product.originalPrice || 0, product.price);

  const handleAddToCart = () => {
    addToCart({
      productId: product.id,
      name: product.name,
      price: product.price,
      quantity,
      image: product.image,
      category: product.category,
      variant: selectedVariant,
    });
  };

  return (
    <div className="min-h-screen bg-[#080C14] text-white pb-24">
      {/* Image Gallery */}
      <div className="relative">
        <div className="aspect-square bg-[#131B2D]">
          <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
        </div>
        <button onClick={() => navigate(-1)} className="absolute top-4 left-4 p-2 rounded-full bg-black/50 backdrop-blur-sm">
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>
        <div className="absolute top-4 right-4 flex gap-2">
          <button onClick={() => setIsFavorite(!isFavorite)} className="p-2 rounded-full bg-black/50 backdrop-blur-sm">
            <Heart className={`w-5 h-5 ${isFavorite ? 'text-red-500 fill-red-500' : 'text-white'}`} />
          </button>
          <button className="p-2 rounded-full bg-black/50 backdrop-blur-sm">
            <Share2 className="w-5 h-5 text-white" />
          </button>
        </div>
      </div>

      {/* Product Info */}
      <div className="px-4 py-4">
        {/* Badges */}
        <div className="flex gap-2 mb-2">
          <span className="px-2 py-0.5 bg-[#00F0FF]/10 text-[#00F0FF] text-xs rounded-lg">{product.category}</span>
          {product.isBestSeller && (
            <span className="px-2 py-0.5 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white text-xs rounded-lg">BEST SELLER</span>
          )}
          {discount > 0 && (
            <span className="px-2 py-0.5 bg-red-500/10 text-red-400 text-xs rounded-lg">-{discount}%</span>
          )}
        </div>

        <h1 className="text-lg font-bold text-white mb-2">{product.name}</h1>

        {/* Price */}
        <div className="flex items-baseline gap-2 mb-2">
          <span className="text-2xl font-bold text-[#00F0FF]">{formatPrice(product.price)}</span>
          {product.originalPrice && (
            <span className="text-sm text-gray-500 line-through">{formatPrice(product.originalPrice)}</span>
          )}
        </div>

        {/* Rating */}
        <div className="flex items-center gap-3 mb-4">
          <div className="flex items-center gap-1">
            <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
            <span className="text-sm font-medium">{product.rating}</span>
          </div>
          <span className="text-sm text-gray-500">{product.reviewCount} {t('reviews')}</span>
          <span className="text-sm text-gray-500">{product.soldCount.toLocaleString('id-ID')}+ terjual</span>
        </div>

        {/* Variant Selector */}
        <div className="mb-4" onClick={() => setShowVariantSheet(true)}>
          <div className="flex items-center justify-between p-3 bg-[#131B2D] border border-[#1C2A45] rounded-xl cursor-pointer">
            <div>
              <p className="text-xs text-gray-500">{t('variant')}</p>
              <p className="text-sm text-white">{selectedVariant}</p>
            </div>
            <ChevronRight className="w-5 h-5 text-gray-500" />
          </div>
        </div>

        {/* Description */}
        <div className="mb-4">
          <h3 className="text-sm font-semibold text-white mb-2">{t('description')}</h3>
          <p className="text-sm text-gray-400 leading-relaxed">{product.description}</p>
        </div>

        {/* Guarantees */}
        <div className="flex gap-3 mb-6">
          <div className="flex items-center gap-1.5 text-xs text-gray-400">
            <Shield className="w-4 h-4 text-green-400" />
            Garansi
          </div>
          <div className="flex items-center gap-1.5 text-xs text-gray-400">
            <Package className="w-4 h-4 text-blue-400" />
            Pengiriman Otomatis
          </div>
        </div>

        {/* Reviews Section */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold text-white">{t('reviews')} ({product.reviewCount})</h3>
            <button className="text-xs text-[#00F0FF]">{t('see_all')}</button>
          </div>
          <div className="flex gap-2 mb-4">
            <span className="px-2 py-1 bg-[#131B2D] text-gray-400 text-xs rounded-lg">Semua</span>
            <span className="px-2 py-1 bg-[#131B2D] text-gray-400 text-xs rounded-lg">Dengan Foto</span>
            <span className="px-2 py-1 bg-[#131B2D] text-gray-400 text-xs rounded-lg">5 Bintang</span>
          </div>
          {reviews.slice(0, 2).map(review => (
            <div key={review.reviewId} className="border-b border-[#1C2A45] pb-3 mb-3">
              <div className="flex items-center gap-2 mb-1">
                <div className="w-7 h-7 rounded-full bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] flex items-center justify-center text-white text-xs font-bold">
                  {review.userName.charAt(0)}
                </div>
                <div>
                  <p className="text-sm text-white">{review.userName}</p>
                  <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className={`w-3 h-3 ${i < review.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-600'}`} />
                    ))}
                  </div>
                </div>
              </div>
              <p className="text-sm text-gray-400 mt-1">{review.text}</p>
              <p className="text-xs text-gray-600 mt-1">{review.variant}</p>
            </div>
          ))}
        </div>

        {/* Related Products */}
        <div>
          <h3 className="text-sm font-semibold text-white mb-3">{t('related_products')}</h3>
          <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-2">
            {relatedProducts.map(p => (
              <div key={p.id} className="flex-shrink-0 w-36" onClick={() => navigate(`/products/${p.id}`)}>
                <ProductCard product={p} />
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Sticky Bottom Action */}
      <div className="fixed bottom-0 left-0 right-0 bg-[#080C14] border-t border-[#1C2A45] p-3 z-40 flex items-center gap-3">
        <button
          onClick={() => navigate('/customer-service')}
          className="p-3 rounded-xl bg-[#131B2D] border border-[#1C2A45]"
        >
          <MessageCircle className="w-5 h-5 text-gray-400" />
        </button>
        <button
          onClick={handleAddToCart}
          className="flex-1 py-3 border border-[#00F0FF] text-[#00F0FF] rounded-xl font-medium text-sm flex items-center justify-center gap-2 hover:bg-[#00F0FF]/10 transition-colors"
        >
          <ShoppingCart className="w-4 h-4" />
          {t('add_to_cart')}
        </button>
        <button
          onClick={() => navigate('/checkout')}
          className="flex-1 py-3 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white rounded-xl font-medium text-sm hover:opacity-90 transition-opacity"
        >
          {t('buy_now')}
        </button>
      </div>

      {/* Variant Bottom Sheet */}
      {showVariantSheet && (
        <div className="fixed inset-0 z-50 flex items-end" onClick={() => setShowVariantSheet(false)}>
          <div className="absolute inset-0 bg-black/60" />
          <div className="relative w-full bg-[#131B2D] rounded-t-2xl p-4 animate-slide-up" onClick={e => e.stopPropagation()}>
            <div className="w-10 h-1 bg-gray-600 rounded-full mx-auto mb-4" />
            <div className="flex gap-3 mb-4">
              <img src={product.image} alt="" className="w-20 h-20 rounded-xl object-cover" />
              <div>
                <p className="text-[#00F0FF] font-bold">{formatPrice(product.price)}</p>
                <p className="text-sm text-gray-400">{t('stock')}: {product.stock}</p>
              </div>
            </div>
            <p className="text-sm text-gray-400 mb-2">{t('variant')}</p>
            <div className="flex gap-2 mb-4">
              {['1 Bulan', '3 Bulan', '6 Bulan', '1 Tahun'].map(v => (
                <button
                  key={v}
                  onClick={() => setSelectedVariant(v)}
                  className={`px-3 py-2 rounded-lg text-sm transition-colors ${
                    selectedVariant === v
                      ? 'bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white'
                      : 'bg-[#080C14] text-gray-400 border border-[#1C2A45]'
                  }`}
                >
                  {v}
                </button>
              ))}
            </div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm text-gray-400">{t('quantity')}</span>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-8 h-8 rounded-lg bg-[#080C14] border border-[#1C2A45] flex items-center justify-center"
                >
                  <Minus className="w-4 h-4 text-gray-400" />
                </button>
                <span className="text-white font-medium w-8 text-center">{quantity}</span>
                <button
                  onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                  className="w-8 h-8 rounded-lg bg-[#080C14] border border-[#1C2A45] flex items-center justify-center"
                >
                  <Plus className="w-4 h-4 text-gray-400" />
                </button>
              </div>
            </div>
            <button
              onClick={() => setShowVariantSheet(false)}
              className="w-full py-3 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white rounded-xl font-medium"
            >
              {t('done')}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
