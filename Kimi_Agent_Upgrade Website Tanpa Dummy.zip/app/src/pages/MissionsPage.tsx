import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { ArrowLeft, Target, Coins, ArrowUpRight, Gift, Clock, ChevronRight } from 'lucide-react';
import { formatPrice } from '@/lib/utils';
import EmptyState from '@/components/shared/EmptyState';

const tabs = [
  { key: 'available', label: 'Misi Tersedia' },
  { key: 'taken', label: 'Sudah Diambil' },
];

const filterChips = [
  { key: 'all', label: 'Semua' },
  { key: 'registrasi', label: 'Registrasi' },
  { key: 'review', label: 'Review' },
  { key: 'download', label: 'Download' },
  { key: 'game', label: 'Game' },
  { key: 'survey', label: 'Survey' },
];

const sampleMissions = [
  { missionId: 'M001', title: 'Misi Review Aplikasi', description: 'Berikan review honest di Play Store', category: 'review', reward: 15000, estimatedMinutes: 15, status: 'available' as const },
  { missionId: 'M002', title: 'Registrasi Akun Baru', description: 'Daftar akun baru di platform partner', category: 'registrasi', reward: 25000, estimatedMinutes: 10, status: 'available' as const },
  { missionId: 'M003', title: 'Download & Install Game', description: 'Download dan mainkan game selama 30 menit', category: 'download', reward: 20000, estimatedMinutes: 30, status: 'available' as const },
  { missionId: 'M004', title: 'Isi Survey Online', description: 'Isi survey tentang kebiasaan belanja online', category: 'survey', reward: 10000, estimatedMinutes: 10, status: 'available' as const },
  { missionId: 'M005', title: 'Main Game Mobile', description: 'Capai level 5 dalam game', category: 'game', reward: 35000, estimatedMinutes: 45, status: 'available' as const },
];

const takenMissions = [
  { missionId: 'M101', title: 'Review Aplikasi Sebelumnya', description: 'Review aplikasi di Play Store', category: 'review', reward: 15000, status: 'taken' as const, progress: 80 },
  { missionId: 'M102', title: 'Registrasi Platform', description: 'Daftar akun di platform partner', category: 'registrasi', reward: 25000, status: 'completed' as const, progress: 100 },
];

const categoryColors: Record<string, string> = {
  registrasi: 'text-blue-400 bg-blue-400/10',
  review: 'text-green-400 bg-green-400/10',
  download: 'text-purple-400 bg-purple-400/10',
  game: 'text-orange-400 bg-orange-400/10',
  survey: 'text-pink-400 bg-pink-400/10',
  pinjaman: 'text-red-400 bg-red-400/10',
};

export default function MissionsPage() {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const [activeTab, setActiveTab] = useState('available');
  const [activeFilter, setActiveFilter] = useState('all');
  const [balance] = useState(125000);

  const filteredMissions = activeTab === 'available'
    ? (activeFilter === 'all' ? sampleMissions : sampleMissions.filter(m => m.category === activeFilter))
    : takenMissions;

  return (
    <div className="min-h-screen bg-[#080C14] text-white pt-16 pb-8">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-[#1C2A45]">
        <button onClick={() => navigate(-1)}><ArrowLeft className="w-5 h-5 text-gray-400" /></button>
        <h1 className="text-lg font-bold">{t('missions')}</h1>
      </div>

      {/* Header Card */}
      <div className="px-4 py-4">
        <div className="bg-gradient-to-br from-[#7C3AED] to-[#3B82F6] rounded-2xl p-5 mb-3">
          <div className="flex items-center gap-2 mb-1">
            <Target className="w-5 h-5 text-white" />
            <span className="text-white font-bold text-lg">Cari Cuan</span>
          </div>
          <p className="text-white/80 text-sm">Rp 1.850.000 didapatkan user lain minggu ini</p>
        </div>

        {/* Balance Card */}
        <div className="bg-[#131B2D] border border-[#1C2A45] rounded-2xl p-4 flex items-center justify-between">
          <div>
            <p className="text-gray-400 text-sm">{t('balance')}</p>
            <p className="text-2xl font-bold text-white">{formatPrice(balance)}</p>
          </div>
          <div className="flex gap-2">
            <button className="p-2.5 rounded-xl bg-[#080C14] border border-[#1C2A45] hover:border-[#00F0FF]/40 transition-colors">
              <Clock className="w-5 h-5 text-gray-400" />
            </button>
            <button
              onClick={() => navigate('/wallet/withdraw')}
              className="p-2.5 rounded-xl bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] hover:opacity-90 transition-opacity"
            >
              <ArrowUpRight className="w-5 h-5 text-white" />
            </button>
            <button className="p-2.5 rounded-xl bg-[#080C14] border border-[#1C2A45] hover:border-[#00F0FF]/40 transition-colors relative">
              <Gift className="w-5 h-5 text-gray-400" />
              <span className="absolute -top-1 -right-1 px-1 bg-red-500 text-white text-[8px] rounded-full">BARU</span>
            </button>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="px-4 flex gap-4 border-b border-[#1C2A45] mb-4">
        {tabs.map(tab => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`pb-3 text-sm font-medium transition-colors ${
              activeTab === tab.key
                ? 'text-[#00F0FF] border-b-2 border-[#00F0FF]'
                : 'text-gray-500'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Filter Chips */}
      {activeTab === 'available' && (
        <div className="px-4 flex gap-2 overflow-x-auto scrollbar-hide mb-4">
          {filterChips.map(chip => (
            <button
              key={chip.key}
              onClick={() => setActiveFilter(chip.key)}
              className={`px-3 py-1.5 rounded-full text-xs whitespace-nowrap transition-all ${
                activeFilter === chip.key
                  ? 'bg-[#00F0FF]/10 text-[#00F0FF] border border-[#00F0FF]/30'
                  : 'bg-[#131B2D] text-gray-400 border border-[#1C2A45]'
              }`}
            >
              {chip.label}
            </button>
          ))}
        </div>
      )}

      {/* Mission List */}
      <div className="px-4 space-y-3">
        {filteredMissions.length === 0 ? (
          <EmptyState type="mission" />
        ) : (
          filteredMissions.map(mission => (
            <div key={mission.missionId} className="bg-[#131B2D] border border-[#1C2A45] rounded-xl p-4 flex items-start gap-3">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${categoryColors[mission.category] || 'text-gray-400 bg-gray-400/10'}`}>
                <Target className="w-6 h-6" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="text-sm text-white font-medium mb-0.5">{mission.title}</h3>
                <p className="text-xs text-gray-500 line-clamp-1 mb-1">{mission.description}</p>
                <div className="flex items-center gap-2">
                  <span className="text-[#00F0FF] font-bold text-sm">{formatPrice(mission.reward)}</span>
                  <span className="text-xs text-gray-600 flex items-center gap-0.5">
                    <Clock className="w-3 h-3" /> {'estimatedMinutes' in mission ? `${mission.estimatedMinutes} menit` : 'In progress'}
                  </span>
                </div>
                {'progress' in mission && (
                  <div className="mt-2">
                    <div className="h-1.5 bg-[#1C2A45] rounded-full overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] rounded-full transition-all" style={{ width: `${mission.progress}%` }} />
                    </div>
                    <p className="text-xs text-gray-500 mt-0.5">{mission.progress}% selesai</p>
                  </div>
                )}
              </div>
              <button className={`px-3 py-1.5 rounded-full text-xs font-medium flex-shrink-0 ${
                mission.status === 'available'
                  ? 'bg-blue-500/10 text-blue-400'
                  : mission.status === 'completed'
                  ? 'bg-green-500/10 text-green-400'
                  : 'bg-yellow-500/10 text-yellow-400'
              }`}>
                {mission.status === 'available' ? 'Ambil' : mission.status === 'completed' ? 'Selesai' : 'Proses'}
              </button>
            </div>
          ))
        )}
      </div>

      {/* Sticky Withdraw Button */}
      {activeTab === 'taken' && (
        <div className="fixed bottom-0 left-0 right-0 bg-[#080C14] border-t border-[#1C2A45] p-4 z-40">
          <button
            onClick={() => navigate('/wallet/withdraw')}
            className="w-full py-3 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white rounded-xl font-medium"
          >
            Tarik Saldo
          </button>
          <p className="text-center text-xs text-gray-500 mt-2">Minimal penarikan Rp 50.000</p>
        </div>
      )}
    </div>
  );
}
