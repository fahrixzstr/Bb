import { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Send, Paperclip, Mic, MoreVertical, Clock, MessageCircle } from 'lucide-react';

interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
}

const quickReplies = ['Tanya Pesanan', 'Cek Fakta', 'Aplikasi Error', 'Lapor Bug', 'Cara Withdraw', 'Cara Misi'];

const sampleMessages: ChatMessage[] = [
  { id: '1', sender: 'ai', text: 'Halo! Ada yang bisa kami bantu?', timestamp: '10:00' },
];

export default function CustomerServicePage() {
  const navigate = useNavigate();
  const [messages, setMessages] = useState<ChatMessage[]>(sampleMessages);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = (text: string) => {
    if (!text.trim()) return;
    const newMessage: ChatMessage = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
    };
    setMessages(prev => [...prev, newMessage]);
    setInput('');
    setIsTyping(true);

    setTimeout(() => {
      setIsTyping(false);
      const aiResponse: ChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'ai',
        text: getAIResponse(text),
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages(prev => [...prev, aiResponse]);
    }, 1500);
  };

  const getAIResponse = (userText: string): string => {
    const lower = userText.toLowerCase();
    if (lower.includes('pesan') || lower.includes('order')) return 'Untuk mengecek pesanan, Anda bisa ke menu "Pesanan Saya" atau kirimkan nomor order ID Anda.';
    if (lower.includes('withdraw') || lower.includes('tarik')) return 'Untuk withdraw, saldo minimal Rp 50.000. Biaya admin Rp 2.500. Proses 1x24 jam.';
    if (lower.includes('misi') || lower.includes('cuan')) return 'Misi tersedia di menu "Cari Cuan". Pilih misi yang sesuai dan ikuti instruksinya.';
    if (lower.includes('bug') || lower.includes('error')) return 'Maaf atas ketidaknyamanannya. Bisa dijelaskan lebih detail masalah yang Anda alami?';
    if (lower.includes('halo') || lower.includes('hi')) return 'Halo! Senang membantu Anda. Ada yang bisa saya bantu?';
    return 'Maaf, saya belum sepenuhnya mengerti. Bisa dijelaskan lebih detail? Atau saya bisa menghubungkan Anda dengan admin.';
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    sendMessage(input);
  };

  return (
    <div className="min-h-screen bg-[#080C14] text-white flex flex-col">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-[#1C2A45] bg-[#080C14]/80 backdrop-blur-md sticky top-0 z-30">
        <button onClick={() => navigate(-1)}><ArrowLeft className="w-5 h-5 text-gray-400" /></button>
        <div className="w-9 h-9 rounded-full bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] flex items-center justify-center">
          <MessageCircle className="w-5 h-5 text-white" />
        </div>
        <div className="flex-1">
          <h1 className="text-sm font-semibold text-white">Customer Service</h1>
          <div className="flex items-center gap-1">
            <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
            <span className="text-xs text-green-400">Online</span>
          </div>
        </div>
        <button className="p-2 rounded-lg hover:bg-white/5">
          <MoreVertical className="w-5 h-5 text-gray-400" />
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages.length === 0 && (
          <div className="flex flex-col items-center justify-center py-16">
            <div className="w-20 h-20 rounded-full bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] flex items-center justify-center mb-4">
              <MessageCircle className="w-10 h-10 text-white" />
            </div>
            <h3 className="text-white font-semibold mb-1">Halo! Ada yang bisa kami bantu?</h3>
            <p className="text-gray-500 text-sm text-center max-w-xs">Kami siap membantu Anda dengan pertanyaan seputar produk, pesanan, misi cuan, dan lainnya.</p>
          </div>
        )}

        {messages.map(msg => (
          <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
            {msg.sender === 'ai' && (
              <div className="w-7 h-7 rounded-full bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] flex items-center justify-center mr-2 flex-shrink-0 self-end">
                <MessageCircle className="w-4 h-4 text-white" />
              </div>
            )}
            <div className={`max-w-[75%] p-3 rounded-2xl ${
              msg.sender === 'user'
                ? 'bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white rounded-tr-sm'
                : 'bg-[#131B2D] border border-[#1C2A45] text-white rounded-tl-sm'
            }`}>
              <p className="text-sm">{msg.text}</p>
              <p className={`text-[10px] mt-1 ${msg.sender === 'user' ? 'text-white/60' : 'text-gray-500'}`}>{msg.timestamp}</p>
            </div>
          </div>
        ))}

        {isTyping && (
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-full bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] flex items-center justify-center">
              <MessageCircle className="w-4 h-4 text-white" />
            </div>
            <div className="bg-[#131B2D] border border-[#1C2A45] rounded-2xl rounded-tl-sm p-3">
              <div className="flex gap-1">
                <span className="w-2 h-2 bg-gray-500 rounded-full animate-bounce" />
                <span className="w-2 h-2 bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} />
                <span className="w-2 h-2 bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />

        {/* Quick Replies */}
        {messages.length <= 2 && (
          <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-2">
            {quickReplies.map(reply => (
              <button
                key={reply}
                onClick={() => sendMessage(reply)}
                className="px-3 py-1.5 bg-[#131B2D] border border-[#1C2A45] rounded-full text-xs text-gray-400 whitespace-nowrap hover:border-[#00F0FF]/40 hover:text-white transition-colors"
              >
                {reply}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Input */}
      <form onSubmit={handleSubmit} className="p-4 border-t border-[#1C2A45] bg-[#080C14]">
        <div className="flex items-center gap-2">
          <button type="button" className="p-2 rounded-lg hover:bg-white/5">
            <Paperclip className="w-5 h-5 text-gray-400" />
          </button>
          <div className="flex-1 relative">
            <input
              type="text"
              value={input}
              onChange={e => setInput(e.target.value)}
              placeholder="Ketik pesan Anda..."
              className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-full py-2.5 px-4 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]"
            />
          </div>
          <button type="button" className="p-2 rounded-lg hover:bg-white/5">
            <Mic className="w-5 h-5 text-gray-400" />
          </button>
          <button
            type="submit"
            disabled={!input.trim()}
            className="p-2.5 rounded-full bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] disabled:opacity-30 transition-opacity"
          >
            <Send className="w-4 h-4 text-white" />
          </button>
        </div>
      </form>
    </div>
  );
}
