import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Mail, Lock, Eye, EyeOff, Phone, Chrome } from 'lucide-react';
import { useStore } from '@/stores/useStore';
import { useToast } from '@/hooks/use-toast';

export default function LoginPage() {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const { setUser, setIsLoggedIn, setIsAdmin } = useStore();
  const { toast } = useToast();
  const [mode, setMode] = useState<'email' | 'phone'>('email');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phone, setPhone] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    await new Promise(resolve => setTimeout(resolve, 1500));

    const mockUser = {
      uid: 'mock-user-123',
      email: mode === 'email' ? email : `user${Date.now()}@example.com`,
      displayName: 'Fahri User',
      photoURL: null,
      phoneNumber: mode === 'phone' ? phone : null,
      role: 'user' as const,
    };

    setUser(mockUser);
    setIsLoggedIn(true);
    setIsAdmin(false);
    setLoading(false);

    toast({ title: 'Login Berhasil', description: 'Selamat datang kembali!' });
    navigate('/');
  };

  const handleGoogleLogin = async () => {
    setLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1500));

    const mockUser = {
      uid: 'google-user-123',
      email: 'fahri@gmail.com',
      displayName: 'Fahri Andrian',
      photoURL: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Fahri',
      phoneNumber: null,
      role: 'user' as const,
    };

    setUser(mockUser);
    setIsLoggedIn(true);
    setIsAdmin(false);
    setLoading(false);

    toast({ title: 'Login Berhasil', description: 'Selamat datang!' });
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-[#080C14] text-white flex flex-col items-center justify-center px-6">
      {/* Logo */}
      <div className="mb-8">
        <div className="logo-icon scale-[2] mx-auto mb-4">
          <span className="block h-1 bg-gradient-to-r from-[#00F0FF] to-[#0077FF] rounded-full w-full" />
          <span className="block h-1 bg-gradient-to-r from-[#00F0FF] to-[#0077FF] rounded-full w-3/4" />
          <span className="block h-1 bg-gradient-to-r from-[#00F0FF] to-[#0077FF] rounded-full w-1/2" />
        </div>
        <h1 className="text-center text-2xl font-bold">FAHRIXZ STORE</h1>
      </div>

      <h2 className="text-lg font-medium mb-1">Masuk atau daftar</h2>
      <p className="text-gray-500 text-sm text-center mb-6 max-w-xs">
        Anda Dapat Membeli Produk Sesuai Kebutuhan Anda Dengan Aman
      </p>

      {/* Mode Toggle */}
      <div className="flex gap-2 mb-6 w-full max-w-sm">
        <button
          onClick={() => setMode('email')}
          className={`flex-1 py-2 rounded-lg text-sm font-medium transition-colors ${
            mode === 'email' ? 'bg-[#131B2D] text-white border border-[#00F0FF]/30' : 'text-gray-500'
          }`}
        >
          Email
        </button>
        <button
          onClick={() => setMode('phone')}
          className={`flex-1 py-2 rounded-lg text-sm font-medium transition-colors ${
            mode === 'phone' ? 'bg-[#131B2D] text-white border border-[#00F0FF]/30' : 'text-gray-500'
          }`}
        >
          Telepon
        </button>
      </div>

      {/* Form */}
      <form onSubmit={handleLogin} className="w-full max-w-sm space-y-4">
        {mode === 'email' ? (
          <>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input
                type="email"
                placeholder="Email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                required
                className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl py-3 pl-11 pr-4 text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]"
              />
            </div>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input
                type={showPassword ? 'text' : 'password'}
                placeholder="Kata sandi"
                value={password}
                onChange={e => setPassword(e.target.value)}
                required
                className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl py-3 pl-11 pr-11 text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2"
              >
                {showPassword ? <EyeOff className="w-5 h-5 text-gray-500" /> : <Eye className="w-5 h-5 text-gray-500" />}
              </button>
            </div>
          </>
        ) : (
          <div className="relative">
            <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
            <input
              type="tel"
              placeholder="+62 812-3456-7890"
              value={phone}
              onChange={e => setPhone(e.target.value)}
              required
              className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl py-3 pl-11 pr-4 text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]"
            />
          </div>
        )}

        <button
          type="submit"
          disabled={loading}
          className="w-full py-3 bg-white text-black rounded-full font-medium hover:bg-gray-100 transition-colors disabled:opacity-50"
        >
          {loading ? (
            <div className="w-5 h-5 border-2 border-black/30 border-t-black rounded-full animate-spin mx-auto" />
          ) : (
            'Lanjutkan'
          )}
        </button>
      </form>

      {/* Divider */}
      <div className="flex items-center gap-3 w-full max-w-sm my-6">
        <div className="flex-1 h-px bg-[#1C2A45]" />
        <span className="text-xs text-gray-500">{t('or')}</span>
        <div className="flex-1 h-px bg-[#1C2A45]" />
      </div>

      {/* Social Login */}
      <button
        onClick={handleGoogleLogin}
        disabled={loading}
        className="w-full max-w-sm flex items-center justify-center gap-2 py-3 border border-[#1C2A45] rounded-full text-white hover:bg-[#131B2D] transition-colors disabled:opacity-50"
      >
        <Chrome className="w-5 h-5" />
        <span className="text-sm">{t('google_login')}</span>
      </button>

      {/* Register Link */}
      <p className="mt-6 text-sm text-gray-500">
        Belum punya akun?{' '}
        <button onClick={() => navigate('/register')} className="text-[#00F0FF] hover:underline">
          Daftar
        </button>
      </p>

      {/* Footer */}
      <div className="mt-auto pt-8 pb-4 flex gap-4 text-xs text-gray-600">
        <span className="hover:text-gray-400 cursor-pointer">Ketentuan Penggunaan</span>
        <span className="hover:text-gray-400 cursor-pointer">Kebijakan Privasi</span>
      </div>
    </div>
  );
}
