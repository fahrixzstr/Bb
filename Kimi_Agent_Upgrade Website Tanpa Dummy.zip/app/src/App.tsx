import { lazy, Suspense, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useStore } from '@/stores/useStore';
import './lib/i18n';
import ErrorBoundary from '@/components/ErrorBoundary';
import LoadingScreen from '@/components/shared/LoadingScreen';
import AppBar from '@/components/layout/AppBar';
import BottomNav from '@/components/layout/BottomNav';
import AdminLayout from '@/components/layout/AdminLayout';

// Lazy Pages - User
const HomePage = lazy(() => import('@/pages/HomePage'));
const ProductsPage = lazy(() => import('@/pages/ProductsPage'));
const ProductDetailPage = lazy(() => import('@/pages/ProductDetailPage'));
const CartPage = lazy(() => import('@/pages/CartPage'));
const CheckoutPage = lazy(() => import('@/pages/CheckoutPage'));
const OrdersPage = lazy(() => import('@/pages/OrdersPage'));
const WalletPage = lazy(() => import('@/pages/WalletPage'));
const TopupPage = lazy(() => import('@/pages/TopupPage'));
const WithdrawPage = lazy(() => import('@/pages/WithdrawPage'));
const MissionsPage = lazy(() => import('@/pages/MissionsPage'));
const ProfilePage = lazy(() => import('@/pages/ProfilePage'));
const SettingsPage = lazy(() => import('@/pages/SettingsPage'));
const CustomerServicePage = lazy(() => import('@/pages/CustomerServicePage'));
const NotificationsPage = lazy(() => import('@/pages/NotificationsPage'));
const SearchPage = lazy(() => import('@/pages/SearchPage'));
const LoginPage = lazy(() => import('@/pages/LoginPage'));
const RegisterPage = lazy(() => import('@/pages/RegisterPage'));

// Lazy Pages - Admin
const AdminDashboard = lazy(() => import('@/pages/admin/AdminDashboard'));
const AdminProducts = lazy(() => import('@/pages/admin/AdminProducts'));
const AdminOrders = lazy(() => import('@/pages/admin/AdminOrders'));
const AdminUsers = lazy(() => import('@/pages/admin/AdminUsers'));
const AdminMissions = lazy(() => import('@/pages/admin/AdminMissions'));
const AdminLoginPage = lazy(() => import('@/pages/admin/AdminLoginPage'));

// Simple placeholder pages
const PlaceholderPage = ({ title }: { title: string }) => (
  <div className="min-h-screen bg-[#080C14] text-white flex flex-col items-center justify-center px-6">
    <h1 className="text-2xl font-bold mb-2">{title}</h1>
    <p className="text-gray-500 text-sm">Halaman ini sedang dalam pengembangan</p>
  </div>
);

const CoinsPage = () => <PlaceholderPage title="Koin Saya" />;
const AffiliatePage = () => <PlaceholderPage title="Affiliate Program" />;
const FavoritesPage = () => <PlaceholderPage title="Favorit Saya" />;
const RecentlyViewedPage = () => <PlaceholderPage title="Terakhir Dilihat" />;
const VouchersPage = () => <PlaceholderPage title="Voucher Saya" />;
const HelpPage = () => <PlaceholderPage title="Pusat Bantuan" />;
const ReportBugPage = () => <PlaceholderPage title="Lapor Bug" />;
const DonationsPage = () => <PlaceholderPage title="Donasi" />;
const EventsPage = () => <PlaceholderPage title="Event" />;

function AppContent() {
  const { theme, setTheme } = useStore();

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      theme === 'dark' ? 'bg-[#080C14] text-white' : 'bg-gray-50 text-gray-900'
    }`}>
      <Routes>
        {/* Auth Routes - No Layout */}
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/vx-admin-login" element={<AdminLoginPage />} />

        {/* Admin Routes */}
        <Route path="/admin" element={<AdminLayout />}>
          <Route index element={<AdminDashboard />} />
          <Route path="products" element={<AdminProducts />} />
          <Route path="orders" element={<AdminOrders />} />
          <Route path="users" element={<AdminUsers />} />
          <Route path="missions" element={<AdminMissions />} />
          <Route path="vouchers" element={<PlaceholderPage title="Kelola Voucher" />} />
          <Route path="donations" element={<PlaceholderPage title="Kelola Donasi" />} />
          <Route path="events" element={<PlaceholderPage title="Kelola Event" />} />
          <Route path="finance" element={<PlaceholderPage title="Keuangan" />} />
          <Route path="settings" element={<PlaceholderPage title="Pengaturan Admin" />} />
          <Route path="security" element={<PlaceholderPage title="Keamanan" />} />
          <Route path="ip" element={<PlaceholderPage title="IP Management" />} />
          <Route path="logs" element={<PlaceholderPage title="Activity Logs" />} />
          <Route path="cs" element={<PlaceholderPage title="Customer Service" />} />
        </Route>

        {/* User Routes - With Layout */}
        <Route path="*" element={
          <>
            <AppBar />
            <main>
              <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/products" element={<ProductsPage />} />
                <Route path="/products/:id" element={<ProductDetailPage />} />
                <Route path="/cart" element={<CartPage />} />
                <Route path="/checkout" element={<CheckoutPage />} />
                <Route path="/orders" element={<OrdersPage />} />
                <Route path="/wallet" element={<WalletPage />} />
                <Route path="/wallet/topup" element={<TopupPage />} />
                <Route path="/wallet/withdraw" element={<WithdrawPage />} />
                <Route path="/missions" element={<MissionsPage />} />
                <Route path="/profile" element={<ProfilePage />} />
                <Route path="/settings" element={<SettingsPage />} />
                <Route path="/customer-service" element={<CustomerServicePage />} />
                <Route path="/notifications" element={<NotificationsPage />} />
                <Route path="/search" element={<SearchPage />} />
                <Route path="/coins" element={<CoinsPage />} />
                <Route path="/affiliate" element={<AffiliatePage />} />
                <Route path="/favorites" element={<FavoritesPage />} />
                <Route path="/recently-viewed" element={<RecentlyViewedPage />} />
                <Route path="/vouchers" element={<VouchersPage />} />
                <Route path="/help" element={<HelpPage />} />
                <Route path="/report-bug" element={<ReportBugPage />} />
                <Route path="/donations" element={<DonationsPage />} />
                <Route path="/events" element={<EventsPage />} />
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </main>
            <BottomNav />
          </>
        } />
      </Routes>
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <ErrorBoundary>
        <Suspense fallback={<LoadingScreen />}>
          <AppContent />
        </Suspense>
      </ErrorBoundary>
    </BrowserRouter>
  );
}
