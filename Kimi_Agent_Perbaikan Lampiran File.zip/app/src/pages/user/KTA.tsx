import { motion } from 'framer-motion';
import { Shield, BadgeCheck, Calendar } from 'lucide-react';
import useStore from '@/stores/useStore';

export default function KTA() {
  const { user } = useStore();

  return (
    <div className="min-h-screen px-4 py-8 max-w-2xl mx-auto">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-2xl font-bold mb-6">Kartu Tanda Anggota</h1>

        <div className="bg-gradient-to-br from-purple-600 via-purple-700 to-pink-600 rounded-2xl p-6 text-white shadow-xl">
          <div className="flex items-start justify-between mb-6">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Shield className="w-5 h-5" />
                <span className="font-bold text-lg">FahriXz Store</span>
              </div>
              <p className="text-white/70 text-sm">Kartu Tanda Anggota</p>
            </div>
            <BadgeCheck className="w-8 h-8 text-yellow-300" />
          </div>

          <div className="flex items-center gap-4 mb-6">
            <div className="w-20 h-20 rounded-full bg-white/20 flex items-center justify-center text-3xl font-bold">
              {user?.photoURL ? (
                <img src={user.photoURL} alt="" className="w-20 h-20 rounded-full" />
              ) : (
                user?.displayName?.charAt(0).toUpperCase() || 'U'
              )}
            </div>
            <div>
              <h2 className="text-xl font-bold">{user?.displayName || 'Member'}</h2>
              <p className="text-white/70 text-sm">{user?.email || 'member@fahrixzstore.com'}</p>
              <span className="inline-flex items-center gap-1 text-xs bg-white/20 px-2 py-0.5 rounded-full mt-1">
                <Shield className="w-3 h-3" />
                {user?.role === 'admin' ? 'Developer' : 'Member'}
              </span>
            </div>
          </div>

          <div className="border-t border-white/20 pt-4 flex items-center justify-between text-sm">
            <div className="flex items-center gap-1 text-white/70">
              <Calendar className="w-4 h-4" />
              <span>Bergabung: {user?.createdAt ? new Date(user.createdAt).toLocaleDateString('id-ID') : '-'}</span>
            </div>
            <p className="text-white/70">ID: {user?.uid?.slice(0, 8) || 'N/A'}</p>
          </div>
        </div>

        <div className="mt-6 bg-card border border-border rounded-xl p-4">
          <h3 className="font-bold mb-2">Informasi</h3>
          <p className="text-sm text-muted-foreground">
            Kartu ini menunjukkan keanggotaan Anda di FahriXz Store. Simpan informasi ini dengan aman.
          </p>
        </div>
      </motion.div>
    </div>
  );
}
