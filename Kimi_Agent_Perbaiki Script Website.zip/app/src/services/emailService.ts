import emailjs from '@emailjs/browser';

const EMAILJS_CONFIG = {
  serviceId: import.meta.env.VITE_EMAILJS_SERVICE_ID || 'service_vbwh3ip',
  orderTemplateId: import.meta.env.VITE_EMAILJS_ORDER_TEMPLATE_ID || 'template_u0j2bvh',
  withdrawTemplateId: import.meta.env.VITE_EMAILJS_WITHDRAW_TEMPLATE_ID || 'template_k6066f7',
  publicKey: import.meta.env.VITE_EMAILJS_PUBLIC_KEY || 'g8pXvoSYyGzCMg0vo',
};

interface OrderData {
  customerName: string;
  customerEmail: string;
  orderId: string;
  productName: string;
  total: string;
  downloadLink: string;
  orderDate: string;
  snOrder?: string;
  paymentMethod?: string;
  usernamePassword?: string;
  licenseKey?: string;
  downloadFileUrl?: string;
}

interface WithdrawData {
  customerName: string;
  customerEmail: string;
  withdrawId: string;
  missionId?: string;
  missionSn?: string;
  snTransaction: string;
  serviceFee: string;
  withdrawAmount: string;
  totalReceived: string;
  withdrawDate: string;
  method: string;
  status: string;
}

export const emailService = {
  /**
   * Send order confirmation email
   */
  sendOrderConfirmation: async (orderData: OrderData): Promise<void> => {
    try {
      await emailjs.send(
        EMAILJS_CONFIG.serviceId,
        EMAILJS_CONFIG.orderTemplateId,
        {
          customer_name: orderData.customerName,
          customer_email: orderData.customerEmail,
          order_id: orderData.orderId,
          product_name: orderData.productName,
          price: orderData.total,
          download_link: orderData.downloadLink,
          order_date: orderData.orderDate,
          website_name: 'FahriXz Store',
        },
        EMAILJS_CONFIG.publicKey
      );
    } catch (error) {
      console.error('EmailJS order confirmation error:', error);
      throw error;
    }
  },

  /**
   * Send purchase invoice email with full details
   */
  sendPurchaseInvoice: async (orderData: OrderData & {
    subtotal: string;
    discount: string;
    serviceFee: string;
    productVariant?: string;
    quantity?: string;
  }): Promise<void> => {
    try {
      await emailjs.send(
        EMAILJS_CONFIG.serviceId,
        EMAILJS_CONFIG.orderTemplateId,
        {
          customer_name: orderData.customerName,
          customer_email: orderData.customerEmail,
          order_id: orderData.orderId,
          sn_order: orderData.snOrder || '',
          uid: '', // Will be filled from auth
          product_name: orderData.productName,
          product_variant: orderData.productVariant || '',
          quantity: orderData.quantity || '1',
          username_password: orderData.usernamePassword || '',
          payment_method: orderData.paymentMethod || '',
          product_price: orderData.subtotal,
          discount: orderData.discount,
          service_fee: orderData.serviceFee,
          total: orderData.total,
          payment_time: orderData.orderDate,
          order_time: orderData.orderDate,
          success_time: orderData.orderDate,
          website_name: 'FahriXz Store',
          license_key: orderData.licenseKey || '',
          download_file_url: orderData.downloadFileUrl || '',
        },
        EMAILJS_CONFIG.publicKey
      );
    } catch (error) {
      console.error('EmailJS invoice error:', error);
      throw error;
    }
  },

  /**
   * Send digital product delivery email
   */
  sendDigitalDelivery: async (orderData: OrderData & {
    licenseKey?: string;
    usernamePassword?: string;
    downloadFileUrl?: string;
  }): Promise<void> => {
    try {
      await emailjs.send(
        EMAILJS_CONFIG.serviceId,
        EMAILJS_CONFIG.orderTemplateId,
        {
          customer_name: orderData.customerName,
          customer_email: orderData.customerEmail,
          order_id: orderData.orderId,
          product_name: orderData.productName,
          license_key: orderData.licenseKey || '',
          username_password: orderData.usernamePassword || '',
          download_file_url: orderData.downloadFileUrl || '',
          download_link: orderData.downloadLink,
          website_name: 'FahriXz Store',
        },
        EMAILJS_CONFIG.publicKey
      );
    } catch (error) {
      console.error('EmailJS digital delivery error:', error);
      throw error;
    }
  },

  /**
   * Send withdraw approved email
   */
  sendWithdrawApproved: async (data: WithdrawData): Promise<void> => {
    try {
      await emailjs.send(
        EMAILJS_CONFIG.serviceId,
        EMAILJS_CONFIG.withdrawTemplateId,
        {
          customer_name: data.customerName,
          customer_email: data.customerEmail,
          withdraw_id: data.withdrawId,
          mission_id: data.missionId || '',
          mission_sn: data.missionSn || '',
          sn_transaction: data.snTransaction,
          service_fee: data.serviceFee,
          withdraw_amount: data.withdrawAmount,
          total_received: data.totalReceived,
          withdraw_date: data.withdrawDate,
          method: data.method,
          status: data.status,
          website_name: 'FahriXz Store',
        },
        EMAILJS_CONFIG.publicKey
      );
    } catch (error) {
      console.error('EmailJS withdraw approved error:', error);
      throw error;
    }
  },

  /**
   * Send withdraw rejected email
   */
  sendWithdrawRejected: async (
    withdrawData: Omit<WithdrawData, 'snTransaction' | 'serviceFee' | 'withdrawAmount' | 'totalReceived' | 'method'>,
    reason: string
  ): Promise<void> => {
    try {
      await emailjs.send(
        EMAILJS_CONFIG.serviceId,
        EMAILJS_CONFIG.withdrawTemplateId,
        {
          customer_name: withdrawData.customerName,
          customer_email: withdrawData.customerEmail,
          withdraw_id: withdrawData.withdrawId,
          reject_reason: reason,
          status: 'Ditolak',
          website_name: 'FahriXz Store',
        },
        EMAILJS_CONFIG.publicKey
      );
    } catch (error) {
      console.error('EmailJS withdraw rejected error:', error);
      throw error;
    }
  },

  /**
   * Send mission approved email
   */
  sendMissionApproved: async (
    customerName: string,
    customerEmail: string,
    missionName: string,
    coins: number
  ): Promise<void> => {
    try {
      await emailjs.send(
        EMAILJS_CONFIG.serviceId,
        EMAILJS_CONFIG.orderTemplateId,
        {
          customer_name: customerName,
          customer_email: customerEmail,
          mission_name: missionName,
          coins_earned: coins.toString(),
          website_name: 'FahriXz Store',
        },
        EMAILJS_CONFIG.publicKey
      );
    } catch (error) {
      console.error('EmailJS mission approved error:', error);
      throw error;
    }
  },

  /**
   * Send mission rejected email
   */
  sendMissionRejected: async (
    customerName: string,
    customerEmail: string,
    missionName: string,
    reason: string
  ): Promise<void> => {
    try {
      await emailjs.send(
        EMAILJS_CONFIG.serviceId,
        EMAILJS_CONFIG.orderTemplateId,
        {
          customer_name: customerName,
          customer_email: customerEmail,
          mission_name: missionName,
          reject_reason: reason,
          website_name: 'FahriXz Store',
        },
        EMAILJS_CONFIG.publicKey
      );
    } catch (error) {
      console.error('EmailJS mission rejected error:', error);
      throw error;
    }
  },
};

export default emailService;
