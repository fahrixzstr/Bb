/**
 * FASPAY SERVICE - Payment Gateway Integration
 * 
 * TODO: Isi konfigurasi Faspay Anda di bawah ini:
 * - VITE_FASPAY_MERCHANT_ID: Merchant ID dari Faspay
 * - VITE_FASPAY_MERCHANT_NAME: Nama merchant
 * - VITE_FASPAY_PASSWORD: Password merchant
 * - VITE_FASPAY_CLIENT_ID: Client ID (untuk API v2)
 * 
 * Untuk development/testing:
 * 1. Daftar akun di https://faspay.co.id
 * 2. Dapatkan credentials sandbox
 * 3. Isi environment variables di Vercel
 */

const FASPAY_CONFIG = {
  merchantId: import.meta.env.VITE_FASPAY_MERCHANT_ID || '',
  merchantName: import.meta.env.VITE_FASPAY_MERCHANT_NAME || '',
  password: import.meta.env.VITE_FASPAY_PASSWORD || '',
  clientId: import.meta.env.VITE_FASPAY_CLIENT_ID || '',
  // Sandbox URL for testing
  sandboxUrl: 'https://fpg.faspay.co.id/payment',
  // Production URL
  productionUrl: 'https://fpg.faspay.co.id/payment',
};

export interface FaspayPaymentRequest {
  orderId: string;
  amount: number;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  returnUrl: string;
  callbackUrl: string;
  description?: string;
}

export interface FaspayPaymentResponse {
  paymentUrl: string;
  transactionId: string;
  status: string;
}

export const faspayService = {
  /**
   * Generate signature for Faspay API
   */
  generateSignature: (orderId: string, amount: number, timestamp: string): string => {
    // TODO: Implement Faspay signature generation
    // Format: SHA1(merchantId + password + orderId + amount + timestamp)
    return '';
  },

  /**
   * Create payment and get payment URL
   */
  createPayment: async (request: FaspayPaymentRequest): Promise<FaspayPaymentResponse> => {
    if (!FASPAY_CONFIG.merchantId || !FASPAY_CONFIG.password) {
      throw new Error('Faspay credentials not configured. Please set VITE_FASPAY_MERCHANT_ID and VITE_FASPAY_PASSWORD in environment variables.');
    }

    // TODO: Implement Faspay API call
    // 1. POST to /cvr/100001 (create payment)
    // 2. Parse response
    // 3. Return payment URL

    // Placeholder response
    return {
      paymentUrl: '',
      transactionId: '',
      status: 'pending',
    };
  },

  /**
   * Check payment status
   */
  checkPaymentStatus: async (transactionId: string): Promise<string> => {
    // TODO: Implement status check
    return 'pending';
  },

  /**
   * Parse callback/webhook from Faspay
   */
  parseCallback: (data: Record<string, any>) => {
    return {
      transactionId: data.trx_id || '',
      orderId: data.order_id || '',
      status: data.payment_status || '',
      paymentMethod: data.payment_channel || '',
      paidAt: data.payment_date || null,
      amount: parseFloat(data.amount) || 0,
    };
  },

  /**
   * Get available payment channels
   */
  getPaymentChannels: () => [
    { id: 'va_bca', name: 'BCA Virtual Account', icon: '/payment/bca.png', category: 'va' },
    { id: 'va_mandiri', name: 'Mandiri Virtual Account', icon: '/payment/mandiri.png', category: 'va' },
    { id: 'va_bni', name: 'BNI Virtual Account', icon: '/payment/bni.png', category: 'va' },
    { id: 'va_bri', name: 'BRI Virtual Account', icon: '/payment/bri.png', category: 'va' },
    { id: 'ewallet_ovo', name: 'OVO', icon: '/payment/ovo.png', category: 'ewallet' },
    { id: 'ewallet_gopay', name: 'GoPay', icon: '/payment/gopay.png', category: 'ewallet' },
    { id: 'ewallet_dana', name: 'DANA', icon: '/payment/dana.png', category: 'ewallet' },
    { id: 'ewallet_shopeepay', name: 'ShopeePay', icon: '/payment/shopeepay.png', category: 'ewallet' },
    { id: 'qris', name: 'QRIS', icon: '/payment/qris.png', category: 'qris' },
    { id: 'cc_visa', name: 'Visa', icon: '/payment/visa.png', category: 'cc' },
    { id: 'cc_mastercard', name: 'Mastercard', icon: '/payment/mastercard.png', category: 'cc' },
  ],
};

export default faspayService;
