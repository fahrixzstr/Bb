import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Heart, ShoppingCart, Trash2, Star } from 'lucide-react';
import useStore from '@/stores/useStore';
import SEO from '@/components/shared/SEO';
import EmptyState from '@/components/shared/EmptyState';
import { toast } from 'sonner';

export default function Wishlist() {
  const { wishlist, toggleWishlist, addToCart } = useStore();
  const [products, setProducts] = useState<any[]>([]);

  // TODO: Fetch actual product data from Firestore based on wishlist IDs
  useEffect(() => {
    setProducts([]);
  }, [wishlist]);

  const handleAddToCart = (product: any) => {
    addToCart({
      productId: product.id,
      product,
      quantity: 1,
      addedAt: new Date(),
    });
    toast.success('Produk ditambahkan ke keranjang');
  };

  // If wishlist is empty (no product data available yet)
  if (wishlist.length === 0 || products.length === 0) {
    return (
      <>
        <SEO title="Wishlist" url="/wishlist" />
        <div className="min-h-screen px-4 py-6 max-w-6xl mx-auto">
          <h1 className="text-2xl font-bold mb-6">Wishlist Saya</h1>
          <EmptyState
            type="wishlist"
            customDescription={wishlist.length > 0 ? 'Memuat produk...' : undefined}
          />
        </div>
      </>
    );
  }

  return (
    <>
      <SEO title="Wishlist" url="/wishlist" />
      <div className="min-h-screen px-4 py-6 max-w-6xl mx-auto">
        <h1 className="text-2xl font-bold mb-6">Wishlist Saya ({wishlist.length})</h1>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {products.map((product, i) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="bg-card border border-border rounded-xl overflow-hidden group"
            >
              <Link to={`/products/${product.id}`} className="block relative">
                <div className="aspect-square bg-muted">
                  <img
                    src={product.coverImages?.[0] || '/placeholder-product.png'}
                    alt={product.name}
                    className="w-full h-full object-cover"
                    loading="lazy"
                  />
                </div>
              </Link>
              <div className="p-3">
                <Link to={`/products/${product.id}`}>
                  <h3 className="text-sm font-medium line-clamp-2 mb-2 hover:text-purple-500 transition-colors">
                    {product.name}
                  </h3>
                </Link>
                <div className="flex items-center gap-1 mb-2">
                  <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />
                  <span className="text-xs text-muted-foreground">{product.rating || 0}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-purple-600 dark:text-purple-400">
                    Rp {(product.discountPrice || product.price).toLocaleString('id-ID')}
                  </span>
                </div>
                <div className="flex gap-2 mt-3">
                  <button
                    onClick={() => handleAddToCart(product)}
                    className="flex-1 flex items-center justify-center gap-1 bg-purple-600 hover:bg-purple-700 text-white py-2 rounded-lg text-xs transition-colors"
                  >
                    <ShoppingCart className="w-3 h-3" />
                    Beli
                  </button>
                  <button
                    onClick={() => {
                      toggleWishlist(product.id);
                      toast.success('Dihapus dari wishlist');
                    }}
                    className="p-2 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </>
  );
}
