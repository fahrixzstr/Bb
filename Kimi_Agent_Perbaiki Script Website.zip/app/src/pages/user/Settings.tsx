import { useState } from 'react';
import { motion } from 'framer-motion';
import { User, Lock, Bell, Moon, Sun, Trash2, Save, Download, AlertTriangle, ChevronRight } from 'lucide-react';
import useStore from '@/stores/useStore';
import authService from '@/services/auth';
import { toast } from 'sonner';
import SEO from '@/components/shared/SEO';

type Tab = 'profile' | 'security' | 'notifications' | 'appearance';

export default function Settings() {
  const { user, theme, toggleTheme, logout } = useStore();
  const [activeTab, setActiveTab] = useState<Tab>('profile');
  const [displayName, setDisplayName] = useState(user?.displayName || '');
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [saving, setSaving] = useState(false);
  const [notifications, setNotifications] = useState({
    order: true,
    promo: true,
    mission: true,
  });
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const handleUpdateProfile = async () => {
    if (!displayName.trim()) {
      toast.error('Nama tidak boleh kosong');
      return;
    }
    setSaving(true);
    try {
      await authService.updateUserProfile({ displayName: displayName.trim() });
      toast.success('Profil berhasil diperbarui');
    } catch (error: any) {
      toast.error(error.message || 'Gagal memperbarui profil');
    } finally { setSaving(false); }
  };

  const handleUpdatePassword = async () => {
    if (newPassword !== confirmPassword) {
      toast.error('Password tidak cocok');
      return;
    }
    if (newPassword.length < 6) {
      toast.error('Password minimal 6 karakter');
      return;
    }
    setSaving(true);
    try {
      await authService.updateUserPassword(newPassword);
      toast.success('Password berhasil diperbarui');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (error: any) {
      toast.error(error.message || 'Gagal memperbarui password');
    } finally { setSaving(false); }
  };

  const handleDeleteAccount = async () => {
    try {
      await authService.deleteAccount();
      logout();
      toast.success('Akun berhasil dihapus');
    } catch (error: any) {
      toast.error(error.message || 'Gagal menghapus akun');
    }
  };

  const handleExportData = () => {
    const data = {
      profile: {
        uid: user?.uid,
        email: user?.email,
        displayName: user?.displayName,
        photoURL: user?.photoURL,
        phoneNumber: user?.phoneNumber,
        emailVerified: user?.emailVerified,
        providers: user?.providers,
        createdAt: user?.createdAt,
      },
      exportDate: new Date().toISOString(),
      website: 'FahriXz Store',
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `data-saya-fahrixzstore-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    toast.success('Data berhasil diunduh');
  };

  const tabs: { id: Tab; label: string; icon: typeof User }[] = [
    { id: 'profile', label: 'Profil', icon: User },
    { id: 'security', label: 'Keamanan', icon: Lock },
    { id: 'notifications', label: 'Notifikasi', icon: Bell },
    { id: 'appearance', label: 'Tampilan', icon: Moon },
  ];

  return (
    <>
      <SEO title="Pengaturan" url="/settings" />
      <div className="min-h-screen px-4 py-6 max-w-4xl mx-auto">
        <h1 className="text-2xl font-bold mb-6">Pengaturan</h1>

        <div className="grid md:grid-cols-4 gap-6">
          {/* Sidebar */}
          <div className="md:col-span-1">
            <div className="bg-card border border-border rounded-xl p-2 space-y-1">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors ${
                    activeTab === tab.id
                      ? 'bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300 font-medium'
                      : 'hover:bg-muted text-muted-foreground'
                  }`}
                >
                  <tab.icon className="w-4 h-4" />
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Danger Zone */}
            <div className="mt-4 bg-card border border-red-200 dark:border-red-900/50 rounded-xl p-4">
              <h3 className="text-sm font-medium text-red-600 dark:text-red-400 mb-2 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4" />
                Zona Berbahaya
              </h3>
              <button
                onClick={handleExportData}
                className="w-full flex items-center gap-2 px-3 py-2 text-sm text-muted-foreground hover:bg-muted rounded-lg transition-colors mb-2"
              >
                <Download className="w-4 h-4" />
                Download Data Saya
              </button>
              <button
                onClick={() => setShowDeleteConfirm(true)}
                className="w-full flex items-center gap-2 px-3 py-2 text-sm text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
              >
                <Trash2 className="w-4 h-4" />
                Hapus Akun
              </button>
            </div>
          </div>

          {/* Content */}
          <div className="md:col-span-3">
            {activeTab === 'profile' && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-card border border-border rounded-xl p-6"
              >
                <h2 className="font-bold mb-4">Profil</h2>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium mb-1.5 block">Email</label>
                    <input
                      type="email"
                      value={user?.email || ''}
                      readOnly
                      className="w-full px-3 py-2.5 bg-muted border border-border rounded-lg text-sm text-muted-foreground"
                    />
                    <p className="text-xs text-muted-foreground mt-1">Email tidak dapat diubah</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-1.5 block">Nama Lengkap</label>
                    <input
                      type="text"
                      value={displayName}
                      onChange={(e) => setDisplayName(e.target.value)}
                      placeholder="Nama Anda"
                      className="w-full px-3 py-2.5 bg-background border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                    />
                  </div>
                  <button
                    onClick={handleUpdateProfile}
                    disabled={saving}
                    className="flex items-center gap-2 bg-purple-600 hover:bg-purple-700 disabled:opacity-50 text-white px-4 py-2.5 rounded-xl text-sm transition-colors"
                  >
                    {saving ? 'Menyimpan...' : <><Save className="w-4 h-4" /> Simpan</>}
                  </button>
                </div>
              </motion.div>
            )}

            {activeTab === 'security' && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-card border border-border rounded-xl p-6"
              >
                <h2 className="font-bold mb-4">Keamanan</h2>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium mb-1.5 block">Password Baru</label>
                    <input
                      type="password"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="Minimal 6 karakter"
                      className="w-full px-3 py-2.5 bg-background border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-1.5 block">Konfirmasi Password Baru</label>
                    <input
                      type="password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="Ulangi password baru"
                      className="w-full px-3 py-2.5 bg-background border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                    />
                  </div>
                  <button
                    onClick={handleUpdatePassword}
                    disabled={saving}
                    className="flex items-center gap-2 bg-purple-600 hover:bg-purple-700 disabled:opacity-50 text-white px-4 py-2.5 rounded-xl text-sm transition-colors"
                  >
                    {saving ? 'Menyimpan...' : <><Lock className="w-4 h-4" /> Update Password</>}
                  </button>
                </div>
              </motion.div>
            )}

            {activeTab === 'notifications' && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-card border border-border rounded-xl p-6"
              >
                <h2 className="font-bold mb-4">Notifikasi</h2>
                <div className="space-y-4">
                  {[
                    { key: 'order', label: 'Pesanan', desc: 'Notifikasi status pesanan' },
                    { key: 'promo', label: 'Promo', desc: 'Info promo dan diskon' },
                    { key: 'mission', label: 'Misi', desc: 'Update status misi' },
                  ].map((item) => (
                    <div key={item.key} className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-sm">{item.label}</p>
                        <p className="text-xs text-muted-foreground">{item.desc}</p>
                      </div>
                      <button
                        onClick={() => setNotifications({ ...notifications, [item.key]: !notifications[item.key as keyof typeof notifications] })}
                        className={`w-11 h-6 rounded-full transition-colors relative ${
                          notifications[item.key as keyof typeof notifications] ? 'bg-purple-600' : 'bg-muted'
                        }`}
                      >
                        <div className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-all ${
                          notifications[item.key as keyof typeof notifications] ? 'left-6' : 'left-1'
                        }`} />
                      </button>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {activeTab === 'appearance' && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-card border border-border rounded-xl p-6"
              >
                <h2 className="font-bold mb-4">Tampilan</h2>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      {theme === 'dark' ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
                      <div>
                        <p className="font-medium text-sm">Mode {theme === 'dark' ? 'Gelap' : 'Terang'}</p>
                        <p className="text-xs text-muted-foreground">Ubah tema tampilan</p>
                      </div>
                    </div>
                    <button
                      onClick={toggleTheme}
                      className={`w-11 h-6 rounded-full transition-colors relative ${
                        theme === 'dark' ? 'bg-purple-600' : 'bg-muted'
                      }`}
                    >
                      <div className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-all ${
                        theme === 'dark' ? 'left-6' : 'left-1'
                      }`} />
                    </button>
                  </div>
                </div>
              </motion.div>
            )}
          </div>
        </div>

        {/* Delete Account Confirm Dialog */}
        {showDeleteConfirm && (
          <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center px-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-card border border-border rounded-2xl p-6 max-w-md w-full"
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center">
                  <AlertTriangle className="w-5 h-5 text-red-600 dark:text-red-400" />
                </div>
                <h3 className="font-bold">Hapus Akun?</h3>
              </div>
              <p className="text-sm text-muted-foreground mb-6">
                Tindakan ini tidak dapat dibatalkan. Semua data Anda akan dihapus permanen. 
                Pastikan Anda telah mengunduh data penting.
              </p>
              <div className="flex gap-3">
                <button
                  onClick={() => setShowDeleteConfirm(false)}
                  className="flex-1 py-2.5 border border-border hover:bg-muted rounded-xl text-sm transition-colors"
                >
                  Batal
                </button>
                <button
                  onClick={handleDeleteAccount}
                  className="flex-1 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-sm transition-colors"
                >
                  Hapus Akun
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </div>
    </>
  );
}
