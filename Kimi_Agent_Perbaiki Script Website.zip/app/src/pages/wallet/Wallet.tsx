import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Wallet as WalletIcon, Coins, ArrowDownLeft, ArrowUpRight, Clock, ChevronRight } from 'lucide-react';
import useStore from '@/stores/useStore';
import SEO from '@/components/shared/SEO';
import EmptyState from '@/components/shared/EmptyState';

// Mock transaction data - will be replaced with Firestore fetch
interface Transaction {
  id: string;
  type: 'coin_exchange' | 'withdraw' | 'reward' | 'purchase';
  amount: number;
  description: string;
  status: 'completed' | 'pending' | 'failed';
  createdAt: Date;
}

export default function Wallet() {
  const { user } = useStore();
  const [balance, setBalance] = useState(0);
  const [coins, setCoins] = useState(0);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [filter, setFilter] = useState<string>('all');

  useEffect(() => {
    // TODO: Fetch wallet data from Firestore
    // Mock data for now
    setBalance(0);
    setCoins(0);
    setTransactions([]);
  }, [user]);

  const filteredTransactions = filter === 'all'
    ? transactions
    : transactions.filter((t) => t.type === filter);

  const coinRate = 15; // 15 coins = Rp 1
  const coinValue = Math.floor(coins / coinRate);

  return (
    <>
      <SEO title="Dompet" url="/wallet" />
      <div className="min-h-screen px-4 py-6 max-w-4xl mx-auto">
        {/* Header Cards */}
        <div className="grid md:grid-cols-2 gap-4 mb-6">
          {/* Balance Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gradient-to-br from-purple-600 to-blue-600 rounded-2xl p-6 text-white"
          >
            <div className="flex items-center gap-2 mb-2">
              <WalletIcon className="w-5 h-5" />
              <span className="text-white/80 text-sm">Saldo</span>
            </div>
            <p className="text-3xl font-bold mb-4">
              Rp {balance.toLocaleString('id-ID')}
            </p>
            <Link
              to="/wallet/withdraw"
              className="inline-flex items-center gap-2 bg-white/20 hover:bg-white/30 text-white px-4 py-2 rounded-xl text-sm transition-colors"
            >
              <ArrowUpRight className="w-4 h-4" />
              Tarik Saldo
            </Link>
          </motion.div>

          {/* Coins Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-gradient-to-br from-yellow-500 to-orange-500 rounded-2xl p-6 text-white"
          >
            <div className="flex items-center gap-2 mb-2">
              <Coins className="w-5 h-5" />
              <span className="text-white/80 text-sm">Koin</span>
            </div>
            <p className="text-3xl font-bold mb-1">
              {coins.toLocaleString('id-ID')} Koin
            </p>
            <p className="text-white/80 text-sm mb-4">
              = Rp {coinValue.toLocaleString('id-ID')} ({coinRate} koin = Rp 1)
            </p>
            <button
              onClick={() => {
                if (coins < 150) {
                  // Show exchange modal - TODO
                  return;
                }
                // Exchange coins - TODO
              }}
              className="inline-flex items-center gap-2 bg-white/20 hover:bg-white/30 text-white px-4 py-2 rounded-xl text-sm transition-colors"
            >
              <ArrowDownLeft className="w-4 h-4" />
              Tukar Koin
            </button>
          </motion.div>
        </div>

        {/* Transactions */}
        <div className="bg-card border border-border rounded-xl">
          <div className="p-4 border-b border-border flex items-center justify-between">
            <h2 className="font-bold">Riwayat Transaksi</h2>
            <div className="flex gap-1">
              {['all', 'coin_exchange', 'withdraw', 'reward'].map((f) => (
                <button
                  key={f}
                  onClick={() => setFilter(f)}
                  className={`px-3 py-1 rounded-lg text-xs transition-colors ${
                    filter === f
                      ? 'bg-purple-600 text-white'
                      : 'hover:bg-muted'
                  }`}
                >
                  {f === 'all' ? 'Semua' : f === 'coin_exchange' ? 'Tukar' : f === 'withdraw' ? 'Tarik' : 'Reward'}
                </button>
              ))}
            </div>
          </div>

          {filteredTransactions.length > 0 ? (
            <div className="divide-y divide-border">
              {filteredTransactions.map((t) => (
                <div key={t.id} className="p-4 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      t.type === 'coin_exchange' ? 'bg-blue-100 text-blue-600' :
                      t.type === 'withdraw' ? 'bg-red-100 text-red-600' :
                      t.type === 'reward' ? 'bg-green-100 text-green-600' :
                      'bg-purple-100 text-purple-600'
                    }`}>
                      {t.type === 'coin_exchange' ? <Coins className="w-4 h-4" /> :
                       t.type === 'withdraw' ? <ArrowUpRight className="w-4 h-4" /> :
                       t.type === 'reward' ? <Coins className="w-4 h-4" /> :
                       <WalletIcon className="w-4 h-4" />}
                    </div>
                    <div>
                      <p className="text-sm font-medium">{t.description}</p>
                      <p className="text-xs text-muted-foreground">
                        {t.createdAt.toLocaleDateString('id-ID')}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`text-sm font-medium ${
                      t.type === 'withdraw' || t.type === 'purchase' ? 'text-red-500' : 'text-green-500'
                    }`}>
                      {t.type === 'withdraw' || t.type === 'purchase' ? '-' : '+'}{' '}
                      Rp {t.amount.toLocaleString('id-ID')}
                    </p>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${
                      t.status === 'completed' ? 'bg-green-100 text-green-700' :
                      t.status === 'pending' ? 'bg-yellow-100 text-yellow-700' :
                      'bg-red-100 text-red-700'
                    }`}>
                      {t.status === 'completed' ? 'Selesai' : t.status === 'pending' ? 'Proses' : 'Gagal'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <EmptyState type="wallet" />
          )}
        </div>

        {/* Info */}
        <div className="mt-6 bg-muted/30 rounded-xl p-4">
          <div className="flex items-start gap-3">
            <Clock className="w-5 h-5 text-muted-foreground flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-medium mb-1">Informasi</p>
              <p className="text-xs text-muted-foreground">
                Koin didapat dari menyelesaikan misi. Minimal 150 koin untuk ditukar. 
                Penarikan saldo membutuhkan waktu paling lambat 7 hari kerja.
                <Link to="/missions" className="text-purple-600 hover:underline ml-1">
                  Lihat Misi <ChevronRight className="w-3 h-3 inline" />
                </Link>
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
