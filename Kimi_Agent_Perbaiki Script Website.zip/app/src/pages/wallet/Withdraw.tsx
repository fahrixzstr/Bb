import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, ArrowUpRight, Banknote, CreditCard, Wallet } from 'lucide-react';
import { toast } from 'sonner';
import SEO from '@/components/shared/SEO';

const banks = ['BCA', 'Mandiri', 'BNI', 'BRI'];
const ewallets = ['OVO', 'GoPay', 'DANA', 'ShopeePay'];

export default function Withdraw() {
  const navigate = useNavigate();
  const [method, setMethod] = useState<'bank' | 'ewallet'>('bank');
  const [selectedBank, setSelectedBank] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [accountName, setAccountName] = useState('');
  const [amount, setAmount] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!selectedBank || !accountNumber || !accountName || !amount) {
      toast.error('Harap isi semua field');
      return;
    }

    const numAmount = Number(amount);
    if (numAmount < 10000) {
      toast.error('Minimal penarikan Rp 10.000');
      return;
    }

    setIsSubmitting(true);

    // TODO: Submit to Firestore withdraw_requests
    // Generate withdraw ID
    const withdrawId = `WD-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;

    await new Promise((resolve) => setTimeout(resolve, 1000));

    toast.success('Permintaan withdraw berhasil diajukan!');
    navigate('/wallet');
  };

  return (
    <>
      <SEO title="Tarik Saldo" url="/wallet/withdraw" />
      <div className="min-h-screen px-4 py-6 max-w-lg mx-auto">
        <button
          onClick={() => navigate('/wallet')}
          className="flex items-center gap-2 text-muted-foreground hover:text-foreground mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          Kembali
        </button>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <h1 className="text-2xl font-bold mb-2">Tarik Saldo</h1>
          <p className="text-muted-foreground text-sm mb-6">
            Penarikan diproses dalam 7 hari kerja
          </p>

          {/* Method Selection */}
          <div className="flex gap-2 mb-6">
            <button
              onClick={() => setMethod('bank')}
              className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl border transition-all ${
                method === 'bank'
                  ? 'border-purple-600 bg-purple-50 dark:bg-purple-900/20 text-purple-600'
                  : 'border-border hover:bg-muted'
              }`}
            >
              <Banknote className="w-4 h-4" />
              <span className="text-sm font-medium">Bank</span>
            </button>
            <button
              onClick={() => setMethod('ewallet')}
              className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl border transition-all ${
                method === 'ewallet'
                  ? 'border-purple-600 bg-purple-50 dark:bg-purple-900/20 text-purple-600'
                  : 'border-border hover:bg-muted'
              }`}
            >
              <CreditCard className="w-4 h-4" />
              <span className="text-sm font-medium">E-Wallet</span>
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Bank/E-Wallet Selection */}
            <div>
              <label className="text-sm font-medium mb-1.5 block">
                {method === 'bank' ? 'Pilih Bank' : 'Pilih E-Wallet'}
              </label>
              <div className="grid grid-cols-2 gap-2">
                {(method === 'bank' ? banks : ewallets).map((b) => (
                  <button
                    key={b}
                    type="button"
                    onClick={() => setSelectedBank(b)}
                    className={`py-2.5 rounded-lg border text-sm transition-all ${
                      selectedBank === b
                        ? 'border-purple-600 bg-purple-50 dark:bg-purple-900/20 text-purple-600'
                        : 'border-border hover:bg-muted'
                    }`}
                  >
                    {b}
                  </button>
                ))}
              </div>
            </div>

            {/* Account Number */}
            <div>
              <label className="text-sm font-medium mb-1.5 block">
                {method === 'bank' ? 'Nomor Rekening' : 'Nomor {method === "bank" ? "Rekening" : "E-Wallet"}'}
              </label>
              <input
                type="text"
                value={accountNumber}
                onChange={(e) => setAccountNumber(e.target.value.replace(/\D/g, ''))}
                placeholder={method === 'bank' ? '1234567890' : '08123456789'}
                className="w-full px-3 py-2.5 bg-background border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>

            {/* Account Name */}
            <div>
              <label className="text-sm font-medium mb-1.5 block">
                Nama Pemilik {method === 'bank' ? 'Rekening' : 'E-Wallet'}
              </label>
              <input
                type="text"
                value={accountName}
                onChange={(e) => setAccountName(e.target.value)}
                placeholder="Nama lengkap"
                className="w-full px-3 py-2.5 bg-background border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>

            {/* Amount */}
            <div>
              <label className="text-sm font-medium mb-1.5 block">Jumlah Penarikan</label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">Rp</span>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="10000"
                  min="10000"
                  className="w-full pl-10 pr-4 py-2.5 bg-background border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>
              <p className="text-xs text-muted-foreground mt-1">Minimal Rp 10.000</p>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full flex items-center justify-center gap-2 bg-purple-600 hover:bg-purple-700 disabled:opacity-50 text-white py-3 rounded-xl font-medium transition-colors"
            >
              {isSubmitting ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <ArrowUpRight className="w-4 h-4" />
              )}
              Ajukan Penarikan
            </button>
          </form>
        </motion.div>
      </div>
    </>
  );
}
