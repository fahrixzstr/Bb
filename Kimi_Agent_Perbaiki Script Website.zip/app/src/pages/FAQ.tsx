import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, HelpCircle } from 'lucide-react';
import SEO from '@/components/shared/SEO';

const faqs = [
  {
    question: 'Bagaimana cara membeli produk?',
    answer: 'Pilih produk yang Anda inginkan, tambahkan ke keranjang, lalu lanjutkan ke checkout. Setelah pembayaran berhasil, produk akan dikirim otomatis ke email Anda.',
  },
  {
    question: 'Metode pembayaran apa saja yang tersedia?',
    answer: 'Kami menerima pembayaran melalui Faspay Payment Gateway yang mendukung Virtual Account (BCA, Mandiri, BNI, BRI), E-Wallet (OVO, GoPay, DANA, ShopeePay), QRIS, dan Kartu Kredit (Visa, Mastercard).',
  },
  {
    question: 'Apakah ada garansi dan refund?',
    answer: 'Ya, kami menyediakan garansi uang kembali selama 7 hari jika produk tidak sesuai deskripsi atau mengalami masalah teknis. Anda dapat mengajukan refund melalui halaman pesanan.',
  },
  {
    question: 'Bagaimana proses pengiriman produk digital?',
    answer: 'Produk digital dikirim secara otomatis ke email Anda setelah pembayaran terverifikasi. Email berisi link download dan license key (jika diperlukan) yang aktif selama 7 hari.',
  },
  {
    question: 'Bagaimana jika lupa password?',
    answer: 'Klik "Lupa password?" di halaman login, masukkan email Anda, dan kami akan mengirimkan link reset password ke email tersebut.',
  },
  {
    question: 'Bagaimana cara menghubungi support?',
    answer: 'Anda dapat menghubungi kami melalui WhatsApp di 0856-0994-9819 atau email ke fahrixzstore@gmail.com. Tim support kami tersedia setiap hari pukul 08:00 - 22:00 WIB.',
  },
  {
    question: 'Bagaimana cara kerja misi dan koin?',
    answer: 'Selesaikan misi yang tersedia untuk mendapatkan koin. Setiap misi memiliki reward koin yang berbeda. Koin dapat ditukar menjadi saldo (15 koin = Rp 1) yang bisa ditarik ke rekening bank atau e-wallet.',
  },
  {
    question: 'Bagaimana cara tukar koin dan withdraw?',
    answer: 'Buka halaman Wallet, pilih "Tukar Koin", masukkan jumlah koin (minimal 150 koin), lalu konfirmasi. Untuk withdraw, pilih "Tarik Saldo", isi detail rekening, dan ajukan penarikan. Proses withdraw memerlukan approval admin dan estimasi 7 hari kerja.',
  },
  {
    question: 'Berapa estimasi waktu withdraw?',
    answer: 'Proses withdraw membutuhkan waktu paling lambat 7 hari kerja setelah pengajuan. Tim kami akan meninjau dan memproses penarikan Anda secepatnya.',
  },
  {
    question: 'Bagaimana cara verifikasi email?',
    answer: 'Saat mendaftar, email verifikasi akan dikirim otomatis. Klik link di email tersebut untuk verifikasi. Jika tidak menemukan email, periksa folder spam atau kirim ulang dari halaman pengaturan.',
  },
];

function FAQItem({ question, answer, isOpen, onClick }: { question: string; answer: string; isOpen: boolean; onClick: () => void }) {
  return (
    <div className="border border-border rounded-xl overflow-hidden">
      <button
        onClick={onClick}
        className="w-full flex items-center justify-between p-4 text-left hover:bg-muted/50 transition-colors"
      >
        <span className="font-medium text-sm pr-4">{question}</span>
        <ChevronDown className={`w-4 h-4 flex-shrink-0 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4 text-sm text-muted-foreground leading-relaxed">
              {answer}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <>
      <SEO title="FAQ - Pertanyaan Umum" url="/faq" />
      <div className="min-h-screen px-4 py-8 max-w-3xl mx-auto">
        <div className="text-center mb-8">
          <HelpCircle className="w-12 h-12 text-purple-600 mx-auto mb-3" />
          <h1 className="text-2xl font-bold mb-2">Pertanyaan Umum (FAQ)</h1>
          <p className="text-muted-foreground text-sm">
            Temukan jawaban untuk pertanyaan yang sering ditanyakan
          </p>
        </div>

        <div className="space-y-3">
          {faqs.map((faq, i) => (
            <FAQItem
              key={i}
              question={faq.question}
              answer={faq.answer}
              isOpen={openIndex === i}
              onClick={() => setOpenIndex(openIndex === i ? null : i)}
            />
          ))}
        </div>
      </div>
    </>
  );
}
