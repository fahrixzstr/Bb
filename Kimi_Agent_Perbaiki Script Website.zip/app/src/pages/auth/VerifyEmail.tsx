import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Mail, CheckCircle, Loader2, Send } from 'lucide-react';
import { auth } from '@/lib/firebase';
import { sendEmailVerification } from 'firebase/auth';
import { toast } from 'sonner';
import SEO from '@/components/shared/SEO';

export default function VerifyEmail() {
  const [isVerified, setIsVerified] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [countdown, setCountdown] = useState(0);

  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [countdown]);

  const handleResend = async () => {
    if (!auth?.currentUser) {
      toast.error('Silakan login terlebih dahulu');
      return;
    }

    setIsSending(true);
    try {
      await sendEmailVerification(auth.currentUser);
      toast.success('Email verifikasi berhasil dikirim ulang!');
      setCountdown(60);
    } catch (error: any) {
      toast.error(error.message || 'Gagal mengirim email verifikasi');
    } finally {
      setIsSending(false);
    }
  };

  const checkVerification = () => {
    auth?.currentUser?.reload().then(() => {
      if (auth.currentUser?.emailVerified) {
        setIsVerified(true);
        toast.success('Email berhasil diverifikasi!');
      } else {
        toast.info('Email belum diverifikasi. Periksa inbox Anda.');
      }
    });
  };

  return (
    <>
      <SEO title="Verifikasi Email" />
      <div className="min-h-screen flex items-center justify-center px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-md w-full text-center"
        >
          {isVerified ? (
            <div className="space-y-4">
              <div className="w-16 h-16 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle className="w-8 h-8 text-green-600 dark:text-green-400" />
              </div>
              <h1 className="text-2xl font-bold">Verifikasi Berhasil!</h1>
              <p className="text-muted-foreground">
                Email Anda telah berhasil diverifikasi. Sekarang Anda dapat melanjutkan belanja.
              </p>
              <Link
                to="/"
                className="inline-flex items-center gap-2 bg-purple-600 hover:bg-purple-700 text-white px-6 py-2.5 rounded-xl transition-colors"
              >
                Kembali ke Beranda
              </Link>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="w-16 h-16 bg-purple-100 dark:bg-purple-900/30 rounded-full flex items-center justify-center mx-auto">
                <Mail className="w-8 h-8 text-purple-600 dark:text-purple-400" />
              </div>
              <h1 className="text-2xl font-bold">Verifikasi Email Anda</h1>
              <p className="text-muted-foreground">
                Kami telah mengirimkan link verifikasi ke email Anda. 
                Silakan periksa inbox atau folder spam, lalu klik link tersebut.
              </p>

              <div className="bg-card border border-border rounded-xl p-4 text-left">
                <p className="text-sm font-medium mb-1">Langkah-langkah:</p>
                <ol className="text-sm text-muted-foreground space-y-1 list-decimal list-inside">
                  <li>Buka email dari FahriXz Store</li>
                  <li>Klik tombol "Verifikasi Email"</li>
                  <li>Kembali ke halaman ini dan klik "Cek Status"</li>
                </ol>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={checkVerification}
                  className="flex-1 bg-purple-600 hover:bg-purple-700 text-white py-2.5 rounded-xl transition-colors text-sm"
                >
                  Cek Status
                </button>
                <button
                  onClick={handleResend}
                  disabled={isSending || countdown > 0}
                  className="flex items-center gap-2 px-4 py-2.5 border border-border hover:bg-muted rounded-xl transition-colors text-sm disabled:opacity-50"
                >
                  {isSending ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Send className="w-4 h-4" />
                  )}
                  {countdown > 0 ? `${countdown}s` : 'Kirim Ulang'}
                </button>
              </div>

              <Link to="/" className="block text-sm text-muted-foreground hover:text-foreground">
                Lewati untuk sekarang
              </Link>
            </div>
          )}
        </motion.div>
      </div>
    </>
  );
}
