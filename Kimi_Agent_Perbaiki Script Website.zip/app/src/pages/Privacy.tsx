import SEO from '@/components/shared/SEO';

export default function Privacy() {
  return (
    <>
      <SEO title="Kebijakan Privasi" url="/privacy" />
      <div className="min-h-screen px-4 py-8 max-w-4xl mx-auto">
        <h1 className="text-2xl font-bold mb-6">Kebijakan Privasi</h1>

        <div className="prose prose-sm max-w-none dark:prose-invert space-y-6">
          <section>
            <h2 className="text-lg font-semibold mb-2">Data yang Kami Kumpulkan</h2>
            <p className="text-muted-foreground">
              Kami mengumpulkan informasi yang Anda berikan saat mendaftar, bertransaksi, atau menghubungi kami, 
              termasuk: nama lengkap, alamat email, nomor telepon, dan alamat pengiriman (jika diperlukan). 
              Kami juga mengumpulkan data teknis seperti alamat IP, jenis perangkat, dan log aktivitas 
              untuk keamanan dan peningkatan layanan.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold mb-2">Bagaimana Data Disimpan & Digunakan</h2>
            <p className="text-muted-foreground">
              Data disimpan di server Firebase yang terenkripsi dan aman. Kami menggunakan data Anda untuk: 
              memproses pesanan, mengirim notifikasi penting, memberikan dukungan pelanggan, 
              dan meningkatkan pengalaman pengguna. Data sensitif seperti password dienkripsi 
              menggunakan algoritma hashing satu arah.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold mb-2">Data Tidak Dijual ke Pihak Ketiga</h2>
            <p className="text-muted-foreground">
              Kami tidak menjual, menyewakan, atau membagikan data pribadi Anda kepada pihak ketiga untuk tujuan komersial. 
              Data hanya dibagikan kepada penyedia layanan yang terpercaya (seperti gateway pembayaran) 
              hanya sejauh yang diperlukan untuk memproses transaksi Anda.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold mb-2">Cara Menghapus Akun & Data</h2>
            <p className="text-muted-foreground">
              Anda dapat menghapus akun kapan saja melalui halaman Pengaturan. 
              Penghapusan akun akan menghapus data profil Anda, namun data transaksi akan dipertahankan 
              untuk keperluan hukum dan perpajakan sesuai ketentuan yang berlaku. 
              Untuk permintaan penghapusan data lengkap, silakan hubungi kami di fahrixzstore@gmail.com.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold mb-2">Cookie Policy</h2>
            <p className="text-muted-foreground">
              Kami menggunakan cookie untuk menyimpan preferensi tema, data keranjang belanja, 
              dan sesi login. Cookie tidak digunakan untuk melacak aktivitas browsing di luar situs ini. 
              Anda dapat menonaktifkan cookie melalui pengaturan browser, namun beberapa fitur mungkin tidak berfungsi optimal.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold mb-2">Hubungi Kami untuk Data Privacy</h2>
            <p className="text-muted-foreground">
              Jika Anda memiliki pertanyaan atau kekhawatiran tentang kebijakan privasi kami, 
              silakan hubungi kami melalui email di fahrixzstore@gmail.com atau WhatsApp di 0856-0994-9819.
            </p>
          </section>
        </div>
      </div>
    </>
  );
}
