import SEO from '@/components/shared/SEO';

export default function Terms() {
  return (
    <>
      <SEO title="Syarat & Ketentuan" url="/terms" />
      <div className="min-h-screen px-4 py-8 max-w-4xl mx-auto">
        <h1 className="text-2xl font-bold mb-6">Syarat & Ketentuan</h1>

        <div className="prose prose-sm max-w-none dark:prose-invert space-y-6">
          <section>
            <h2 className="text-lg font-semibold mb-2">1. Syarat Penggunaan Platform</h2>
            <p className="text-muted-foreground">
              Dengan mengakses dan menggunakan FahriXz Store, Anda menyetujui untuk terikat oleh syarat dan ketentuan ini. 
              Jika Anda tidak menyetujui bagian mana pun dari syarat ini, Anda tidak diperbolehkan menggunakan layanan kami. 
              Anda harus berusia minimal 18 tahun atau memiliki persetujuan orang tua/wali untuk menggunakan platform ini.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold mb-2">2. Kebijakan Pembelian & Pengembalian</h2>
            <p className="text-muted-foreground">
              Semua pembelian produk digital bersifat final. Kami menyediakan garansi uang kembali selama 7 hari 
              jika produk tidak sesuai deskripsi atau mengalami masalah teknis yang tidak dapat diperbaiki. 
              Pengajuan refund harus dilakukan melalui halaman pesanan dengan alasan yang jelas.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold mb-2">3. Larangan Pemakaian Akun/Produk</h2>
            <p className="text-muted-foreground">
              Anda dilarang menjual kembali, mendistribusikan, atau membagikan produk digital yang dibeli tanpa izin. 
              Setiap akun hanya untuk penggunaan pribadi dan tidak boleh dibagi atau dijual. 
              Pelanggaran dapat mengakibatkan penangguhan akun permanen tanpa pengembalian dana.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold mb-2">4. Penalti Pembatalan Order</h2>
            <p className="text-muted-foreground">
              Order yang dibatalkan setelah pembayaran akan dikenakan biaya administrasi sebesar 10% dari total pembelian. 
              Order yang statusnya sudah "completed" tidak dapat dibatalkan.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold mb-2">5. Hak dan Kewajiban User</h2>
            <p className="text-muted-foreground">
              Pengguna berhak mendapatkan produk yang sesuai deskripsi, dukungan teknis, dan privasi data. 
              Pengguna wajib memberikan informasi yang akurat, menjaga kerahasiaan akun, 
              dan tidak menggunakan platform untuk aktivitas ilegal.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold mb-2">6. Ketentuan Misi & Reward</h2>
            <p className="text-muted-foreground">
              Misi harus dikerjakan dengan jujur dan sesuai petunjuk. Curang, menggunakan bot, 
              atau memberikan data palsu akan mengakibatkan diskualifikasi dan penghapusan koin. 
              Koin yang didapat dari misi curang akan ditarik kembali. 
              Keputusan admin mengenai persetujuan misi bersifat mutlak.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold mb-2">7. Ketentuan Withdraw</h2>
            <p className="text-muted-foreground">
              Penarikan saldo memerlukan persetujuan admin dan estimasi waktu paling lambat 7 hari kerja. 
              Minimal penarikan Rp 10.000. Saldo yang ditarik akan dipotong biaya layanan sesuai ketentuan yang berlaku. 
              Admin berhak menolak penarikan jika ditemukan aktivitas mencurigakan.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold mb-2">8. Ketentuan Faspay Pembayaran</h2>
            <p className="text-muted-foreground">
              Pembayaran diproses melalui gateway Faspay. Waktu pembayaran maksimal 24 jam setelah order dibuat. 
              Setelah batas waktu, order akan otomatis dibatalkan. 
              Bukti pembayaran akan dikirim ke email terdaftar.
            </p>
          </section>
        </div>
      </div>
    </>
  );
}
