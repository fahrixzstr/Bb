import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { MessageCircle, Mail, HelpCircle, FileText, ArrowRight } from 'lucide-react';
import SEO from '@/components/shared/SEO';

export default function Support() {
  return (
    <>
      <SEO title="Dukungan" url="/support" />
      <div className="min-h-screen px-4 py-8 max-w-4xl mx-auto">
        <div className="text-center mb-10">
          <h1 className="text-2xl font-bold mb-2">Pusat Dukungan</h1>
          <p className="text-muted-foreground text-sm">
            Kami siap membantu Anda menyelesaikan masalah
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 mb-10">
          {[
            {
              icon: MessageCircle,
              title: 'Chat WhatsApp',
              desc: 'Respon tercepat untuk masalah urgent',
              href: 'https://wa.me/6285609949819',
              external: true,
              color: 'bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400',
            },
            {
              icon: Mail,
              title: 'Email Support',
              desc: 'Kirim detail masalah Anda',
              href: 'mailto:fahrixzstore@gmail.com',
              external: true,
              color: 'bg-purple-100 text-purple-600 dark:bg-purple-900/30 dark:text-purple-400',
            },
            {
              icon: HelpCircle,
              title: 'FAQ',
              desc: 'Jawaban untuk pertanyaan umum',
              href: '/faq',
              external: false,
              color: 'bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400',
            },
            {
              icon: FileText,
              title: 'Syarat & Ketentuan',
              desc: 'Ketentuan penggunaan platform',
              href: '/terms',
              external: false,
              color: 'bg-orange-100 text-orange-600 dark:bg-orange-900/30 dark:text-orange-400',
            },
          ].map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
            >
              {item.external ? (
                <a
                  href={item.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block p-6 bg-card border border-border rounded-xl hover:border-purple-500/50 transition-colors group"
                >
                  <div className={`w-10 h-10 ${item.color} rounded-full flex items-center justify-center mb-4`}>
                    <item.icon className="w-5 h-5" />
                  </div>
                  <h3 className="font-bold mb-1">{item.title}</h3>
                  <p className="text-sm text-muted-foreground mb-3">{item.desc}</p>
                  <span className="text-sm text-purple-600 flex items-center gap-1 group-hover:gap-2 transition-all">
                    Hubungi <ArrowRight className="w-3 h-3" />
                  </span>
                </a>
              ) : (
                <Link
                  to={item.href}
                  className="block p-6 bg-card border border-border rounded-xl hover:border-purple-500/50 transition-colors group"
                >
                  <div className={`w-10 h-10 ${item.color} rounded-full flex items-center justify-center mb-4`}>
                    <item.icon className="w-5 h-5" />
                  </div>
                  <h3 className="font-bold mb-1">{item.title}</h3>
                  <p className="text-sm text-muted-foreground mb-3">{item.desc}</p>
                  <span className="text-sm text-purple-600 flex items-center gap-1 group-hover:gap-2 transition-all">
                    Buka <ArrowRight className="w-3 h-3" />
                  </span>
                </Link>
              )}
            </motion.div>
          ))}
        </div>

        {/* Quick Help */}
        <div className="bg-card border border-border rounded-xl p-6">
          <h2 className="font-bold mb-4">Bantuan Cepat</h2>
          <div className="space-y-3">
            {[
              { q: 'Bagaimana cara melacak pesanan saya?', a: 'Login ke akun Anda, buka halaman "Pesanan Saya" untuk melihat status pesanan.' },
              { q: 'Produk belum diterima setelah pembayaran?', a: 'Cek folder spam email Anda. Jika masih belum diterima, hubungi kami via WhatsApp dengan nomor order Anda.' },
              { q: 'Bagaimana cara mengajukan refund?', a: 'Buka halaman "Pesanan Saya", klik pesanan yang ingin direfund, lalu pilih "Ajukan Refund".' },
            ].map((item, i) => (
              <div key={i} className="border-b border-border last:border-0 pb-3 last:pb-0">
                <p className="font-medium text-sm mb-1">{item.q}</p>
                <p className="text-sm text-muted-foreground">{item.a}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}
