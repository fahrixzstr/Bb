import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Target, Coins, Clock, Users, ChevronRight, Filter } from 'lucide-react';
import useStore from '@/stores/useStore';
import SEO from '@/components/shared/SEO';
import EmptyState from '@/components/shared/EmptyState';

interface Mission {
  id: string;
  name: string;
  description: string;
  reward: number;
  thumbnail: string;
  status: 'new' | 'active' | 'completed' | 'claimed';
  deadline: string;
  duration: string;
  maxParticipants: number;
  currentParticipants: number;
  progress: number;
  requirements: string[];
}

// Mock missions data - will be fetched from Firestore
const mockMissions: Mission[] = [];

export default function Missions() {
  const { user } = useStore();
  const [missions, setMissions] = useState<Mission[]>([]);
  const [filter, setFilter] = useState<string>('all');
  const [coins, setCoins] = useState(0);
  const [completedCount, setCompletedCount] = useState(0);

  useEffect(() => {
    // TODO: Fetch missions from Firestore
    setMissions(mockMissions);
    setCoins(0);
    setCompletedCount(0);
  }, []);

  const filteredMissions = missions.filter((m) => {
    if (filter === 'all') return true;
    if (filter === 'active') return m.status === 'new' || m.status === 'active';
    if (filter === 'completed') return m.status === 'completed';
    if (filter === 'claimable') return m.status === 'completed' && m.status !== 'claimed';
    return true;
  });

  return (
    <>
      <SEO title="Misi & Tantangan" url="/missions" />
      <div className="min-h-screen">
        {/* Hero */}
        <section className="relative bg-gradient-to-br from-purple-600 via-blue-600 to-black py-12 px-4">
          <div className="max-w-4xl mx-auto text-center text-white">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <Target className="w-12 h-12 mx-auto mb-4" />
              <h1 className="text-3xl font-bold mb-2">Misi & Tantangan</h1>
              <p className="text-white/80 max-w-lg mx-auto">
                Selesaikan misi, dapatkan koin, dan tukarkan menjadi saldo!
              </p>
            </motion.div>
          </div>
        </section>

        {/* Stats */}
        <section className="px-4 -mt-6 max-w-4xl mx-auto">
          <div className="grid grid-cols-3 gap-3">
            {[
              { label: 'Koin Saya', value: coins.toLocaleString('id-ID'), icon: Coins },
              { label: 'Misi Selesai', value: completedCount.toString(), icon: Target },
              { label: 'Misi Aktif', value: missions.filter((m) => m.status === 'active').length.toString(), icon: Filter },
            ].map((stat, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="bg-card border border-border rounded-xl p-4 text-center"
              >
                <stat.icon className="w-5 h-5 text-purple-600 mx-auto mb-2" />
                <p className="text-xl font-bold">{stat.value}</p>
                <p className="text-xs text-muted-foreground">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Filter & Missions List */}
        <section className="px-4 py-8 max-w-4xl mx-auto">
          {/* Filter Tabs */}
          <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
            {[
              { key: 'all', label: 'Semua' },
              { key: 'active', label: 'Berjalan' },
              { key: 'completed', label: 'Selesai' },
              { key: 'claimable', label: 'Bisa Diklaim' },
            ].map((f) => (
              <button
                key={f.key}
                onClick={() => setFilter(f.key)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all whitespace-nowrap ${
                  filter === f.key
                    ? 'bg-purple-600 text-white'
                    : 'bg-muted text-muted-foreground hover:bg-muted/80'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          {/* Missions Grid */}
          {filteredMissions.length > 0 ? (
            <div className="grid md:grid-cols-2 gap-4">
              {filteredMissions.map((mission, i) => (
                <motion.div
                  key={mission.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className="bg-card border border-border rounded-xl overflow-hidden hover:shadow-lg transition-shadow"
                >
                  {/* Thumbnail */}
                  <div className="aspect-video bg-gradient-to-br from-purple-500 to-blue-500 relative">
                    {mission.thumbnail ? (
                      <img src={mission.thumbnail} alt={mission.name} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <Target className="w-12 h-12 text-white/50" />
                      </div>
                    )}
                    <span className={`absolute top-2 right-2 text-xs font-bold px-2 py-1 rounded-full ${
                      mission.status === 'new' ? 'bg-green-500 text-white' :
                      mission.status === 'active' ? 'bg-blue-500 text-white' :
                      mission.status === 'completed' ? 'bg-purple-500 text-white' :
                      'bg-gray-500 text-white'
                    }`}>
                      {mission.status === 'new' ? 'Baru' :
                       mission.status === 'active' ? 'Berjalan' :
                       mission.status === 'completed' ? 'Selesai' : 'Diklaim'}
                    </span>
                  </div>

                  <div className="p-4">
                    <h3 className="font-bold mb-1">{mission.name}</h3>
                    <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{mission.description}</p>

                    {/* Reward */}
                    <div className="flex items-center gap-2 mb-3">
                      <Coins className="w-4 h-4 text-yellow-500" />
                      <span className="text-sm font-bold text-yellow-600 dark:text-yellow-400">
                        {mission.reward.toLocaleString('id-ID')} Koin
                      </span>
                    </div>

                    {/* Progress */}
                    {mission.progress > 0 && (
                      <div className="mb-3">
                        <div className="w-full bg-muted rounded-full h-2">
                          <div
                            className="bg-purple-600 h-2 rounded-full transition-all"
                            style={{ width: `${mission.progress}%` }}
                          />
                        </div>
                        <p className="text-xs text-muted-foreground mt-1">{mission.progress}% selesai</p>
                      </div>
                    )}

                    {/* Meta */}
                    <div className="flex items-center gap-4 text-xs text-muted-foreground mb-3">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {mission.duration}
                      </span>
                      <span className="flex items-center gap-1">
                        <Users className="w-3 h-3" />
                        {mission.currentParticipants}/{mission.maxParticipants}
                      </span>
                    </div>

                    {/* Participants progress */}
                    <div className="mb-4">
                      <div className="w-full bg-muted rounded-full h-1.5">
                        <div
                          className="bg-blue-500 h-1.5 rounded-full transition-all"
                          style={{ width: `${(mission.currentParticipants / mission.maxParticipants) * 100}%` }}
                        />
                      </div>
                    </div>

                    {/* Action */}
                    <Link
                      to={`/missions/${mission.id}`}
                      className="flex items-center justify-center gap-2 w-full bg-purple-600 hover:bg-purple-700 text-white py-2.5 rounded-xl text-sm font-medium transition-colors"
                    >
                      {mission.status === 'new' ? 'Ambil Misi' :
                       mission.status === 'active' ? 'Lanjutkan' :
                       mission.status === 'completed' ? 'Klaim Reward' : 'Lihat Detail'}
                      <ChevronRight className="w-4 h-4" />
                    </Link>
                  </div>
                </motion.div>
              ))}
            </div>
          ) : (
            <EmptyState
              type="missions"
              customDescription="Belum ada misi yang tersedia saat ini. Misi baru akan segera ditambahkan!"
            />
          )}
        </section>
      </div>
    </>
  );
}
