import { motion } from 'framer-motion';
import { Zap, Shield, Headphones, Clock, Mail, MessageCircle } from 'lucide-react';
import SEO from '@/components/shared/SEO';

export default function About() {
  return (
    <>
      <SEO title="Tentang Kami" url="/about" />
      <div className="min-h-screen">
        {/* Hero */}
        <section className="relative bg-gradient-to-br from-purple-600 via-blue-600 to-black py-16 px-4">
          <div className="max-w-4xl mx-auto text-center text-white">
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-3xl md:text-4xl font-bold mb-4"
            >
              Tentang FahriXz Store
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="text-white/80 max-w-2xl mx-auto"
            >
              Platform e-commerce digital terpercaya di Indonesia yang menyediakan berbagai produk digital berkualitas dengan harga terbaik.
            </motion.p>
          </div>
        </section>

        {/* Story */}
        <section className="px-4 py-12 max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="space-y-6"
          >
            <div>
              <h2 className="text-2xl font-bold mb-3">Cerita Kami</h2>
              <p className="text-muted-foreground leading-relaxed">
                FahriXz Store didirikan dengan visi untuk menjadi marketplace produk digital terdepan di Indonesia. 
                Kami memahami kebutuhan masyarakat akan produk digital yang berkualitas, aman, dan terjangkau. 
                Dengan pengalaman bertahun-tahun di industri digital, kami berkomitmen untuk memberikan 
                pelayanan terbaik kepada setiap pelanggan.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-bold mb-3">Misi & Visi</h2>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-card border border-border rounded-xl p-6">
                  <h3 className="font-bold text-purple-600 mb-2">Misi</h3>
                  <p className="text-muted-foreground text-sm">
                    Menyediakan produk digital berkualitas dengan harga kompetitif, 
                    memberikan pengalaman berbelanja yang aman dan nyaman, 
                    serta mendukung pertumbuhan ekonomi digital Indonesia.
                  </p>
                </div>
                <div className="bg-card border border-border rounded-xl p-6">
                  <h3 className="font-bold text-purple-600 mb-2">Visi</h3>
                  <p className="text-muted-foreground text-sm">
                    Menjadi marketplace produk digital terpercaya dan terbesar di Indonesia 
                    yang dikenal karena kualitas produk, keamanan transaksi, 
                    dan pelayanan pelanggan yang luar biasa.
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        </section>

        {/* Why Choose Us */}
        <section className="px-4 py-12 bg-muted/30">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-2xl font-bold text-center mb-8">Mengapa Memilih Kami?</h2>
            <div className="grid md:grid-cols-3 gap-6">
              {[
                { icon: Zap, title: 'Instant Delivery', desc: 'Produk digital dikirim otomatis ke email Anda setelah pembayaran' },
                { icon: Shield, title: 'Aman Terpercaya', desc: 'Transaksi terenkripsi dan dilindungi dengan sistem keamanan terbaik' },
                { icon: Headphones, title: 'Support 24/7', desc: 'Tim support kami siap membantu kapan saja Anda membutuhkan' },
              ].map((item, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="bg-card border border-border rounded-xl p-6 text-center"
                >
                  <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                    <item.icon className="w-6 h-6 text-purple-600 dark:text-purple-400" />
                  </div>
                  <h3 className="font-bold mb-2">{item.title}</h3>
                  <p className="text-muted-foreground text-sm">{item.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Contact Info */}
        <section className="px-4 py-12 max-w-4xl mx-auto">
          <h2 className="text-2xl font-bold text-center mb-8">Hubungi Kami</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="flex items-center gap-4 bg-card border border-border rounded-xl p-4">
              <div className="w-10 h-10 bg-purple-100 dark:bg-purple-900/30 rounded-full flex items-center justify-center">
                <Mail className="w-5 h-5 text-purple-600 dark:text-purple-400" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Email</p>
                <p className="font-medium">fahrixzstore@gmail.com</p>
              </div>
            </div>
            <a
              href="https://wa.me/6285609949819"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-4 bg-card border border-border rounded-xl p-4 hover:border-purple-500/50 transition-colors"
            >
              <div className="w-10 h-10 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center">
                <MessageCircle className="w-5 h-5 text-green-600 dark:text-green-400" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">WhatsApp</p>
                <p className="font-medium">0856-0994-9819</p>
              </div>
            </a>
          </div>
          <div className="mt-6 text-center">
            <p className="text-sm text-muted-foreground">
              Jam Operasional: Senin - Minggu, 08:00 - 22:00 WIB
            </p>
          </div>
        </section>
      </div>
    </>
  );
}
