import { Package, ShoppingCart, Heart, ClipboardList, Target, Wallet, Search } from 'lucide-react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

interface EmptyStateProps {
  type: 'cart' | 'orders' | 'products' | 'wishlist' | 'missions' | 'wallet' | 'search';
  customTitle?: string;
  customDescription?: string;
  customAction?: { label: string; href: string };
}

const configs = {
  cart: {
    icon: ShoppingCart,
    title: 'Keranjang Belanja Kosong',
    description: 'Belum ada produk di keranjang Anda',
    action: { label: 'Mulai Belanja', href: '/products' },
  },
  orders: {
    icon: ClipboardList,
    title: 'Belum Ada Pesanan',
    description: 'Anda belum melakukan pemesanan',
    action: { label: 'Lihat Produk', href: '/products' },
  },
  products: {
    icon: Package,
    title: 'Belum Ada Produk',
    description: 'Produk akan segera tersedia',
    action: null,
  },
  wishlist: {
    icon: Heart,
    title: 'Wishlist Kosong',
    description: 'Belum ada produk favorit',
    action: { label: 'Jelajahi Produk', href: '/products' },
  },
  missions: {
    icon: Target,
    title: 'Belum Ada Misi Aktif',
    description: 'Misi akan segera tersedia',
    action: null,
  },
  wallet: {
    icon: Wallet,
    title: 'Belum Ada Transaksi',
    description: 'Riwayat transaksi akan muncul di sini',
    action: null,
  },
  search: {
    icon: Search,
    title: 'Produk Tidak Ditemukan',
    description: 'Coba ubah kata kunci pencarian',
    action: null,
  },
};

export default function EmptyState({ type, customTitle, customDescription, customAction }: EmptyStateProps) {
  const config = configs[type];
  const Icon = config.icon;
  const title = customTitle || config.title;
  const description = customDescription || config.description;
  const action = customAction || config.action;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-col items-center justify-center py-16 px-4 text-center"
    >
      <div className="w-16 h-16 bg-purple-100 dark:bg-purple-900/30 rounded-full flex items-center justify-center mb-4">
        <Icon className="w-8 h-8 text-purple-600 dark:text-purple-400" />
      </div>
      <h3 className="text-lg font-semibold mb-1">{title}</h3>
      <p className="text-muted-foreground text-sm mb-4">{description}</p>
      {action && (
        <Link
          to={action.href}
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-sm font-medium transition-colors"
        >
          <Icon className="w-4 h-4" />
          {action.label}
        </Link>
      )}
    </motion.div>
  );
}
