import { Link, useLocation } from 'react-router-dom';
import { ChevronRight, Home } from 'lucide-react';

interface BreadcrumbItem {
  label: string;
  href?: string;
}

interface BreadcrumbProps {
  items?: BreadcrumbItem[];
}

const routeNames: Record<string, string> = {
  'products': 'Produk',
  'cart': 'Keranjang',
  'checkout': 'Checkout',
  'dashboard': 'Dashboard',
  'orders': 'Pesanan Saya',
  'settings': 'Pengaturan',
  'about': 'Tentang Kami',
  'contact': 'Kontak',
  'faq': 'FAQ',
  'terms': 'Syarat & Ketentuan',
  'privacy': 'Kebijakan Privasi',
  'support': 'Dukungan',
  'missions': 'Misi',
  'wallet': 'Dompet',
  'wishlist': 'Wishlist',
};

export default function Breadcrumb({ items }: BreadcrumbProps) {
  const location = useLocation();

  // Auto-generate from path if no items provided
  const breadcrumbItems: BreadcrumbItem[] = items || (() => {
    const paths = location.pathname.split('/').filter(Boolean);
    if (paths.length === 0) return [];

    const items: BreadcrumbItem[] = [];
    let currentPath = '';

    paths.forEach((segment, index) => {
      currentPath += `/${segment}`;
      // Skip ID segments (they look like product IDs)
      if (segment.length > 15 && segment.includes('-')) {
        items.push({ label: 'Detail' });
      } else {
        items.push({
          label: routeNames[segment] || segment,
          href: index < paths.length - 1 ? currentPath : undefined,
        });
      }
    });

    return items;
  })();

  if (breadcrumbItems.length === 0) return null;

  return (
    <nav className="flex items-center gap-1.5 text-sm text-muted-foreground py-4 px-4 md:px-8 max-w-7xl mx-auto overflow-x-auto">
      <Link to="/" className="flex items-center gap-1 hover:text-purple-600 transition-colors flex-shrink-0">
        <Home className="w-3.5 h-3.5" />
        <span className="hidden sm:inline">Beranda</span>
      </Link>
      {breadcrumbItems.map((item, index) => (
        <div key={index} className="flex items-center gap-1.5 flex-shrink-0">
          <ChevronRight className="w-3.5 h-3.5" />
          {item.href ? (
            <Link to={item.href} className="hover:text-purple-600 transition-colors whitespace-nowrap">
              {item.label}
            </Link>
          ) : (
            <span className="text-foreground font-medium whitespace-nowrap truncate max-w-[200px]">
              {item.label}
            </span>
          )}
        </div>
      ))}
    </nav>
  );
}
