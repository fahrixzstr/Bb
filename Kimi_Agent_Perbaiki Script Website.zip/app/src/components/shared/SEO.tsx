import { Helmet } from 'react-helmet-async';

interface SEOProps {
  title?: string;
  description?: string;
  image?: string;
  url?: string;
  type?: string;
}

const defaultTitle = 'FahriXz Store - Marketplace Produk Digital';
const defaultDescription = 'Temukan produk digital berkualitas dengan harga terbaik. Akses instant, garansi, dan support 24/7.';
const defaultImage = 'https://fahrixz-store.vercel.app/og-image.jpg';
const siteUrl = 'https://fahrixz-store.vercel.app';

export default function SEO({
  title,
  description,
  image,
  url,
  type = 'website',
}: SEOProps) {
  const fullTitle = title ? `${title} - FahriXz Store` : defaultTitle;
  const fullUrl = url ? `${siteUrl}${url}` : siteUrl;

  return (
    <Helmet>
      <title>{fullTitle}</title>
      <meta name="description" content={description || defaultDescription} />

      {/* Open Graph */}
      <meta property="og:title" content={fullTitle} />
      <meta property="og:description" content={description || defaultDescription} />
      <meta property="og:image" content={image || defaultImage} />
      <meta property="og:url" content={fullUrl} />
      <meta property="og:type" content={type} />
      <meta property="og:site_name" content="FahriXz Store" />

      {/* Twitter Card */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={fullTitle} />
      <meta name="twitter:description" content={description || defaultDescription} />
      <meta name="twitter:image" content={image || defaultImage} />

      {/* Canonical */}
      <link rel="canonical" href={fullUrl} />
    </Helmet>
  );
}
