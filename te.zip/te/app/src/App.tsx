import { lazy, Suspense, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useStore } from '@/stores/useStore';
import { useAuth } from '@/hooks/useAuth';
import './lib/i18n';
import { Toaster } from 'sonner';
import ErrorBoundary from '@/components/ErrorBoundary';
import LoadingScreen from '@/components/shared/LoadingScreen';
import UserLayout from '@/components/layout/UserLayout';
import AdminLayout from '@/components/layout/AdminLayout';

// Lazy Pages - Auth
const LoginPage = lazy(() => import('@/pages/LoginPage'));
const RegisterPage = lazy(() => import('@/pages/RegisterPage'));
const ForgotPasswordPage = lazy(() => import('@/pages/ForgotPasswordPage'));
const AdminLoginPage = lazy(() => import('@/pages/admin/AdminLoginPage'));

// Lazy Pages - User
const HomePage = lazy(() => import('@/pages/HomePage'));
const ProductsPage = lazy(() => import('@/pages/ProductsPage'));
const ProductDetailPage = lazy(() => import('@/pages/ProductDetailPage'));
const CartPage = lazy(() => import('@/pages/CartPage'));
const CheckoutPage = lazy(() => import('@/pages/CheckoutPage'));
const OrdersPage = lazy(() => import('@/pages/OrdersPage'));
const WalletPage = lazy(() => import('@/pages/WalletPage'));
const WithdrawPage = lazy(() => import('@/pages/WithdrawPage'));
const MissionsPage = lazy(() => import('@/pages/MissionsPage'));
const ProfilePage = lazy(() => import('@/pages/ProfilePage'));
const SettingsPage = lazy(() => import('@/pages/SettingsPage'));
const CustomerServicePage = lazy(() => import('@/pages/CustomerServicePage'));
const NotificationsPage = lazy(() => import('@/pages/NotificationsPage'));
const SearchPage = lazy(() => import('@/pages/SearchPage'));
const CoinsPage = lazy(() => import('@/pages/CoinsPage'));
const AffiliatePage = lazy(() => import('@/pages/AffiliatePage'));
const FavoritesPage = lazy(() => import('@/pages/FavoritesPage'));
const RecentlyViewedPage = lazy(() => import('@/pages/RecentlyViewedPage'));
const VouchersPage = lazy(() => import('@/pages/VouchersPage'));
const HelpPage = lazy(() => import('@/pages/HelpPage'));
const ReportBugPage = lazy(() => import('@/pages/ReportBugPage'));
const DonationsPage = lazy(() => import('@/pages/DonationsPage'));
const EventsPage = lazy(() => import('@/pages/EventsPage'));
const AboutPage = lazy(() => import('@/pages/AboutPage'));
const TermsPage = lazy(() => import('@/pages/TermsPage'));
const PrivacyPage = lazy(() => import('@/pages/PrivacyPage'));
const RefundPage = lazy(() => import('@/pages/RefundPage'));
const TermsMissionsPage = lazy(() => import('@/pages/TermsMissionsPage'));

// Lazy Pages - Admin
const AdminDashboard = lazy(() => import('@/pages/admin/AdminDashboard'));
const AdminProducts = lazy(() => import('@/pages/admin/AdminProducts'));
const AdminOrders = lazy(() => import('@/pages/admin/AdminOrders'));
const AdminUsers = lazy(() => import('@/pages/admin/AdminUsers'));
const AdminMissions = lazy(() => import('@/pages/admin/AdminMissions'));
const AdminVouchers = lazy(() => import('@/pages/admin/AdminVouchers'));
const AdminDonations = lazy(() => import('@/pages/admin/AdminDonations'));
const AdminEvents = lazy(() => import('@/pages/admin/AdminEvents'));
const AdminFinance = lazy(() => import('@/pages/admin/AdminFinance'));
const AdminSettings = lazy(() => import('@/pages/admin/AdminSettings'));
const AdminSecurity = lazy(() => import('@/pages/admin/AdminSecurity'));
const AdminIPManagement = lazy(() => import('@/pages/admin/AdminIPManagement'));
const AdminActivityLogs = lazy(() => import('@/pages/admin/AdminActivityLogs'));
const AdminCustomerService = lazy(() => import('@/pages/admin/AdminCustomerService'));
const AdminKTAManagement = lazy(() => import('@/pages/admin/AdminKTAManagement'));

function AppContent() {
  const { theme } = useStore();
  useAuth();

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      theme === 'dark' ? 'bg-[#080C14] text-white' : 'bg-gray-50 text-gray-900'
    }`}>
      <Routes>
        {/* Auth Routes - No Layout */}
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/forgot-password" element={<ForgotPasswordPage />} />
        <Route path="/vx-admin-login" element={<AdminLoginPage />} />

        {/* Admin Routes */}
        <Route path="/admin" element={<AdminLayout />}>
          <Route index element={<AdminDashboard />} />
          <Route path="products" element={<AdminProducts />} />
          <Route path="orders" element={<AdminOrders />} />
          <Route path="users" element={<AdminUsers />} />
          <Route path="missions" element={<AdminMissions />} />
          <Route path="vouchers" element={<AdminVouchers />} />
          <Route path="donations" element={<AdminDonations />} />
          <Route path="events" element={<AdminEvents />} />
          <Route path="finance" element={<AdminFinance />} />
          <Route path="settings" element={<AdminSettings />} />
          <Route path="security" element={<AdminSecurity />} />
          <Route path="ip" element={<AdminIPManagement />} />
          <Route path="logs" element={<AdminActivityLogs />} />
          <Route path="cs" element={<AdminCustomerService />} />
          <Route path="kta" element={<AdminKTAManagement />} />
        </Route>

        {/* User Routes - With Layout */}
        <Route element={<UserLayout />}>
          <Route path="/" element={<HomePage />} />
          <Route path="/products" element={<ProductsPage />} />
          <Route path="/products/:id" element={<ProductDetailPage />} />
          <Route path="/cart" element={<CartPage />} />
          <Route path="/checkout" element={<CheckoutPage />} />
          <Route path="/orders" element={<OrdersPage />} />
          <Route path="/wallet" element={<WalletPage />} />
          <Route path="/wallet/withdraw" element={<WithdrawPage />} />
          <Route path="/missions" element={<MissionsPage />} />
          <Route path="/profile" element={<ProfilePage />} />
          <Route path="/settings" element={<SettingsPage />} />
          <Route path="/customer-service" element={<CustomerServicePage />} />
          <Route path="/notifications" element={<NotificationsPage />} />
          <Route path="/search" element={<SearchPage />} />
          <Route path="/coins" element={<CoinsPage />} />
          <Route path="/affiliate" element={<AffiliatePage />} />
          <Route path="/favorites" element={<FavoritesPage />} />
          <Route path="/recently-viewed" element={<RecentlyViewedPage />} />
          <Route path="/vouchers" element={<VouchersPage />} />
          <Route path="/help" element={<HelpPage />} />
          <Route path="/report-bug" element={<ReportBugPage />} />
          <Route path="/donations" element={<DonationsPage />} />
          <Route path="/events" element={<EventsPage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/terms" element={<TermsPage />} />
          <Route path="/privacy" element={<PrivacyPage />} />
          <Route path="/refund" element={<RefundPage />} />
          <Route path="/terms-missions" element={<TermsMissionsPage />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Route>
      </Routes>

      <Toaster
        position="top-right"
        toastOptions={{
          style: {
            background: '#131B2D',
            border: '1px solid #1C2A45',
            color: '#fff',
          },
        }}
      />
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <ErrorBoundary>
        <Suspense fallback={<LoadingScreen />}>
          <AppContent />
        </Suspense>
      </ErrorBoundary>
    </BrowserRouter>
  );
}