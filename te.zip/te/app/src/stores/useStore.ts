import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { User, Theme, Language, CartItem, Notification } from '@/types';

interface AppState {
  // Auth
  user: User | null;
  isLoggedIn: boolean;
  isAdmin: boolean;
  loading: boolean;
  setUser: (user: User | null) => void;
  setIsLoggedIn: (val: boolean) => void;
  setIsAdmin: (val: boolean) => void;
  setLoading: (val: boolean) => void;

  // Theme
  theme: Theme;
  setTheme: (theme: Theme) => void;
  toggleTheme: () => void;

  // Language
  language: Language;
  setLanguage: (lang: Language) => void;

  // Cart
  cart: CartItem[];
  setCart: (cart: CartItem[]) => void;
  addToCart: (item: CartItem) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  getCartTotal: () => number;
  getCartCount: () => number;

  // Notifications
  notifications: Notification[];
  unreadCount: number;
  setNotifications: (notifs: Notification[]) => void;
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;

  // Admin
  adminClicks: number;
  lastAdminClick: number;
  setAdminClicks: (count: number) => void;
  setLastAdminClick: (time: number) => void;

  // UI
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;

  // Actions
  reset: () => void;
}

const initialState = {
  user: null,
  isLoggedIn: false,
  isAdmin: false,
  loading: true,
  theme: 'dark' as Theme,
  language: 'id' as Language,
  cart: [],
  notifications: [],
  unreadCount: 0,
  adminClicks: 0,
  lastAdminClick: 0,
  sidebarOpen: true,
};

export const useStore = create<AppState>()(
  persist(
    (set, get) => ({
      ...initialState,

      // Auth
      setUser: (user) => set({ user }),
      setIsLoggedIn: (isLoggedIn) => set({ isLoggedIn }),
      setIsAdmin: (isAdmin) => set({ isAdmin }),
      setLoading: (loading) => set({ loading }),

      // Theme
      setTheme: (theme) => {
        set({ theme });
        const root = document.documentElement;
        if (theme === 'dark') {
          root.classList.add('dark');
          root.classList.remove('light');
        } else {
          root.classList.add('light');
          root.classList.remove('dark');
        }
      },
      toggleTheme: () => {
        const newTheme = get().theme === 'dark' ? 'light' : 'dark';
        set({ theme: newTheme });
        const root = document.documentElement;
        if (newTheme === 'dark') {
          root.classList.add('dark');
          root.classList.remove('light');
        } else {
          root.classList.add('light');
          root.classList.remove('dark');
        }
      },

      // Language
      setLanguage: (language) => set({ language }),

      // Cart
      setCart: (cart) => set({ cart }),
      addToCart: (item) => {
        const cart = get().cart;
        const existing = cart.find(i => i.productId === item.productId && i.variant === item.variant);
        if (existing) {
          set({
            cart: cart.map(i =>
              i.productId === item.productId && i.variant === item.variant
                ? { ...i, quantity: i.quantity + item.quantity }
                : i
            )
          });
        } else {
          set({ cart: [...cart, item] });
        }
      },
      removeFromCart: (productId) => {
        set({ cart: get().cart.filter(i => i.productId !== productId) });
      },
      updateCartQuantity: (productId, quantity) => {
        if (quantity <= 0) {
          set({ cart: get().cart.filter(i => i.productId !== productId) });
        } else {
          set({
            cart: get().cart.map(i =>
              i.productId === productId ? { ...i, quantity } : i
            )
          });
        }
      },
      clearCart: () => set({ cart: [] }),
      getCartTotal: () => {
        return get().cart.reduce((total, item) => total + item.price * item.quantity, 0);
      },
      getCartCount: () => {
        return get().cart.reduce((count, item) => count + item.quantity, 0);
      },

      // Notifications
      setNotifications: (notifications) => {
        const unreadCount = notifications.filter(n => !n.read).length;
        set({ notifications, unreadCount });
      },
      markAsRead: (id) => {
        const notifications = get().notifications.map(n =>
          n.notificationId === id ? { ...n, read: true } : n
        );
        const unreadCount = notifications.filter(n => !n.read).length;
        set({ notifications, unreadCount });
      },
      markAllAsRead: () => {
        const notifications = get().notifications.map(n => ({ ...n, read: true }));
        set({ notifications, unreadCount: 0 });
      },

      // Admin clicks
      setAdminClicks: (count) => set({ adminClicks: count }),
      setLastAdminClick: (time) => set({ lastAdminClick: time }),

      // UI
      setSidebarOpen: (open) => set({ sidebarOpen: open }),

      // Reset
      reset: () => {
        set({
          ...initialState,
          theme: get().theme,
          language: get().language,
        });
      },
    }),
    {
      name: 'fahrixz-store',
      partialize: (state) => ({
        theme: state.theme,
        language: state.language,
        cart: state.cart,
        notifications: state.notifications,
        unreadCount: state.unreadCount,
        adminClicks: state.adminClicks,
        lastAdminClick: state.lastAdminClick,
      }),
    }
  )
);
