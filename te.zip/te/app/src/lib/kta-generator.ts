export interface KTAData {
  ktaId: string;
  ktaCode: string;
  userId: string;
  websiteName: string;
  developerName: string;
  fullName: string;
  createdAt: string;
  expiresAt: string;
  status: 'active' | 'expired' | 'revoked';
}

export const generateKTACode = (): string => {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = 'FZS-';
  for (let i = 0; i < 4; i++) code += chars.charAt(Math.floor(Math.random() * chars.length));
  code += '-';
  for (let i = 0; i < 4; i++) code += chars.charAt(Math.floor(Math.random() * chars.length));
  return code;
};

export const generateKTACardSVG = (data: KTAData): string => {
  const expiresDate = new Date(data.expiresAt).toLocaleDateString('id-ID', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });
  const createdDate = new Date(data.createdAt).toLocaleDateString('id-ID', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  const statusColor = data.status === 'active' ? '#10B981' : data.status === 'expired' ? '#F59E0B' : '#EF4444';

  return `<?xml version="1.0" encoding="UTF-8"?>
<svg width="856" height="540" viewBox="0 0 856 540" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#0a0e1a;stop-opacity:1" />
      <stop offset="100%" style="stop-color:#131B2D;stop-opacity:1" />
    </linearGradient>
    <linearGradient id="accentGrad" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" style="stop-color:#7C3AED;stop-opacity:1" />
      <stop offset="100%" style="stop-color:#3B82F6;stop-opacity:1" />
    </linearGradient>
    <linearGradient id="cyanGrad" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" style="stop-color:#00F0FF;stop-opacity:1" />
      <stop offset="100%" style="stop-color:#0077FF;stop-opacity:1" />
    </linearGradient>
    <filter id="glow">
      <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
      <feMerge>
        <feMergeNode in="coloredBlur"/>
        <feMergeNode in="SourceGraphic"/>
      </feMerge>
    </filter>
  </defs>
  
  <!-- Background -->
  <rect width="856" height="540" rx="24" fill="url(#bgGrad)"/>
  <rect x="2" y="2" width="852" height="536" rx="22" fill="none" stroke="url(#accentGrad)" stroke-width="2"/>
  
  <!-- Decorative lines -->
  <line x1="40" y1="120" x2="816" y2="120" stroke="url(#accentGrad)" stroke-width="1" opacity="0.3"/>
  <line x1="40" y1="400" x2="816" y2="400" stroke="url(#accentGrad)" stroke-width="1" opacity="0.3"/>
  
  <!-- Logo area -->
  <g transform="translate(40, 40)">
    <rect width="40" height="30" rx="4" fill="none"/>
    <line x1="0" y1="6" x2="40" y2="6" stroke="url(#cyanGrad)" stroke-width="4" stroke-linecap="round"/>
    <line x1="0" y1="15" x2="30" y2="15" stroke="url(#cyanGrad)" stroke-width="4" stroke-linecap="round"/>
    <line x1="0" y1="24" x2="20" y2="24" stroke="url(#cyanGrad)" stroke-width="4" stroke-linecap="round"/>
  </g>
  
  <!-- Title -->
  <text x="90" y="55" font-family="Arial, sans-serif" font-size="22" font-weight="bold" fill="url(#accentGrad)" filter="url(#glow)">FahriXz Store</text>
  <text x="90" y="75" font-family="Arial, sans-serif" font-size="12" fill="#6B7280">KARTU TANDA ANGGOTA</text>
  
  <!-- KTA Label -->
  <text x="750" y="55" font-family="Arial, sans-serif" font-size="14" font-weight="bold" fill="#00F0FF" text-anchor="end" filter="url(#glow)">KTA</text>
  
  <!-- Main Content -->
  <g transform="translate(40, 150)">
    <!-- KTA ID -->
    <text x="0" y="0" font-family="Arial, sans-serif" font-size="11" fill="#6B7280">KTA ID</text>
    <text x="0" y="25" font-family="'Courier New', monospace" font-size="18" font-weight="bold" fill="#FFFFFF">${data.ktaId}</text>
    
    <!-- KTA Code -->
    <text x="400" y="0" font-family="Arial, sans-serif" font-size="11" fill="#6B7280">KTA CODE</text>
    <text x="400" y="25" font-family="'Courier New', monospace" font-size="18" font-weight="bold" fill="url(#cyanGrad)" filter="url(#glow)">${data.ktaCode}</text>
    
    <!-- Member Name -->
    <text x="0" y="80" font-family="Arial, sans-serif" font-size="11" fill="#6B7280">NAMA ANGGOTA</text>
    <text x="0" y="110" font-family="Arial, sans-serif" font-size="28" font-weight="bold" fill="#FFFFFF">${data.fullName}</text>
    
    <!-- Developer -->
    <text x="0" y="150" font-family="Arial, sans-serif" font-size="11" fill="#6B7280">DEVELOPER</text>
    <text x="0" y="172" font-family="Arial, sans-serif" font-size="14" fill="#D1D5DB">${data.developerName}</text>
    
    <!-- Website -->
    <text x="300" y="150" font-family="Arial, sans-serif" font-size="11" fill="#6B7280">WEBSITE</text>
    <text x="300" y="172" font-family="Arial, sans-serif" font-size="14" fill="#D1D5DB">${data.websiteName}</text>
    
    <!-- Dates -->
    <text x="0" y="210" font-family="Arial, sans-serif" font-size="11" fill="#6B7280">BERLAKU DARI</text>
    <text x="0" y="230" font-family="Arial, sans-serif" font-size="13" fill="#D1D5DB">${createdDate}</text>
    
    <text x="300" y="210" font-family="Arial, sans-serif" font-size="11" fill="#6B7280">BERLAKU SAMPAI</text>
    <text x="300" y="230" font-family="Arial, sans-serif" font-size="13" fill="#D1D5DB">${expiresDate}</text>
    
    <!-- Status -->
    <text x="550" y="210" font-family="Arial, sans-serif" font-size="11" fill="#6B7280">STATUS</text>
    <rect x="550" y="218" width="80" height="22" rx="11" fill="${statusColor}" opacity="0.2"/>
    <text x="590" y="233" font-family="Arial, sans-serif" font-size="12" font-weight="bold" fill="${statusColor}" text-anchor="middle">${data.status.toUpperCase()}</text>
  </g>
  
  <!-- Footer -->
  <text x="428" y="510" font-family="Arial, sans-serif" font-size="11" fill="#4B5563" text-anchor="middle">&#169; ${new Date().getFullYear()} Fahrixz Store - Kartu Tanda Anggota Digital</text>
  
  <!-- Holographic effect -->
  <polygon points="700,0 856,0 856,160 700,0" fill="url(#accentGrad)" opacity="0.05"/>
</svg>`;
};

export const downloadKTACard = (svg: string, filename: string) => {
  const blob = new Blob([svg], { type: 'image/svg+xml' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
};
