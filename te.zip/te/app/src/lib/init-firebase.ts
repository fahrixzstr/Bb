import { db } from './firebase';
import { collection, getDocs, setDoc, doc, serverTimestamp } from 'firebase/firestore';

const COLLECTIONS = [
  'users',
  'products',
  'orders',
  'wallets',
  'transactions',
  'missions',
  'userMissions',
  'notifications',
  'vouchers',
  'reviews',
  'carts',
  'affiliates',
  'referrals',
  'coins',
  'coinTransactions',
  'banners',
  'faq',
  'supportTickets',
  'adminUsers',
  'blockedIPs',
  'securityLogs',
  'activityLogs',
  'events',
  'donations',
  'paymentMethods',
  'withdrawalRequests',
];

export const initializeFirebaseCollections = async () => {
  for (const colName of COLLECTIONS) {
    try {
      const snapshot = await getDocs(collection(db, colName));
      console.log(`Collection ${colName}: ${snapshot.size} documents`);
    } catch (error) {
      console.warn(`Collection ${colName} may not exist yet:`, error);
    }
  }
};

export const createDefaultFAQ = async () => {
  const faqSnapshot = await getDocs(collection(db, 'faq'));
  if (faqSnapshot.empty) {
    const defaultFAQs = [
      {
        faqId: 'faq-1',
        question: 'Bagaimana cara membeli produk?',
        answer: 'Anda dapat membeli produk dengan memilih produk yang diinginkan, lalu klik "Order Sekarang" atau "Tambahkan ke Keranjang". Setelah itu, ikuti proses checkout dan pembayaran.',
        category: 'pembelian',
        keywords: ['beli', 'order', 'checkout'],
      },
      {
        faqId: 'faq-2',
        question: 'Metode pembayaran apa saja yang tersedia?',
        answer: 'Saat ini kami sedang mengintegrasikan berbagai metode pembayaran. Silakan cek halaman checkout untuk melihat metode yang tersedia.',
        category: 'pembayaran',
        keywords: ['bayar', 'payment', 'metode'],
      },
      {
        faqId: 'faq-3',
        question: 'Bagaimana cara kerja Misi Cuan?',
        answer: 'Misi Cuan adalah sistem tugas digital di mana Anda dapat menyelesaikan tugas-tugas yang tersedia dan mendapatkan reward berupa saldo yang dapat ditarik.',
        category: 'misi',
        keywords: ['misi', 'cuan', 'tugas', 'reward'],
      },
      {
        faqId: 'faq-4',
        question: 'Bagaimana cara withdraw saldo?',
        answer: 'Anda dapat menarik saldo melalui halaman Wallet > Withdraw. Pilih metode penarikan, masukkan jumlah dan detail akun, lalu ajukan permohonan.',
        category: 'wallet',
        keywords: ['withdraw', 'tarik', 'saldo', 'wallet'],
      },
      {
        faqId: 'faq-5',
        question: 'Berapa lama proses withdraw?',
        answer: 'Proses withdraw memakan waktu 1-3 hari kerja setelah payment gateway terintegrasi. Saat ini dalam pengembangan.',
        category: 'wallet',
        keywords: ['withdraw', 'waktu', 'proses'],
      },
      {
        faqId: 'faq-6',
        question: 'Apakah ada garansi untuk produk?',
        answer: 'Kebijakan garansi bervariasi tergantung jenis produk. Silakan cek detail produk atau hubungi customer service untuk informasi lebih lanjut.',
        category: 'produk',
        keywords: ['garansi', 'refund', 'produk'],
      },
      {
        faqId: 'faq-7',
        question: 'Bagaimana cara menggunakan voucher?',
        answer: 'Anda dapat menggunakan voucher saat checkout. Masukkan kode voucher di kolom yang tersedia, dan diskon akan otomatis diterapkan.',
        category: 'voucher',
        keywords: ['voucher', 'diskon', 'kode'],
      },
      {
        faqId: 'faq-8',
        question: 'Bagaimana cara menghubungi admin?',
        answer: 'Anda dapat menghubungi admin melalui halaman Customer Service atau melalui WhatsApp Channel: https://whatsapp.com/channel/0029VbCHdOx7j6gAsxGkZ80m',
        category: 'kontak',
        keywords: ['kontak', 'admin', 'hubungi', 'cs'],
      },
    ];

    for (const faq of defaultFAQs) {
      await setDoc(doc(db, 'faq', faq.faqId), faq);
    }
    console.log('Default FAQs created');
  }
};
