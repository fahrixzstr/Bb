import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey: "AIzaSyC1g32siIEOJHbQCxm9ssPpKSac9ANu_lM",
  authDomain: "fahrixzstore-c9de7.firebaseapp.com",
  projectId: "fahrixzstore-c9de7",
  storageBucket: "fahrixzstore-c9de7.firebasestorage.app",
  messagingSenderId: "29590938796",
  appId: "1:29590938796:web:e0e280930ce90a1992ab09",
  measurementId: "G-3F3XKS5JFT"
};

// Validasi config
if (!firebaseConfig.apiKey || !firebaseConfig.projectId) {
  console.error('Firebase config tidak lengkap. Fitur auth dan database tidak akan berfungsi.');
}

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);

export default app;
