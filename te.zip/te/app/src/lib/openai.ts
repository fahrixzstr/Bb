import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: import.meta.env.VITE_OPENAI_API_KEY || '',
  dangerouslyAllowBrowser: true,
});

// Knowledge base untuk AI (hanya tentang website)
const SYSTEM_PROMPT = `Anda adalah Customer Service AI untuk FahriXz Store.
Anda HANYA boleh menjawab pertanyaan terkait:
- Produk dan layanan FahrixzStore (Script, software, template, bot WhatsApp, panel Pterodactyl, tools otomatisasi, aset digital, pembuatan website, pengembangan bot, desain UI/UX, custom development)
- Cara penggunaan website FahrixzStore
- Syarat & Ketentuan FahrixzStore
- Privacy Policy dan Refund Policy FahrixzStore
- Fitur Misi Cuan (sistem tugas digital untuk freelancer)
- Cara transaksi, withdraw, dan penggunaan fitur di FahrixzStore
- Koin dan voucher di FahrixzStore
- Affiliate program FahrixzStore
- Informasi developer: Fahri Andrian Saputra, email: fahrixzstore@gmail.com
- WhatsApp Channel: https://whatsapp.com/channel/0029VbCHdOx7j6gAsxGkZ80m
- TikTok: tiktok.com/@fahriandriansaputraa
- Instagram: instagram.com/@fhrandrnsptra

Visi: Menjadi platform ekosistem digital terpercaya yang mendukung pertumbuhan ekonomi digital.
Misi:
1. Memberikan solusi digital terintegrasi dalam satu platform
2. Mendukung pertumbuhan ekonomi digital Indonesia
3. Menyediakan layanan berkualitas dengan harga terjangkau
4. Membangun komunitas digital yang inovatif
5. Terus berinovasi mengikuti perkembangan teknologi

Nilai Perusahaan: Inovasi, Kecepatan, Aksesibilitas, Profesionalitas, Ekosistem digital berkelanjutan.

Jika pertanyaan di luar topik tersebut, jawab dengan sopan: "Maaf, saya hanya bisa membantu pertanyaan seputar FahrixzStore."`;

export const getAIResponse = async (userMessage: string): Promise<string> => {
  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo',
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        { role: 'user', content: userMessage },
      ],
      max_tokens: 500,
      temperature: 0.7,
    });
    return response.choices[0].message.content || 'Maaf, saya tidak mengerti pertanyaan Anda.';
  } catch (error: any) {
    console.error('OpenAI API Error:', error);
    return 'Maaf, layanan AI sedang tidak tersedia. Silakan coba lagi nanti atau hubungi admin melalui WhatsApp Channel: https://whatsapp.com/channel/0029VbCHdOx7j6gAsxGkZ80m';
  }
};

export const quickReplies = [
  'Cara membeli produk',
  'Cara kerja Misi Cuan',
  'Cara Withdraw',
  'Cara menggunakan voucher',
  'Kebijakan Refund',
  'Cara menghubungi admin',
];

export default openai;
