import { db, auth } from './firebase';
import {
  collection, doc, getDoc, getDocs, addDoc, updateDoc, deleteDoc,
  query, where, orderBy, limit, onSnapshot, serverTimestamp, setDoc
} from 'firebase/firestore';
import { updateProfile } from 'firebase/auth';

// ===== PRODUCTS =====
export const getProducts = () => getDocs(collection(db, 'products'));
export const getProductById = (id: string) => getDoc(doc(db, 'products', id));
export const addProduct = (data: any) => addDoc(collection(db, 'products'), { ...data, createdAt: serverTimestamp() });
export const updateProduct = (id: string, data: any) => updateDoc(doc(db, 'products', id), { ...data, updatedAt: serverTimestamp() });
export const deleteProduct = (id: string) => deleteDoc(doc(db, 'products', id));

// ===== ORDERS =====
export const getOrders = (userId?: string) => {
  const ordersRef = collection(db, 'orders');
  if (userId) return getDocs(query(ordersRef, where('userId', '==', userId), orderBy('createdAt', 'desc')));
  return getDocs(query(ordersRef, orderBy('createdAt', 'desc')));
};
export const getOrderById = (id: string) => getDoc(doc(db, 'orders', id));
export const addOrder = (data: any) => addDoc(collection(db, 'orders'), { ...data, createdAt: serverTimestamp() });
export const updateOrder = (id: string, data: any) => updateDoc(doc(db, 'orders', id), { ...data, updatedAt: serverTimestamp() });

// ===== USERS =====
export const getUsers = () => getDocs(collection(db, 'users'));
export const getUserById = (id: string) => getDoc(doc(db, 'users', id));
export const createUser = (uid: string, data: any) => setDoc(doc(db, 'users', uid), { ...data, createdAt: serverTimestamp() });
export const updateUser = (uid: string, data: any) => updateDoc(doc(db, 'users', uid), { ...data, updatedAt: serverTimestamp() });

// ===== WALLETS =====
export const getWallet = (userId: string) => getDoc(doc(db, 'wallets', userId));
export const createWallet = (userId: string, data?: any) => setDoc(doc(db, 'wallets', userId), { userId, balance: 0, coins: 0, ...data, updatedAt: serverTimestamp() });
export const updateWallet = (userId: string, data: any) => updateDoc(doc(db, 'wallets', userId), { ...data, updatedAt: serverTimestamp() });

// ===== TRANSACTIONS =====
export const getTransactions = (userId: string) => getDocs(query(collection(db, 'transactions'), where('userId', '==', userId), orderBy('createdAt', 'desc')));
export const addTransaction = (data: any) => addDoc(collection(db, 'transactions'), { ...data, createdAt: serverTimestamp() });

// ===== MISSIONS =====
export const getMissions = () => getDocs(collection(db, 'missions'));
export const getUserMissions = (userId: string) => getDocs(query(collection(db, 'userMissions'), where('userId', '==', userId)));

// ===== NOTIFICATIONS =====
export const getNotifications = (userId: string) => getDocs(query(collection(db, 'notifications'), where('userId', '==', userId), orderBy('createdAt', 'desc')));
export const addNotification = (data: any) => addDoc(collection(db, 'notifications'), { ...data, createdAt: serverTimestamp() });

// ===== VOUCHERS =====
export const getVouchers = () => getDocs(collection(db, 'vouchers'));
export const getVoucherById = (id: string) => getDoc(doc(db, 'vouchers', id));
export const addVoucher = (data: any) => addDoc(collection(db, 'vouchers'), { ...data, createdAt: serverTimestamp() });
export const updateVoucher = (id: string, data: any) => updateDoc(doc(db, 'vouchers', id), { ...data, updatedAt: serverTimestamp() });
export const deleteVoucher = (id: string) => deleteDoc(doc(db, 'vouchers', id));

// ===== REVIEWS =====
export const getReviews = (productId?: string) => {
  const reviewsRef = collection(db, 'reviews');
  if (productId) return getDocs(query(reviewsRef, where('productId', '==', productId), orderBy('createdAt', 'desc')));
  return getDocs(query(reviewsRef, orderBy('createdAt', 'desc')));
};

// ===== CARTS =====
export const getCart = (userId: string) => getDoc(doc(db, 'carts', userId));
export const updateCart = (userId: string, data: any) => setDoc(doc(db, 'carts', userId), { ...data, updatedAt: serverTimestamp() });

// ===== ADMIN USERS =====
export const getAdminUsers = () => getDocs(collection(db, 'adminUsers'));
export const getAdminUserById = (uid: string) => getDoc(doc(db, 'adminUsers', uid));

// ===== SECURITY LOGS =====
export const addSecurityLog = (data: any) => addDoc(collection(db, 'securityLogs'), { ...data, timestamp: serverTimestamp() });

// ===== BLOCKED IPs =====
export const getBlockedIPs = () => getDocs(collection(db, 'blockedIPs'));
export const addBlockedIP = (data: any) => addDoc(collection(db, 'blockedIPs'), { ...data, blockedAt: serverTimestamp() });

// ===== DONATIONS =====
export const getDonations = () => getDocs(query(collection(db, 'donations'), orderBy('createdAt', 'desc')));
export const addDonation = (data: any) => addDoc(collection(db, 'donations'), { ...data, createdAt: serverTimestamp() });

// ===== EVENTS =====
export const getEvents = () => getDocs(query(collection(db, 'events'), orderBy('createdAt', 'desc')));
export const addEvent = (data: any) => addDoc(collection(db, 'events'), { ...data, createdAt: serverTimestamp() });

// ===== WITHDRAWAL REQUESTS =====
export const getWithdrawalRequests = (userId?: string) => {
  const ref = collection(db, 'withdrawalRequests');
  if (userId) return getDocs(query(ref, where('userId', '==', userId), orderBy('createdAt', 'desc')));
  return getDocs(query(ref, orderBy('createdAt', 'desc')));
};
export const addWithdrawalRequest = (data: any) => addDoc(collection(db, 'withdrawalRequests'), { ...data, createdAt: serverTimestamp() });

// ===== SUPPORT TICKETS =====
export const getSupportTickets = () => getDocs(query(collection(db, 'supportTickets'), orderBy('createdAt', 'desc')));
export const updateSupportTicket = (id: string, data: any) => updateDoc(doc(db, 'supportTickets', id), { ...data, updatedAt: serverTimestamp() });

// ===== UPDATE USER DISPLAY NAME =====
export const updateUserDisplayName = async (displayName: string) => {
  if (auth.currentUser) {
    await updateProfile(auth.currentUser, { displayName });
  }
};
