export const APP_NAME = 'Fahrixz Store';
export const APP_VERSION = '3.0.0';

export const CURRENCY = 'IDR';
export const LOCALE = 'id-ID';

export const MIN_WITHDRAW = 50000;
export const WITHDRAW_FEE = 2500;
export const MIN_MISSION_WITHDRAW = 13000;

export const COIN_RATE = 0.1; // 10 koin = Rp 1
export const PURCHASE_COIN_RATE = 0.01; // 1% dari total pembelian

export const REFERRAL_REWARD = 5000;

export const ORDER_STATUS_LABELS = {
  pending: 'Belum Bayar',
  processing: 'Di Proses',
  shipped: 'Dikirim',
  completed: 'Berhasil',
  cancelled: 'Dibatalkan',
  refund: 'Refund',
} as const;

export const MISSION_CATEGORY_LABELS = {
  review: 'Review',
  registrasi: 'Registrasi',
  download: 'Download',
  game: 'Game',
  survey: 'Survey',
  pinjaman: 'Pinjaman',
} as const;

export const PRODUCT_CATEGORIES = [
  { key: 'subscription', label: 'Subscription', icon: 'Crown' },
  { key: 'panel', label: 'Panel Pterodactyl', icon: 'Server' },
  { key: 'hosting', label: 'Hosting', icon: 'Globe' },
  { key: 'voucher', label: 'Voucher', icon: 'Ticket' },
  { key: 'jasa', label: 'Jasa', icon: 'Wrench' },
  { key: 'digital', label: 'Digital', icon: 'Smartphone' },
  { key: 'other', label: 'Lainnya', icon: 'MoreHorizontal' },
] as const;

export const PAYMENT_METHODS = [
  { key: 'qris', label: 'QRIS', icon: 'QrCode' },
  { key: 'dana', label: 'DANA', icon: 'Wallet' },
  { key: 'gopay', label: 'GoPay', icon: 'CreditCard' },
  { key: 'bank_transfer', label: 'Transfer Bank', icon: 'Landmark' },
  { key: 'credit_card', label: 'Kartu Kredit/Debit', icon: 'CreditCard' },
] as const;

export const QUICK_ACTIONS = [
  { key: 'bot', label: 'Bot WhatsApp', icon: 'Bot', path: '/products?category=digital' },
  { key: 'voucher', label: 'Voucher', icon: 'Ticket', path: '/products?category=voucher' },
  { key: 'missions', label: 'Cari Cuan', icon: 'Target', path: '/missions' },
  { key: 'events', label: 'Event', icon: 'Calendar', path: '/events' },
  { key: 'donation', label: 'Donasi', icon: 'Heart', path: '/donations' },
  { key: 'hosting', label: 'Hosting', icon: 'Globe', path: '/products?category=hosting' },
  { key: 'panel', label: 'Panel', icon: 'Server', path: '/products?category=panel' },
  { key: 'subscription', label: 'Subscription', icon: 'Crown', path: '/products?category=subscription' },
  { key: 'services', label: 'Jasa', icon: 'Wrench', path: '/products?category=jasa' },
  { key: 'more', label: 'Lainnya', icon: 'MoreHorizontal', path: '/products' },
] as const;

export const SETTINGS_SECTIONS = [
  { key: 'profile', icon: 'User', label: 'Edit Profil', requireAuth: true },
  { key: 'withdrawal', icon: 'CreditCard', label: 'Nomor Penarikan', requireAuth: true },
  { key: 'language', icon: 'Globe', label: 'Bahasa', requireAuth: false },
  { key: 'theme', icon: 'Moon', label: 'Tema', requireAuth: false },
  { key: 'email', icon: 'Mail', label: 'Verifikasi Email', requireAuth: true },
  { key: 'security', icon: 'Shield', label: 'Keamanan', requireAuth: true },
  { key: 'notifications', icon: 'Bell', label: 'Notifikasi', requireAuth: true },
  { key: 'privacy', icon: 'Lock', label: 'Privasi', requireAuth: true },
  { key: 'about', icon: 'Info', label: 'Tentang', requireAuth: false },
] as const;

export const ADMIN_MENU = [
  { key: 'dashboard', label: 'Dashboard', icon: 'LayoutDashboard', path: '/admin' },
  { key: 'products', label: 'Produk', icon: 'Package', path: '/admin/products' },
  { key: 'orders', label: 'Pesanan', icon: 'ShoppingCart', path: '/admin/orders' },
  { key: 'users', label: 'Pengguna', icon: 'Users', path: '/admin/users' },
  { key: 'missions', label: 'Misi', icon: 'Target', path: '/admin/missions' },
  { key: 'vouchers', label: 'Voucher', icon: 'Ticket', path: '/admin/vouchers' },
  { key: 'donations', label: 'Donasi', icon: 'Heart', path: '/admin/donations' },
  { key: 'events', label: 'Event', icon: 'Calendar', path: '/admin/events' },
  { key: 'finance', label: 'Keuangan', icon: 'BarChart3', path: '/admin/finance' },
  { key: 'settings', label: 'Pengaturan', icon: 'Settings', path: '/admin/settings' },
  { key: 'security', label: 'Keamanan', icon: 'Shield', path: '/admin/security' },
  { key: 'ip', label: 'IP Management', icon: 'Ban', path: '/admin/ip' },
  { key: 'logs', label: 'Activity Logs', icon: 'FileText', path: '/admin/logs' },
  { key: 'cs', label: 'Customer Service', icon: 'MessageCircle', path: '/admin/cs' },
] as const;

export const SECURITY_METHODS = [
  { key: 'totp', label: 'Google Authenticator', icon: 'Smartphone' },
  { key: 'email', label: 'Verifikasi Email', icon: 'Mail' },
  { key: 'phone', label: 'SMS OTP', icon: 'MessageSquare' },
  { key: 'biometric', label: 'Face ID / Fingerprint', icon: 'Fingerprint' },
  { key: 'kta', label: 'Kartu Tanda Admin (KTA)', icon: 'IdCard' },
] as const;
