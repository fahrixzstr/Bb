import { z } from 'zod';

export const loginSchema = z.object({
  email: z.string().email('Email tidak valid'),
  password: z.string().min(6, 'Password minimal 6 karakter'),
  rememberMe: z.boolean().optional(),
});

export const registerSchema = z.object({
  fullName: z.string().min(2, 'Nama minimal 2 karakter'),
  email: z.string().email('Email tidak valid'),
  password: z.string().min(8, 'Password minimal 8 karakter'),
  confirmPassword: z.string(),
  agreeTerms: z.boolean().refine(val => val === true, {
    message: 'Anda harus menyetujui syarat dan ketentuan',
  }),
}).refine(data => data.password === data.confirmPassword, {
  message: 'Password tidak cocok',
  path: ['confirmPassword'],
});

export const withdrawSchema = z.object({
  amount: z.number().min(50000, 'Minimal penarikan Rp 50.000'),
  method: z.string().min(1, 'Pilih metode penarikan'),
  accountNumber: z.string().min(5, 'Masukkan nomor rekening/e-wallet'),
});

export const profileSchema = z.object({
  displayName: z.string().min(2, 'Nama minimal 2 karakter'),
  username: z.string().min(3, 'Username minimal 3 karakter').optional(),
  email: z.string().email('Email tidak valid'),
  phoneNumber: z.string().min(10, 'Nomor telepon minimal 10 digit').optional(),
  bio: z.string().max(200, 'Bio maksimal 200 karakter').optional(),
});

export const addressSchema = z.object({
  fullName: z.string().min(2, 'Nama lengkap wajib diisi'),
  phone: z.string().min(10, 'Nomor telepon minimal 10 digit'),
  address: z.string().min(5, 'Alamat minimal 5 karakter'),
  city: z.string().min(2, 'Kota wajib diisi'),
  postalCode: z.string().min(5, 'Kode pos minimal 5 digit'),
});

export const missionSchema = z.object({
  title: z.string().min(5, 'Judul minimal 5 karakter'),
  description: z.string().min(10, 'Deskripsi minimal 10 karakter'),
  category: z.string().min(1, 'Pilih kategori'),
  reward: z.number().min(1000, 'Reward minimal Rp 1.000'),
  estimatedMinutes: z.number().min(1, 'Estimasi waktu minimal 1 menit'),
  requirements: z.array(z.string()).optional(),
});

export const voucherSchema = z.object({
  code: z.string().min(3, 'Kode voucher minimal 3 karakter'),
  title: z.string().min(3, 'Judul wajib diisi'),
  description: z.string().min(5, 'Deskripsi wajib diisi'),
  discountAmount: z.number().min(0),
  discountPercent: z.number().min(0).max(100).optional(),
  minPurchase: z.number().min(0),
  maxDiscount: z.number().optional(),
  expiryDate: z.string().min(1, 'Tanggal expiry wajib diisi'),
  category: z.string().optional(),
  usageLimit: z.number().optional(),
});

export const productSchema = z.object({
  name: z.string().min(2, 'Nama produk wajib diisi'),
  description: z.string().min(5, 'Deskripsi wajib diisi'),
  price: z.number().min(0, 'Harga tidak valid'),
  originalPrice: z.number().optional(),
  category: z.string().min(1, 'Pilih kategori'),
  subCategory: z.string().optional(),
  stock: z.number().min(0, 'Stok tidak valid'),
  minOrder: z.number().min(1).optional(),
  tags: z.array(z.string()).optional(),
});

export const reviewSchema = z.object({
  rating: z.number().min(1).max(5),
  text: z.string().min(5, 'Review minimal 5 karakter'),
});

export const otpSchema = z.object({
  otp: z.string().length(6, 'OTP harus 6 digit'),
});

export const forgotPasswordSchema = z.object({
  email: z.string().email('Email tidak valid'),
});

export const checkoutSchema = z.object({
  paymentMethod: z.string().min(1, 'Pilih metode pembayaran'),
  voucherCode: z.string().optional(),
  useCoins: z.boolean().optional(),
});

export type LoginForm = z.infer<typeof loginSchema>;
export type RegisterForm = z.infer<typeof registerSchema>;
export type WithdrawForm = z.infer<typeof withdrawSchema>;
export type ProfileForm = z.infer<typeof profileSchema>;
export type AddressForm = z.infer<typeof addressSchema>;
export type MissionForm = z.infer<typeof missionSchema>;
export type VoucherForm = z.infer<typeof voucherSchema>;
export type ProductForm = z.infer<typeof productSchema>;
export type ReviewForm = z.infer<typeof reviewSchema>;
export type OtpForm = z.infer<typeof otpSchema>;
export type ForgotPasswordForm = z.infer<typeof forgotPasswordSchema>;
export type CheckoutForm = z.infer<typeof checkoutSchema>;
