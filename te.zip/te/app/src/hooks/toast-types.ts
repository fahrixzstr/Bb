export interface ToastOptions {
  title: string;
  description?: string;
  variant?: 'default' | 'destructive';
}

export interface Toast extends ToastOptions {
  id: string;
}
