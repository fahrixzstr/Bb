import { useEffect } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { auth, db } from '@/lib/firebase';
import { useStore } from '@/stores/useStore';

export function useAuth() {
  const { setUser, setIsLoggedIn, setIsAdmin, setLoading } = useStore();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        try {
          // Fetch user data from Firestore
          const userDoc = await getDoc(doc(db, 'users', firebaseUser.uid));
          const userData = userDoc.exists() ? userDoc.data() : {};

          setUser({
            uid: firebaseUser.uid,
            email: firebaseUser.email,
            displayName: firebaseUser.displayName || userData.displayName || 'User',
            photoURL: firebaseUser.photoURL,
            phoneNumber: firebaseUser.phoneNumber,
            role: userData.role || 'user',
            ...userData,
          });
          setIsLoggedIn(true);

          // Check if admin
          const adminDoc = await getDoc(doc(db, 'adminUsers', firebaseUser.uid));
          setIsAdmin(adminDoc.exists());
        } catch (error) {
          console.error('Error fetching user data:', error);
          setUser(null);
          setIsLoggedIn(false);
          setIsAdmin(false);
        }
      } else {
        setUser(null);
        setIsLoggedIn(false);
        setIsAdmin(false);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [setUser, setIsLoggedIn, setIsAdmin, setLoading]);
}
