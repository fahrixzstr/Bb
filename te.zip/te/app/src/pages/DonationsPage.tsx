import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Heart, ExternalLink, Coffee, Gift } from 'lucide-react';
import { toast } from 'sonner';

export default function DonationsPage() {
  const navigate = useNavigate();

  const donationMethods = [
    {
      name: 'Saweria',
      description: 'Dukung melalui Saweria',
      icon: Coffee,
      url: 'https://saweria.co/fahrixz',
      color: 'from-[#7C3AED] to-[#3B82F6]',
    },
    {
      name: 'Trakteer',
      description: 'Traktir kopi untuk developer',
      icon: Gift,
      url: 'https://trakteer.id/fahrixz',
      color: 'from-[#FF6B6B] to-[#EE5A6F]',
    },
  ];

  const handleDonate = (url: string) => {
    if (url) {
      window.open(url, '_blank', 'noopener,noreferrer');
    } else {
      toast.info('Link donasi akan segera tersedia');
    }
  };

  return (
    <div className="min-h-screen bg-[#080C14] text-white pb-20">
      <div className="sticky top-0 z-40 bg-[#080C14]/80 backdrop-blur-md border-b border-[#1C2A45]">
        <div className="flex items-center gap-3 px-4 py-3">
          <button onClick={() => navigate(-1)} className="p-2 rounded-lg hover:bg-white/5">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-bold">Donasi</h1>
        </div>
      </div>

      <div className="px-4 py-6 space-y-6">
        {/* Hero */}
        <div className="text-center py-8">
          <div className="w-20 h-20 rounded-full bg-gradient-to-r from-[#7C3AED]/20 to-[#3B82F6]/20 flex items-center justify-center mx-auto mb-4">
            <Heart className="w-10 h-10 text-red-400" />
          </div>
          <h2 className="text-2xl font-bold mb-2">Dukung FahrixzStore</h2>
          <p className="text-gray-400 text-sm max-w-sm mx-auto">
            Donasi Anda membantu kami untuk terus mengembangkan platform dan memberikan layanan terbaik.
          </p>
        </div>

        {/* Why Donate */}
        <div className="cyber-bg rounded-2xl p-5">
          <h3 className="text-lg font-bold mb-3">Mengapa Donasi?</h3>
          <ul className="space-y-2 text-sm text-gray-400">
            <li className="flex items-start gap-2">
              <Heart className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
              Mendukung pengembangan fitur baru
            </li>
            <li className="flex items-start gap-2">
              <Heart className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
              Membantu biaya server dan infrastruktur
            </li>
            <li className="flex items-start gap-2">
              <Heart className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
              Memberikan apresiasi untuk developer
            </li>
          </ul>
        </div>

        {/* Donation Methods */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold">Metode Donasi</h3>
          {donationMethods.map((method, i) => (
            <button
              key={i}
              onClick={() => handleDonate(method.url)}
              className="w-full cyber-bg rounded-xl p-4 flex items-center gap-4 hover:bg-[#1C2A45] transition-colors text-left"
            >
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-r ${method.color} flex items-center justify-center`}>
                <method.icon className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <h4 className="text-sm font-bold">{method.name}</h4>
                <p className="text-xs text-gray-400">{method.description}</p>
              </div>
              <ExternalLink className="w-5 h-5 text-gray-500" />
            </button>
          ))}
        </div>

        {/* Thanks */}
        <div className="cyber-bg rounded-xl p-4 text-center">
          <p className="text-sm text-gray-400">
            Terima kasih atas dukungan Anda! ❤️
          </p>
        </div>
      </div>
    </div>
  );
}
