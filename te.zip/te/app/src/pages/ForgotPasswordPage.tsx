import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Mail, ArrowLeft, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';
import { auth } from '@/lib/firebase';
import { sendPasswordResetEmail } from 'firebase/auth';

export default function ForgotPasswordPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      toast.error('Email wajib diisi');
      return;
    }
    setLoading(true);
    try {
      await sendPasswordResetEmail(auth, email);
      setSent(true);
      toast.success('Email reset password telah dikirim!', { description: 'Silakan cek inbox Anda.' });
    } catch (error: any) {
      toast.error('Gagal mengirim email reset', { description: error.message });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#080C14] text-white flex flex-col items-center justify-center px-6">
      <button onClick={() => navigate('/login')} className="absolute top-6 left-6">
        <ArrowLeft className="w-5 h-5 text-gray-400" />
      </button>

      <div className="mb-8">
        <div className="logo-icon scale-[2] mx-auto mb-4">
          <span className="block h-1 bg-gradient-to-r from-[#00F0FF] to-[#0077FF] rounded-full w-full" />
          <span className="block h-1 bg-gradient-to-r from-[#00F0FF] to-[#0077FF] rounded-full w-3/4" />
          <span className="block h-1 bg-gradient-to-r from-[#00F0FF] to-[#0077FF] rounded-full w-1/2" />
        </div>
        <h1 className="text-center text-2xl font-bold">FAHRIXZ STORE</h1>
      </div>

      {sent ? (
        <div className="w-full max-w-sm text-center">
          <CheckCircle className="w-16 h-16 text-green-400 mx-auto mb-4" />
          <h2 className="text-xl font-bold mb-2">Email Terkirim!</h2>
          <p className="text-gray-400 text-sm mb-6">
            Kami telah mengirimkan link reset password ke <span className="text-white">{email}</span>.
            Silakan cek inbox atau folder spam Anda.
          </p>
          <button
            onClick={() => navigate('/login')}
            className="w-full py-3 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white rounded-full font-medium hover:opacity-90 transition-opacity"
          >
            Kembali ke Login
          </button>
        </div>
      ) : (
        <>
          <h2 className="text-lg font-medium mb-1">Lupa Kata Sandi?</h2>
          <p className="text-gray-500 text-sm text-center mb-6 max-w-xs">
            Masukkan email Anda dan kami akan mengirimkan link untuk mereset password.
          </p>

          <form onSubmit={handleSubmit} className="w-full max-w-sm space-y-4">
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input
                type="email"
                placeholder="Email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                required
                className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl py-3 pl-11 pr-4 text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white rounded-full font-medium hover:opacity-90 transition-opacity disabled:opacity-50"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mx-auto" />
              ) : (
                'Kirim Link Reset'
              )}
            </button>
          </form>
        </>
      )}
    </div>
  );
}
