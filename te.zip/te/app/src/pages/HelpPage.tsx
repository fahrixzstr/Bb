import { useState, useEffect } from 'react';
import { db } from '@/lib/firebase';
import { collection, getDocs } from 'firebase/firestore';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Search, MessageCircle, Bug, FileText, ChevronRight, MessageSquare } from 'lucide-react';

interface FAQItem {
  q: string;
  a: string;
}

interface FAQCategory {
  title: string;
  icon: React.ElementType;
  items: FAQItem[];
}

const [faqCategories, setFaqCategories] = useState<FAQCategory[]>([]);
const [loading, setLoading] = useState(true);

useEffect(() => {
  const fetchFAQ = async () => {
    try {
      const snapshot = await getDocs(collection(db, 'faqCategories'));
      const data = snapshot.docs.map(d => ({
        title: d.data().title,
        icon: FileText,
        items: d.data().items || [],
      } as FAQCategory));
      if (data.length > 0) {
        setFaqCategories(data);
      } else {
        // Fallback to default FAQ if none in database
        setFaqCategories([
          {
            title: 'Pembelian',
            icon: FileText,
            items: [
              { q: 'Bagaimana cara membeli produk?', a: 'Pilih produk yang diinginkan, klik "Order Sekarang" atau "Tambahkan ke Keranjang", lalu ikuti proses checkout.' },
              { q: 'Metode pembayaran apa saja yang tersedia?', a: 'Saat ini kami sedang mengintegrasikan berbagai metode pembayaran. Silakan cek halaman checkout untuk melihat metode yang tersedia.' },
              { q: 'Apakah transaksi di FahrixzStore aman?', a: 'Ya, semua transaksi dilindungi dengan enkripsi SSL dan sistem keamanan terbaru.' },
            ],
          },
          {
            title: 'Produk',
            icon: FileText,
            items: [
              { q: 'Produk apa saja yang tersedia?', a: 'Kami menyediakan script, software, template, bot WhatsApp, panel Pterodactyl, tools otomatisasi, dan aset digital.' },
              { q: 'Bagaimana jika produk bermasalah?', a: 'Anda dapat mengajukan komplain melalui halaman Customer Service atau halaman pesanan Anda.' },
              { q: 'Apakah ada garansi untuk produk?', a: 'Kebijakan garansi bervariasi tergantung jenis produk. Silakan cek detail produk atau hubungi customer service.' },
            ],
          },
          {
            title: 'Wallet & Withdraw',
            icon: FileText,
            items: [
              { q: 'Bagaimana cara withdraw saldo?', a: 'Anda dapat menarik saldo melalui halaman Wallet > Withdraw. Pilih metode penarikan, masukkan jumlah dan detail akun.' },
              { q: 'Berapa lama proses withdraw?', a: 'Proses withdraw memakan waktu 1-3 hari kerja setelah payment gateway terintegrasi.' },
              { q: 'Apakah ada biaya admin untuk withdraw?', a: 'Biaya admin bervariasi tergantung metode penarikan yang dipilih.' },
            ],
          },
          {
            title: 'Misi Cuan',
            icon: FileText,
            items: [
              { q: 'Bagaimana cara kerja Misi Cuan?', a: 'Misi Cuan adalah sistem tugas digital di mana Anda dapat menyelesaikan tugas-tugas yang tersedia dan mendapatkan reward berupa saldo yang dapat ditarik.' },
              { q: 'Berapa minimal withdraw Misi Cuan?', a: 'Minimal saldo untuk withdraw adalah Rp 10.000.' },
              { q: 'Apakah Misi Cuan bisa digunakan untuk belanja?', a: 'Tidak, saldo Misi Cuan hanya bisa ditarik (withdraw), tidak bisa digunakan untuk belanja.' },
            ],
          },
          {
            title: 'Akun',
            icon: FileText,
            items: [
              { q: 'Bagaimana cara mengubah password?', a: 'Anda dapat mengubah password melalui halaman Settings > Keamanan.' },
              { q: 'Bagaimana cara menghapus akun?', a: 'Untuk menghapus akun, silakan hubungi customer service kami.' },
              { q: 'Apakah saya bisa memiliki lebih dari satu akun?', a: 'Tidak, setiap pengguna hanya diperbolehkan memiliki satu akun.' },
            ],
          },
        ]);
      }
    } catch (error) {
      console.error('Error fetching FAQ:', error);
    } finally {
      setLoading(false);
    }
  };
  fetchFAQ();
}, []);

export default function HelpPage() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedCategory, setExpandedCategory] = useState<number | null>(null);
  const [expandedItem, setExpandedItem] = useState<string | null>(null);

  const filteredCategories = faqCategories.map(cat => ({
    ...cat,
    items: cat.items.filter(item =>
      item.q.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.a.toLowerCase().includes(searchQuery.toLowerCase())
    ),
  })).filter(cat => cat.items.length > 0);

  return (
    <div className="min-h-screen bg-[#080C14] text-white pb-20">
      <div className="sticky top-0 z-40 bg-[#080C14]/80 backdrop-blur-md border-b border-[#1C2A45]">
        <div className="flex items-center gap-3 px-4 py-3">
          <button onClick={() => navigate(-1)} className="p-2 rounded-lg hover:bg-white/5">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-bold">Pusat Bantuan</h1>
        </div>
      </div>

      <div className="px-4 py-6 space-y-6">
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
          <input
            type="text"
            placeholder="Cari bantuan..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl py-3 pl-11 pr-4 text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]"
          />
        </div>

        {/* Quick Links */}
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => navigate('/customer-service')}
            className="cyber-bg rounded-xl p-4 text-center hover:bg-[#1C2A45] transition-colors"
          >
            <MessageCircle className="w-6 h-6 mx-auto mb-2 text-[#7C3AED]" />
            <p className="text-sm font-medium">Customer Service</p>
          </button>
          <button
            onClick={() => navigate('/report-bug')}
            className="cyber-bg rounded-xl p-4 text-center hover:bg-[#1C2A45] transition-colors"
          >
            <Bug className="w-6 h-6 mx-auto mb-2 text-red-400" />
            <p className="text-sm font-medium">Laporkan Bug</p>
          </button>
        </div>

        {/* FAQ Categories */}
        <div className="space-y-3">
          {filteredCategories.map((category, catIdx) => (
            <div key={catIdx} className="cyber-bg rounded-xl overflow-hidden">
              <button
                onClick={() => setExpandedCategory(expandedCategory === catIdx ? null : catIdx)}
                className="w-full flex items-center justify-between p-4"
              >
                <div className="flex items-center gap-3">
                  <category.icon className="w-5 h-5 text-[#00F0FF]" />
                  <span className="text-sm font-bold">{category.title}</span>
                </div>
                <ChevronRight className={`w-5 h-5 text-gray-500 transition-transform ${expandedCategory === catIdx ? 'rotate-90' : ''}`} />
              </button>
              {expandedCategory === catIdx && (
                <div className="border-t border-[#1C2A45]">
                  {category.items.map((item, itemIdx) => (
                    <div key={itemIdx} className="border-b border-[#1C2A45] last:border-0">
                      <button
                        onClick={() => setExpandedItem(expandedItem === `${catIdx}-${itemIdx}` ? null : `${catIdx}-${itemIdx}`)}
                        className="w-full flex items-center justify-between p-3 px-4"
                      >
                        <span className="text-sm text-left">{item.q}</span>
                        <ChevronRight className={`w-4 h-4 text-gray-500 flex-shrink-0 transition-transform ${expandedItem === `${catIdx}-${itemIdx}` ? 'rotate-90' : ''}`} />
                      </button>
                      {expandedItem === `${catIdx}-${itemIdx}` && (
                        <div className="px-4 pb-3">
                          <p className="text-sm text-gray-400">{item.a}</p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Contact */}
        <div className="cyber-bg rounded-xl p-4 text-center">
          <MessageSquare className="w-8 h-8 mx-auto mb-2 text-[#00F0FF]" />
          <p className="text-sm text-gray-400">Masih butuh bantuan?</p>
          <button
            onClick={() => navigate('/customer-service')}
            className="mt-2 px-6 py-2 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] rounded-full text-sm font-medium hover:opacity-90"
          >
            Hubungi CS
          </button>
        </div>
      </div>
    </div>
  );
}
