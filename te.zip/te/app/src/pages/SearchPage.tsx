import { useState, useMemo, useEffect } from 'react';
import { db } from '@/lib/firebase';
import { collection, query, orderBy, limit, getDocs } from 'firebase/firestore';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Search, Clock, TrendingUp } from 'lucide-react';
import ProductCard from '@/components/shared/ProductCard';
import { db } from '@/lib/firebase';
import { collection, getDocs } from 'firebase/firestore';
import { useEffect } from 'react';
import type { Product } from '@/types';

const escapeHtml = (text: string): string => {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
};

const [trendingSearches, setTrendingSearches] = useState<string[]>([]);
const [searchHistory, setSearchHistory] = useState<string[]>([]);

export default function SearchPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const query = searchParams.get('q') || '';
  const [searchQuery, setSearchQuery] = useState(query);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchProducts();
    const fetchSearchData = async () => {
      try {
        const trendingQ = query(collection(db, 'searchTrends'), orderBy('count', 'desc'), limit(5));
        const trendingSnap = await getDocs(trendingQ);
        setTrendingSearches(trendingSnap.docs.map(d => d.data().term));

        const history = localStorage.getItem('searchHistory');
        if (history) setSearchHistory(JSON.parse(history));
      } catch (error) {
        console.error('Error fetching search data:', error);
      }
    };
    fetchSearchData();
  }, []);

  const fetchProducts = async () => {
    try {
      const snapshot = await getDocs(collection(db, 'products'));
      const data = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Product));
      setProducts(data);
    } catch (error) {
      console.error('Error fetching products:', error);
    } finally {
      setLoading(false);
    }
  };

  const results = useMemo(() => {
    if (!searchQuery.trim()) return [];
    const q = searchQuery.toLowerCase();
    return products.filter(p =>
      p.name?.toLowerCase().includes(q) || p.description?.toLowerCase().includes(q) || p.category?.toLowerCase().includes(q)
    );
  }, [searchQuery, products]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setSearchParams({ q: searchQuery });
      const newHistory = [searchQuery, ...searchHistory.filter(h => h !== searchQuery)].slice(0, 10);
      setSearchHistory(newHistory);
      localStorage.setItem('searchHistory', JSON.stringify(newHistory));
    }
  };

  return (
    <div className="min-h-screen bg-[#080C14] text-white pt-16 pb-8">
      {/* Search Header */}
      <div className="px-4 py-3 border-b border-[#1C2A45]">
        <form onSubmit={handleSearch} className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <input
            type="text"
            placeholder="Cari produk..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            autoFocus
            className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl py-2.5 pl-10 pr-4 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]"
          />
        </form>
      </div>

      {!searchQuery ? (
        <div className="px-4 py-4">
          {/* Search History */}
          <div className="mb-6">
            <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
              <Clock className="w-4 h-4 text-gray-400" /> Riwayat Pencarian
            </h3>
            <div className="flex flex-wrap gap-2">
              {searchHistory.map((term, i) => (
                <button
                  key={i}
                  onClick={() => { setSearchQuery(term); setSearchParams({ q: term }); }}
                  className="px-3 py-1.5 bg-[#131B2D] border border-[#1C2A45] rounded-full text-xs text-gray-400 hover:border-[#00F0FF]/40 transition-colors"
                >
                  {escapeHtml(term)}
                </button>
              ))}
            </div>
          </div>

          {/* Trending */}
          <div>
            <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-gray-400" /> Paling Banyak Dicari
            </h3>
            <div className="flex flex-wrap gap-2">
              {trendingSearches.map((term, i) => (
                <button
                  key={i}
                  onClick={() => { setSearchQuery(term); setSearchParams({ q: term }); }}
                  className="px-3 py-1.5 bg-gradient-to-r from-[#7C3AED]/10 to-[#3B82F6]/10 border border-[#00F0FF]/20 rounded-full text-xs text-[#00F0FF]"
                >
                  {escapeHtml(term)}
                </button>
              ))}
            </div>
          </div>
        </div>
      ) : (
        <div className="px-4 py-4">
          <p className="text-sm text-gray-500 mb-4">{results.length} hasil untuk &quot;{escapeHtml(searchQuery)}&quot;</p>
          {results.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-500">Tidak ada hasil untuk &quot;{escapeHtml(searchQuery)}&quot;</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-3">
              {results.map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
