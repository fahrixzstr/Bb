import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Bug, Send, CheckCircle } from 'lucide-react';
import { useStore } from '@/stores/useStore';
import { toast } from 'sonner';
import { db } from '@/lib/firebase';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';

const bugTypes = [
  'Tampilan/UI',
  'Fungsionalitas',
  'Performa',
  'Keamanan',
  'Login/Auth',
  'Pembayaran',
  'Lainnya',
];

export default function ReportBugPage() {
  const navigate = useNavigate();
  const { user } = useStore();
  const [bugType, setBugType] = useState('');
  const [description, setDescription] = useState('');
  const [deviceInfo, setDeviceInfo] = useState('');
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    // Auto-fill device info
    const info = `${navigator.userAgent} | ${window.screen.width}x${window.screen.height}`;
    setDeviceInfo(info);
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!bugType || !description) {
      toast.error('Semua field wajib diisi');
      return;
    }
    setLoading(true);
    try {
      await addDoc(collection(db, 'supportTickets'), {
        userId: user?.uid || 'anonymous',
        userName: user?.displayName || 'Anonymous',
        type: 'bug_report',
        bugType,
        description,
        deviceInfo,
        status: 'waiting_admin',
        createdAt: serverTimestamp(),
      });
      setSubmitted(true);
      toast.success('Bug report terkirim! Terima kasih atas laporannya.');
    } catch (error) {
      toast.error('Gagal mengirim laporan');
    } finally {
      setLoading(false);
    }
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-[#080C14] text-white flex flex-col items-center justify-center px-6">
        <CheckCircle className="w-16 h-16 text-green-400 mb-4" />
        <h2 className="text-xl font-bold mb-2">Terima Kasih!</h2>
        <p className="text-gray-400 text-sm text-center max-w-xs mb-6">
          Laporan bug Anda telah terkirim. Tim kami akan segera menindaklanjuti.
        </p>
        <button
          onClick={() => navigate('/settings')}
          className="px-6 py-3 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] rounded-full text-sm font-medium hover:opacity-90"
        >
          Kembali
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#080C14] text-white pb-20">
      <div className="sticky top-0 z-40 bg-[#080C14]/80 backdrop-blur-md border-b border-[#1C2A45]">
        <div className="flex items-center gap-3 px-4 py-3">
          <button onClick={() => navigate(-1)} className="p-2 rounded-lg hover:bg-white/5">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-bold">Lapor Bug</h1>
        </div>
      </div>

      <div className="px-4 py-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-xl bg-red-500/10 flex items-center justify-center">
            <Bug className="w-6 h-6 text-red-400" />
          </div>
          <div>
            <h2 className="text-lg font-bold">Laporkan Masalah</h2>
            <p className="text-xs text-gray-400">Bantu kami meningkatkan kualitas layanan</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Bug Type */}
          <div>
            <label className="text-sm font-medium mb-2 block">Jenis Masalah</label>
            <div className="grid grid-cols-2 gap-2">
              {bugTypes.map(type => (
                <button
                  key={type}
                  type="button"
                  onClick={() => setBugType(type)}
                  className={`py-2 px-3 rounded-lg text-sm transition-colors ${
                    bugType === type ? 'bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white' : 'bg-[#131B2D] text-gray-400 border border-[#1C2A45]'
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="text-sm font-medium mb-2 block">Deskripsi Detail</label>
            <textarea
              value={description}
              onChange={e => setDescription(e.target.value)}
              placeholder="Jelaskan masalah yang Anda temui..."
              required
              rows={5}
              className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl p-4 text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF] resize-none"
            />
          </div>

          {/* Device Info (auto-filled) */}
          <div>
            <label className="text-sm font-medium mb-2 block">Info Perangkat (auto)</label>
            <div className="bg-[#131B2D] border border-[#1C2A45] rounded-xl p-3">
              <p className="text-xs text-gray-500 font-mono break-all">{deviceInfo}</p>
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white rounded-full font-medium hover:opacity-90 transition-opacity disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {loading ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <>
                <Send className="w-4 h-4" /> Kirim Laporan
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
