import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Calendar, Clock, Tag, ChevronRight } from 'lucide-react';
import { db } from '@/lib/firebase';
import { collection, getDocs, query, orderBy } from 'firebase/firestore';

interface Event {
  eventId: string;
  title: string;
  description: string;
  image?: string;
  startDate: string;
  endDate: string;
  discount?: number;
  active: boolean;
  link?: string;
}

export default function EventsPage() {
  const navigate = useNavigate();
  const [events, setEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchEvents();
  }, []);

  const fetchEvents = async () => {
    try {
      const q = query(collection(db, 'events'), orderBy('createdAt', 'desc'));
      const snapshot = await getDocs(q);
      const data = snapshot.docs.map(d => d.data() as Event);
      setEvents(data);
    } catch (error) {
      console.error('Error fetching events:', error);
    } finally {
      setLoading(false);
    }
  };

  const isActive = (event: Event) => {
    const now = new Date();
    return event.active && new Date(event.startDate) <= now && new Date(event.endDate) >= now;
  };

  return (
    <div className="min-h-screen bg-[#080C14] text-white pb-20">
      <div className="sticky top-0 z-40 bg-[#080C14]/80 backdrop-blur-md border-b border-[#1C2A45]">
        <div className="flex items-center gap-3 px-4 py-3">
          <button onClick={() => navigate(-1)} className="p-2 rounded-lg hover:bg-white/5">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-bold">Event & Promo</h1>
        </div>
      </div>

      <div className="px-4 py-6 space-y-4">
        {events.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20">
            <Calendar className="w-16 h-16 text-gray-600 mb-4" />
            <p className="text-gray-400 text-sm">Belum ada event saat ini</p>
            <p className="text-xs text-gray-600 mt-1">Nantikan event menarik dari kami!</p>
          </div>
        ) : (
          events.map(event => (
            <div
              key={event.eventId}
              className="cyber-bg rounded-2xl overflow-hidden hover:border-[#00F0FF]/40 transition-colors cursor-pointer"
              onClick={() => event.link && window.open(event.link, '_blank')}
            >
              {event.image && (
                <div className="h-40 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] flex items-center justify-center">
                  <Calendar className="w-16 h-16 text-white/30" />
                </div>
              )}
              <div className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  {isActive(event) ? (
                    <span className="px-2 py-0.5 bg-green-500/20 text-green-400 text-xs rounded-full">Berlangsung</span>
                  ) : (
                    <span className="px-2 py-0.5 bg-gray-500/20 text-gray-400 text-xs rounded-full">Berakhir</span>
                  )}
                  {event.discount && (
                    <span className="px-2 py-0.5 bg-[#7C3AED]/20 text-[#7C3AED] text-xs rounded-full flex items-center gap-1">
                      <Tag className="w-3 h-3" /> Diskon {event.discount}%
                    </span>
                  )}
                </div>
                <h3 className="text-lg font-bold mb-1">{event.title}</h3>
                <p className="text-sm text-gray-400 mb-3">{event.description}</p>
                <div className="flex items-center gap-4 text-xs text-gray-500">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {new Date(event.startDate).toLocaleDateString('id-ID')} - {new Date(event.endDate).toLocaleDateString('id-ID')}
                  </span>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
