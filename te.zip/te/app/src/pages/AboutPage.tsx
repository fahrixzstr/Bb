import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Zap, Target, Shield, Users, Globe, Heart } from 'lucide-react';

export default function AboutPage() {
  const navigate = useNavigate();

  const values = [
    { icon: Zap, title: 'Inovasi', desc: 'Selalu mengadopsi teknologi terbaru untuk memberikan solusi terbaik.' },
    { icon: Target, title: 'Kecepatan', desc: 'Layanan yang responsif dan efisien untuk memenuhi kebutuhan Anda.' },
    { icon: Shield, title: 'Aksesibilitas', desc: 'Platform yang mudah diakses oleh semua kalangan.' },
    { icon: Users, title: 'Profesionalitas', desc: 'Tim berpengalaman dengan standar layanan profesional.' },
    { icon: Globe, title: 'Ekosistem Digital', desc: 'Membangun ekosistem digital berkelanjutan.' },
    { icon: Heart, title: 'Integritas', desc: 'Menjaga kepercayaan pelanggan dengan transparansi.' },
  ];

  const missions = [
    'Memberikan solusi digital terintegrasi dalam satu platform',
    'Mendukung pertumbuhan ekonomi digital Indonesia',
    'Menyediakan layanan berkualitas dengan harga terjangkau',
    'Membangun komunitas digital yang inovatif',
    'Terus berinovasi mengikuti perkembangan teknologi',
  ];

  return (
    <div className="min-h-screen bg-[#080C14] text-white pb-20">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-[#080C14]/80 backdrop-blur-md border-b border-[#1C2A45]">
        <div className="flex items-center gap-3 px-4 py-3">
          <button onClick={() => navigate(-1)} className="p-2 rounded-lg hover:bg-white/5">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-bold">Tentang Kami</h1>
        </div>
      </div>

      <div className="px-4 py-6 space-y-8">
        {/* Hero */}
        <div className="text-center">
          <div className="logo-icon scale-[1.5] mx-auto mb-4">
            <span className="block h-1 bg-gradient-to-r from-[#00F0FF] to-[#0077FF] rounded-full w-full" />
            <span className="block h-1 bg-gradient-to-r from-[#00F0FF] to-[#0077FF] rounded-full w-3/4" />
            <span className="block h-1 bg-gradient-to-r from-[#00F0FF] to-[#0077FF] rounded-full w-1/2" />
          </div>
          <h2 className="text-2xl font-bold text-gradient mb-2">FahriXz Store</h2>
          <p className="text-gray-400 text-sm max-w-md mx-auto">
            Platform ekosistem digital yang menggabungkan berbagai layanan dalam satu sistem terpadu.
          </p>
        </div>

        {/* Profile */}
        <div className="cyber-bg rounded-2xl p-5">
          <h3 className="text-lg font-bold mb-3">Profil Perusahaan</h3>
          <p className="text-gray-400 text-sm leading-relaxed">
            FahrixzStore adalah platform ekosistem digital yang menggabungkan berbagai layanan dalam satu sistem terpadu.
            Kami menyediakan produk digital, layanan jasa teknologi, dan fitur Misi Cuan untuk mendukung pertumbuhan ekonomi digital.
          </p>
        </div>

        {/* Bidang Layanan */}
        <div className="cyber-bg rounded-2xl p-5">
          <h3 className="text-lg font-bold mb-3">Bidang Layanan</h3>
          <div className="space-y-3">
            <div className="flex gap-3">
              <div className="w-8 h-8 rounded-lg bg-[#7C3AED]/20 flex items-center justify-center flex-shrink-0">
                <Zap className="w-4 h-4 text-[#7C3AED]" />
              </div>
              <div>
                <h4 className="text-sm font-semibold">Produk Digital</h4>
                <p className="text-xs text-gray-400">Script, software, template, bot WhatsApp, panel Pterodactyl, tools otomatisasi, aset digital</p>
              </div>
            </div>
            <div className="flex gap-3">
              <div className="w-8 h-8 rounded-lg bg-[#3B82F6]/20 flex items-center justify-center flex-shrink-0">
                <Globe className="w-4 h-4 text-[#3B82F6]" />
              </div>
              <div>
                <h4 className="text-sm font-semibold">Layanan Jasa Teknologi</h4>
                <p className="text-xs text-gray-400">Pembuatan website, pengembangan bot, desain UI/UX, custom development</p>
              </div>
            </div>
            <div className="flex gap-3">
              <div className="w-8 h-8 rounded-lg bg-[#00F0FF]/20 flex items-center justify-center flex-shrink-0">
                <Target className="w-4 h-4 text-[#00F0FF]" />
              </div>
              <div>
                <h4 className="text-sm font-semibold">Fitur Misi Cuan</h4>
                <p className="text-xs text-gray-400">Sistem tugas digital untuk freelancer</p>
              </div>
            </div>
          </div>
        </div>

        {/* Visi */}
        <div className="cyber-bg rounded-2xl p-5">
          <h3 className="text-lg font-bold mb-2">Visi</h3>
          <p className="text-gray-400 text-sm">
            Menjadi platform ekosistem digital terpercaya yang mendukung pertumbuhan ekonomi digital.
          </p>
        </div>

        {/* Misi */}
        <div className="cyber-bg rounded-2xl p-5">
          <h3 className="text-lg font-bold mb-3">Misi</h3>
          <ol className="space-y-2">
            {missions.map((mission, i) => (
              <li key={i} className="flex gap-2 text-sm text-gray-400">
                <span className="text-[#7C3AED] font-bold flex-shrink-0">{i + 1}.</span>
                {mission}
              </li>
            ))}
          </ol>
        </div>

        {/* Nilai */}
        <div className="cyber-bg rounded-2xl p-5">
          <h3 className="text-lg font-bold mb-4">Nilai Perusahaan</h3>
          <div className="grid grid-cols-2 gap-4">
            {values.map((v, i) => (
              <div key={i} className="text-center">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-r from-[#7C3AED]/20 to-[#3B82F6]/20 flex items-center justify-center mx-auto mb-2">
                  <v.icon className="w-5 h-5 text-[#00F0FF]" />
                </div>
                <h4 className="text-sm font-semibold">{v.title}</h4>
                <p className="text-xs text-gray-400 mt-1">{v.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Developer Info */}
        <div className="cyber-bg rounded-2xl p-5">
          <h3 className="text-lg font-bold mb-3">Developer</h3>
          <div className="space-y-2 text-sm text-gray-400">
            <p><span className="text-white">Nama:</span> Fahri Andrian Saputra</p>
            <p><span className="text-white">Email:</span> fahrixzstore@gmail.com</p>
            <p><span className="text-white">WhatsApp:</span> <a href="https://whatsapp.com/channel/0029VbCHdOx7j6gAsxGkZ80m" target="_blank" rel="noopener noreferrer" className="text-[#00F0FF] hover:underline">Channel WA</a></p>
            <p><span className="text-white">TikTok:</span> @fahriandriansaputraa</p>
            <p><span className="text-white">Instagram:</span> @fhrandrnsptra</p>
          </div>
        </div>
      </div>
    </div>
  );
}
