import { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Send, Paperclip, Mic, MoreVertical, MessageCircle } from 'lucide-react';
import { getAIResponse, quickReplies } from '@/lib/openai';

interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
}

const welcomeMessage: ChatMessage = {
  id: '1',
  sender: 'ai',
  text: 'Halo! Saya adalah AI Customer Service FahrixzStore. Saya hanya bisa membantu pertanyaan seputar produk, layanan, dan fitur yang ada di website FahrixzStore. Ada yang bisa saya bantu?',
  timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
};

export default function CustomerServicePage() {
  const navigate = useNavigate();
  const [messages, setMessages] = useState<ChatMessage[]>([welcomeMessage]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = async (text: string) => {
    if (!text.trim()) return;
    const newMessage: ChatMessage = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
    };
    setMessages(prev => [...prev, newMessage]);
    setInput('');
    setIsTyping(true);

    try {
      const aiResponse = await getAIResponse(text);
      setIsTyping(false);
      const aiMessage: ChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'ai',
        text: aiResponse,
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
      setIsTyping(false);
      const errorMessage: ChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'ai',
        text: 'Maaf, layanan AI sedang tidak tersedia. Silakan coba lagi nanti atau hubungi admin melalui WhatsApp Channel: https://whatsapp.com/channel/0029VbCHdOx7j6gAsxGkZ80m',
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages(prev => [...prev, errorMessage]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    sendMessage(input);
  };

  return (
    <div className="min-h-screen bg-[#080C14] text-white flex flex-col">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-[#1C2A45] bg-[#080C14]/80 backdrop-blur-md sticky top-0 z-30">
        <button onClick={() => navigate(-1)}><ArrowLeft className="w-5 h-5 text-gray-400" /></button>
        <div className="w-9 h-9 rounded-full bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] flex items-center justify-center">
          <MessageCircle className="w-5 h-5 text-white" />
        </div>
        <div className="flex-1">
          <h1 className="text-sm font-semibold text-white">AI Customer Service</h1>
          <div className="flex items-center gap-1">
            <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
            <span className="text-xs text-green-400">Online</span>
          </div>
        </div>
        <button className="p-2 rounded-lg hover:bg-white/5">
          <MoreVertical className="w-5 h-5 text-gray-400" />
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages.length === 0 && (
          <div className="flex flex-col items-center justify-center py-16">
            <div className="w-20 h-20 rounded-full bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] flex items-center justify-center mb-4">
              <MessageCircle className="w-10 h-10 text-white" />
            </div>
            <h3 className="text-white font-semibold mb-1">Halo! Ada yang bisa kami bantu?</h3>
            <p className="text-gray-500 text-sm text-center max-w-xs">AI Customer Service siap membantu Anda dengan pertanyaan seputar FahrixzStore.</p>
          </div>
        )}

        {messages.map(msg => (
          <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
            {msg.sender === 'ai' && (
              <div className="w-7 h-7 rounded-full bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] flex items-center justify-center mr-2 flex-shrink-0 self-end">
                <MessageCircle className="w-4 h-4 text-white" />
              </div>
            )}
            <div className={`max-w-[75%] p-3 rounded-2xl ${
              msg.sender === 'user'
                ? 'bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white rounded-tr-sm'
                : 'bg-[#131B2D] border border-[#1C2A45] text-white rounded-tl-sm'
            }`}>
              <p className="text-sm whitespace-pre-wrap">{msg.text}</p>
              <p className={`text-[10px] mt-1 ${msg.sender === 'user' ? 'text-white/60' : 'text-gray-500'}`}>{msg.timestamp}</p>
            </div>
          </div>
        ))}

        {isTyping && (
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-full bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] flex items-center justify-center">
              <MessageCircle className="w-4 h-4 text-white" />
            </div>
            <div className="bg-[#131B2D] border border-[#1C2A45] rounded-2xl rounded-tl-sm p-3">
              <div className="flex gap-1">
                <span className="w-2 h-2 bg-gray-500 rounded-full animate-bounce" />
                <span className="w-2 h-2 bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} />
                <span className="w-2 h-2 bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />

        {/* Quick Replies */}
        {messages.length <= 2 && (
          <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-2">
            {quickReplies.map(reply => (
              <button
                key={reply}
                onClick={() => sendMessage(reply)}
                className="px-3 py-1.5 bg-[#131B2D] border border-[#1C2A45] rounded-full text-xs text-gray-400 whitespace-nowrap hover:border-[#00F0FF]/40 hover:text-white transition-colors"
              >
                {reply}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Input */}
      <form onSubmit={handleSubmit} className="p-4 border-t border-[#1C2A45] bg-[#080C14]">
        <div className="flex items-center gap-2">
          <button type="button" className="p-2 rounded-lg hover:bg-white/5">
            <Paperclip className="w-5 h-5 text-gray-400" />
          </button>
          <div className="flex-1 relative">
            <input
              type="text"
              value={input}
              onChange={e => setInput(e.target.value)}
              placeholder="Ketik pesan Anda..."
              className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-full py-2.5 px-4 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]"
            />
          </div>
          <button type="button" className="p-2 rounded-lg hover:bg-white/5">
            <Mic className="w-5 h-5 text-gray-400" />
          </button>
          <button
            type="submit"
            disabled={!input.trim() || isTyping}
            className="p-2.5 rounded-full bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] disabled:opacity-30 transition-opacity"
          >
            <Send className="w-4 h-4 text-white" />
          </button>
        </div>
      </form>
    </div>
  );
}
