import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { ArrowLeft, User, CreditCard, Globe, Moon, Mail, Shield, Bell, Lock, Info, ChevronRight, Check } from 'lucide-react';
import { useStore } from '@/stores/useStore';
import { useToast } from '@/hooks/use-toast';

const sections = [
  { key: 'profile', icon: User, label: 'Edit Profil', requireAuth: true },
  { key: 'withdrawal', icon: CreditCard, label: 'Nomor Penarikan', requireAuth: true },
  { key: 'language', icon: Globe, label: 'Bahasa', requireAuth: false },
  { key: 'theme', icon: Moon, label: 'Tema', requireAuth: false },
  { key: 'email', icon: Mail, label: 'Verifikasi Email', requireAuth: true },
  { key: 'security', icon: Shield, label: 'Keamanan', requireAuth: true },
  { key: 'notifications', icon: Bell, label: 'Notifikasi', requireAuth: true },
  { key: 'privacy', icon: Lock, label: 'Privasi', requireAuth: true },
  { key: 'about', icon: Info, label: 'Tentang', requireAuth: false },
];

export default function SettingsPage() {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const { user, theme, language, setTheme, setLanguage } = useStore();
  const { toast } = useToast();
  const [activeSection, setActiveSection] = useState<string | null>(null);
  const [selectedLang, setSelectedLang] = useState(language);
  const [selectedTheme, setSelectedTheme] = useState(theme);
  const [profile, setProfile] = useState({
    displayName: user?.displayName || '',
    username: user?.username || '',
    email: user?.email || '',
    phoneNumber: user?.phoneNumber || '',
    bio: user?.bio || '',
  });

  const visibleSections = sections.filter(s => !s.requireAuth || !!user);

  const handleSaveLanguage = () => {
    setLanguage(selectedLang);
    toast({ title: 'Bahasa diperbarui', description: 'Pengaturan bahasa berhasil disimpan' });
    setActiveSection(null);
  };

  const handleSaveTheme = () => {
    setTheme(selectedTheme);
    toast({ title: 'Tema diperbarui', description: 'Pengaturan tema berhasil disimpan' });
    setActiveSection(null);
  };

  const handleSaveProfile = () => {
    toast({ title: 'Profil diperbarui', description: 'Data profil berhasil disimpan' });
    setActiveSection(null);
  };

  const renderContent = () => {
    if (!activeSection) return null;

    switch (activeSection) {
      case 'language':
        return (
          <div className="p-4">
            <h2 className="text-lg font-bold text-white mb-4">{t('language')}</h2>
            <div className="space-y-2">
              {[
                { key: 'id' as const, label: 'Bahasa Indonesia' },
                { key: 'en' as const, label: 'English' },
              ].map(lang => (
                <button
                  key={lang.key}
                  onClick={() => setSelectedLang(lang.key)}
                  className={`w-full flex items-center justify-between p-4 rounded-xl transition-colors ${
                    selectedLang === lang.key ? 'bg-gradient-to-r from-[#7C3AED]/20 to-[#3B82F6]/20 border border-[#00F0FF]/30' : 'bg-[#131B2D] border border-[#1C2A45]'
                  }`}
                >
                  <span className="text-white">{lang.label}</span>
                  {selectedLang === lang.key && <Check className="w-5 h-5 text-[#00F0FF]" />}
                </button>
              ))}
            </div>
            <button onClick={handleSaveLanguage} className="w-full mt-4 py-3 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white rounded-xl font-medium">
              {t('save')}
            </button>
          </div>
        );

      case 'theme':
        return (
          <div className="p-4">
            <h2 className="text-lg font-bold text-white mb-4">{t('theme')}</h2>
            <div className="space-y-2">
              {[
                { key: 'dark' as const, label: t('dark') },
                { key: 'light' as const, label: t('light') },
              ].map(th => (
                <button
                  key={th.key}
                  onClick={() => setSelectedTheme(th.key)}
                  className={`w-full flex items-center justify-between p-4 rounded-xl transition-colors ${
                    selectedTheme === th.key ? 'bg-gradient-to-r from-[#7C3AED]/20 to-[#3B82F6]/20 border border-[#00F0FF]/30' : 'bg-[#131B2D] border border-[#1C2A45]'
                  }`}
                >
                  <span className="text-white">{th.label}</span>
                  {selectedTheme === th.key && <Check className="w-5 h-5 text-[#00F0FF]" />}
                </button>
              ))}
            </div>
            <button onClick={handleSaveTheme} className="w-full mt-4 py-3 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white rounded-xl font-medium">
              {t('save')}
            </button>
          </div>
        );

      case 'profile':
        return (
          <div className="p-4">
            <h2 className="text-lg font-bold text-white mb-4">{t('edit')} Profil</h2>
            <div className="space-y-3">
              <div>
                <label className="text-sm text-gray-400 mb-1 block">{t('full_name')}</label>
                <input
                  type="text"
                  value={profile.displayName}
                  onChange={e => setProfile({ ...profile, displayName: e.target.value })}
                  className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-[#00F0FF]"
                />
              </div>
              <div>
                <label className="text-sm text-gray-400 mb-1 block">{t('username')}</label>
                <input
                  type="text"
                  value={profile.username}
                  onChange={e => setProfile({ ...profile, username: e.target.value })}
                  className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-[#00F0FF]"
                />
              </div>
              <div>
                <label className="text-sm text-gray-400 mb-1 block">{t('email')}</label>
                <input
                  type="email"
                  value={profile.email}
                  onChange={e => setProfile({ ...profile, email: e.target.value })}
                  className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-[#00F0FF]"
                />
              </div>
              <div>
                <label className="text-sm text-gray-400 mb-1 block">{t('phone')}</label>
                <input
                  type="tel"
                  value={profile.phoneNumber}
                  onChange={e => setProfile({ ...profile, phoneNumber: e.target.value })}
                  className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-[#00F0FF]"
                />
              </div>
              <div>
                <label className="text-sm text-gray-400 mb-1 block">{t('bio')}</label>
                <textarea
                  value={profile.bio}
                  onChange={e => setProfile({ ...profile, bio: e.target.value })}
                  rows={3}
                  className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-[#00F0FF] resize-none"
                />
              </div>
            </div>
            <button onClick={handleSaveProfile} className="w-full mt-4 py-3 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white rounded-xl font-medium">
              {t('save')}
            </button>
          </div>
        );

      default:
        return (
          <div className="p-4 text-center">
            <p className="text-gray-500">Fitur ini akan segera hadir</p>
            <button onClick={() => setActiveSection(null)} className="mt-4 px-6 py-2 bg-[#131B2D] border border-[#1C2A45] rounded-xl text-sm text-gray-400">
              {t('back')}
            </button>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-[#080C14] text-white pt-16 pb-8">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-[#1C2A45]">
        {activeSection ? (
          <button onClick={() => setActiveSection(null)}><ArrowLeft className="w-5 h-5 text-gray-400" /></button>
        ) : (
          <button onClick={() => navigate(-1)}><ArrowLeft className="w-5 h-5 text-gray-400" /></button>
        )}
        <h1 className="text-lg font-bold">{t('settings')}</h1>
      </div>

      {activeSection ? (
        renderContent()
      ) : (
        <div className="px-4 mt-4 space-y-1">
          {visibleSections.map(section => {
            const Icon = section.icon;
            return (
              <button
                key={section.key}
                onClick={() => setActiveSection(section.key)}
                className="w-full flex items-center gap-3 p-4 bg-[#131B2D] border border-[#1C2A45] rounded-xl mb-2 hover:bg-[#1C2A45] transition-colors"
              >
                <div className="w-10 h-10 rounded-xl bg-[#080C14] flex items-center justify-center">
                  <Icon className="w-5 h-5 text-gray-400" />
                </div>
                <span className="flex-1 text-left text-sm text-white">{section.label}</span>
                <ChevronRight className="w-4 h-4 text-gray-500" />
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
