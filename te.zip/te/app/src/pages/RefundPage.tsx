import { useNavigate } from 'react-router-dom';
import { ArrowLeft, RefreshCw } from 'lucide-react';

export default function RefundPage() {
  const navigate = useNavigate();

  const policies = [
    'Refund dapat diajukan dalam waktu 7 hari setelah pembelian produk.',
    'Refund hanya berlaku untuk produk yang mengalami masalah teknis yang tidak dapat diselesaikan.',
    'Produk yang sudah diaktifkan atau digunakan tidak dapat direfund kecuali terdapat cacat produk.',
    'Pengajuan refund harus disertai dengan bukti masalah yang jelas.',
    'Proses refund memakan waktu 3-7 hari kerja setelah pengajuan disetujui.',
    'Refund akan dikembalikan melalui metode pembayaran yang sama saat pembelian.',
    'Produk digital yang sudah didownload tidak dapat direfund kecuali rusak/corrupt.',
    'Layanan jasa yang sudah dimulai tidak dapat direfund.',
    'FahrixzStore berhak menolak pengajuan refund jika tidak memenuhi syarat.',
    'Kebijakan refund ini dapat berubah sewaktu-waktu tanpa pemberitahuan terlebih dahulu.',
  ];

  return (
    <div className="min-h-screen bg-[#080C14] text-white pb-20">
      <div className="sticky top-0 z-40 bg-[#080C14]/80 backdrop-blur-md border-b border-[#1C2A45]">
        <div className="flex items-center gap-3 px-4 py-3">
          <button onClick={() => navigate(-1)} className="p-2 rounded-lg hover:bg-white/5">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-bold">Kebijakan Refund</h1>
        </div>
      </div>

      <div className="px-4 py-6 space-y-4">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-[#7C3AED]/20 to-[#3B82F6]/20 flex items-center justify-center">
            <RefreshCw className="w-6 h-6 text-[#00F0FF]" />
          </div>
          <div>
            <h2 className="text-xl font-bold">Refund Policy</h2>
            <p className="text-xs text-gray-400">Terakhir diperbarui: Juni 2025</p>
          </div>
        </div>

        <div className="cyber-bg rounded-2xl p-5">
          <p className="text-sm text-gray-400 mb-4">
            FahrixzStore berkomitmen untuk memberikan kepuasan pelanggan. Kebijakan refund ini mengatur ketentuan pengembalian dana untuk produk dan layanan yang dibeli di platform kami.
          </p>
          <ol className="space-y-3">
            {policies.map((policy, i) => (
              <li key={i} className="flex gap-3 text-sm text-gray-400">
                <span className="w-6 h-6 rounded-full bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] flex items-center justify-center text-xs font-bold flex-shrink-0">{i + 1}</span>
                {policy}
              </li>
            ))}
          </ol>
        </div>
      </div>
    </div>
  );
}
