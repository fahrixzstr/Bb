import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Mail, Lock, Eye, EyeOff, Shield, AlertTriangle } from 'lucide-react';
import { useStore } from '@/stores/useStore';
import { toast } from 'sonner';
import { auth, db } from '@/lib/firebase';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';

export default function AdminLoginPage() {
  const navigate = useNavigate();
  const { setUser, setIsLoggedIn, setIsAdmin } = useStore();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      toast.error('Email dan password wajib diisi');
      return;
    }
    setLoading(true);

    try {
      // Sign in with Firebase Auth
      const result = await signInWithEmailAndPassword(auth, email, password);

      // Check if user is admin via Firestore
      const adminDoc = await getDoc(doc(db, 'adminUsers', result.user.uid));

      if (!adminDoc.exists()) {
        toast.error('Akses Ditolak', { description: 'Anda tidak memiliki hak akses admin.' });
        setLoading(false);
        return;
      }

      const adminData = adminDoc.data();

      if (!adminData.active) {
        toast.error('Akun Admin Non-Aktif', { description: 'Hubungi super admin untuk aktivasi.' });
        setLoading(false);
        return;
      }

      // Set user data
      const userDoc = await getDoc(doc(db, 'users', result.user.uid));
      const userData = userDoc.exists() ? userDoc.data() : {};

      setUser({
        uid: result.user.uid,
        email: result.user.email,
        displayName: result.user.displayName || userData.displayName || 'Admin',
        photoURL: result.user.photoURL,
        phoneNumber: result.user.phoneNumber,
        role: 'admin',
        ...userData,
      });
      setIsLoggedIn(true);
      setIsAdmin(true);

      toast.success('Admin Login Berhasil!', { description: 'Selamat datang di panel admin!' });
      navigate('/admin');
    } catch (error: any) {
      toast.error('Login Gagal', { description: error.message || 'Email atau password salah' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#080C14] text-white flex flex-col items-center justify-center px-6">
      {/* Warning Banner */}
      <div className="mb-6 flex items-center gap-2 bg-red-500/10 border border-red-500/30 rounded-xl px-4 py-3 max-w-sm w-full">
        <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0" />
        <p className="text-xs text-red-400">Area Khusus Admin. Akses tidak sah akan dicatat.</p>
      </div>

      {/* Logo */}
      <div className="mb-8">
        <div className="logo-icon scale-[2] mx-auto mb-4">
          <span className="block h-1 bg-gradient-to-r from-[#00F0FF] to-[#0077FF] rounded-full w-full" />
          <span className="block h-1 bg-gradient-to-r from-[#00F0FF] to-[#0077FF] rounded-full w-3/4" />
          <span className="block h-1 bg-gradient-to-r from-[#00F0FF] to-[#0077FF] rounded-full w-1/2" />
        </div>
        <h1 className="text-center text-2xl font-bold">ADMIN PANEL</h1>
      </div>

      <div className="flex items-center gap-2 mb-6">
        <Shield className="w-5 h-5 text-[#00F0FF]" />
        <span className="text-gray-400 text-sm">Login dengan kredensial admin</span>
      </div>

      <form onSubmit={handleLogin} className="w-full max-w-sm space-y-4">
        <div className="relative">
          <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
          <input
            type="email"
            placeholder="Email Admin"
            value={email}
            onChange={e => setEmail(e.target.value)}
            required
            className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl py-3 pl-11 pr-4 text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]"
          />
        </div>
        <div className="relative">
          <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
          <input
            type={showPassword ? 'text' : 'password'}
            placeholder="Kata sandi"
            value={password}
            onChange={e => setPassword(e.target.value)}
            required
            className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl py-3 pl-11 pr-11 text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]"
          />
          <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2">
            {showPassword ? <EyeOff className="w-5 h-5 text-gray-500" /> : <Eye className="w-5 h-5 text-gray-500" />}
          </button>
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full py-3 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white rounded-full font-medium hover:opacity-90 transition-opacity disabled:opacity-50"
        >
          {loading ? (
            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mx-auto" />
          ) : (
            'Login Admin'
          )}
        </button>
      </form>

      <button onClick={() => navigate('/')} className="mt-6 text-sm text-gray-500 hover:text-gray-400">
        Kembali ke Beranda
      </button>
    </div>
  );
}
