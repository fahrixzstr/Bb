import { useState, useEffect } from 'react';
import { Shield, Plus, Download, CheckCircle, XCircle } from 'lucide-react';
import { toast } from 'sonner';
import { db } from '@/lib/firebase';
import { collection, getDocs, addDoc, updateDoc, doc, serverTimestamp } from 'firebase/firestore';
import { generateKTACode, generateKTACardSVG, downloadKTACard } from '@/lib/kta-generator';

interface KTARecord {
  id: string;
  ktaId: string;
  ktaCode: string;
  fullName: string;
  userId: string;
  websiteName: string;
  developerName: string;
  createdAt: string;
  expiresAt: string;
  status: 'active' | 'expired' | 'revoked';
}

export default function AdminKTAManagement() {
  const [ktas, setKTAs] = useState<KTARecord[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    fullName: '', userId: '', websiteName: 'FahriXz Store', developerName: 'Fahri Andrian Saputra',
  });

  useEffect(() => {
    fetchKTAs();
  }, []);

  const fetchKTAs = async () => {
    try {
      const snapshot = await getDocs(collection(db, 'ktaRecords'));
      const data = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as KTARecord));
      setKTAs(data);
    } catch (error) {
      console.error('Error fetching KTAs:', error);
    }
  };

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const ktaCode = generateKTACode();
      const ktaId = `KTA-${Date.now()}`;
      const now = new Date();
      const expiresAt = new Date(now.getFullYear() + 1, now.getMonth(), now.getDate());

      const ktaData = {
        ktaId,
        ktaCode,
        userId: formData.userId,
        websiteName: formData.websiteName,
        developerName: formData.developerName,
        fullName: formData.fullName,
        createdAt: now.toISOString(),
        expiresAt: expiresAt.toISOString(),
        status: 'active' as const,
        createdAtServer: serverTimestamp(),
      };

      await addDoc(collection(db, 'ktaRecords'), ktaData);

      // Generate and download SVG
      const svg = generateKTACardSVG(ktaData);
      downloadKTACard(svg, `KTA-${ktaCode}.svg`);

      toast.success('KTA berhasil dibuat dan diunduh!');
      setShowForm(false);
      setFormData({ fullName: '', userId: '', websiteName: 'FahriXz Store', developerName: 'Fahri Andrian Saputra' });
      fetchKTAs();
    } catch (error) {
      toast.error('Gagal membuat KTA');
    }
  };

  const handleRevoke = async (id: string) => {
    if (!confirm('Yakin ingin mencabut KTA ini?')) return;
    try {
      await updateDoc(doc(db, 'ktaRecords', id), { status: 'revoked' });
      toast.success('KTA dicabut!');
      fetchKTAs();
    } catch (error) {
      toast.error('Gagal mencabut KTA');
    }
  };

  const handleDownload = (kta: KTARecord) => {
    const svg = generateKTACardSVG(kta);
    downloadKTACard(svg, `KTA-${kta.ktaCode}.svg`);
    toast.success('KTA diunduh!');
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">KTA Management</h1>
        <button
          onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] rounded-lg text-sm font-medium hover:opacity-90"
        >
          <Plus className="w-4 h-4" /> Generate KTA
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-4">
        <div className="cyber-bg rounded-xl p-4 text-center">
          <Shield className="w-6 h-6 mx-auto mb-2 text-[#7C3AED]" />
          <p className="text-2xl font-bold">{ktas.length}</p>
          <p className="text-xs text-gray-400">Total KTA</p>
        </div>
        <div className="cyber-bg rounded-xl p-4 text-center">
          <CheckCircle className="w-6 h-6 mx-auto mb-2 text-green-400" />
          <p className="text-2xl font-bold">{ktas.filter(k => k.status === 'active').length}</p>
          <p className="text-xs text-gray-400">Aktif</p>
        </div>
        <div className="cyber-bg rounded-xl p-4 text-center">
          <XCircle className="w-6 h-6 mx-auto mb-2 text-red-400" />
          <p className="text-2xl font-bold">{ktas.filter(k => k.status === 'revoked').length}</p>
          <p className="text-xs text-gray-400">Dicabut</p>
        </div>
        <div className="cyber-bg rounded-xl p-4 text-center">
          <Shield className="w-6 h-6 mx-auto mb-2 text-yellow-400" />
          <p className="text-2xl font-bold">{ktas.filter(k => k.status === 'expired').length}</p>
          <p className="text-xs text-gray-400">Expired</p>
        </div>
      </div>

      {/* Generate Form */}
      {showForm && (
        <form onSubmit={handleGenerate} className="cyber-bg rounded-2xl p-6 space-y-4">
          <h3 className="text-lg font-bold">Generate KTA Baru</h3>
          <div className="grid grid-cols-2 gap-4">
            <input type="text" placeholder="Nama Lengkap" value={formData.fullName} onChange={e => setFormData({ ...formData, fullName: e.target.value })} required className="bg-[#080C14] border border-[#1C2A45] rounded-lg py-2.5 px-4 text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]" />
            <input type="text" placeholder="User ID" value={formData.userId} onChange={e => setFormData({ ...formData, userId: e.target.value })} required className="bg-[#080C14] border border-[#1C2A45] rounded-lg py-2.5 px-4 text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]" />
            <input type="text" placeholder="Website Name" value={formData.websiteName} onChange={e => setFormData({ ...formData, websiteName: e.target.value })} className="bg-[#080C14] border border-[#1C2A45] rounded-lg py-2.5 px-4 text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]" />
            <input type="text" placeholder="Developer Name" value={formData.developerName} onChange={e => setFormData({ ...formData, developerName: e.target.value })} className="bg-[#080C14] border border-[#1C2A45] rounded-lg py-2.5 px-4 text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]" />
          </div>
          <div className="flex gap-3">
            <button type="submit" className="flex items-center gap-2 px-6 py-2 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] rounded-lg text-sm font-medium hover:opacity-90">
              <Shield className="w-4 h-4" /> Generate & Download
            </button>
            <button type="button" onClick={() => setShowForm(false)} className="px-6 py-2 border border-[#1C2A45] rounded-lg text-sm text-gray-400 hover:bg-[#131B2D]">Batal</button>
          </div>
        </form>
      )}

      {/* KTA List */}
      <div className="space-y-3">
        {ktas.map(kta => (
          <div key={kta.id} className="cyber-bg rounded-xl p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-[#7C3AED]/20 to-[#3B82F6]/20 flex items-center justify-center">
                  <Shield className="w-5 h-5 text-[#00F0FF]" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="text-sm font-bold">{kta.fullName}</h4>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${
                      kta.status === 'active' ? 'bg-green-500/20 text-green-400' :
                      kta.status === 'expired' ? 'bg-yellow-500/20 text-yellow-400' :
                      'bg-red-500/20 text-red-400'
                    }`}>
                      {kta.status}
                    </span>
                  </div>
                  <p className="text-xs text-gray-400 font-mono">{kta.ktaCode} | {kta.websiteName}</p>
                  <p className="text-xs text-gray-500">Berlaku: {new Date(kta.createdAt).toLocaleDateString('id-ID')} - {new Date(kta.expiresAt).toLocaleDateString('id-ID')}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button onClick={() => handleDownload(kta)} className="p-2 rounded-lg hover:bg-[#7C3AED]/10 text-[#7C3AED]">
                  <Download className="w-4 h-4" />
                </button>
                {kta.status === 'active' && (
                  <button onClick={() => handleRevoke(kta.id)} className="p-2 rounded-lg hover:bg-red-500/10 text-red-400">
                    <XCircle className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
