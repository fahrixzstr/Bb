import { useState, useEffect } from 'react';
import { Shield, Ban, Globe, Clock } from 'lucide-react';
import { toast } from 'sonner';
import { db } from '@/lib/firebase';
import { collection, getDocs, addDoc, deleteDoc, doc, serverTimestamp } from 'firebase/firestore';

interface BlockedIP {
  id: string;
  ip: string;
  reason: string;
  blockedBy: string;
  blockedAt: string;
  status: 'active' | 'unblocked';
}

export default function AdminIPManagement() {
  const [blockedIPs, setBlockedIPs] = useState<BlockedIP[]>([]);
  const [ipInput, setIpInput] = useState('');
  const [reasonInput, setReasonInput] = useState('');

  useEffect(() => {
    fetchBlockedIPs();
  }, []);

  const fetchBlockedIPs = async () => {
    try {
      const snapshot = await getDocs(collection(db, 'blockedIPs'));
      const data = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as BlockedIP));
      setBlockedIPs(data);
    } catch (error) {
      console.error('Error fetching blocked IPs:', error);
    }
  };

  const handleBlock = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!ipInput || !reasonInput) {
      toast.error('IP dan alasan wajib diisi');
      return;
    }
    try {
      await addDoc(collection(db, 'blockedIPs'), {
        ip: ipInput,
        reason: reasonInput,
        blockedBy: 'admin',
        blockedAt: serverTimestamp(),
        status: 'active',
      });
      toast.success(`IP ${ipInput} berhasil diblokir`);
      setIpInput('');
      setReasonInput('');
      fetchBlockedIPs();
    } catch (error) {
      toast.error('Gagal memblokir IP');
    }
  };

  const handleUnblock = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'blockedIPs', id));
      toast.success('IP berhasil diunblock');
      fetchBlockedIPs();
    } catch (error) {
      toast.error('Gagal unblock IP');
    }
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">IP Management</h1>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        <div className="cyber-bg rounded-xl p-4 text-center">
          <Ban className="w-6 h-6 mx-auto mb-2 text-red-400" />
          <p className="text-2xl font-bold">{blockedIPs.filter(i => i.status === 'active').length}</p>
          <p className="text-xs text-gray-400">IP Diblokir</p>
        </div>
        <div className="cyber-bg rounded-xl p-4 text-center">
          <Globe className="w-6 h-6 mx-auto mb-2 text-[#7C3AED]" />
          <p className="text-2xl font-bold">{blockedIPs.length}</p>
          <p className="text-xs text-gray-400">Total Record</p>
        </div>
        <div className="cyber-bg rounded-xl p-4 text-center">
          <Shield className="w-6 h-6 mx-auto mb-2 text-green-400" />
          <p className="text-2xl font-bold">{blockedIPs.filter(i => i.status === 'unblocked').length}</p>
          <p className="text-xs text-gray-400">Diunblock</p>
        </div>
      </div>

      {/* Block Form */}
      <form onSubmit={handleBlock} className="cyber-bg rounded-2xl p-6 space-y-4">
        <h3 className="text-lg font-bold">Blokir IP Baru</h3>
        <div className="grid grid-cols-2 gap-4">
          <input
            type="text"
            placeholder="Alamat IP (e.g., 192.168.1.1)"
            value={ipInput}
            onChange={e => setIpInput(e.target.value)}
            required
            className="bg-[#080C14] border border-[#1C2A45] rounded-lg py-2.5 px-4 text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]"
          />
          <input
            type="text"
            placeholder="Alasan pemblokiran"
            value={reasonInput}
            onChange={e => setReasonInput(e.target.value)}
            required
            className="bg-[#080C14] border border-[#1C2A45] rounded-lg py-2.5 px-4 text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]"
          />
        </div>
        <button type="submit" className="px-6 py-2 bg-red-500/20 text-red-400 border border-red-500/30 rounded-lg text-sm font-medium hover:bg-red-500/30">
          <Ban className="w-4 h-4 inline mr-1" /> Blokir IP
        </button>
      </form>

      {/* Blocked IPs List */}
      <div className="cyber-bg rounded-2xl overflow-hidden">
        <div className="p-4 border-b border-[#1C2A45]">
          <h3 className="text-sm font-bold">Daftar IP Diblokir</h3>
        </div>
        <div className="divide-y divide-[#1C2A45]">
          {blockedIPs.length === 0 ? (
            <div className="p-6 text-center text-sm text-gray-500">Belum ada IP yang diblokir</div>
          ) : (
            blockedIPs.map(ip => (
              <div key={ip.id} className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-red-500/10 flex items-center justify-center">
                    <Ban className="w-4 h-4 text-red-400" />
                  </div>
                  <div>
                    <p className="text-sm font-mono font-bold">{ip.ip}</p>
                    <p className="text-xs text-gray-400">{ip.reason}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className={`text-xs px-2 py-1 rounded-full ${ip.status === 'active' ? 'bg-red-500/20 text-red-400' : 'bg-green-500/20 text-green-400'}`}>
                    {ip.status}
                  </span>
                  {ip.status === 'active' && (
                    <button onClick={() => handleUnblock(ip.id)} className="px-3 py-1 text-xs bg-green-500/20 text-green-400 rounded-lg hover:bg-green-500/30">
                      Unblock
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
