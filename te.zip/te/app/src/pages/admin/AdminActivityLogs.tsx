import { useState, useEffect } from 'react';
import { Activity, Clock, User, Monitor } from 'lucide-react';
import { db } from '@/lib/firebase';
import { collection, getDocs, query, orderBy } from 'firebase/firestore';

interface ActivityLog {
  id: string;
  userId: string;
  userName: string;
  action: string;
  details: string;
  ipAddress: string;
  timestamp: string;
}

export default function AdminActivityLogs() {
  const [logs, setLogs] = useState<ActivityLog[]>([]);
  const [filter, setFilter] = useState('');

  useEffect(() => {
    fetchLogs();
  }, []);

  const fetchLogs = async () => {
    try {
      const q = query(collection(db, 'activityLogs'), orderBy('timestamp', 'desc'));
      const snapshot = await getDocs(q);
      const data = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as ActivityLog));
      setLogs(data);
    } catch (error) {
      console.error('Error fetching activity logs:', error);
    }
  };

  const filteredLogs = logs.filter(log =>
    log.userName?.toLowerCase().includes(filter.toLowerCase()) ||
    log.action?.toLowerCase().includes(filter.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Activity Logs</h1>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        <div className="cyber-bg rounded-xl p-4 text-center">
          <Activity className="w-6 h-6 mx-auto mb-2 text-[#7C3AED]" />
          <p className="text-2xl font-bold">{logs.length}</p>
          <p className="text-xs text-gray-400">Total Activities</p>
        </div>
        <div className="cyber-bg rounded-xl p-4 text-center">
          <User className="w-6 h-6 mx-auto mb-2 text-green-400" />
          <p className="text-2xl font-bold">{new Set(logs.map(l => l.userId)).size}</p>
          <p className="text-xs text-gray-400">Unique Users</p>
        </div>
        <div className="cyber-bg rounded-xl p-4 text-center">
          <Clock className="w-6 h-6 mx-auto mb-2 text-yellow-400" />
          <p className="text-2xl font-bold">{logs.filter(l => {
            const d = new Date(l.timestamp);
            const now = new Date();
            return now.getTime() - d.getTime() < 24 * 60 * 60 * 1000;
          }).length}</p>
          <p className="text-xs text-gray-400">Last 24 Hours</p>
        </div>
      </div>

      {/* Filter */}
      <input
        type="text"
        placeholder="Filter berdasarkan user atau action..."
        value={filter}
        onChange={e => setFilter(e.target.value)}
        className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl py-2.5 px-4 text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]"
      />

      {/* Logs Table */}
      <div className="cyber-bg rounded-2xl overflow-hidden">
        <div className="grid grid-cols-12 gap-4 p-4 border-b border-[#1C2A45] text-xs text-gray-400 font-medium">
          <div className="col-span-2">Timestamp</div>
          <div className="col-span-2">User</div>
          <div className="col-span-3">Action</div>
          <div className="col-span-3">Details</div>
          <div className="col-span-2">IP Address</div>
        </div>
        <div className="max-h-[500px] overflow-y-auto divide-y divide-[#1C2A45]">
          {filteredLogs.length === 0 ? (
            <div className="p-6 text-center text-sm text-gray-500">Belum ada activity log</div>
          ) : (
            filteredLogs.map(log => (
              <div key={log.id} className="grid grid-cols-12 gap-4 p-4 items-center hover:bg-[#131B2D]/50">
                <div className="col-span-2 text-xs text-gray-400">
                  {log.timestamp ? new Date(log.timestamp).toLocaleString('id-ID') : '-'}
                </div>
                <div className="col-span-2 text-sm">{log.userName || log.userId}</div>
                <div className="col-span-3 text-sm">
                  <span className="px-2 py-0.5 bg-[#7C3AED]/20 text-[#7C3AED] text-xs rounded-full">{log.action}</span>
                </div>
                <div className="col-span-3 text-xs text-gray-400">{log.details}</div>
                <div className="col-span-2 text-xs font-mono text-gray-500">{log.ipAddress}</div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
