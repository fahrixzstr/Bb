import { useState, useEffect } from 'react';
import { Shield, Lock, Unlock, Eye } from 'lucide-react';
import { db } from '@/lib/firebase';
import { collection, getDocs, query, orderBy } from 'firebase/firestore';

interface SecurityLog {
  id: string;
  userId: string;
  action: string;
  ipAddress: string;
  deviceInfo: string;
  timestamp: string;
}

export default function AdminSecurity() {
  const [logs, setLogs] = useState<SecurityLog[]>([]);
  const [stats, setStats] = useState({ totalLogs: 0, uniqueIPs: 0, failedLogins: 0 });

  useEffect(() => {
    fetchSecurityData();
  }, []);

  const fetchSecurityData = async () => {
    try {
      const q = query(collection(db, 'securityLogs'), orderBy('timestamp', 'desc'));
      const snapshot = await getDocs(q);
      const data = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as SecurityLog));
      setLogs(data);

      const uniqueIPs = new Set(data.map(d => d.ipAddress));
      const failed = data.filter(d => d.action?.toLowerCase().includes('failed') || d.action?.toLowerCase().includes('gagal'));

      setStats({
        totalLogs: data.length,
        uniqueIPs: uniqueIPs.size,
        failedLogins: failed.length,
      });
    } catch (error) {
      console.error('Error fetching security data:', error);
    }
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Keamanan</h1>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        <div className="cyber-bg rounded-xl p-4 text-center">
          <Eye className="w-6 h-6 mx-auto mb-2 text-[#7C3AED]" />
          <p className="text-2xl font-bold">{stats.totalLogs}</p>
          <p className="text-xs text-gray-400">Total Log</p>
        </div>
        <div className="cyber-bg rounded-xl p-4 text-center">
          <Shield className="w-6 h-6 mx-auto mb-2 text-green-400" />
          <p className="text-2xl font-bold">{stats.uniqueIPs}</p>
          <p className="text-xs text-gray-400">IP Unik</p>
        </div>
        <div className="cyber-bg rounded-xl p-4 text-center">
          <Lock className="w-6 h-6 mx-auto mb-2 text-red-400" />
          <p className="text-2xl font-bold">{stats.failedLogins}</p>
          <p className="text-xs text-gray-400">Login Gagal</p>
        </div>
      </div>

      {/* 2FA Settings */}
      <div className="cyber-bg rounded-2xl p-6">
        <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
          <Shield className="w-5 h-5 text-[#00F0FF]" /> Autentikasi Dua Faktor (2FA)
        </h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between bg-[#080C14] border border-[#1C2A45] rounded-lg p-3">
            <div>
              <p className="text-sm font-medium">Email OTP</p>
              <p className="text-xs text-gray-400">Verifikasi login dengan kode OTP email</p>
            </div>
            <div className="w-12 h-6 rounded-full bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] relative">
              <div className="w-4 h-4 bg-white rounded-full absolute top-1 translate-x-7" />
            </div>
          </div>
          <div className="flex items-center justify-between bg-[#080C14] border border-[#1C2A45] rounded-lg p-3">
            <div>
              <p className="text-sm font-medium">Login Notification</p>
              <p className="text-xs text-gray-400">Notifikasi saat ada login dari perangkat baru</p>
            </div>
            <div className="w-12 h-6 rounded-full bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] relative">
              <div className="w-4 h-4 bg-white rounded-full absolute top-1 translate-x-7" />
            </div>
          </div>
        </div>
      </div>

      {/* Security Logs */}
      <div className="cyber-bg rounded-2xl overflow-hidden">
        <div className="p-4 border-b border-[#1C2A45]">
          <h3 className="text-sm font-bold">Security Logs</h3>
        </div>
        <div className="divide-y divide-[#1C2A45] max-h-96 overflow-y-auto">
          {logs.length === 0 ? (
            <div className="p-6 text-center text-sm text-gray-500">Belum ada log keamanan</div>
          ) : (
            logs.map(log => (
              <div key={log.id} className="p-3">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-medium">{log.action}</p>
                  <span className="text-xs text-gray-500">{log.timestamp ? new Date(log.timestamp).toLocaleString('id-ID') : '-'}</span>
                </div>
                <div className="flex items-center gap-4 text-xs text-gray-500 mt-1">
                  <span>IP: {log.ipAddress}</span>
                  <span>{log.deviceInfo?.substring(0, 50)}...</span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
