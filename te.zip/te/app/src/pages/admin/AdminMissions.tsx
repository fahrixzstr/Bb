import { useState } from 'react';
import { Search, Plus, Pencil, Trash2, CheckCircle, XCircle, Clock, Target } from 'lucide-react';

const missions = [
  { missionId: 'M001', title: 'Review Aplikasi', category: 'review', reward: 15000, participants: 45, status: 'active' },
  { missionId: 'M002', title: 'Registrasi Akun Baru', category: 'registrasi', reward: 25000, participants: 32, status: 'active' },
  { missionId: 'M003', title: 'Download Game', category: 'download', reward: 20000, participants: 28, status: 'active' },
  { missionId: 'M004', title: 'Isi Survey', category: 'survey', reward: 10000, participants: 67, status: 'ended' },
  { missionId: 'M005', title: 'Main Game Level 5', category: 'game', reward: 35000, participants: 15, status: 'active' },
];

const statusConfig: Record<string, { color: string; label: string }> = {
  active: { color: 'bg-green-500/10 text-green-400', label: 'Aktif' },
  ended: { color: 'bg-gray-500/10 text-gray-400', label: 'Berakhir' },
  pending: { color: 'bg-yellow-500/10 text-yellow-400', label: 'Pending' },
};

export default function AdminMissions() {
  const [search, setSearch] = useState('');
  const [showAdd, setShowAdd] = useState(false);

  const filtered = missions.filter(m =>
    !search || m.title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold text-white">Kelola Misi</h2>
        <button
          onClick={() => setShowAdd(true)}
          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white rounded-xl text-sm font-medium"
        >
          <Plus className="w-4 h-4" /> Tambah Misi
        </button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
        <input
          type="text"
          placeholder="Cari misi..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl py-2.5 pl-10 pr-4 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]"
        />
      </div>

      <div className="cyber-bg rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="text-left text-xs text-gray-500 border-b border-[#1C2A45]">
                <th className="p-4 font-medium">ID</th>
                <th className="p-4 font-medium">Judul</th>
                <th className="p-4 font-medium">Kategori</th>
                <th className="p-4 font-medium">Reward</th>
                <th className="p-4 font-medium">Peserta</th>
                <th className="p-4 font-medium">Status</th>
                <th className="p-4 font-medium">Aksi</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(mission => {
                const config = statusConfig[mission.status] || statusConfig.pending;
                return (
                  <tr key={mission.missionId} className="border-b border-[#1C2A45]/50 hover:bg-white/5 transition-colors">
                    <td className="p-4 text-sm text-[#00F0FF]">{mission.missionId}</td>
                    <td className="p-4 text-sm text-white">{mission.title}</td>
                    <td className="p-4 text-sm text-gray-400 capitalize">{mission.category}</td>
                    <td className="p-4 text-sm text-[#00F0FF]">Rp {mission.reward.toLocaleString('id-ID')}</td>
                    <td className="p-4 text-sm text-white">{mission.participants}</td>
                    <td className="p-4">
                      <span className={`text-xs px-2 py-0.5 rounded-full ${config.color}`}>{config.label}</span>
                    </td>
                    <td className="p-4">
                      <div className="flex gap-1">
                        <button className="p-1.5 rounded-lg hover:bg-white/5"><Pencil className="w-4 h-4 text-blue-400" /></button>
                        <button className="p-1.5 rounded-lg hover:bg-green-500/10"><CheckCircle className="w-4 h-4 text-green-400" /></button>
                        <button className="p-1.5 rounded-lg hover:bg-red-500/10"><Trash2 className="w-4 h-4 text-red-400" /></button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
