import { useState } from 'react';
import { Search, Shield, ShieldCheck, Ban, Eye } from 'lucide-react';

const users = [
  { uid: '1', name: 'Ahmad Fauzi', email: 'ahmad@email.com', role: 'user', status: 'active', joined: '2026-01-15', orders: 24, spent: 1250000 },
  { uid: '2', name: 'Siti Nurhaliza', email: 'siti@email.com', role: 'user', status: 'active', joined: '2026-02-20', orders: 18, spent: 890000 },
  { uid: '3', name: 'Budi Santoso', email: 'budi@email.com', role: 'user', status: 'suspended', joined: '2026-03-10', orders: 5, spent: 175000 },
  { uid: '4', name: 'Dewi Lestari', email: 'dewi@email.com', role: 'admin', status: 'active', joined: '2025-12-01', orders: 0, spent: 0 },
  { uid: '5', name: 'Rudi Hartono', email: 'rudi@email.com', role: 'user', status: 'active', joined: '2026-04-05', orders: 12, spent: 560000 },
];

export default function AdminUsers() {
  const [search, setSearch] = useState('');
  const filtered = users.filter(u =>
    !search || u.name.toLowerCase().includes(search.toLowerCase()) || u.email.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold text-white">Kelola Pengguna</h2>
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
        <input
          type="text"
          placeholder="Cari user..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl py-2.5 pl-10 pr-4 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]"
        />
      </div>
      <div className="cyber-bg rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="text-left text-xs text-gray-500 border-b border-[#1C2A45]">
                <th className="p-4 font-medium">User</th>
                <th className="p-4 font-medium">Role</th>
                <th className="p-4 font-medium">Status</th>
                <th className="p-4 font-medium">Orders</th>
                <th className="p-4 font-medium">Total Spent</th>
                <th className="p-4 font-medium">Aksi</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(user => (
                <tr key={user.uid} className="border-b border-[#1C2A45]/50 hover:bg-white/5 transition-colors">
                  <td className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] flex items-center justify-center text-white text-xs font-bold">
                        {user.name.charAt(0)}
                      </div>
                      <div>
                        <p className="text-sm text-white">{user.name}</p>
                        <p className="text-xs text-gray-500">{user.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="p-4">
                    <span className={`text-xs px-2 py-0.5 rounded-full ${
                      user.role === 'admin' ? 'bg-purple-500/10 text-purple-400' : 'bg-blue-500/10 text-blue-400'
                    }`}>
                      {user.role === 'admin' ? 'Admin' : 'User'}
                    </span>
                  </td>
                  <td className="p-4">
                    <span className={`text-xs px-2 py-0.5 rounded-full ${
                      user.status === 'active' ? 'bg-green-500/10 text-green-400' : 'bg-red-500/10 text-red-400'
                    }`}>
                      {user.status === 'active' ? 'Aktif' : 'Suspended'}
                    </span>
                  </td>
                  <td className="p-4 text-sm text-white">{user.orders}</td>
                  <td className="p-4 text-sm text-white">Rp {user.spent.toLocaleString('id-ID')}</td>
                  <td className="p-4">
                    <div className="flex gap-1">
                      <button className="p-1.5 rounded-lg hover:bg-white/5"><Eye className="w-4 h-4 text-gray-400" /></button>
                      <button className="p-1.5 rounded-lg hover:bg-yellow-500/10"><Shield className="w-4 h-4 text-yellow-400" /></button>
                      <button className="p-1.5 rounded-lg hover:bg-red-500/10"><Ban className="w-4 h-4 text-red-400" /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
