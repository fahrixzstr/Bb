import { useState } from 'react';
import { Search, Plus, Pencil, Trash2, Package } from 'lucide-react';

const products = [
  { id: '1', name: 'Netflix Premium 4K', category: 'Subscription', price: 45000, stock: 100, sold: 8500, status: 'active' },
  { id: '2', name: 'Spotify Premium Family', category: 'Subscription', price: 25000, stock: 80, sold: 6200, status: 'active' },
  { id: '3', name: 'Panel Pterodactyl Basic', category: 'Panel', price: 35000, stock: 50, sold: 3100, status: 'active' },
  { id: '4', name: 'Hosting VPS 2GB', category: 'Hosting', price: 85000, stock: 30, sold: 1800, status: 'low' },
  { id: '5', name: 'YouTube Premium', category: 'Subscription', price: 20000, stock: 90, sold: 4500, status: 'active' },
];

export default function AdminProducts() {
  const [search, setSearch] = useState('');
  const [showAdd, setShowAdd] = useState(false);

  const filtered = products.filter(p =>
    !search || p.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold text-white">Kelola Produk</h2>
        <button
          onClick={() => setShowAdd(true)}
          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white rounded-xl text-sm font-medium hover:opacity-90"
        >
          <Plus className="w-4 h-4" /> Tambah Produk
        </button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
        <input
          type="text"
          placeholder="Cari produk..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl py-2.5 pl-10 pr-4 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]"
        />
      </div>

      <div className="cyber-bg rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="text-left text-xs text-gray-500 border-b border-[#1C2A45]">
                <th className="p-4 font-medium">ID</th>
                <th className="p-4 font-medium">Nama</th>
                <th className="p-4 font-medium">Kategori</th>
                <th className="p-4 font-medium">Harga</th>
                <th className="p-4 font-medium">Stok</th>
                <th className="p-4 font-medium">Terjual</th>
                <th className="p-4 font-medium">Status</th>
                <th className="p-4 font-medium">Aksi</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(product => (
                <tr key={product.id} className="border-b border-[#1C2A45]/50 hover:bg-white/5 transition-colors">
                  <td className="p-4 text-sm text-[#00F0FF]">#{product.id}</td>
                  <td className="p-4 text-sm text-white">{product.name}</td>
                  <td className="p-4 text-sm text-gray-400">{product.category}</td>
                  <td className="p-4 text-sm text-white">Rp {product.price.toLocaleString('id-ID')}</td>
                  <td className="p-4 text-sm text-white">{product.stock}</td>
                  <td className="p-4 text-sm text-white">{product.sold.toLocaleString('id-ID')}</td>
                  <td className="p-4">
                    <span className={`text-xs px-2 py-0.5 rounded-full ${
                      product.status === 'active' ? 'bg-green-500/10 text-green-400' :
                      product.status === 'low' ? 'bg-yellow-500/10 text-yellow-400' :
                      'bg-red-500/10 text-red-400'
                    }`}>
                      {product.status === 'active' ? 'Aktif' : product.status === 'low' ? 'Stok Rendah' : 'Nonaktif'}
                    </span>
                  </td>
                  <td className="p-4">
                    <div className="flex gap-1">
                      <button className="p-1.5 rounded-lg hover:bg-white/5"><Pencil className="w-4 h-4 text-blue-400" /></button>
                      <button className="p-1.5 rounded-lg hover:bg-red-500/10"><Trash2 className="w-4 h-4 text-red-400" /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showAdd && (
        <div className="fixed inset-0 z-50 flex items-center justify-center" onClick={() => setShowAdd(false)}>
          <div className="absolute inset-0 bg-black/60" />
          <div className="relative bg-[#131B2D] border border-[#1C2A45] rounded-2xl p-6 w-full max-w-lg mx-4" onClick={e => e.stopPropagation()}>
            <h3 className="text-lg font-bold text-white mb-4">Tambah Produk</h3>
            <div className="space-y-3">
              <input placeholder="Nama Produk" className="w-full bg-[#080C14] border border-[#1C2A45] rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-[#00F0FF]" />
              <select className="w-full bg-[#080C14] border border-[#1C2A45] rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-[#00F0FF]">
                <option>Subscription</option>
                <option>Panel</option>
                <option>Hosting</option>
                <option>Voucher</option>
              </select>
              <div className="flex gap-3">
                <input type="number" placeholder="Harga" className="flex-1 bg-[#080C14] border border-[#1C2A45] rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-[#00F0FF]" />
                <input type="number" placeholder="Stok" className="flex-1 bg-[#080C14] border border-[#1C2A45] rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-[#00F0FF]" />
              </div>
              <textarea placeholder="Deskripsi" rows={3} className="w-full bg-[#080C14] border border-[#1C2A45] rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-[#00F0FF] resize-none" />
            </div>
            <div className="flex gap-3 mt-6">
              <button onClick={() => setShowAdd(false)} className="flex-1 py-2.5 border border-[#1C2A45] text-gray-400 rounded-xl text-sm">Batal</button>
              <button onClick={() => setShowAdd(false)} className="flex-1 py-2.5 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white rounded-xl text-sm font-medium">Simpan</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
