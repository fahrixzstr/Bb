import { useState, useEffect } from 'react';
import { Plus, Edit2, Trash2, Tag, Search } from 'lucide-react';
import { toast } from 'sonner';
import { db } from '@/lib/firebase';
import { collection, getDocs, addDoc, deleteDoc, doc, serverTimestamp } from 'firebase/firestore';

interface Voucher {
  id: string;
  code: string;
  title: string;
  description: string;
  discountAmount: number;
  discountPercent?: number;
  minPurchase: number;
  expiryDate: string;
  status: 'active' | 'expired' | 'used';
}

export default function AdminVouchers() {
  const [vouchers, setVouchers] = useState<Voucher[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    code: '', title: '', description: '', discountAmount: '', discountPercent: '', minPurchase: '', expiryDate: '',
  });

  useEffect(() => {
    fetchVouchers();
  }, []);

  const fetchVouchers = async () => {
    try {
      const snapshot = await getDocs(collection(db, 'vouchers'));
      const data = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Voucher));
      setVouchers(data);
    } catch (error) {
      console.error('Error fetching vouchers:', error);
    }
  };

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await addDoc(collection(db, 'vouchers'), {
        code: formData.code,
        title: formData.title,
        description: formData.description,
        discountAmount: Number(formData.discountAmount),
        discountPercent: Number(formData.discountPercent) || 0,
        minPurchase: Number(formData.minPurchase),
        expiryDate: formData.expiryDate,
        status: 'active',
        usageCount: 0,
        createdAt: serverTimestamp(),
      });
      toast.success('Voucher berhasil ditambahkan!');
      setShowForm(false);
      setFormData({ code: '', title: '', description: '', discountAmount: '', discountPercent: '', minPurchase: '', expiryDate: '' });
      fetchVouchers();
    } catch (error) {
      toast.error('Gagal menambahkan voucher');
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Yakin ingin menghapus voucher ini?')) return;
    try {
      await deleteDoc(doc(db, 'vouchers', id));
      toast.success('Voucher dihapus!');
      fetchVouchers();
    } catch (error) {
      toast.error('Gagal menghapus voucher');
    }
  };

  const filtered = vouchers.filter(v =>
    v.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    v.code.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Kelola Voucher</h1>
        <button
          onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] rounded-lg text-sm font-medium hover:opacity-90"
        >
          <Plus className="w-4 h-4" /> Tambah Voucher
        </button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
        <input
          type="text"
          placeholder="Cari voucher..."
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl py-2.5 pl-10 pr-4 text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]"
        />
      </div>

      {/* Add Form */}
      {showForm && (
        <form onSubmit={handleAdd} className="cyber-bg rounded-2xl p-6 space-y-4">
          <h3 className="text-lg font-bold">Tambah Voucher Baru</h3>
          <div className="grid grid-cols-2 gap-4">
            <input type="text" placeholder="Kode Voucher" value={formData.code} onChange={e => setFormData({ ...formData, code: e.target.value })} required className="bg-[#080C14] border border-[#1C2A45] rounded-lg py-2.5 px-4 text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]" />
            <input type="text" placeholder="Judul" value={formData.title} onChange={e => setFormData({ ...formData, title: e.target.value })} required className="bg-[#080C14] border border-[#1C2A45] rounded-lg py-2.5 px-4 text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]" />
            <input type="text" placeholder="Deskripsi" value={formData.description} onChange={e => setFormData({ ...formData, description: e.target.value })} className="bg-[#080C14] border border-[#1C2A45] rounded-lg py-2.5 px-4 text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]" />
            <input type="number" placeholder="Diskon (Rp)" value={formData.discountAmount} onChange={e => setFormData({ ...formData, discountAmount: e.target.value })} required className="bg-[#080C14] border border-[#1C2A45] rounded-lg py-2.5 px-4 text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]" />
            <input type="number" placeholder="Diskon (%)" value={formData.discountPercent} onChange={e => setFormData({ ...formData, discountPercent: e.target.value })} className="bg-[#080C14] border border-[#1C2A45] rounded-lg py-2.5 px-4 text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]" />
            <input type="number" placeholder="Min. Pembelian" value={formData.minPurchase} onChange={e => setFormData({ ...formData, minPurchase: e.target.value })} required className="bg-[#080C14] border border-[#1C2A45] rounded-lg py-2.5 px-4 text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]" />
            <input type="date" value={formData.expiryDate} onChange={e => setFormData({ ...formData, expiryDate: e.target.value })} required className="bg-[#080C14] border border-[#1C2A45] rounded-lg py-2.5 px-4 text-white focus:outline-none focus:border-[#00F0FF]" />
          </div>
          <div className="flex gap-3">
            <button type="submit" className="px-6 py-2 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] rounded-lg text-sm font-medium hover:opacity-90">Simpan</button>
            <button type="button" onClick={() => setShowForm(false)} className="px-6 py-2 border border-[#1C2A45] rounded-lg text-sm text-gray-400 hover:bg-[#131B2D]">Batal</button>
          </div>
        </form>
      )}

      {/* Vouchers List */}
      <div className="space-y-3">
        {filtered.map(voucher => (
          <div key={voucher.id} className="cyber-bg rounded-xl p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-[#7C3AED]/20 to-[#3B82F6]/20 flex items-center justify-center">
                <Tag className="w-5 h-5 text-[#00F0FF]" />
              </div>
              <div>
                <h4 className="text-sm font-bold">{voucher.title}</h4>
                <p className="text-xs text-gray-400">{voucher.code} | Min: Rp {voucher.minPurchase.toLocaleString('id-ID')}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className={`text-xs px-2 py-1 rounded-full ${voucher.status === 'active' ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'}`}>
                {voucher.status}
              </span>
              <button onClick={() => handleDelete(voucher.id)} className="p-2 rounded-lg hover:bg-red-500/10 text-red-400">
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
