import { useState } from 'react';
import { Settings, Save } from 'lucide-react';
import { toast } from 'sonner';

export default function AdminSettings() {
  const [settings, setSettings] = useState({
    siteName: 'FahriXz Store',
    siteDescription: 'Platform Ekosistem Digital Terpercaya',
    maintenanceMode: false,
    allowRegistration: true,
    requireEmailVerification: false,
    defaultLanguage: 'id',
    timezone: 'Asia/Jakarta',
    currency: 'IDR',
    coinRate: '10',
    minWithdraw: '10000',
    contactEmail: 'fahrixzstore@gmail.com',
    whatsappChannel: 'https://whatsapp.com/channel/0029VbCHdOx7j6gAsxGkZ80m',
  });

  const handleSave = () => {
    // Save to localStorage for now (in production, save to Firestore config)
    localStorage.setItem('admin_settings', JSON.stringify(settings));
    toast.success('Pengaturan berhasil disimpan!');
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Pengaturan Admin</h1>

      <div className="cyber-bg rounded-2xl p-6 space-y-6">
        {/* Site Settings */}
        <div>
          <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
            <Settings className="w-5 h-5 text-[#00F0FF]" /> Pengaturan Umum
          </h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-xs text-gray-400 mb-1 block">Nama Situs</label>
              <input type="text" value={settings.siteName} onChange={e => setSettings({ ...settings, siteName: e.target.value })} className="w-full bg-[#080C14] border border-[#1C2A45] rounded-lg py-2.5 px-4 text-white focus:outline-none focus:border-[#00F0FF]" />
            </div>
            <div>
              <label className="text-xs text-gray-400 mb-1 block">Deskripsi</label>
              <input type="text" value={settings.siteDescription} onChange={e => setSettings({ ...settings, siteDescription: e.target.value })} className="w-full bg-[#080C14] border border-[#1C2A45] rounded-lg py-2.5 px-4 text-white focus:outline-none focus:border-[#00F0FF]" />
            </div>
            <div>
              <label className="text-xs text-gray-400 mb-1 block">Email Kontak</label>
              <input type="email" value={settings.contactEmail} onChange={e => setSettings({ ...settings, contactEmail: e.target.value })} className="w-full bg-[#080C14] border border-[#1C2A45] rounded-lg py-2.5 px-4 text-white focus:outline-none focus:border-[#00F0FF]" />
            </div>
            <div>
              <label className="text-xs text-gray-400 mb-1 block">WhatsApp Channel</label>
              <input type="text" value={settings.whatsappChannel} onChange={e => setSettings({ ...settings, whatsappChannel: e.target.value })} className="w-full bg-[#080C14] border border-[#1C2A45] rounded-lg py-2.5 px-4 text-white focus:outline-none focus:border-[#00F0FF]" />
            </div>
          </div>
        </div>

        {/* System Settings */}
        <div className="border-t border-[#1C2A45] pt-6">
          <h3 className="text-lg font-bold mb-4">Pengaturan Sistem</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center justify-between bg-[#080C14] border border-[#1C2A45] rounded-lg p-3">
              <span className="text-sm">Mode Maintenance</span>
              <button
                onClick={() => setSettings({ ...settings, maintenanceMode: !settings.maintenanceMode })}
                className={`w-12 h-6 rounded-full transition-colors ${settings.maintenanceMode ? 'bg-gradient-to-r from-[#7C3AED] to-[#3B82F6]' : 'bg-gray-600'} relative`}
              >
                <div className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-transform ${settings.maintenanceMode ? 'translate-x-7' : 'translate-x-1'}`} />
              </button>
            </div>
            <div className="flex items-center justify-between bg-[#080C14] border border-[#1C2A45] rounded-lg p-3">
              <span className="text-sm">Izinkan Registrasi</span>
              <button
                onClick={() => setSettings({ ...settings, allowRegistration: !settings.allowRegistration })}
                className={`w-12 h-6 rounded-full transition-colors ${settings.allowRegistration ? 'bg-gradient-to-r from-[#7C3AED] to-[#3B82F6]' : 'bg-gray-600'} relative`}
              >
                <div className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-transform ${settings.allowRegistration ? 'translate-x-7' : 'translate-x-1'}`} />
              </button>
            </div>
          </div>
        </div>

        {/* Financial Settings */}
        <div className="border-t border-[#1C2A45] pt-6">
          <h3 className="text-lg font-bold mb-4">Pengaturan Keuangan</h3>
          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="text-xs text-gray-400 mb-1 block">Rate Koin (koin per Rp)</label>
              <input type="text" value={settings.coinRate} onChange={e => setSettings({ ...settings, coinRate: e.target.value })} className="w-full bg-[#080C14] border border-[#1C2A45] rounded-lg py-2.5 px-4 text-white focus:outline-none focus:border-[#00F0FF]" />
            </div>
            <div>
              <label className="text-xs text-gray-400 mb-1 block">Minimal Withdraw (Rp)</label>
              <input type="text" value={settings.minWithdraw} onChange={e => setSettings({ ...settings, minWithdraw: e.target.value })} className="w-full bg-[#080C14] border border-[#1C2A45] rounded-lg py-2.5 px-4 text-white focus:outline-none focus:border-[#00F0FF]" />
            </div>
            <div>
              <label className="text-xs text-gray-400 mb-1 block">Mata Uang</label>
              <input type="text" value={settings.currency} disabled className="w-full bg-[#080C14] border border-[#1C2A45] rounded-lg py-2.5 px-4 text-gray-400" />
            </div>
          </div>
        </div>

        <button
          onClick={handleSave}
          className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] rounded-lg text-sm font-medium hover:opacity-90"
        >
          <Save className="w-4 h-4" /> Simpan Pengaturan
        </button>
      </div>
    </div>
  );
}
