import { useState, useEffect } from 'react';
import { Plus, Calendar, Trash2, Edit2 } from 'lucide-react';
import { toast } from 'sonner';
import { db } from '@/lib/firebase';
import { collection, getDocs, addDoc, deleteDoc, doc, serverTimestamp } from 'firebase/firestore';

interface EventItem {
  id: string;
  title: string;
  description: string;
  startDate: string;
  endDate: string;
  discount?: number;
  active: boolean;
}

export default function AdminEvents() {
  const [events, setEvents] = useState<EventItem[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    title: '', description: '', startDate: '', endDate: '', discount: '',
  });

  useEffect(() => {
    fetchEvents();
  }, []);

  const fetchEvents = async () => {
    try {
      const snapshot = await getDocs(collection(db, 'events'));
      const data = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as EventItem));
      setEvents(data);
    } catch (error) {
      console.error('Error fetching events:', error);
    }
  };

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await addDoc(collection(db, 'events'), {
        title: formData.title,
        description: formData.description,
        startDate: formData.startDate,
        endDate: formData.endDate,
        discount: Number(formData.discount) || 0,
        active: true,
        createdAt: serverTimestamp(),
      });
      toast.success('Event berhasil ditambahkan!');
      setShowForm(false);
      setFormData({ title: '', description: '', startDate: '', endDate: '', discount: '' });
      fetchEvents();
    } catch (error) {
      toast.error('Gagal menambahkan event');
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Yakin ingin menghapus event ini?')) return;
    try {
      await deleteDoc(doc(db, 'events', id));
      toast.success('Event dihapus!');
      fetchEvents();
    } catch (error) {
      toast.error('Gagal menghapus event');
    }
  };

  const isActive = (event: EventItem) => {
    const now = new Date();
    return event.active && new Date(event.startDate) <= now && new Date(event.endDate) >= now;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Kelola Event</h1>
        <button
          onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] rounded-lg text-sm font-medium hover:opacity-90"
        >
          <Plus className="w-4 h-4" /> Tambah Event
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleAdd} className="cyber-bg rounded-2xl p-6 space-y-4">
          <h3 className="text-lg font-bold">Tambah Event Baru</h3>
          <div className="grid grid-cols-2 gap-4">
            <input type="text" placeholder="Judul Event" value={formData.title} onChange={e => setFormData({ ...formData, title: e.target.value })} required className="bg-[#080C14] border border-[#1C2A45] rounded-lg py-2.5 px-4 text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]" />
            <input type="text" placeholder="Deskripsi" value={formData.description} onChange={e => setFormData({ ...formData, description: e.target.value })} className="bg-[#080C14] border border-[#1C2A45] rounded-lg py-2.5 px-4 text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]" />
            <input type="date" value={formData.startDate} onChange={e => setFormData({ ...formData, startDate: e.target.value })} required className="bg-[#080C14] border border-[#1C2A45] rounded-lg py-2.5 px-4 text-white focus:outline-none focus:border-[#00F0FF]" />
            <input type="date" value={formData.endDate} onChange={e => setFormData({ ...formData, endDate: e.target.value })} required className="bg-[#080C14] border border-[#1C2A45] rounded-lg py-2.5 px-4 text-white focus:outline-none focus:border-[#00F0FF]" />
            <input type="number" placeholder="Diskon (%)" value={formData.discount} onChange={e => setFormData({ ...formData, discount: e.target.value })} className="bg-[#080C14] border border-[#1C2A45] rounded-lg py-2.5 px-4 text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]" />
          </div>
          <div className="flex gap-3">
            <button type="submit" className="px-6 py-2 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] rounded-lg text-sm font-medium hover:opacity-90">Simpan</button>
            <button type="button" onClick={() => setShowForm(false)} className="px-6 py-2 border border-[#1C2A45] rounded-lg text-sm text-gray-400 hover:bg-[#131B2D]">Batal</button>
          </div>
        </form>
      )}

      <div className="space-y-3">
        {events.map(event => (
          <div key={event.id} className="cyber-bg rounded-xl p-4">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-[#7C3AED]/20 to-[#3B82F6]/20 flex items-center justify-center">
                  <Calendar className="w-5 h-5 text-[#00F0FF]" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="text-sm font-bold">{event.title}</h4>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${isActive(event) ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'}`}>
                      {isActive(event) ? 'Aktif' : 'Non-Aktif'}
                    </span>
                  </div>
                  <p className="text-xs text-gray-400">{event.description}</p>
                  <p className="text-xs text-gray-500 mt-1">{new Date(event.startDate).toLocaleDateString('id-ID')} - {new Date(event.endDate).toLocaleDateString('id-ID')}</p>
                  {event.discount ? <p className="text-xs text-[#7C3AED] mt-1">Diskon {event.discount}%</p> : null}
                </div>
              </div>
              <button onClick={() => handleDelete(event.id)} className="p-2 rounded-lg hover:bg-red-500/10 text-red-400">
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
