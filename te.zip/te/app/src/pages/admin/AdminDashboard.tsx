import { TrendingUp, ShoppingCart, Users, Target, DollarSign, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const stats = [
  { label: 'Total Penjualan', value: 'Rp 125.5M', change: '+12.5%', up: true, icon: DollarSign },
  { label: 'Pesanan Baru', value: '1,284', change: '+8.2%', up: true, icon: ShoppingCart },
  { label: 'User Online', value: '342', change: '+15.3%', up: true, icon: Users },
  { label: 'Misi Aktif', value: '86', change: '-3.1%', up: false, icon: Target },
];

const chartData = [
  { name: 'Sen', value: 4200 },
  { name: 'Sel', value: 5100 },
  { name: 'Rab', value: 4800 },
  { name: 'Kam', value: 6200 },
  { name: 'Jum', value: 7500 },
  { name: 'Sab', value: 8900 },
  { name: 'Min', value: 7200 },
];

const recentTransactions = [
  { id: 'TXN-001', user: 'Ahmad Fauzi', type: 'Pembelian', amount: 45000, status: 'success', time: '2 menit lalu' },
  { id: 'TXN-002', user: 'Siti Nurhaliza', type: 'Top Up', amount: 100000, status: 'success', time: '5 menit lalu' },
  { id: 'TXN-003', user: 'Budi Santoso', type: 'Withdraw', amount: 50000, status: 'pending', time: '10 menit lalu' },
  { id: 'TXN-004', user: 'Dewi Lestari', type: 'Pembelian', amount: 25000, status: 'success', time: '15 menit lalu' },
  { id: 'TXN-005', user: 'Rudi Hartono', type: 'Reward', amount: 15000, status: 'success', time: '20 menit lalu' },
];

export default function AdminDashboard() {
  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        {stats.map(stat => (
          <div key={stat.label} className="cyber-bg rounded-2xl p-5">
            <div className="flex items-start justify-between mb-3">
              <div className="w-10 h-10 rounded-xl bg-[#00F0FF]/10 flex items-center justify-center">
                <stat.icon className="w-5 h-5 text-[#00F0FF]" />
              </div>
              <span className={`flex items-center gap-0.5 text-xs ${stat.up ? 'text-green-400' : 'text-red-400'}`}>
                {stat.up ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                {stat.change}
              </span>
            </div>
            <p className="text-2xl font-bold text-white">{stat.value}</p>
            <p className="text-sm text-gray-500">{stat.label}</p>
          </div>
        ))}
      </div>

      {/* Chart */}
      <div className="cyber-bg rounded-2xl p-5">
        <h3 className="text-white font-semibold mb-4">Revenue Mingguan</h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1C2A45" />
              <XAxis dataKey="name" stroke="#8A95B5" fontSize={12} />
              <YAxis stroke="#8A95B5" fontSize={12} />
              <Tooltip
                contentStyle={{ backgroundColor: '#131B2D', border: '1px solid #1C2A45', borderRadius: '12px' }}
                labelStyle={{ color: '#8A95B5' }}
                itemStyle={{ color: '#00F0FF' }}
              />
              <Line type="monotone" dataKey="value" stroke="#00F0FF" strokeWidth={2} dot={{ fill: '#00F0FF', r: 4 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Recent Transactions */}
      <div className="cyber-bg rounded-2xl p-5">
        <h3 className="text-white font-semibold mb-4">Transaksi Terbaru</h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="text-left text-xs text-gray-500 border-b border-[#1C2A45]">
                <th className="pb-3 font-medium">ID</th>
                <th className="pb-3 font-medium">User</th>
                <th className="pb-3 font-medium">Tipe</th>
                <th className="pb-3 font-medium">Jumlah</th>
                <th className="pb-3 font-medium">Status</th>
                <th className="pb-3 font-medium">Waktu</th>
              </tr>
            </thead>
            <tbody>
              {recentTransactions.map(tx => (
                <tr key={tx.id} className="border-b border-[#1C2A45]/50 hover:bg-white/5 transition-colors">
                  <td className="py-3 text-sm text-[#00F0FF]">{tx.id}</td>
                  <td className="py-3 text-sm text-white">{tx.user}</td>
                  <td className="py-3 text-sm text-gray-400">{tx.type}</td>
                  <td className="py-3 text-sm text-white">Rp {tx.amount.toLocaleString('id-ID')}</td>
                  <td className="py-3">
                    <span className={`text-xs px-2 py-0.5 rounded-full ${
                      tx.status === 'success' ? 'bg-green-500/10 text-green-400' : 'bg-yellow-500/10 text-yellow-400'
                    }`}>
                      {tx.status === 'success' ? 'Sukses' : 'Pending'}
                    </span>
                  </td>
                  <td className="py-3 text-xs text-gray-500">{tx.time}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
