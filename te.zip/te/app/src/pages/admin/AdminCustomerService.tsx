import { useState, useEffect } from 'react';
import { MessageSquare, CheckCircle, Clock, Send } from 'lucide-react';
import { toast } from 'sonner';
import { db } from '@/lib/firebase';
import { collection, getDocs, query, orderBy, updateDoc, doc } from 'firebase/firestore';

interface SupportTicket {
  id: string;
  userId: string;
  userName: string;
  type: string;
  description: string;
  status: string;
  createdAt: string;
  adminReply?: string;
}

export default function AdminCustomerService() {
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(null);
  const [reply, setReply] = useState('');

  useEffect(() => {
    fetchTickets();
  }, []);

  const fetchTickets = async () => {
    try {
      const q = query(collection(db, 'supportTickets'), orderBy('createdAt', 'desc'));
      const snapshot = await getDocs(q);
      const data = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as SupportTicket));
      setTickets(data);
    } catch (error) {
      console.error('Error fetching tickets:', error);
    }
  };

  const handleReply = async () => {
    if (!selectedTicket || !reply.trim()) return;
    try {
      await updateDoc(doc(db, 'supportTickets', selectedTicket.id), {
        status: 'resolved',
        adminReply: reply,
        updatedAt: new Date().toISOString(),
      });
      toast.success('Balasan terkirim!');
      setReply('');
      setSelectedTicket(null);
      fetchTickets();
    } catch (error) {
      toast.error('Gagal mengirim balasan');
    }
  };

  const handleClose = async (id: string) => {
    try {
      await updateDoc(doc(db, 'supportTickets', id), {
        status: 'closed',
        updatedAt: new Date().toISOString(),
      });
      toast.success('Tiket ditutup!');
      fetchTickets();
    } catch (error) {
      toast.error('Gagal menutup tiket');
    }
  };

  const statusCounts = {
    waiting: tickets.filter(t => t.status === 'waiting_admin').length,
    resolved: tickets.filter(t => t.status === 'resolved').length,
    closed: tickets.filter(t => t.status === 'closed').length,
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Customer Service Admin</h1>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        <div className="cyber-bg rounded-xl p-4 text-center">
          <Clock className="w-6 h-6 mx-auto mb-2 text-yellow-400" />
          <p className="text-2xl font-bold">{statusCounts.waiting}</p>
          <p className="text-xs text-gray-400">Menunggu</p>
        </div>
        <div className="cyber-bg rounded-xl p-4 text-center">
          <CheckCircle className="w-6 h-6 mx-auto mb-2 text-green-400" />
          <p className="text-2xl font-bold">{statusCounts.resolved}</p>
          <p className="text-xs text-gray-400">Terjawab</p>
        </div>
        <div className="cyber-bg rounded-xl p-4 text-center">
          <MessageSquare className="w-6 h-6 mx-auto mb-2 text-[#7C3AED]" />
          <p className="text-2xl font-bold">{tickets.length}</p>
          <p className="text-xs text-gray-400">Total Tiket</p>
        </div>
      </div>

      {selectedTicket ? (
        /* Ticket Detail */
        <div className="cyber-bg rounded-2xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-bold">Detail Tiket</h3>
              <p className="text-xs text-gray-400">Dari: {selectedTicket.userName} | {selectedTicket.createdAt ? new Date(selectedTicket.createdAt).toLocaleString('id-ID') : '-'}</p>
            </div>
            <button onClick={() => setSelectedTicket(null)} className="text-sm text-gray-400 hover:text-white">Tutup</button>
          </div>

          <div className="bg-[#080C14] border border-[#1C2A45] rounded-xl p-4">
            <span className="px-2 py-0.5 bg-[#7C3AED]/20 text-[#7C3AED] text-xs rounded-full">{selectedTicket.type}</span>
            <p className="text-sm text-gray-300 mt-3">{selectedTicket.description}</p>
          </div>

          {selectedTicket.adminReply && (
            <div className="bg-green-500/5 border border-green-500/20 rounded-xl p-4">
              <p className="text-xs text-green-400 font-medium mb-1">Balasan Admin:</p>
              <p className="text-sm text-gray-300">{selectedTicket.adminReply}</p>
            </div>
          )}

          {selectedTicket.status !== 'closed' && (
            <>
              <textarea
                value={reply}
                onChange={e => setReply(e.target.value)}
                placeholder="Tulis balasan..."
                rows={4}
                className="w-full bg-[#080C14] border border-[#1C2A45] rounded-xl p-4 text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF] resize-none"
              />
              <div className="flex gap-3">
                <button onClick={handleReply} className="flex items-center gap-2 px-6 py-2 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] rounded-lg text-sm font-medium hover:opacity-90">
                  <Send className="w-4 h-4" /> Kirim Balasan
                </button>
                <button onClick={() => handleClose(selectedTicket.id)} className="px-6 py-2 border border-[#1C2A45] rounded-lg text-sm text-gray-400 hover:bg-[#131B2D]">
                  Tutup Tiket
                </button>
              </div>
            </>
          )}
        </div>
      ) : (
        /* Ticket List */
        <div className="space-y-3">
          {tickets.length === 0 ? (
            <div className="cyber-bg rounded-xl p-8 text-center">
              <MessageSquare className="w-12 h-12 text-gray-600 mx-auto mb-2" />
              <p className="text-sm text-gray-500">Belum ada tiket support</p>
            </div>
          ) : (
            tickets.map(ticket => (
              <button
                key={ticket.id}
                onClick={() => setSelectedTicket(ticket)}
                className="w-full cyber-bg rounded-xl p-4 text-left hover:bg-[#1C2A45] transition-colors"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] flex items-center justify-center text-xs font-bold">
                      {ticket.userName?.charAt(0).toUpperCase() || '?'}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm font-bold">{ticket.userName}</h4>
                        <span className={`text-xs px-2 py-0.5 rounded-full ${
                          ticket.status === 'waiting_admin' ? 'bg-yellow-500/20 text-yellow-400' :
                          ticket.status === 'resolved' ? 'bg-green-500/20 text-green-400' :
                          'bg-gray-500/20 text-gray-400'
                        }`}>
                          {ticket.status}
                        </span>
                      </div>
                      <p className="text-xs text-gray-400">{ticket.type} | {ticket.description?.substring(0, 60)}...</p>
                    </div>
                  </div>
                  <span className="text-xs text-gray-500">{ticket.createdAt ? new Date(ticket.createdAt).toLocaleDateString('id-ID') : '-'}</span>
                </div>
              </button>
            ))
          )}
        </div>
      )}
    </div>
  );
}
