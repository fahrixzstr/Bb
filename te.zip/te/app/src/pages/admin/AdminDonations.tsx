import { useState, useEffect } from 'react';
import { Heart, DollarSign, Users } from 'lucide-react';
import { db } from '@/lib/firebase';
import { collection, getDocs, query, orderBy } from 'firebase/firestore';

interface Donation {
  id: string;
  donorName: string;
  amount: number;
  message?: string;
  createdAt: string;
}

export default function AdminDonations() {
  const [donations, setDonations] = useState<Donation[]>([]);
  const [stats, setStats] = useState({ total: 0, count: 0, avg: 0 });

  useEffect(() => {
    fetchDonations();
  }, []);

  const fetchDonations = async () => {
    try {
      const q = query(collection(db, 'donations'), orderBy('createdAt', 'desc'));
      const snapshot = await getDocs(q);
      const data = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Donation));
      setDonations(data);

      const total = data.reduce((sum, d) => sum + (d.amount || 0), 0);
      setStats({
        total,
        count: data.length,
        avg: data.length > 0 ? Math.round(total / data.length) : 0,
      });
    } catch (error) {
      console.error('Error fetching donations:', error);
    }
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Kelola Donasi</h1>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        <div className="cyber-bg rounded-xl p-4 text-center">
          <DollarSign className="w-6 h-6 mx-auto mb-2 text-green-400" />
          <p className="text-2xl font-bold">{stats.total.toLocaleString('id-ID')}</p>
          <p className="text-xs text-gray-400">Total Donasi</p>
        </div>
        <div className="cyber-bg rounded-xl p-4 text-center">
          <Users className="w-6 h-6 mx-auto mb-2 text-[#7C3AED]" />
          <p className="text-2xl font-bold">{stats.count}</p>
          <p className="text-xs text-gray-400">Jumlah Donatur</p>
        </div>
        <div className="cyber-bg rounded-xl p-4 text-center">
          <Heart className="w-6 h-6 mx-auto mb-2 text-red-400" />
          <p className="text-2xl font-bold">{stats.avg.toLocaleString('id-ID')}</p>
          <p className="text-xs text-gray-400">Rata-rata</p>
        </div>
      </div>

      {/* Donations List */}
      <div className="cyber-bg rounded-2xl overflow-hidden">
        <div className="p-4 border-b border-[#1C2A45]">
          <h3 className="text-sm font-bold">Riwayat Donasi</h3>
        </div>
        {donations.length === 0 ? (
          <div className="p-8 text-center">
            <Heart className="w-12 h-12 text-gray-600 mx-auto mb-2" />
            <p className="text-sm text-gray-500">Belum ada donasi</p>
          </div>
        ) : (
          <div className="divide-y divide-[#1C2A45]">
            {donations.map(d => (
              <div key={d.id} className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] flex items-center justify-center text-xs font-bold">
                    {d.donorName?.charAt(0).toUpperCase() || '?'}
                  </div>
                  <div>
                    <p className="text-sm font-medium">{d.donorName}</p>
                    {d.message && <p className="text-xs text-gray-500">{d.message}</p>}
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-bold text-green-400">Rp {d.amount?.toLocaleString('id-ID')}</p>
                  <p className="text-xs text-gray-500">{d.createdAt ? new Date(d.createdAt).toLocaleDateString('id-ID') : '-'}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
