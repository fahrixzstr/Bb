import { useState, useEffect } from 'react';
import { DollarSign, TrendingUp, TrendingDown, BarChart3 } from 'lucide-react';
import { db } from '@/lib/firebase';
import { collection, getDocs, query, orderBy } from 'firebase/firestore';

interface Transaction {
  id: string;
  type: string;
  amount: number;
  status: string;
  createdAt: string;
  description: string;
}

interface WithdrawalRequest {
  id: string;
  userId: string;
  amount: number;
  status: string;
  createdAt: string;
  accountName: string;
}

export default function AdminFinance() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [withdrawals, setWithdrawals] = useState<WithdrawalRequest[]>([]);
  const [stats, setStats] = useState({
    totalRevenue: 0,
    totalWithdrawals: 0,
    pendingWithdrawals: 0,
    netBalance: 0,
  });

  useEffect(() => {
    fetchFinanceData();
  }, []);

  const fetchFinanceData = async () => {
    try {
      const txSnapshot = await getDocs(query(collection(db, 'transactions'), orderBy('createdAt', 'desc')));
      const txs = txSnapshot.docs.map(d => ({ id: d.id, ...d.data() } as Transaction));
      setTransactions(txs);

      const rev = txs.filter(t => t.type === 'purchase' && t.status === 'success').reduce((sum, t) => sum + (t.amount || 0), 0);

      const wdSnapshot = await getDocs(query(collection(db, 'withdrawalRequests'), orderBy('createdAt', 'desc')));
      const wds = wdSnapshot.docs.map(d => ({ id: d.id, ...d.data() } as WithdrawalRequest));
      setWithdrawals(wds);

      const totalWd = wds.filter(w => w.status === 'success').reduce((sum, w) => sum + (w.amount || 0), 0);
      const pendingWd = wds.filter(w => w.status === 'pending').reduce((sum, w) => sum + (w.amount || 0), 0);

      setStats({
        totalRevenue: rev,
        totalWithdrawals: totalWd,
        pendingWithdrawals: pendingWd,
        netBalance: rev - totalWd,
      });
    } catch (error) {
      console.error('Error fetching finance data:', error);
    }
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Keuangan</h1>

      {/* Stats Cards */}
      <div className="grid grid-cols-4 gap-4">
        <div className="cyber-bg rounded-xl p-4 text-center">
          <DollarSign className="w-6 h-6 mx-auto mb-2 text-green-400" />
          <p className="text-xl font-bold">{stats.totalRevenue.toLocaleString('id-ID')}</p>
          <p className="text-xs text-gray-400">Total Pendapatan</p>
        </div>
        <div className="cyber-bg rounded-xl p-4 text-center">
          <TrendingDown className="w-6 h-6 mx-auto mb-2 text-red-400" />
          <p className="text-xl font-bold">{stats.totalWithdrawals.toLocaleString('id-ID')}</p>
          <p className="text-xs text-gray-400">Total Withdraw</p>
        </div>
        <div className="cyber-bg rounded-xl p-4 text-center">
          <TrendingUp className="w-6 h-6 mx-auto mb-2 text-yellow-400" />
          <p className="text-xl font-bold">{stats.pendingWithdrawals.toLocaleString('id-ID')}</p>
          <p className="text-xs text-gray-400">Pending Withdraw</p>
        </div>
        <div className="cyber-bg rounded-xl p-4 text-center">
          <BarChart3 className="w-6 h-6 mx-auto mb-2 text-[#7C3AED]" />
          <p className="text-xl font-bold">{stats.netBalance.toLocaleString('id-ID')}</p>
          <p className="text-xs text-gray-400">Net Balance</p>
        </div>
      </div>

      {/* Transactions */}
      <div className="cyber-bg rounded-2xl overflow-hidden">
        <div className="p-4 border-b border-[#1C2A45]">
          <h3 className="text-sm font-bold">Transaksi Terbaru</h3>
        </div>
        <div className="divide-y divide-[#1C2A45] max-h-64 overflow-y-auto">
          {transactions.slice(0, 20).map(tx => (
            <div key={tx.id} className="p-3 flex items-center justify-between">
              <div>
                <p className="text-sm font-medium">{tx.description || tx.type}</p>
                <p className="text-xs text-gray-500">{tx.createdAt ? new Date(tx.createdAt).toLocaleDateString('id-ID') : '-'}</p>
              </div>
              <div className="text-right">
                <p className={`text-sm font-bold ${tx.type === 'purchase' || tx.type === 'topup' ? 'text-green-400' : 'text-red-400'}`}>
                  {tx.type === 'purchase' || tx.type === 'topup' ? '+' : '-'}{tx.amount?.toLocaleString('id-ID')}
                </p>
                <span className={`text-xs px-2 py-0.5 rounded-full ${tx.status === 'success' ? 'bg-green-500/20 text-green-400' : tx.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' : 'bg-red-500/20 text-red-400'}`}>
                  {tx.status}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Withdrawal Requests */}
      <div className="cyber-bg rounded-2xl overflow-hidden">
        <div className="p-4 border-b border-[#1C2A45]">
          <h3 className="text-sm font-bold">Permohonan Withdraw</h3>
        </div>
        <div className="divide-y divide-[#1C2A45] max-h-64 overflow-y-auto">
          {withdrawals.length === 0 ? (
            <div className="p-6 text-center text-sm text-gray-500">Belum ada permohonan withdraw</div>
          ) : (
            withdrawals.map(wd => (
              <div key={wd.id} className="p-3 flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">{wd.accountName}</p>
                  <p className="text-xs text-gray-500">{wd.createdAt ? new Date(wd.createdAt).toLocaleDateString('id-ID') : '-'}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-bold">Rp {wd.amount?.toLocaleString('id-ID')}</p>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${wd.status === 'success' ? 'bg-green-500/20 text-green-400' : wd.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' : 'bg-red-500/20 text-red-400'}`}>
                    {wd.status}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
