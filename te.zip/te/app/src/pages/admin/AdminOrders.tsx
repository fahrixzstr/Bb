import { useState } from 'react';
import { Search, Filter, Eye, Package } from 'lucide-react';

const orders = [
  { orderId: 'ORD-20260617-001', user: 'Ahmad Fauzi', product: 'Netflix Premium 4K', qty: 1, total: 45000, status: 'completed', date: '2026-06-17' },
  { orderId: 'ORD-20260617-002', user: 'Siti Nurhaliza', product: 'Spotify Premium Family', qty: 2, total: 50000, status: 'processing', date: '2026-06-17' },
  { orderId: 'ORD-20260616-003', user: 'Budi Santoso', product: 'Panel Pterodactyl', qty: 1, total: 35000, status: 'pending', date: '2026-06-16' },
  { orderId: 'ORD-20260616-004', user: 'Dewi Lestari', product: 'Voucher Google Play', qty: 3, total: 465000, status: 'completed', date: '2026-06-16' },
  { orderId: 'ORD-20260615-005', user: 'Rudi Hartono', product: 'Hosting VPS 2GB', qty: 1, total: 85000, status: 'cancelled', date: '2026-06-15' },
];

const statusColors: Record<string, string> = {
  pending: 'text-yellow-400 bg-yellow-400/10',
  processing: 'text-blue-400 bg-blue-400/10',
  completed: 'text-green-400 bg-green-400/10',
  cancelled: 'text-red-400 bg-red-400/10',
  refund: 'text-gray-400 bg-gray-400/10',
};

const statusLabels: Record<string, string> = {
  pending: 'Belum Bayar',
  processing: 'Di Proses',
  completed: 'Berhasil',
  cancelled: 'Dibatalkan',
  refund: 'Refund',
};

export default function AdminOrders() {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  const filtered = orders.filter(o => {
    if (statusFilter !== 'all' && o.status !== statusFilter) return false;
    if (search) {
      const q = search.toLowerCase();
      return o.orderId.toLowerCase().includes(q) || o.user.toLowerCase().includes(q) || o.product.toLowerCase().includes(q);
    }
    return true;
  });

  return (
    <div className="space-y-4">
      <div className="flex flex-col md:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <input
            type="text"
            placeholder="Cari order ID, user, atau produk..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl py-2.5 pl-10 pr-4 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]"
          />
        </div>
        <select
          value={statusFilter}
          onChange={e => setStatusFilter(e.target.value)}
          className="bg-[#131B2D] border border-[#1C2A45] rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-[#00F0FF]"
        >
          <option value="all">Semua Status</option>
          <option value="pending">Belum Bayar</option>
          <option value="processing">Di Proses</option>
          <option value="completed">Berhasil</option>
          <option value="cancelled">Dibatalkan</option>
        </select>
      </div>

      <div className="cyber-bg rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="text-left text-xs text-gray-500 border-b border-[#1C2A45]">
                <th className="p-4 font-medium">Order ID</th>
                <th className="p-4 font-medium">User</th>
                <th className="p-4 font-medium">Produk</th>
                <th className="p-4 font-medium">Qty</th>
                <th className="p-4 font-medium">Total</th>
                <th className="p-4 font-medium">Status</th>
                <th className="p-4 font-medium">Aksi</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(order => (
                <tr key={order.orderId} className="border-b border-[#1C2A45]/50 hover:bg-white/5 transition-colors">
                  <td className="p-4 text-sm text-[#00F0FF]">{order.orderId}</td>
                  <td className="p-4 text-sm text-white">{order.user}</td>
                  <td className="p-4 text-sm text-gray-400">{order.product}</td>
                  <td className="p-4 text-sm text-white">{order.qty}</td>
                  <td className="p-4 text-sm text-white">Rp {order.total.toLocaleString('id-ID')}</td>
                  <td className="p-4">
                    <span className={`text-xs px-2 py-0.5 rounded-full ${statusColors[order.status]}`}>
                      {statusLabels[order.status]}
                    </span>
                  </td>
                  <td className="p-4">
                    <button className="p-1.5 rounded-lg hover:bg-white/5 transition-colors">
                      <Eye className="w-4 h-4 text-gray-400" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {filtered.length === 0 && (
          <div className="text-center py-12">
            <Package className="w-12 h-12 text-gray-600 mx-auto mb-3" />
            <p className="text-gray-500">Tidak ada pesanan</p>
          </div>
        )}
      </div>
    </div>
  );
}
