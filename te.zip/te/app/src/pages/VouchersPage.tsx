import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Ticket, Copy, Check, Tag } from 'lucide-react';
import { useStore } from '@/stores/useStore';
import { toast } from 'sonner';
import { db } from '@/lib/firebase';
import { collection, getDocs, query, where } from 'firebase/firestore';

interface Voucher {
  voucherId: string;
  code: string;
  title: string;
  description: string;
  discountAmount: number;
  discountPercent?: number;
  minPurchase: number;
  expiryDate: string;
  status: 'active' | 'expired' | 'used';
}

export default function VouchersPage() {
  const navigate = useNavigate();
  const { user } = useStore();
  const [vouchers, setVouchers] = useState<Voucher[]>([]);
  const [userVouchers, setUserVouchers] = useState<string[]>([]);
  const [copiedCode, setCopiedCode] = useState('');
  const [activeTab, setActiveTab] = useState<'all' | 'active' | 'expired'>('all');

  useEffect(() => {
    fetchVouchers();
  }, [user]);

  const fetchVouchers = async () => {
    try {
      const snapshot = await getDocs(collection(db, 'vouchers'));
      const allVouchers = snapshot.docs.map(d => d.data() as Voucher);
      setVouchers(allVouchers);

      if (user?.uid) {
        const userDoc = await getDocs(query(collection(db, 'users'), where('__name__', '==', user.uid)));
        if (!userDoc.empty) {
          setUserVouchers(userDoc.docs[0].data().claimedVouchers || []);
        }
      }
    } catch (error) {
      console.error('Error fetching vouchers:', error);
    }
  };

  const handleCopy = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    toast.success('Kode voucher disalin!');
    setTimeout(() => setCopiedCode(''), 2000);
  };

  const filteredVouchers = vouchers.filter(v => {
    if (activeTab === 'active') return v.status === 'active';
    if (activeTab === 'expired') return v.status === 'expired' || v.status === 'used';
    return true;
  });

  return (
    <div className="min-h-screen bg-[#080C14] text-white pb-20">
      <div className="sticky top-0 z-40 bg-[#080C14]/80 backdrop-blur-md border-b border-[#1C2A45]">
        <div className="flex items-center gap-3 px-4 py-3">
          <button onClick={() => navigate(-1)} className="p-2 rounded-lg hover:bg-white/5">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-bold">Voucher Saya</h1>
        </div>
      </div>

      <div className="px-4 py-6 space-y-4">
        {/* Tabs */}
        <div className="flex gap-2">
          {(['all', 'active', 'expired'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeTab === tab ? 'bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white' : 'bg-[#131B2D] text-gray-400'
              }`}
            >
              {tab === 'all' ? 'Semua' : tab === 'active' ? 'Aktif' : 'Kadaluarsa'}
            </button>
          ))}
        </div>

        {/* Vouchers */}
        {filteredVouchers.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20">
            <Ticket className="w-16 h-16 text-gray-600 mb-4" />
            <p className="text-gray-400 text-sm">Belum ada voucher</p>
          </div>
        ) : (
          <div className="space-y-3">
            {filteredVouchers.map(voucher => (
              <div key={voucher.voucherId} className={`cyber-bg rounded-xl p-4 ${voucher.status !== 'active' ? 'opacity-50' : ''}`}>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-[#7C3AED]/20 to-[#3B82F6]/20 flex items-center justify-center">
                      <Tag className="w-5 h-5 text-[#00F0FF]" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold">{voucher.title}</h4>
                      <p className="text-xs text-gray-400">{voucher.description}</p>
                    </div>
                  </div>
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    voucher.status === 'active' ? 'bg-green-500/20 text-green-400' :
                    voucher.status === 'used' ? 'bg-gray-500/20 text-gray-400' :
                    'bg-red-500/20 text-red-400'
                  }`}>
                    {voucher.status === 'active' ? 'Aktif' : voucher.status === 'used' ? 'Digunakan' : 'Kadaluarsa'}
                  </span>
                </div>
                <div className="mt-3 flex items-center justify-between">
                  <div>
                    <p className="text-xs text-gray-500">Min. pembelian: Rp {voucher.minPurchase.toLocaleString('id-ID')}</p>
                    <p className="text-xs text-gray-500">Berlaku s/d: {new Date(voucher.expiryDate).toLocaleDateString('id-ID')}</p>
                  </div>
                  {voucher.status === 'active' && (
                    <button
                      onClick={() => handleCopy(voucher.code)}
                      className="flex items-center gap-1 px-3 py-1.5 bg-[#080C14] rounded-lg text-xs font-mono hover:bg-[#1C2A45]"
                    >
                      {copiedCode === voucher.code ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
                      {voucher.code}
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
