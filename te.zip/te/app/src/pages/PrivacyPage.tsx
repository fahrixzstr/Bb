import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Shield } from 'lucide-react';

export default function PrivacyPage() {
  const navigate = useNavigate();

  const sections = [
    {
      title: '1. Informasi yang Kami Kumpulkan',
      content: 'Kami mengumpulkan informasi pribadi seperti nama, email, nomor telepon, dan informasi pembayaran saat Anda mendaftar dan menggunakan layanan kami. Kami juga mengumpulkan data penggunaan platform untuk meningkatkan layanan.',
    },
    {
      title: '2. Penggunaan Informasi',
      content: 'Informasi Anda digunakan untuk memproses pesanan, memberikan dukungan pelanggan, mengirim notifikasi penting, dan meningkatkan pengalaman pengguna. Kami tidak akan menjual atau menyewakan informasi pribadi Anda kepada pihak ketiga.',
    },
    {
      title: '3. Perlindungan Data',
      content: 'Kami menerapkan langkah-langkah keamanan teknis dan organisasi untuk melindungi informasi pribadi Anda dari akses tidak sah, pengungkapan, atau penghancuran. Data disimpan di server yang aman dengan enkripsi.',
    },
    {
      title: '4. Cookies dan Teknologi Pelacakan',
      content: 'Kami menggunakan cookies untuk meningkatkan pengalaman browsing Anda. Anda dapat mengatur browser untuk menolak cookies, namun beberapa fitur mungkin tidak berfungsi optimal.',
    },
    {
      title: '5. Berbagi Informasi',
      content: 'Kami hanya membagikan informasi Anda dengan pihak ketiga yang terpercaya untuk keperluan pemrosesan pembayaran dan pengiriman produk. Semua pihak ketiga wajib menjaga kerahasiaan data.',
    },
    {
      title: '6. Hak Pengguna',
      content: 'Anda berhak mengakses, memperbarui, atau menghapus informasi pribadi Anda. Anda juga dapat menarik persetujuan penggunaan data kapan saja dengan menghubungi kami.',
    },
    {
      title: '7. Penyimpanan Data',
      content: 'Kami menyimpan informasi pribadi Anda selama akun Anda aktif atau selama diperlukan untuk menyediakan layanan. Anda dapat meminta penghapusan data dengan mengajukan permohonan.',
    },
    {
      title: '8. Perubahan Kebijakan',
      content: 'Kebijakan privasi ini dapat diperbarui sewaktu-waktu. Perubahan akan diumumkan di platform. Penggunaan berkelanjutan atas layanan kami setelah perubahan berarti Anda menerima kebijakan yang diperbarui.',
    },
    {
      title: '9. Kontak',
      content: 'Jika Anda memiliki pertanyaan tentang kebijakan privasi ini, silakan hubungi kami di fahrixzstore@gmail.com atau melalui WhatsApp Channel kami.',
    },
    {
      title: '10. Keamanan Akun',
      content: 'Kami menerapkan autentikasi dua faktor dan enkripsi password untuk keamanan akun. Pengguna juga bertanggung jawab untuk menjaga kerahasiaan kredensial login mereka.',
    },
    {
      title: '11. Data Anak-anak',
      content: 'Layanan kami tidak ditujukan untuk anak-anak di bawah 13 tahun. Kami tidak secara sengaja mengumpulkan informasi dari anak-anak di bawah usia tersebut.',
    },
    {
      title: '12. Transfer Data Internasional',
      content: 'Data Anda mungkin ditransfer ke dan diproses di server yang berlokasi di luar negara Anda. Kami memastikan perlindungan data yang sesuai standar.',
    },
    {
      title: '13. Persetujuan',
      content: 'Dengan menggunakan layanan FahrixzStore, Anda menyetujui pengumpulan dan penggunaan informasi sesuai dengan kebijakan privasi ini.',
    },
  ];

  return (
    <div className="min-h-screen bg-[#080C14] text-white pb-20">
      <div className="sticky top-0 z-40 bg-[#080C14]/80 backdrop-blur-md border-b border-[#1C2A45]">
        <div className="flex items-center gap-3 px-4 py-3">
          <button onClick={() => navigate(-1)} className="p-2 rounded-lg hover:bg-white/5">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-bold">Kebijakan Privasi</h1>
        </div>
      </div>

      <div className="px-4 py-6 space-y-4">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-[#7C3AED]/20 to-[#3B82F6]/20 flex items-center justify-center">
            <Shield className="w-6 h-6 text-[#00F0FF]" />
          </div>
          <div>
            <h2 className="text-xl font-bold">Privacy Policy</h2>
            <p className="text-xs text-gray-400">Terakhir diperbarui: Juni 2025</p>
          </div>
        </div>

        {sections.map((section, i) => (
          <div key={i} className="cyber-bg rounded-xl p-4">
            <h3 className="text-sm font-bold text-[#00F0FF] mb-2">{section.title}</h3>
            <p className="text-sm text-gray-400 leading-relaxed">{section.content}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
