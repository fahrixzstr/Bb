import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { User, Mail, Lock, Eye, EyeOff, Phone, Chrome, Github, Apple, Check, ArrowLeft } from 'lucide-react';
import { useStore } from '@/stores/useStore';
import { toast } from 'sonner';
import { auth, db } from '@/lib/firebase';
import {
  createUserWithEmailAndPassword,
  updateProfile,
  signInWithPopup,
  GoogleAuthProvider,
  GithubAuthProvider,
  OAuthProvider,
} from 'firebase/auth';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';

type RegisterMode = 'email' | 'phone';

export default function RegisterPage() {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const { setUser, setIsLoggedIn } = useStore();
  const [mode, setMode] = useState<RegisterMode>('email');
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [phone, setPhone] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [agreeTerms, setAgreeTerms] = useState(false);
  const [loading, setLoading] = useState(false);
  const [passwordStrength, setPasswordStrength] = useState(0);

  const checkPasswordStrength = (pwd: string) => {
    let strength = 0;
    if (pwd.length >= 8) strength++;
    if (/[A-Z]/.test(pwd)) strength++;
    if (/[0-9]/.test(pwd)) strength++;
    if (/[^A-Za-z0-9]/.test(pwd)) strength++;
    setPasswordStrength(strength);
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      toast.error('Password tidak cocok');
      return;
    }
    if (password.length < 8) {
      toast.error('Password minimal 8 karakter');
      return;
    }
    if (!agreeTerms) {
      toast.error('Anda harus menyetujui syarat dan ketentuan');
      return;
    }

    setLoading(true);
    try {
      const result = await createUserWithEmailAndPassword(auth, email, password);
      await updateProfile(result.user, { displayName: fullName });

      await setDoc(doc(db, 'users', result.user.uid), {
        uid: result.user.uid,
        email,
        displayName: fullName,
        photoURL: null,
        phoneNumber: mode === 'phone' ? phone : null,
        role: 'user',
        linkedProviders: ['email'],
        createdAt: serverTimestamp(),
      });

      setUser({
        uid: result.user.uid,
        email,
        displayName: fullName,
        photoURL: null,
        phoneNumber: mode === 'phone' ? phone : null,
        role: 'user',
        linkedProviders: ['email'],
      });
      setIsLoggedIn(true);

      toast.success('Registrasi Berhasil!', { description: 'Akun Anda telah dibuat!' });
      navigate('/');
    } catch (error: any) {
      toast.error('Registrasi Gagal', { description: error.message });
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleRegister = async () => {
    setLoading(true);
    try {
      const googleProvider = new GoogleAuthProvider();
      const result = await signInWithPopup(auth, googleProvider);

      await setDoc(doc(db, 'users', result.user.uid), {
        uid: result.user.uid,
        email: result.user.email,
        displayName: result.user.displayName || 'User',
        photoURL: result.user.photoURL,
        phoneNumber: result.user.phoneNumber,
        role: 'user',
        linkedProviders: ['google'],
        createdAt: serverTimestamp(),
      }, { merge: true });

      setUser({
        uid: result.user.uid,
        email: result.user.email,
        displayName: result.user.displayName || 'User',
        photoURL: result.user.photoURL,
        phoneNumber: result.user.phoneNumber,
        role: 'user',
        linkedProviders: ['google'],
      });
      setIsLoggedIn(true);
      toast.success('Registrasi berhasil!');
      navigate('/');
    } catch (error: any) {
      toast.error('Registrasi Google gagal', { description: error.message });
    } finally {
      setLoading(false);
    }
  };

  const handleGithubRegister = async () => {
    setLoading(true);
    try {
      const githubProvider = new GithubAuthProvider();
      const result = await signInWithPopup(auth, githubProvider);

      await setDoc(doc(db, 'users', result.user.uid), {
        uid: result.user.uid,
        email: result.user.email,
        displayName: result.user.displayName || 'User',
        photoURL: result.user.photoURL,
        role: 'user',
        linkedProviders: ['github'],
        createdAt: serverTimestamp(),
      }, { merge: true });

      setUser({
        uid: result.user.uid,
        email: result.user.email,
        displayName: result.user.displayName || 'User',
        photoURL: result.user.photoURL,
        role: 'user',
        linkedProviders: ['github'],
      });
      setIsLoggedIn(true);
      toast.success('Registrasi berhasil!');
      navigate('/');
    } catch (error: any) {
      toast.error('Registrasi GitHub gagal', { description: error.message });
    } finally {
      setLoading(false);
    }
  };

  const handleAppleRegister = async () => {
    setLoading(true);
    try {
      const appleProvider = new OAuthProvider('apple.com');
      appleProvider.addScope('email');
      appleProvider.addScope('name');
      const result = await signInWithPopup(auth, appleProvider);

      await setDoc(doc(db, 'users', result.user.uid), {
        uid: result.user.uid,
        email: result.user.email,
        displayName: result.user.displayName || 'User',
        photoURL: result.user.photoURL,
        role: 'user',
        linkedProviders: ['apple'],
        createdAt: serverTimestamp(),
      }, { merge: true });

      setUser({
        uid: result.user.uid,
        email: result.user.email,
        displayName: result.user.displayName || 'User',
        photoURL: result.user.photoURL,
        role: 'user',
        linkedProviders: ['apple'],
      });
      setIsLoggedIn(true);
      toast.success('Registrasi berhasil!');
      navigate('/');
    } catch (error: any) {
      toast.error('Registrasi Apple gagal', { description: error.message });
    } finally {
      setLoading(false);
    }
  };

  const strengthLabels = ['', 'Lemah', 'Sedang', 'Kuat', 'Sangat Kuat'];
  const strengthColors = ['', 'bg-red-500', 'bg-yellow-500', 'bg-blue-500', 'bg-green-500'];

  return (
    <div className="min-h-screen bg-[#080C14] text-white flex flex-col px-6 py-8">
      <button onClick={() => navigate(-1)} className="mb-6">
        <ArrowLeft className="w-5 h-5 text-gray-400" />
      </button>

      <h1 className="text-2xl font-bold mb-1">Daftar</h1>
      <p className="text-gray-500 text-sm mb-6">Buat akun baru untuk mulai berbelanja</p>

      {/* Mode Toggle */}
      <div className="flex gap-2 mb-6">
        <button
          onClick={() => setMode('email')}
          className={`flex-1 py-2 rounded-lg text-sm font-medium transition-colors ${
            mode === 'email' ? 'bg-[#131B2D] text-white border border-[#00F0FF]/30' : 'text-gray-500'
          }`}
        >
          <Mail className="w-4 h-4 inline mr-1" /> Email
        </button>
        <button
          onClick={() => setMode('phone')}
          className={`flex-1 py-2 rounded-lg text-sm font-medium transition-colors ${
            mode === 'phone' ? 'bg-[#131B2D] text-white border border-[#00F0FF]/30' : 'text-gray-500'
          }`}
        >
          <Phone className="w-4 h-4 inline mr-1" /> Telepon
        </button>
      </div>

      <form onSubmit={handleRegister} className="space-y-4 flex-1">
        <div className="relative">
          <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
          <input
            type="text"
            placeholder="Nama Lengkap"
            value={fullName}
            onChange={e => setFullName(e.target.value)}
            required
            className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl py-3 pl-11 pr-4 text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]"
          />
        </div>

        {mode === 'email' ? (
          <>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input
                type="email"
                placeholder="Email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                required
                className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl py-3 pl-11 pr-4 text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]"
              />
            </div>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input
                type={showPassword ? 'text' : 'password'}
                placeholder="Kata sandi (min 8 karakter)"
                value={password}
                onChange={e => { setPassword(e.target.value); checkPasswordStrength(e.target.value); }}
                required
                minLength={8}
                className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl py-3 pl-11 pr-11 text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]"
              />
              <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2">
                {showPassword ? <EyeOff className="w-5 h-5 text-gray-500" /> : <Eye className="w-5 h-5 text-gray-500" />}
              </button>
            </div>

            {/* Password Strength */}
            {password && (
              <div>
                <div className="flex gap-1 mb-1">
                  {[1, 2, 3, 4].map(i => (
                    <div key={i} className={`flex-1 h-1 rounded-full ${i <= passwordStrength ? strengthColors[passwordStrength] : 'bg-[#1C2A45]'}`} />
                  ))}
                </div>
                <p className="text-xs text-gray-500">{strengthLabels[passwordStrength]}</p>
              </div>
            )}

            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input
                type="password"
                placeholder="Konfirmasi kata sandi"
                value={confirmPassword}
                onChange={e => setConfirmPassword(e.target.value)}
                required
                className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl py-3 pl-11 pr-4 text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]"
              />
            </div>
          </>
        ) : (
          <div className="relative">
            <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
            <input
              type="tel"
              placeholder="+62 812-3456-7890"
              value={phone}
              onChange={e => setPhone(e.target.value)}
              required
              className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl py-3 pl-11 pr-4 text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]"
            />
          </div>
        )}

        {/* Terms */}
        <div className="flex items-start gap-2">
          <button
            type="button"
            onClick={() => setAgreeTerms(!agreeTerms)}
            className={`w-5 h-5 rounded border-2 flex-shrink-0 flex items-center justify-center mt-0.5 transition-colors ${
              agreeTerms ? 'bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] border-transparent' : 'border-gray-500'
            }`}
          >
            {agreeTerms && <Check className="w-3 h-3 text-white" />}
          </button>
          <p className="text-xs text-gray-400">
            Saya setuju dengan{' '}
            <button type="button" onClick={() => navigate('/terms')} className="text-[#00F0FF] hover:underline">Syarat & Ketentuan</button>
            {' '}dan{' '}
            <button type="button" onClick={() => navigate('/privacy')} className="text-[#00F0FF] hover:underline">Kebijakan Privasi</button>
          </p>
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full py-3 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white rounded-full font-medium hover:opacity-90 transition-opacity disabled:opacity-50"
        >
          {loading ? (
            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mx-auto" />
          ) : (
            'Daftar'
          )}
        </button>
      </form>

      {/* Social Register */}
      <div className="mt-4 space-y-3">
        <div className="flex items-center gap-3">
          <div className="flex-1 h-px bg-[#1C2A45]" />
          <span className="text-xs text-gray-500">atau daftar dengan</span>
          <div className="flex-1 h-px bg-[#1C2A45]" />
        </div>
        <div className="flex gap-3">
          <button onClick={handleGoogleRegister} disabled={loading} className="flex-1 flex items-center justify-center gap-2 py-2.5 border border-[#1C2A45] rounded-xl text-white hover:bg-[#131B2D] transition-colors disabled:opacity-50">
            <Chrome className="w-5 h-5" />
          </button>
          <button onClick={handleGithubRegister} disabled={loading} className="flex-1 flex items-center justify-center gap-2 py-2.5 border border-[#1C2A45] rounded-xl text-white hover:bg-[#131B2D] transition-colors disabled:opacity-50">
            <Github className="w-5 h-5" />
          </button>
          <button onClick={handleAppleRegister} disabled={loading} className="flex-1 flex items-center justify-center gap-2 py-2.5 border border-[#1C2A45] rounded-xl text-white hover:bg-[#131B2D] transition-colors disabled:opacity-50">
            <Apple className="w-5 h-5" />
          </button>
        </div>
      </div>

      <p className="mt-4 text-center text-sm text-gray-500">
        Sudah punya akun?{' '}
        <button onClick={() => navigate('/login')} className="text-[#00F0FF] hover:underline">
          Masuk
        </button>
      </p>
    </div>
  );
}
