import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Wallet, AlertCircle, Check } from 'lucide-react';
import { useStore } from '@/stores/useStore';
import { formatPrice } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { db } from '@/lib/firebase';
import { collection, addDoc, serverTimestamp, doc, getDoc, updateDoc } from 'firebase/firestore';
import { useStore } from '@/stores/useStore';

const methods = [
  { key: 'dana', label: 'DANA', account: '08123456789' },
  { key: 'gopay', label: 'GoPay', account: '08123456789' },
  { key: 'bca', label: 'Transfer Bank BCA', account: '1234567890' },
  { key: 'bni', label: 'Transfer Bank BNI', account: '0987654321' },
];

export default function WithdrawPage() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [amount, setAmount] = useState('');
  const [selectedMethod, setSelectedMethod] = useState('dana');
  const [accountNumber, setAccountNumber] = useState('');
  const [processing, setProcessing] = useState(false);
  const [balance, setBalance] = useState(0);
  const { user } = useStore();

  useEffect(() => {
    const fetchBalance = async () => {
      if (!user?.uid) return;
      const walletDoc = await getDoc(doc(db, 'wallets', user.uid));
      if (walletDoc.exists()) {
        setBalance(walletDoc.data().balance || 0);
      }
    };
    fetchBalance();
  }, [user]);

  const numAmount = Number(amount);
  const fee = 2500;
  const totalDeduction = numAmount + fee;
  const isValid = numAmount >= 50000 && numAmount > 0 && totalDeduction <= balance && accountNumber.length >= 5;

  const handleWithdraw = async () => {
    if (!isValid || !user?.uid) return;
    setProcessing(true);
    try {
      // Create withdraw transaction
      await addDoc(collection(db, 'transactions'), {
        userId: user.uid,
        type: 'withdraw',
        amount: numAmount,
        netAmount: numAmount,
        fee: fee,
        status: 'pending',
        method: selectedMethod,
        accountNumber: accountNumber,
        description: `Penarikan ke ${methods.find(m => m.key === selectedMethod)?.label}`,
        createdAt: serverTimestamp(),
      });

      // Update balance
      const walletRef = doc(db, 'wallets', user.uid);
      await updateDoc(walletRef, {
        balance: balance - totalDeduction,
        updatedAt: serverTimestamp(),
      });

      toast({ title: 'Penarikan Berhasil', description: 'Penarikan akan diproses dalam 1x24 jam' });
      navigate('/wallet');
    } catch (error) {
      toast({ title: 'Gagal', description: 'Terjadi kesalahan saat penarikan' });
    } finally {
      setProcessing(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#080C14] text-white pt-16 pb-8">
      <div className="flex items-center gap-3 px-4 py-3 border-b border-[#1C2A45]">
        <button onClick={() => navigate(-1)}><ArrowLeft className="w-5 h-5 text-gray-400" /></button>
        <h1 className="text-lg font-bold">Tarik Saldo</h1>
      </div>

      <div className="px-4 py-4 max-w-lg mx-auto space-y-4">
        {/* Balance */}
        <div className="bg-gradient-to-br from-[#7C3AED] to-[#3B82F6] rounded-2xl p-5 text-center">
          <p className="text-white/70 text-sm mb-1">Saldo Tersedia</p>
          <p className="text-3xl font-bold text-white">{formatPrice(balance)}</p>
        </div>

        {/* Amount */}
        <div>
          <label className="text-sm text-gray-400 mb-2 block">Nominal Penarikan</label>
          <div className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500">Rp</span>
            <input
              type="number"
              value={amount}
              onChange={e => setAmount(e.target.value)}
              placeholder="50.000"
              className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl py-3 pl-12 pr-4 text-white text-lg focus:outline-none focus:border-[#00F0FF]"
            />
          </div>
          {numAmount > 0 && numAmount < 50000 && (
            <p className="text-xs text-red-400 mt-1 flex items-center gap-1">
              <AlertCircle className="w-3 h-3" /> Minimal penarikan Rp 50.000
            </p>
          )}
          {numAmount > 0 && totalDeduction > balance && (
            <p className="text-xs text-red-400 mt-1 flex items-center gap-1">
              <AlertCircle className="w-3 h-3" /> Saldo tidak mencukupi
            </p>
          )}
          <div className="flex gap-2 mt-2">
            {[50000, 100000, 200000].map(amt => (
              <button
                key={amt}
                onClick={() => setAmount(String(amt))}
                className="px-3 py-1.5 bg-[#131B2D] border border-[#1C2A45] rounded-lg text-xs text-gray-400 hover:border-[#00F0FF]/40 transition-colors"
              >
                {formatPrice(amt)}
              </button>
            ))}
          </div>
        </div>

        {/* Method */}
        <div>
          <label className="text-sm text-gray-400 mb-2 block">Metode Penarikan</label>
          <div className="space-y-2">
            {methods.map(method => (
              <button
                key={method.key}
                onClick={() => setSelectedMethod(method.key)}
                className={`w-full flex items-center gap-3 p-3 rounded-xl transition-colors ${
                  selectedMethod === method.key
                    ? 'bg-gradient-to-r from-[#7C3AED]/20 to-[#3B82F6]/20 border border-[#00F0FF]/30'
                    : 'bg-[#131B2D] border border-[#1C2A45]'
                }`}
              >
                <div className="w-10 h-10 rounded-xl bg-[#080C14] flex items-center justify-center">
                  <Wallet className="w-5 h-5 text-[#00F0FF]" />
                </div>
                <div className="flex-1 text-left">
                  <p className="text-sm text-white">{method.label}</p>
                  <p className="text-xs text-gray-500">{method.account}</p>
                </div>
                {selectedMethod === method.key && (
                  <div className="w-5 h-5 rounded-full bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] flex items-center justify-center">
                    <Check className="w-3 h-3 text-white" />
                  </div>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Account Number */}
        <div>
          <label className="text-sm text-gray-400 mb-2 block">Nomor Rekening/E-Wallet Tujuan</label>
          <input
            type="text"
            value={accountNumber}
            onChange={e => setAccountNumber(e.target.value)}
            placeholder="Contoh: 08123456789"
            className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl py-3 px-4 text-white text-sm focus:outline-none focus:border-[#00F0FF]"
          />
        </div>

        {/* Summary */}
        {numAmount > 0 && (
          <div className="bg-[#131B2D] border border-[#1C2A45] rounded-xl p-4 space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Nominal</span>
              <span className="text-white">{formatPrice(numAmount)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Biaya Admin</span>
              <span className="text-white">{formatPrice(fee)}</span>
            </div>
            <div className="border-t border-[#1C2A45] pt-2 flex justify-between">
              <span className="text-gray-400">Total Diterima</span>
              <span className="text-[#00F0FF] font-bold">{formatPrice(numAmount)}</span>
            </div>
          </div>
        )}

        <button
          onClick={handleWithdraw}
          disabled={!isValid || processing}
          className="w-full py-3.5 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white rounded-xl font-medium disabled:opacity-50 hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
        >
          {processing ? (
            <>
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              Memproses...
            </>
          ) : balance === 0 ? (
            'Saldo Kosong'
          ) : (
            'Tarik Saldo'
          )}
        </button>
      </div>
    </div>
  );
}
