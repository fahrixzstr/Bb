import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Clock } from 'lucide-react';
import { useStore } from '@/stores/useStore';
import { db } from '@/lib/firebase';
import { doc, getDoc, collection, getDocs } from 'firebase/firestore';
import ProductCard from '@/components/shared/ProductCard';
import type { Product } from '@/types';

export default function RecentlyViewedPage() {
  const navigate = useNavigate();
  const { user } = useStore();
  const [recentProducts, setRecentProducts] = useState<Product[]>([]);

  useEffect(() => {
    fetchRecentlyViewed();
  }, [user]);

  const fetchRecentlyViewed = async () => {
    try {
      let recentIds: string[] = [];
      
      if (user?.uid) {
        const userDoc = await getDoc(doc(db, 'users', user.uid));
        if (userDoc.exists()) {
          recentIds = userDoc.data().recentlyViewed || [];
        }
      }
      
      // Fallback to localStorage
      if (recentIds.length === 0) {
        const local = localStorage.getItem('recentlyViewed');
        if (local) recentIds = JSON.parse(local);
      }

      if (recentIds.length > 0) {
        const productsSnapshot = await getDocs(collection(db, 'products'));
        const allProducts = productsSnapshot.docs.map(d => ({ id: d.id, ...d.data() } as Product));
        const recent = allProducts.filter(p => recentIds.includes(p.id));
        setRecentProducts(recent);
      }
    } catch (error) {
      console.error('Error fetching recently viewed:', error);
    }
  };

  return (
    <div className="min-h-screen bg-[#080C14] text-white pb-20">
      <div className="sticky top-0 z-40 bg-[#080C14]/80 backdrop-blur-md border-b border-[#1C2A45]">
        <div className="flex items-center gap-3 px-4 py-3">
          <button onClick={() => navigate(-1)} className="p-2 rounded-lg hover:bg-white/5">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-bold">Terakhir Dilihat</h1>
        </div>
      </div>

      <div className="px-4 py-6">
        {recentProducts.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20">
            <Clock className="w-16 h-16 text-gray-600 mb-4" />
            <p className="text-gray-400 text-sm">Belum ada produk yang dilihat</p>
            <button
              onClick={() => navigate('/products')}
              className="mt-4 px-6 py-2 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] rounded-full text-sm font-medium hover:opacity-90"
            >
              Jelajahi Produk
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {recentProducts.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
