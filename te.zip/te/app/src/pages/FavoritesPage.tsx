import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Heart } from 'lucide-react';
import { useStore } from '@/stores/useStore';
import { db } from '@/lib/firebase';
import { doc, getDoc, collection, getDocs } from 'firebase/firestore';
import ProductCard from '@/components/shared/ProductCard';
import type { Product } from '@/types';

export default function FavoritesPage() {
  const navigate = useNavigate();
  const { user } = useStore();
  const [favorites, setFavorites] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user?.uid) return;
    fetchFavorites();
  }, [user]);

  const fetchFavorites = async () => {
    if (!user?.uid) return;
    try {
      const userDoc = await getDoc(doc(db, 'users', user.uid));
      if (userDoc.exists()) {
        const userData = userDoc.data();
        const favoriteIds: string[] = userData.favorites || [];
        
        if (favoriteIds.length > 0) {
          const productsSnapshot = await getDocs(collection(db, 'products'));
          const allProducts = productsSnapshot.docs.map(d => ({ id: d.id, ...d.data() } as Product));
          const favProducts = allProducts.filter(p => favoriteIds.includes(p.id));
          setFavorites(favProducts);
        }
      }
    } catch (error) {
      console.error('Error fetching favorites:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#080C14] text-white pb-20">
      <div className="sticky top-0 z-40 bg-[#080C14]/80 backdrop-blur-md border-b border-[#1C2A45]">
        <div className="flex items-center gap-3 px-4 py-3">
          <button onClick={() => navigate(-1)} className="p-2 rounded-lg hover:bg-white/5">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-bold">Favorit Saya</h1>
        </div>
      </div>

      <div className="px-4 py-6">
        {favorites.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20">
            <Heart className="w-16 h-16 text-gray-600 mb-4" />
            <p className="text-gray-400 text-sm">Belum ada produk favorit</p>
            <button
              onClick={() => navigate('/products')}
              className="mt-4 px-6 py-2 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] rounded-full text-sm font-medium hover:opacity-90"
            >
              Jelajahi Produk
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {favorites.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
