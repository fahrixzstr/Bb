import { useNavigate } from 'react-router-dom';
import { ArrowLeft, FileText } from 'lucide-react';

export default function TermsPage() {
  const navigate = useNavigate();

  const sections = [
    {
      title: 'Pasal 1 - Ketentuan Umum',
      content: 'Dengan mengakses dan menggunakan layanan FahrixzStore, Anda menyetujui untuk terikat oleh syarat dan ketentuan ini. Jika Anda tidak menyetujui salah satu bagian dari ketentuan ini, Anda tidak diperkenankan menggunakan layanan kami.',
    },
    {
      title: 'Pasal 2 - Definisi',
      content: '"Platform" merujuk pada website dan aplikasi FahrixzStore. "Pengguna" merujuk pada individu yang mengakses platform. "Produk" merujuk pada barang dan jasa digital yang tersedia di platform. "Misi Cuan" merujuk pada sistem tugas digital untuk mendapatkan reward.',
    },
    {
      title: 'Pasal 3 - Pendaftaran Akun',
      content: 'Pengguna wajib memberikan informasi yang akurat saat pendaftaran. Pengguna bertanggung jawab atas kerahasiaan akun dan password. Setiap aktivitas yang terjadi di akun Anda menjadi tanggung jawab Anda.',
    },
    {
      title: 'Pasal 4 - Produk dan Layanan',
      content: 'FahrixzStore menyediakan produk digital seperti script, software, template, bot WhatsApp, panel Pterodactyl, tools otomatisasi, dan aset digital. Layanan jasa meliputi pembuatan website, pengembangan bot, desain UI/UX, dan custom development.',
    },
    {
      title: 'Pasal 5 - Pembayaran',
      content: 'Semua pembayaran harus dilakukan melalui metode pembayaran yang tersedia di platform. Harga yang tercantum dapat berubah sewaktu-waktu tanpa pemberitahuan terlebih dahulu.',
    },
    {
      title: 'Pasal 6 - Pengiriman Produk',
      content: 'Produk digital akan dikirimkan melalui akun pengguna atau email yang terdaftar. Waktu pengiriman bervariasi tergantung jenis produk. Produk digital tidak memerlukan pengiriman fisik.',
    },
    {
      title: 'Pasal 7 - Kebijakan Refund',
      content: 'Refund hanya dapat diajukan dalam kondisi tertentu sesuai dengan Kebijakan Refund yang berlaku. Pengguna wajib membaca dan memahami kebijakan refund sebelum melakukan pembelian.',
    },
    {
      title: 'Pasal 8 - Misi Cuan',
      content: 'Pengguna dapat mengikuti Misi Cuan dengan menyelesaikan tugas yang tersedia. Reward akan diberikan setelah tugas diverifikasi. FahrixzStore berhak menolak atau membatalkan reward jika terdapat kecurangan.',
    },
    {
      title: 'Pasal 9 - Batasan Tanggung Jawab',
      content: 'FahrixzStore tidak bertanggung jawab atas kerugian tidak langsung yang timbul dari penggunaan layanan. Kami berupaya sebaik mungkin untuk menjaga ketersediaan layanan.',
    },
    {
      title: 'Pasal 10 - Hak Kekayaan Intelektual',
      content: 'Semua konten di platform FahrixzStore dilindungi oleh hak cipta. Pengguna tidak diperkenankan menyalin, mendistribusikan, atau memodifikasi konten tanpa izin tertulis.',
    },
    {
      title: 'Pasal 11 - Privasi',
      content: 'FahrixzStore menghormati privasi pengguna. Informasi pribadi pengguna akan dilindungi sesuai dengan Kebijakan Privasi yang berlaku.',
    },
    {
      title: 'Pasal 12 - Perubahan Ketentuan',
      content: 'FahrixzStore berhak mengubah syarat dan ketentuan ini sewaktu-waktu. Perubahan akan efektif segera setelah dipublikasikan di platform.',
    },
    {
      title: 'Pasal 13 - Hukum yang Berlaku',
      content: 'Syarat dan ketentuan ini tunduk pada hukum yang berlaku di Indonesia. Setiap perselisihan akan diselesaikan secara musyawarah terlebih dahulu.',
    },
  ];

  return (
    <div className="min-h-screen bg-[#080C14] text-white pb-20">
      <div className="sticky top-0 z-40 bg-[#080C14]/80 backdrop-blur-md border-b border-[#1C2A45]">
        <div className="flex items-center gap-3 px-4 py-3">
          <button onClick={() => navigate(-1)} className="p-2 rounded-lg hover:bg-white/5">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-bold">Syarat & Ketentuan</h1>
        </div>
      </div>

      <div className="px-4 py-6 space-y-4">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-[#7C3AED]/20 to-[#3B82F6]/20 flex items-center justify-center">
            <FileText className="w-6 h-6 text-[#00F0FF]" />
          </div>
          <div>
            <h2 className="text-xl font-bold">S&K FahrixzStore</h2>
            <p className="text-xs text-gray-400">Terakhir diperbarui: Juni 2025</p>
          </div>
        </div>

        {sections.map((section, i) => (
          <div key={i} className="cyber-bg rounded-xl p-4">
            <h3 className="text-sm font-bold text-[#00F0FF] mb-2">{section.title}</h3>
            <p className="text-sm text-gray-400 leading-relaxed">{section.content}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
