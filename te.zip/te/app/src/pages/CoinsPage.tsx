import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Coins as CoinsIcon, Gift, Check, Clock, ChevronRight } from 'lucide-react';
import { useStore } from '@/stores/useStore';
import { toast } from 'sonner';
import { db } from '@/lib/firebase';
import { doc, getDoc, setDoc, updateDoc, collection, query, where, getDocs, orderBy, serverTimestamp } from 'firebase/firestore';

interface CoinTransaction {
  id: string;
  type: 'earn' | 'redeem';
  amount: number;
  source: string;
  description: string;
  createdAt: string;
}

export default function CoinsPage() {
  const navigate = useNavigate();
  const { user } = useStore();
  const [coins, setCoins] = useState(0);
  const [checkedIn, setCheckedIn] = useState(false);
  const [transactions, setTransactions] = useState<CoinTransaction[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user?.uid) return;
    fetchCoinsData();
  }, [user]);

  const fetchCoinsData = async () => {
    if (!user?.uid) return;
    try {
      // Get wallet
      const walletDoc = await getDoc(doc(db, 'wallets', user.uid));
      if (walletDoc.exists()) {
        const data = walletDoc.data();
        setCoins(data.coins || 0);
      }

      // Get coin transactions
      const q = query(
        collection(db, 'coinTransactions'),
        where('userId', '==', user.uid),
        orderBy('createdAt', 'desc')
      );
      const snapshot = await getDocs(q);
      const txs = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as CoinTransaction));
      setTransactions(txs);

      // Check if already checked in today
      const today = new Date().toISOString().split('T')[0];
      const lastCheckIn = txs.find(t => t.source === 'daily_checkin');
      if (lastCheckIn) {
        const checkInDate = lastCheckIn.createdAt.split('T')[0];
        setCheckedIn(checkInDate === today);
      }
    } catch (error) {
      console.error('Error fetching coins:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCheckIn = async () => {
    if (!user?.uid || checkedIn) return;
    try {
      const walletRef = doc(db, 'wallets', user.uid);
      await updateDoc(walletRef, { coins: (coins || 0) + 10, updatedAt: serverTimestamp() });

      await setDoc(doc(collection(db, 'coinTransactions')), {
        userId: user.uid,
        type: 'earn',
        amount: 10,
        source: 'daily_checkin',
        description: 'Check-in harian',
        createdAt: new Date().toISOString(),
      });

      setCoins((coins || 0) + 10);
      setCheckedIn(true);
      toast.success('Check-in berhasil!', { description: '+10 Koin' });
    } catch (error) {
      toast.error('Gagal check-in');
    }
  };

  const handleRedeem = async () => {
    if (!user?.uid || coins < 100) {
      toast.error('Minimal 100 koin untuk ditukar');
      return;
    }
    try {
      const redeemAmount = Math.floor(coins / 100) * 100;
      const walletRef = doc(db, 'wallets', user.uid);
      await updateDoc(walletRef, {
        coins: coins - redeemAmount,
        balance: (await getDoc(walletRef)).data()?.balance || 0 + redeemAmount,
        updatedAt: serverTimestamp(),
      });

      await setDoc(doc(collection(db, 'coinTransactions')), {
        userId: user.uid,
        type: 'redeem',
        amount: redeemAmount,
        source: 'redeem_to_wallet',
        description: `Tukar ${redeemAmount} koin ke saldo wallet`,
        createdAt: new Date().toISOString(),
      });

      setCoins(coins - redeemAmount);
      toast.success('Koin berhasil ditukar!', { description: `Rp ${redeemAmount} ditambahkan ke wallet` });
    } catch (error) {
      toast.error('Gagal menukar koin');
    }
  };

  return (
    <div className="min-h-screen bg-[#080C14] text-white pb-20">
      <div className="sticky top-0 z-40 bg-[#080C14]/80 backdrop-blur-md border-b border-[#1C2A45]">
        <div className="flex items-center gap-3 px-4 py-3">
          <button onClick={() => navigate(-1)} className="p-2 rounded-lg hover:bg-white/5">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-bold">Koin Saya</h1>
        </div>
      </div>

      <div className="px-4 py-6 space-y-6">
        {/* Coin Balance */}
        <div className="cyber-bg rounded-2xl p-6 text-center">
          <CoinsIcon className="w-12 h-12 text-yellow-400 mx-auto mb-2" />
          <p className="text-4xl font-bold text-gradient">{coins.toLocaleString('id-ID')}</p>
          <p className="text-sm text-gray-400 mt-1">Total Koin</p>
          <p className="text-xs text-gray-500 mt-1">Rate: 10 Koin = Rp 1</p>
        </div>

        {/* Actions */}
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={handleCheckIn}
            disabled={checkedIn}
            className={`cyber-bg rounded-xl p-4 text-center transition-colors ${checkedIn ? 'opacity-50' : 'hover:bg-[#1C2A45]'}`}
          >
            <Check className="w-6 h-6 mx-auto mb-1 text-green-400" />
            <p className="text-sm font-medium">{checkedIn ? 'Sudah Check-in' : 'Check-in Harian'}</p>
            <p className="text-xs text-gray-400">+10 Koin</p>
          </button>
          <button
            onClick={handleRedeem}
            className="cyber-bg rounded-xl p-4 text-center hover:bg-[#1C2A45] transition-colors"
          >
            <Gift className="w-6 h-6 mx-auto mb-1 text-[#7C3AED]" />
            <p className="text-sm font-medium">Tukar Koin</p>
            <p className="text-xs text-gray-400">Minimal 100</p>
          </button>
        </div>

        {/* Transactions */}
        <div>
          <h3 className="text-sm font-bold mb-3">Riwayat Koin</h3>
          {transactions.length === 0 ? (
            <div className="cyber-bg rounded-xl p-6 text-center">
              <p className="text-sm text-gray-500">Belum ada riwayat</p>
            </div>
          ) : (
            <div className="space-y-2">
              {transactions.map(tx => (
                <div key={tx.id} className="cyber-bg rounded-xl p-3 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${tx.type === 'earn' ? 'bg-green-500/20' : 'bg-[#7C3AED]/20'}`}>
                      {tx.type === 'earn' ? <Check className="w-4 h-4 text-green-400" /> : <Gift className="w-4 h-4 text-[#7C3AED]" />}
                    </div>
                    <div>
                      <p className="text-sm font-medium">{tx.description}</p>
                      <p className="text-xs text-gray-500">{new Date(tx.createdAt).toLocaleDateString('id-ID')}</p>
                    </div>
                  </div>
                  <span className={`text-sm font-bold ${tx.type === 'earn' ? 'text-green-400' : 'text-red-400'}`}>
                    {tx.type === 'earn' ? '+' : '-'}{tx.amount}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
