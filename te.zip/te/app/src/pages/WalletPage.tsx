import { useState, useEffect } from 'react';
import { db } from '@/lib/firebase';
import { collection, query, where, getDocs, orderBy, doc, getDoc } from 'firebase/firestore';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { ArrowLeft, ArrowUpRight, ArrowDownLeft, Gift, History, Wallet, ChevronRight } from 'lucide-react';
import { useStore } from '@/stores/useStore';
import { formatPrice, formatDate } from '@/lib/utils';

interface Transaction {
  transactionId: string;
  type: string;
  amount: number;
  netAmount: number;
  status: string;
  method: string;
  description: string;
  createdAt: string;
}

const [transactions, setTransactions] = useState<Transaction[]>([]);
const [balance, setBalance] = useState(0);
const [coins, setCoins] = useState(0);
const [loading, setLoading] = useState(true);

const typeIcons: Record<string, React.ElementType> = {
  topup: ArrowDownLeft,
  withdraw: ArrowUpRight,
  purchase: Wallet,
  reward: Gift,
  refund: ArrowDownLeft,
};

const typeColors: Record<string, string> = {
  topup: 'text-green-400 bg-green-400/10',
  withdraw: 'text-red-400 bg-red-400/10',
  purchase: 'text-blue-400 bg-blue-400/10',
  reward: 'text-yellow-400 bg-yellow-400/10',
  refund: 'text-purple-400 bg-purple-400/10',
};

const typeLabels: Record<string, string> = {
  topup: 'Top Up',
  withdraw: 'Penarikan',
  purchase: 'Pembelian',
  reward: 'Reward',
  refund: 'Refund',
};

export default function WalletPage() {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const { user } = useStore();
  
  
  const [activeTab, setActiveTab] = useState<'all' | 'topup' | 'withdraw'>('all');

  const filteredTransactions = activeTab === 'all'
    ? transactions
    : transactions.filter(tx => tx.type === activeTab);

  return (
    <div className="min-h-screen bg-[#080C14] text-white pt-16 pb-8">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-[#1C2A45]">
        <button onClick={() => navigate(-1)}><ArrowLeft className="w-5 h-5 text-gray-400" /></button>
        <h1 className="text-lg font-bold">{t('wallet')}</h1>
      </div>

      {/* Balance Card */}
      <div className="px-4 py-4">
        <div className="bg-gradient-to-br from-[#7C3AED] to-[#3B82F6] rounded-2xl p-5">
          <p className="text-white/70 text-sm mb-1">{t('balance')}</p>
          <p className="text-3xl font-bold text-white mb-4">{formatPrice(balance)}</p>
          <div className="flex gap-3">
            <button
              onClick={() => navigate('/wallet/topup')}
              className="flex-1 py-2.5 bg-white/20 backdrop-blur-sm rounded-xl text-white text-sm font-medium flex items-center justify-center gap-1.5 hover:bg-white/30 transition-colors"
            >
              <ArrowDownLeft className="w-4 h-4" /> {t('topup')}
            </button>
            <button
              onClick={() => navigate('/wallet/withdraw')}
              className="flex-1 py-2.5 bg-white/20 backdrop-blur-sm rounded-xl text-white text-sm font-medium flex items-center justify-center gap-1.5 hover:bg-white/30 transition-colors"
            >
              <ArrowUpRight className="w-4 h-4" /> {t('withdraw')}
            </button>
          </div>
        </div>

        {/* Coins Card */}
        <div className="mt-3 bg-[#131B2D] border border-[#1C2A45] rounded-2xl p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-yellow-500/10 flex items-center justify-center">
              <Gift className="w-5 h-5 text-yellow-400" />
            </div>
            <div>
              <p className="text-sm text-gray-400">{t('coins')}</p>
              <p className="text-white font-bold">{coins} Koin</p>
            </div>
          </div>
          <ChevronRight className="w-5 h-5 text-gray-500" />
        </div>
      </div>

      {/* Transaction Tabs */}
      <div className="px-4 flex gap-2 mb-4">
        {(['all', 'topup', 'withdraw'] as const).map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 rounded-full text-sm transition-all ${
              activeTab === tab
                ? 'bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white'
                : 'bg-[#131B2D] text-gray-400 border border-[#1C2A45]'
            }`}
          >
            {tab === 'all' ? 'Semua' : tab === 'topup' ? 'Pemasukan' : 'Penarikan'}
          </button>
        ))}
      </div>

      {/* Transactions */}
      <div className="px-4 space-y-2">
        {filteredTransactions.map(tx => {
          const Icon = typeIcons[tx.type] || Wallet;
          return (
            <div key={tx.transactionId} className="flex items-center gap-3 p-3 bg-[#131B2D] border border-[#1C2A45] rounded-xl">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${typeColors[tx.type]}`}>
                <Icon className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-white">{tx.description}</p>
                <p className="text-xs text-gray-500">{formatDate(tx.createdAt)}</p>
              </div>
              <div className="text-right">
                <p className={`text-sm font-medium ${tx.type === 'withdraw' || tx.type === 'purchase' ? 'text-red-400' : 'text-green-400'}`}>
                  {tx.type === 'withdraw' || tx.type === 'purchase' ? '-' : '+'}{formatPrice(tx.amount)}
                </p>
                <span className={`text-xs px-1.5 py-0.5 rounded-full ${tx.status === 'success' ? 'text-green-400 bg-green-400/10' : 'text-yellow-400 bg-yellow-400/10'}`}>
                  {tx.status === 'success' ? 'Sukses' : 'Pending'}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
