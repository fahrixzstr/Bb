import { useState, useMemo, useEffect } from 'react';
import { db } from '@/lib/firebase';
import { collection, getDocs, query, orderBy } from 'firebase/firestore';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Search, SlidersHorizontal, Crown, Server, Globe, Ticket, Wrench, Smartphone, MoreHorizontal, X } from 'lucide-react';
import ProductCard from '@/components/shared/ProductCard';
import type { Product } from '@/types';

const categories = [
  { key: 'all', label: 'Semua', icon: null },
  { key: 'subscription', label: 'Subscription', icon: Crown },
  { key: 'panel', label: 'Panel', icon: Server },
  { key: 'hosting', label: 'Hosting', icon: Globe },
  { key: 'voucher', label: 'Voucher', icon: Ticket },
  { key: 'jasa', label: 'Jasa', icon: Wrench },
  { key: 'digital', label: 'Digital', icon: Smartphone },
  { key: 'other', label: 'Lainnya', icon: MoreHorizontal },
];

const sortOptions = [
  { key: 'recommended', label: 'Rekomendasi' },
  { key: 'newest', label: 'Terbaru' },
  { key: 'lowest_price', label: 'Harga Terendah' },
  { key: 'highest_price', label: 'Harga Tertinggi' },
  { key: 'best_seller', label: 'Terlaris' },
];

const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const q = query(collection(db, 'products'), orderBy('createdAt', 'desc'));
        const snapshot = await getDocs(q);
        const data = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Product));
        setProducts(data);
      } catch (error) {
        console.error('Error fetching products:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchProducts();
  }, []);

export default function ProductsPage() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { t } = useTranslation();
  const urlCategory = searchParams.get('category');
  const urlFlashSale = searchParams.get('flashsale');

  const [activeCategory, setActiveCategory] = useState(urlCategory || 'all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('recommended');
  const [showSortSheet, setShowSortSheet] = useState(false);
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 500000]);
  const [showFilter, setShowFilter] = useState(false);

  const filteredProducts = useMemo(() => {
    let productsList = [...products];

    if (urlFlashSale === 'true') {
      productsList = productsList.filter(p => p.discount && p.discount > 0);
    }

    if (activeCategory !== 'all') {
      productsList = productsList.filter(p => p.category === activeCategory);
    }

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      productsList = productsList.filter(p =>
        p.name.toLowerCase().includes(q) || p.description.toLowerCase().includes(q)
      );
    }

    productsList = productsList.filter(p => p.price >= priceRange[0] && p.price <= priceRange[1]);

    switch (sortBy) {
      case 'lowest_price': products.sort((a, b) => a.price - b.price); break;
      case 'highest_price': products.sort((a, b) => b.price - a.price); break;
      case 'best_seller': products.sort((a, b) => b.soldCount - a.soldCount); break;
      case 'newest': products.sort((a, b) => b.id.localeCompare(a.id)); break;
      default: break;
    }

    return productsList;
  }, [activeCategory, searchQuery, sortBy, priceRange, urlFlashSale]);

  return (
    <div className="min-h-screen bg-[#080C14] text-white pt-16 pb-24 md:pb-8">
      {/* Search Header */}
      <div className="sticky top-16 z-40 bg-[#080C14]/95 backdrop-blur-md border-b border-[#1C2A45] px-4 py-3">
        <div className="max-w-7xl mx-auto flex items-center gap-3">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <input
              type="text"
              placeholder={t('search_placeholder')}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl py-2.5 pl-10 pr-4 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]"
            />
          </div>
          <button
            onClick={() => setShowFilter(true)}
            className="p-2.5 rounded-xl bg-[#131B2D] border border-[#1C2A45] hover:border-[#00F0FF]/40 transition-colors"
          >
            <SlidersHorizontal className="w-5 h-5 text-gray-400" />
          </button>
        </div>

        {/* Category Tabs */}
        <div className="max-w-7xl mx-auto mt-3 flex gap-2 overflow-x-auto scrollbar-hide pb-1">
          {categories.map(cat => {
            const Icon = cat.icon;
            return (
              <button
                key={cat.key}
                onClick={() => setActiveCategory(cat.key)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-all ${
                  activeCategory === cat.key
                    ? 'bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white'
                    : 'bg-[#131B2D] text-gray-400 border border-[#1C2A45] hover:border-[#00F0FF]/40'
                }`}
              >
                {Icon && <Icon className="w-3.5 h-3.5" />}
                {cat.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Sort Bar */}
      <div className="px-4 py-2 max-w-7xl mx-auto flex items-center justify-between">
        <span className="text-xs text-gray-500">{filteredProducts.length} produk</span>
        <button onClick={() => setShowSortSheet(true)} className="text-xs text-gray-400 flex items-center gap-1 hover:text-white">
          {sortOptions.find(s => s.key === sortBy)?.label} <SlidersHorizontal className="w-3 h-3" />
        </button>
      </div>

      {/* Product Grid */}
      <div className="px-4 max-w-7xl mx-auto">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
          {filteredProducts.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
        {filteredProducts.length === 0 && (
          <div className="text-center py-16">
            <p className="text-gray-500">{t('no_results')}</p>
          </div>
        )}
      </div>

      {/* Sort Bottom Sheet */}
      {showSortSheet && (
        <div className="fixed inset-0 z-50 flex items-end" onClick={() => setShowSortSheet(false)}>
          <div className="absolute inset-0 bg-black/60" />
          <div className="relative w-full bg-[#131B2D] rounded-t-2xl p-4 animate-slide-up" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-white font-semibold">{t('sort')}</h3>
              <button onClick={() => setShowSortSheet(false)}><X className="w-5 h-5 text-gray-400" /></button>
            </div>
            {sortOptions.map(opt => (
              <button
                key={opt.key}
                onClick={() => { setSortBy(opt.key); setShowSortSheet(false); }}
                className={`w-full text-left px-4 py-3 rounded-xl mb-1 text-sm transition-colors ${
                  sortBy === opt.key ? 'bg-gradient-to-r from-[#7C3AED]/20 to-[#3B82F6]/20 text-white' : 'text-gray-400 hover:bg-white/5'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Filter Bottom Sheet */}
      {showFilter && (
        <div className="fixed inset-0 z-50 flex items-end" onClick={() => setShowFilter(false)}>
          <div className="absolute inset-0 bg-black/60" />
          <div className="relative w-full bg-[#131B2D] rounded-t-2xl p-4 animate-slide-up" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-white font-semibold">{t('filter')}</h3>
              <button onClick={() => setShowFilter(false)}><X className="w-5 h-5 text-gray-400" /></button>
            </div>
            <div className="mb-4">
              <label className="text-sm text-gray-400 mb-2 block">Harga</label>
              <div className="flex items-center gap-3">
                <input
                  type="number"
                  value={priceRange[0]}
                  onChange={e => setPriceRange([Number(e.target.value), priceRange[1]])}
                  className="flex-1 bg-[#080C14] border border-[#1C2A45] rounded-lg px-3 py-2 text-sm text-white"
                  placeholder="Min"
                />
                <span className="text-gray-500">-</span>
                <input
                  type="number"
                  value={priceRange[1]}
                  onChange={e => setPriceRange([priceRange[0], Number(e.target.value)])}
                  className="flex-1 bg-[#080C14] border border-[#1C2A45] rounded-lg px-3 py-2 text-sm text-white"
                  placeholder="Max"
                />
              </div>
            </div>
            <button
              onClick={() => setShowFilter(false)}
              className="w-full py-3 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white rounded-xl font-medium"
            >
              {t('apply')}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
