import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Target } from 'lucide-react';

export default function TermsMissionsPage() {
  const navigate = useNavigate();

  const terms = [
    'Pengguna harus memiliki akun yang terverifikasi untuk mengikuti Misi Cuan.',
    'Setiap misi memiliki persyaratan dan tenggat waktu yang harus dipatuhi.',
    'Reward akan diberikan setelah tugas selesai diverifikasi oleh sistem.',
    'FahrixzStore berhak menolak hasil tugas yang tidak memenuhi kualitas minimum.',
    'Pengguna tidak boleh menggunakan bot atau metode otomatis untuk menyelesaikan misi.',
    'Akun yang terindikasi melakukan kecurangan akan dibanned secara permanen.',
    'Reward dari Misi Cuan hanya bisa ditarik (withdraw), tidak bisa digunakan untuk belanja.',
    'Minimal saldo untuk withdraw adalah Rp 10.000.',
    'Proses withdraw memakan waktu 1-3 hari kerja setelah payment gateway terintegrasi.',
    'FahrixzStore berhak mengubah ketentuan Misi Cuan sewaktu-waktu.',
  ];

  return (
    <div className="min-h-screen bg-[#080C14] text-white pb-20">
      <div className="sticky top-0 z-40 bg-[#080C14]/80 backdrop-blur-md border-b border-[#1C2A45]">
        <div className="flex items-center gap-3 px-4 py-3">
          <button onClick={() => navigate(-1)} className="p-2 rounded-lg hover:bg-white/5">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-bold">S&K Misi Cuan</h1>
        </div>
      </div>

      <div className="px-4 py-6 space-y-4">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-[#7C3AED]/20 to-[#3B82F6]/20 flex items-center justify-center">
            <Target className="w-6 h-6 text-[#00F0FF]" />
          </div>
          <div>
            <h2 className="text-xl font-bold">Syarat & Ketentuan Misi Cuan</h2>
            <p className="text-xs text-gray-400">Terakhir diperbarui: Juni 2025</p>
          </div>
        </div>

        <div className="cyber-bg rounded-2xl p-5">
          <p className="text-sm text-gray-400 mb-4">
            Misi Cuan adalah fitur yang memungkinkan pengguna untuk mendapatkan reward dengan menyelesaikan tugas digital. Dengan mengikuti Misi Cuan, Anda menyetujui syarat dan ketentuan berikut:
          </p>
          <ol className="space-y-3">
            {terms.map((term, i) => (
              <li key={i} className="flex gap-3 text-sm text-gray-400">
                <span className="w-6 h-6 rounded-full bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] flex items-center justify-center text-xs font-bold flex-shrink-0">{i + 1}</span>
                {term}
              </li>
            ))}
          </ol>
        </div>
      </div>
    </div>
  );
}
