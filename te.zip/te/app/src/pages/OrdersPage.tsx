import { useState, useEffect } from 'react';
import { db } from '@/lib/firebase';
import { collection, query, where, getDocs, orderBy } from 'firebase/firestore';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { ArrowLeft, Search, Package, Clock, CheckCircle, XCircle, RefreshCcw } from 'lucide-react';
import { formatPrice } from '@/lib/utils';
import EmptyState from '@/components/shared/EmptyState';

const tabs = [
  { key: 'all', label: 'Semua' },
  { key: 'pending', label: 'Belum Bayar' },
  { key: 'processing', label: 'Proses' },
  { key: 'completed', label: 'Berhasil' },
  { key: 'refund', label: 'Refund' },
];

interface OrderItem {
  name: string;
  qty: number;
  price: number;
  image: string;
}

interface Order {
  orderId: string;
  status: string;
  items: OrderItem[];
  total: number;
  date: string;
}

const [orders, setOrders] = useState<Order[]>([]);
const [loading, setLoading] = useState(true);

useEffect(() => {
  const fetchOrders = async () => {
    try {
      const q = query(collection(db, 'orders'), where('userId', '==', user?.uid || ''), orderBy('createdAt', 'desc'));
      const snapshot = await getDocs(q);
      setOrders(snapshot.docs.map(d => ({ orderId: d.id, ...d.data() } as Order)));
    } catch (error) {
      console.error('Error fetching orders:', error);
    } finally {
      setLoading(false);
    }
  };
  fetchOrders();
}, [user]);

const statusColors: Record<string, string> = {
  pending: 'text-yellow-400 bg-yellow-400/10',
  processing: 'text-blue-400 bg-blue-400/10',
  shipped: 'text-purple-400 bg-purple-400/10',
  completed: 'text-green-400 bg-green-400/10',
  cancelled: 'text-red-400 bg-red-400/10',
  refund: 'text-gray-400 bg-gray-400/10',
};

const statusLabels: Record<string, string> = {
  pending: 'Belum Bayar',
  processing: 'Di Proses',
  shipped: 'Dikirim',
  completed: 'Berhasil',
  cancelled: 'Dibatalkan',
  refund: 'Refund',
};

export default function OrdersPage() {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const [activeTab, setActiveTab] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredOrders = orders.filter(order => {
    if (activeTab !== 'all' && order.status !== activeTab) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return order.orderId.toLowerCase().includes(q) || order.items.some(i => i.name.toLowerCase().includes(q));
    }
    return true;
  });

  return (
    <div className="min-h-screen bg-[#080C14] text-white pt-16 pb-8">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-[#1C2A45] sticky top-16 bg-[#080C14] z-30">
        <button onClick={() => navigate(-1)}><ArrowLeft className="w-5 h-5 text-gray-400" /></button>
        <h1 className="text-lg font-bold">{t('my_orders')}</h1>
      </div>

      {/* Search */}
      <div className="px-4 py-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <input
            type="text"
            placeholder="Nama Produk atau Order ID"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl py-2.5 pl-10 pr-4 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]"
          />
        </div>
      </div>

      {/* Tabs */}
      <div className="px-4 flex gap-1 overflow-x-auto scrollbar-hide mb-4">
        {tabs.map(tab => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`px-4 py-2 rounded-full text-sm whitespace-nowrap transition-all ${
              activeTab === tab.key
                ? 'bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white'
                : 'bg-[#131B2D] text-gray-400 border border-[#1C2A45]'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Orders List */}
      <div className="px-4 space-y-3">
        {filteredOrders.length === 0 ? (
          <EmptyState type="order" />
        ) : (
          filteredOrders.map(order => (
            <div key={order.orderId} className="bg-[#131B2D] border border-[#1C2A45] rounded-xl p-4">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs text-gray-500">{order.orderId}</span>
                <span className={`text-xs px-2 py-0.5 rounded-full ${statusColors[order.status]}`}>
                  {statusLabels[order.status]}
                </span>
              </div>
              {order.items.map((item, i) => (
                <div key={i} className="flex gap-3 py-2">
                  <img src={item.image} alt={item.name} className="w-16 h-16 rounded-lg object-cover" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-white line-clamp-1">{item.name}</p>
                    <p className="text-xs text-gray-500">x{item.qty}</p>
                  </div>
                  <p className="text-sm text-[#00F0FF] font-medium">{formatPrice(item.price * item.qty)}</p>
                </div>
              ))}
              <div className="border-t border-[#1C2A45] pt-3 mt-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-400">Total ({order.items.length} produk)</span>
                  <span className="text-sm font-bold text-white">{formatPrice(order.total)}</span>
                </div>
                <div className="flex gap-2 mt-3">
                  {order.status === 'pending' && (
                    <button className="flex-1 py-2 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white rounded-lg text-sm font-medium">
                      Bayar Sekarang
                    </button>
                  )}
                  {order.status === 'completed' && (
                    <>
                      <button className="flex-1 py-2 border border-[#00F0FF] text-[#00F0FF] rounded-lg text-sm">Nilai</button>
                      <button className="flex-1 py-2 border border-[#1C2A45] text-gray-400 rounded-lg text-sm">Beli Lagi</button>
                    </>
                  )}
                  {order.status === 'processing' && (
                    <button className="flex-1 py-2 border border-[#1C2A45] text-gray-400 rounded-lg text-sm flex items-center justify-center gap-1">
                      <Clock className="w-3.5 h-3.5" /> Cek Status
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
