import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Mail, Lock, Eye, EyeOff, Phone, Chrome, Github, Apple, User } from 'lucide-react';
import { useStore } from '@/stores/useStore';
import { toast } from 'sonner';
import { auth, db } from '@/lib/firebase';
import {
  signInWithEmailAndPassword,
  signInWithPopup,
  GoogleAuthProvider,
  GithubAuthProvider,
  OAuthProvider,
  signInAnonymously,
  updateProfile,
} from 'firebase/auth';
import { doc, setDoc, getDoc, serverTimestamp } from 'firebase/firestore';

type LoginMode = 'email' | 'phone';

export default function LoginPage() {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const { setUser, setIsLoggedIn, setIsAdmin } = useStore();
  const [mode, setMode] = useState<LoginMode>('email');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [showOtpInput, setShowOtpInput] = useState(false);
  const [confirmationResult, setConfirmationResult] = useState<any>(null);
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      toast.error('Email dan password wajib diisi');
      return;
    }
    setLoading(true);
    try {
      const result = await signInWithEmailAndPassword(auth, email, password);
      const userDoc = await getDoc(doc(db, 'users', result.user.uid));
      const userData = userDoc.exists() ? userDoc.data() : {};

      setUser({
        uid: result.user.uid,
        email: result.user.email,
        displayName: result.user.displayName || userData.displayName || 'User',
        photoURL: result.user.photoURL,
        phoneNumber: result.user.phoneNumber,
        ...userData,
      });
      setIsLoggedIn(true);

      const adminDoc = await getDoc(doc(db, 'adminUsers', result.user.uid));
      setIsAdmin(adminDoc.exists());

      toast.success('Login berhasil!', { description: 'Selamat datang kembali!' });
      navigate('/');
    } catch (error: any) {
      toast.error('Login gagal', { description: error.message || 'Email atau password salah' });
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setLoading(true);
    try {
      const googleProvider = new GoogleAuthProvider();
      const result = await signInWithPopup(auth, googleProvider);

      await setDoc(doc(db, 'users', result.user.uid), {
        uid: result.user.uid,
        email: result.user.email,
        displayName: result.user.displayName || 'User',
        photoURL: result.user.photoURL,
        phoneNumber: result.user.phoneNumber,
        role: 'user',
        linkedProviders: ['google'],
        createdAt: serverTimestamp(),
      }, { merge: true });

      setUser({
        uid: result.user.uid,
        email: result.user.email,
        displayName: result.user.displayName || 'User',
        photoURL: result.user.photoURL,
        phoneNumber: result.user.phoneNumber,
        role: 'user',
        linkedProviders: ['google'],
      });
      setIsLoggedIn(true);
      toast.success('Login berhasil!', { description: `Selamat datang, ${result.user.displayName || 'User'}!` });
      navigate('/');
    } catch (error: any) {
      toast.error('Login Google gagal', { description: error.message });
    } finally {
      setLoading(false);
    }
  };

  const handleGithubLogin = async () => {
    setLoading(true);
    try {
      const githubProvider = new GithubAuthProvider();
      const result = await signInWithPopup(auth, githubProvider);

      await setDoc(doc(db, 'users', result.user.uid), {
        uid: result.user.uid,
        email: result.user.email,
        displayName: result.user.displayName || 'User',
        photoURL: result.user.photoURL,
        role: 'user',
        linkedProviders: ['github'],
        createdAt: serverTimestamp(),
      }, { merge: true });

      setUser({
        uid: result.user.uid,
        email: result.user.email,
        displayName: result.user.displayName || 'User',
        photoURL: result.user.photoURL,
        role: 'user',
        linkedProviders: ['github'],
      });
      setIsLoggedIn(true);
      toast.success('Login berhasil!');
      navigate('/');
    } catch (error: any) {
      toast.error('Login GitHub gagal', { description: error.message });
    } finally {
      setLoading(false);
    }
  };

  const handleAppleLogin = async () => {
    setLoading(true);
    try {
      const appleProvider = new OAuthProvider('apple.com');
      appleProvider.addScope('email');
      appleProvider.addScope('name');
      const result = await signInWithPopup(auth, appleProvider);

      await setDoc(doc(db, 'users', result.user.uid), {
        uid: result.user.uid,
        email: result.user.email,
        displayName: result.user.displayName || 'User',
        photoURL: result.user.photoURL,
        role: 'user',
        linkedProviders: ['apple'],
        createdAt: serverTimestamp(),
      }, { merge: true });

      setUser({
        uid: result.user.uid,
        email: result.user.email,
        displayName: result.user.displayName || 'User',
        photoURL: result.user.photoURL,
        role: 'user',
        linkedProviders: ['apple'],
      });
      setIsLoggedIn(true);
      toast.success('Login berhasil!');
      navigate('/');
    } catch (error: any) {
      toast.error('Login Apple gagal', { description: error.message });
    } finally {
      setLoading(false);
    }
  };

  const handleGuestLogin = async () => {
    setLoading(true);
    try {
      const result = await signInAnonymously(auth);

      await setDoc(doc(db, 'users', result.user.uid), {
        uid: result.user.uid,
        email: null,
        displayName: 'Guest User',
        photoURL: null,
        phoneNumber: null,
        role: 'guest',
        isGuest: true,
        linkedProviders: ['guest'],
        createdAt: serverTimestamp(),
      }, { merge: true });

      setUser({
        uid: result.user.uid,
        email: null,
        displayName: 'Guest User',
        photoURL: null,
        phoneNumber: null,
        role: 'guest',
        isGuest: true,
        linkedProviders: ['guest'],
      });
      setIsLoggedIn(true);
      toast.success('Login sebagai Guest berhasil!');
      navigate('/');
    } catch (error: any) {
      toast.error('Login Guest gagal', { description: error.message });
    } finally {
      setLoading(false);
    }
  };

  const handlePhoneLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!phone) {
      toast.error('Nomor telepon wajib diisi');
      return;
    }
    // Phone OTP requires Recaptcha setup - show placeholder for now
    toast.info('Login dengan OTP memerlukan setup Recaptcha. Silakan gunakan metode login lain.');
  };

  return (
    <div className="min-h-screen bg-[#080C14] text-white flex flex-col items-center justify-center px-6">
      {/* Logo */}
      <div className="mb-8">
        <div className="logo-icon scale-[2] mx-auto mb-4">
          <span className="block h-1 bg-gradient-to-r from-[#00F0FF] to-[#0077FF] rounded-full w-full" />
          <span className="block h-1 bg-gradient-to-r from-[#00F0FF] to-[#0077FF] rounded-full w-3/4" />
          <span className="block h-1 bg-gradient-to-r from-[#00F0FF] to-[#0077FF] rounded-full w-1/2" />
        </div>
        <h1 className="text-center text-2xl font-bold">FAHRIXZ STORE</h1>
      </div>

      <h2 className="text-lg font-medium mb-1">Masuk atau daftar</h2>
      <p className="text-gray-500 text-sm text-center mb-6 max-w-xs">
        Anda Dapat Membeli Produk Sesuai Kebutuhan Anda Dengan Aman
      </p>

      {/* Mode Toggle */}
      <div className="flex gap-2 mb-6 w-full max-w-sm">
        <button
          onClick={() => setMode('email')}
          className={`flex-1 py-2 rounded-lg text-sm font-medium transition-colors ${
            mode === 'email' ? 'bg-[#131B2D] text-white border border-[#00F0FF]/30' : 'text-gray-500'
          }`}
        >
          <Mail className="w-4 h-4 inline mr-1" /> Email
        </button>
        <button
          onClick={() => setMode('phone')}
          className={`flex-1 py-2 rounded-lg text-sm font-medium transition-colors ${
            mode === 'phone' ? 'bg-[#131B2D] text-white border border-[#00F0FF]/30' : 'text-gray-500'
          }`}
        >
          <Phone className="w-4 h-4 inline mr-1" /> Telepon
        </button>
      </div>

      {/* Form */}
      {mode === 'email' ? (
        <form onSubmit={handleEmailLogin} className="w-full max-w-sm space-y-4">
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
            <input
              type="email"
              placeholder="Email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              required
              className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl py-3 pl-11 pr-4 text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]"
            />
          </div>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
            <input
              type={showPassword ? 'text' : 'password'}
              placeholder="Kata sandi"
              value={password}
              onChange={e => setPassword(e.target.value)}
              required
              className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl py-3 pl-11 pr-11 text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2"
            >
              {showPassword ? <EyeOff className="w-5 h-5 text-gray-500" /> : <Eye className="w-5 h-5 text-gray-500" />}
            </button>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-white text-black rounded-full font-medium hover:bg-gray-100 transition-colors disabled:opacity-50"
          >
            {loading ? (
              <div className="w-5 h-5 border-2 border-black/30 border-t-black rounded-full animate-spin mx-auto" />
            ) : (
              'Masuk'
            )}
          </button>

          <button
            type="button"
            onClick={() => navigate('/forgot-password')}
            className="w-full text-center text-sm text-[#00F0FF] hover:underline"
          >
            Lupa kata sandi?
          </button>
        </form>
      ) : (
        <form onSubmit={handlePhoneLogin} className="w-full max-w-sm space-y-4">
          <div className="relative">
            <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
            <input
              type="tel"
              placeholder="+62 812-3456-7890"
              value={phone}
              onChange={e => setPhone(e.target.value)}
              required
              className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl py-3 pl-11 pr-4 text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]"
            />
          </div>

          {showOtpInput && (
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input
                type="text"
                placeholder="Kode OTP"
                value={otp}
                onChange={e => setOtp(e.target.value)}
                maxLength={6}
                className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl py-3 pl-11 pr-4 text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]"
              />
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-white text-black rounded-full font-medium hover:bg-gray-100 transition-colors disabled:opacity-50"
          >
            {loading ? (
              <div className="w-5 h-5 border-2 border-black/30 border-t-black rounded-full animate-spin mx-auto" />
            ) : showOtpInput ? 'Verifikasi OTP' : 'Kirim OTP'}
          </button>
        </form>
      )}

      {/* Divider */}
      <div className="flex items-center gap-3 w-full max-w-sm my-6">
        <div className="flex-1 h-px bg-[#1C2A45]" />
        <span className="text-xs text-gray-500">{t('or')}</span>
        <div className="flex-1 h-px bg-[#1C2A45]" />
      </div>

      {/* Social Login */}
      <div className="w-full max-w-sm space-y-3">
        <button
          onClick={handleGoogleLogin}
          disabled={loading}
          className="w-full flex items-center justify-center gap-2 py-3 border border-[#1C2A45] rounded-full text-white hover:bg-[#131B2D] transition-colors disabled:opacity-50"
        >
          <Chrome className="w-5 h-5" />
          <span className="text-sm">{t('google_login') || 'Google'}</span>
        </button>

        <button
          onClick={handleGithubLogin}
          disabled={loading}
          className="w-full flex items-center justify-center gap-2 py-3 border border-[#1C2A45] rounded-full text-white hover:bg-[#131B2D] transition-colors disabled:opacity-50"
        >
          <Github className="w-5 h-5" />
          <span className="text-sm">GitHub</span>
        </button>

        <button
          onClick={handleAppleLogin}
          disabled={loading}
          className="w-full flex items-center justify-center gap-2 py-3 border border-[#1C2A45] rounded-full text-white hover:bg-[#131B2D] transition-colors disabled:opacity-50"
        >
          <Apple className="w-5 h-5" />
          <span className="text-sm">Apple</span>
        </button>

        <button
          onClick={handleGuestLogin}
          disabled={loading}
          className="w-full flex items-center justify-center gap-2 py-3 border border-[#1C2A45] rounded-full text-gray-400 hover:bg-[#131B2D] transition-colors disabled:opacity-50"
        >
          <User className="w-5 h-5" />
          <span className="text-sm">Masuk sebagai Guest</span>
        </button>
      </div>

      {/* Register Link */}
      <p className="mt-6 text-sm text-gray-500">
        Belum punya akun?{' '}
        <button onClick={() => navigate('/register')} className="text-[#00F0FF] hover:underline">
          Daftar
        </button>
      </p>

      {/* Footer */}
      <div className="mt-auto pt-8 pb-4 flex gap-4 text-xs text-gray-600">
        <button onClick={() => navigate('/terms')} className="hover:text-gray-400">Ketentuan Penggunaan</button>
        <button onClick={() => navigate('/privacy')} className="hover:text-gray-400">Kebijakan Privasi</button>
      </div>
    </div>
  );
}
