import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useStore } from '@/stores/useStore';
import {
  Bot, Ticket, Target, Calendar, Heart, Globe,
  Server, Crown, Wrench, MoreHorizontal, ChevronRight, Coins, Zap
} from 'lucide-react';
import { QUICK_ACTIONS } from '@/lib/constants';
import ProductCard from '@/components/shared/ProductCard';
import { useEffect, useRef, useState } from 'react';
import { db } from '@/lib/firebase';
import { collection, getDocs, query, orderBy, limit, doc, getDoc } from 'firebase/firestore';

const quickIcons: Record<string, React.ElementType> = {
  Bot, Ticket, Target, Calendar, Heart, Globe, Server, Crown, Wrench, MoreHorizontal,
};

const [bannerImages, setBannerImages] = useState<string[]>([
  '/assets/media/banners/banner-1.jpg',
  '/assets/media/banners/banner-2.jpg',
  '/assets/media/banners/banner-3.jpg',
]);

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  category: string;
  image: string;
  rating: number;
  reviewCount: number;
  soldCount: number;
  stock: number;
  isBestSeller?: boolean;
  discount?: number;
}

const [products, setProducts] = useState<Product[]>([]);
const [loadingProducts, setLoadingProducts] = useState(true);

export default function HomePage() {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const { user, isLoggedIn } = useStore();
  const [currentBanner, setCurrentBanner] = useState(0);
  const [flashSaleTime, setFlashSaleTime] = useState({ hours: 4, minutes: 32, seconds: 15 });
const [totalEarnings, setTotalEarnings] = useState(0);
  const earningsRef = useRef(totalEarnings);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const q = query(collection(db, 'products'), orderBy('soldCount', 'desc'), limit(8));
        const snapshot = await getDocs(q);
        const data = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Product));
        setProducts(data);

        const earningsDoc = await getDoc(doc(db, 'stats', 'missions'));
        if (earningsDoc.exists()) {
          setTotalEarnings(earningsDoc.data().totalEarnings || 0);
        }
      } catch (error) {
        console.error('Error fetching home data:', error);
      } finally {
        setLoadingProducts(false);
      }
    };
    fetchData();

    const timer = setInterval(() => {
      setFlashSaleTime(prev => {
        let { hours, minutes, seconds } = prev;
        seconds--;
        if (seconds < 0) { seconds = 59; minutes--; }
        if (minutes < 0) { minutes = 59; hours--; }
        if (hours < 0) { hours = 4; minutes = 32; seconds = 15; }
        return { hours, minutes, seconds };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const bannerTimer = setInterval(() => {
      setCurrentBanner(prev => (prev + 1) % bannerImages.length);
    }, 4000);
    return () => clearInterval(bannerTimer);
  }, []);

  return (
    <div className="min-h-screen bg-[#080C14] text-white pb-24 md:pb-8">
      {/* Hero Header */}
      <section className="relative pt-20 pb-8 px-4">
        <div className="absolute inset-0 bg-gradient-to-br from-[#7C3AED]/20 via-[#6366F1]/10 to-[#3B82F6]/20" />
        <div className="relative max-w-7xl mx-auto">
          <p className="text-sm text-gray-400 mb-1">
            {isLoggedIn ? `${t('welcome')}, ${user?.displayName || 'User'}` : t('welcome_guest')}
          </p>
          <h1 className="text-2xl md:text-3xl font-bold mb-2">
            BELANJA <span className="text-gradient">&amp; CARI CUAN</span>
          </h1>
          <p className="text-gray-400 text-sm">{t('tagline')}</p>
        </div>
      </section>

      {/* Banner Carousel */}
      <section className="px-4 mb-6">
        <div className="max-w-7xl mx-auto">
          <div className="relative rounded-2xl overflow-hidden aspect-[21/9] bg-[#131B2D]">
            {bannerImages.map((img, i) => (
              <div
                key={i}
                className={`absolute inset-0 transition-opacity duration-700 ${i === currentBanner ? 'opacity-100' : 'opacity-0'}`}
              >
                <img src={img} alt={`Banner ${i + 1}`} className="w-full h-full object-cover" />
              </div>
            ))}
            {/* Dots */}
            <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5">
              {bannerImages.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setCurrentBanner(i)}
                  className={`w-2 h-2 rounded-full transition-all ${i === currentBanner ? 'bg-white w-6' : 'bg-white/50'}`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Quick Actions */}
      <section className="px-4 mb-6">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-sm font-semibold text-gray-400 mb-3">{t('quick_actions')}</h2>
          <div className="grid grid-cols-5 gap-2 md:gap-3">
            {QUICK_ACTIONS.map((action) => {
              const Icon = quickIcons[action.icon] || MoreHorizontal;
              return (
                <button
                  key={action.key}
                  onClick={() => navigate(action.path)}
                  className="flex flex-col items-center gap-1.5 p-2 rounded-xl bg-[#131B2D] border border-[#1C2A45] hover:border-[#00F0FF]/40 transition-all active:scale-95"
                >
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#7C3AED]/20 to-[#3B82F6]/20 flex items-center justify-center">
                    <Icon className="w-5 h-5 text-[#00F0FF]" />
                  </div>
                  <span className="text-[10px] text-gray-400 text-center leading-tight">{action.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* Flash Sale */}
      <section className="px-4 mb-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-3">
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Zap className="w-5 h-5 text-yellow-400" />
                {t('flash_sale')}
              </h2>
              <div className="flex items-center gap-1">
                <span className="bg-[#131B2D] border border-[#1C2A45] rounded-lg px-2 py-0.5 text-sm font-mono text-white">
                  {String(flashSaleTime.hours).padStart(2, '0')}
                </span>
                <span className="text-gray-500">:</span>
                <span className="bg-[#131B2D] border border-[#1C2A45] rounded-lg px-2 py-0.5 text-sm font-mono text-white">
                  {String(flashSaleTime.minutes).padStart(2, '0')}
                </span>
                <span className="text-gray-500">:</span>
                <span className="bg-[#131B2D] border border-[#1C2A45] rounded-lg px-2 py-0.5 text-sm font-mono text-white">
                  {String(flashSaleTime.seconds).padStart(2, '0')}
                </span>
              </div>
            </div>
            <button onClick={() => navigate('/products?flashsale=true')} className="text-sm text-[#00F0FF] flex items-center gap-1 hover:underline">
              {t('see_all')} <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-2">
            {products.slice(0, 4).map(product => (
              <div key={product.id} className="flex-shrink-0 w-40" onClick={() => navigate(`/products/${product.id}`)}>
                <div className="neon-card cursor-pointer">
                  <div className="relative aspect-square overflow-hidden rounded-t-[24px]">
                    <img src={product.image} alt={product.name} loading="lazy" className="w-full h-full object-cover" />
                    {product.discount && (
                      <span className="absolute top-1.5 left-1.5 bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded">
                        -{product.discount}%
                      </span>
                    )}
                  </div>
                  <div className="p-2">
                    <p className="text-xs text-white line-clamp-2 mb-1">{product.name}</p>
                    <p className="text-[#00F0FF] font-bold text-xs">Rp {product.price.toLocaleString('id-ID')}</p>
                    {product.originalPrice && (
                      <p className="text-gray-600 text-[10px] line-through">Rp {product.originalPrice.toLocaleString('id-ID')}</p>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Product Grid */}
      <section className="px-4 mb-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-white">{t('featured_products')}</h2>
            <button onClick={() => navigate('/products')} className="text-sm text-[#00F0FF] flex items-center gap-1 hover:underline">
              {t('see_all')} <ChevronRight className="w-4 h-4" />
            </button>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
            {products.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* Missions Preview */}
      <section className="px-4 mb-6">
        <div className="max-w-7xl mx-auto">
          <div
            className="rounded-2xl p-5 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] cursor-pointer hover:opacity-95 transition-opacity"
            onClick={() => navigate('/missions')}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center">
                  <Coins className="w-6 h-6 text-yellow-300" />
                </div>
                <div>
                  <h3 className="font-bold text-white">Cari Cuan Hari Ini</h3>
                  <p className="text-white/80 text-sm">Rp {totalEarnings.toLocaleString('id-ID')} didapatkan user lain</p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-white" />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
