import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Users, DollarSign, Copy, Check, Share2, Link2 } from 'lucide-react';
import { useStore } from '@/stores/useStore';
import { toast } from 'sonner';
import { db } from '@/lib/firebase';
import { doc, getDoc, setDoc, collection, query, where, getDocs, serverTimestamp } from 'firebase/firestore';

interface Referral {
  id: string;
  referredUserName: string;
  reward: number;
  status: 'pending' | 'completed';
  createdAt: string;
}

export default function AffiliatePage() {
  const navigate = useNavigate();
  const { user } = useStore();
  const [referralCode, setReferralCode] = useState('');
  const [totalReferrals, setTotalReferrals] = useState(0);
  const [totalEarnings, setTotalEarnings] = useState(0);
  const [pendingEarnings, setPendingEarnings] = useState(0);
  const [referrals, setReferrals] = useState<Referral[]>([]);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!user?.uid) return;
    fetchAffiliateData();
  }, [user]);

  const fetchAffiliateData = async () => {
    if (!user?.uid) return;
    try {
      // Get or create affiliate data
      const affiliateRef = doc(db, 'affiliates', user.uid);
      const affiliateDoc = await getDoc(affiliateRef);

      if (affiliateDoc.exists()) {
        const data = affiliateDoc.data();
        setReferralCode(data.referralCode || '');
        setTotalReferrals(data.totalReferrals || 0);
        setTotalEarnings(data.totalEarnings || 0);
        setPendingEarnings(data.pendingEarnings || 0);
      } else {
        // Create affiliate record
        const code = generateReferralCode();
        await setDoc(affiliateRef, {
          userId: user.uid,
          referralCode: code,
          totalReferrals: 0,
          totalEarnings: 0,
          pendingEarnings: 0,
          createdAt: serverTimestamp(),
        });
        setReferralCode(code);
      }

      // Get referral history
      const q = query(collection(db, 'referrals'), where('referrerId', '==', user.uid));
      const snapshot = await getDocs(q);
      const refs = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Referral));
      setReferrals(refs);
    } catch (error) {
      console.error('Error fetching affiliate data:', error);
    }
  };

  const generateReferralCode = () => {
    return 'FZS-' + Math.random().toString(36).substring(2, 8).toUpperCase();
  };

  const handleCopy = () => {
    const link = `${window.location.origin}/register?ref=${referralCode}`;
    navigator.clipboard.writeText(link);
    setCopied(true);
    toast.success('Link referral disalin!');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShare = async () => {
    const link = `${window.location.origin}/register?ref=${referralCode}`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Gabung FahrixzStore!',
          text: `Daftar di FahrixzStore dengan kode referral saya: ${referralCode}`,
          url: link,
        });
      } catch (error) {
        // User cancelled
      }
    } else {
      handleCopy();
    }
  };

  return (
    <div className="min-h-screen bg-[#080C14] text-white pb-20">
      <div className="sticky top-0 z-40 bg-[#080C14]/80 backdrop-blur-md border-b border-[#1C2A45]">
        <div className="flex items-center gap-3 px-4 py-3">
          <button onClick={() => navigate(-1)} className="p-2 rounded-lg hover:bg-white/5">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-bold">Affiliate Program</h1>
        </div>
      </div>

      <div className="px-4 py-6 space-y-6">
        {/* Stats */}
        <div className="grid grid-cols-3 gap-3">
          <div className="cyber-bg rounded-xl p-3 text-center">
            <Users className="w-5 h-5 mx-auto mb-1 text-[#7C3AED]" />
            <p className="text-lg font-bold">{totalReferrals}</p>
            <p className="text-xs text-gray-400">Referral</p>
          </div>
          <div className="cyber-bg rounded-xl p-3 text-center">
            <DollarSign className="w-5 h-5 mx-auto mb-1 text-green-400" />
            <p className="text-lg font-bold">{totalEarnings.toLocaleString('id-ID')}</p>
            <p className="text-xs text-gray-400">Total</p>
          </div>
          <div className="cyber-bg rounded-xl p-3 text-center">
            <DollarSign className="w-5 h-5 mx-auto mb-1 text-yellow-400" />
            <p className="text-lg font-bold">{pendingEarnings.toLocaleString('id-ID')}</p>
            <p className="text-xs text-gray-400">Pending</p>
          </div>
        </div>

        {/* Referral Code */}
        <div className="cyber-bg rounded-2xl p-5">
          <h3 className="text-sm font-bold mb-3">Kode Referral Anda</h3>
          <div className="flex items-center gap-2 bg-[#080C14] rounded-xl p-3 border border-[#1C2A45]">
            <Link2 className="w-5 h-5 text-gray-500" />
            <span className="text-sm font-mono flex-1">{referralCode}</span>
            <button onClick={handleCopy} className="p-2 rounded-lg hover:bg-white/5">
              {copied ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4 text-gray-400" />}
            </button>
          </div>
          <div className="flex gap-2 mt-3">
            <button onClick={handleCopy} className="flex-1 py-2 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] rounded-lg text-sm font-medium hover:opacity-90">
              Salin Link
            </button>
            <button onClick={handleShare} className="flex-1 py-2 border border-[#1C2A45] rounded-lg text-sm font-medium hover:bg-[#131B2D]">
              <Share2 className="w-4 h-4 inline mr-1" /> Bagikan
            </button>
          </div>
        </div>

        {/* Referral History */}
        <div>
          <h3 className="text-sm font-bold mb-3">Riwayat Referral</h3>
          {referrals.length === 0 ? (
            <div className="cyber-bg rounded-xl p-6 text-center">
              <p className="text-sm text-gray-500">Belum ada referral</p>
              <p className="text-xs text-gray-600 mt-1">Bagikan kode referral Anda untuk mulai mendapatkan reward</p>
            </div>
          ) : (
            <div className="space-y-2">
              {referrals.map(ref => (
                <div key={ref.id} className="cyber-bg rounded-xl p-3 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] flex items-center justify-center text-xs font-bold">
                      {ref.referredUserName?.charAt(0).toUpperCase() || '?'}
                    </div>
                    <div>
                      <p className="text-sm font-medium">{ref.referredUserName}</p>
                      <p className="text-xs text-gray-500">{new Date(ref.createdAt).toLocaleDateString('id-ID')}</p>
                    </div>
                  </div>
                  <span className={`text-xs px-2 py-1 rounded-full ${ref.status === 'completed' ? 'bg-green-500/20 text-green-400' : 'bg-yellow-500/20 text-yellow-400'}`}>
                    {ref.status === 'completed' ? 'Selesai' : 'Pending'}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
