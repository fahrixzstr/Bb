import { useEffect, useState } from 'react';

export default function LoadingScreen() {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(timer);
          return 100;
        }
        return prev + Math.random() * 30;
      });
    }, 100);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="fixed inset-0 bg-[#080C14] flex flex-col items-center justify-center z-[100]">
      {/* Logo Animation */}
      <div className="mb-8 animate-float">
        <div className="logo-icon scale-150">
          <span className="block h-1.5 bg-gradient-to-r from-[#00F0FF] to-[#0077FF] rounded-full w-full animate-pulse" />
          <span className="block h-1.5 bg-gradient-to-r from-[#00F0FF] to-[#0077FF] rounded-full w-3/4 animate-pulse" style={{ animationDelay: '0.1s' }} />
          <span className="block h-1.5 bg-gradient-to-r from-[#00F0FF] to-[#0077FF] rounded-full w-1/2 animate-pulse" style={{ animationDelay: '0.2s' }} />
        </div>
      </div>

      <h1 className="text-2xl font-bold text-white mb-2 tracking-tight">FAHRIXZ STORE</h1>
      <p className="text-gray-500 text-sm mb-8">Loading experience...</p>

      {/* Progress Bar */}
      <div className="w-48 h-1 bg-[#1C2A45] rounded-full overflow-hidden">
        <div
          className="h-full bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] rounded-full transition-all duration-300"
          style={{ width: `${Math.min(progress, 100)}%` }}
        />
      </div>
    </div>
  );
}
