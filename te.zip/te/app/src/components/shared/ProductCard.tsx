import { useNavigate } from 'react-router-dom';
import { Star, ShoppingCart, Heart } from 'lucide-react';
import { useState } from 'react';
import { useStore } from '@/stores/useStore';
import { formatPrice, calculateDiscount, truncateText } from '@/lib/utils';
import type { Product } from '@/types';

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const navigate = useNavigate();
  const { addToCart } = useStore();
  const [isFavorite, setIsFavorite] = useState(false);

  const discount = calculateDiscount(product.originalPrice || 0, product.price);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart({
      productId: product.id,
      name: product.name,
      price: product.price,
      quantity: 1,
      image: product.image,
      category: product.category,
    });
  };

  return (
    <div
      className="neon-card group cursor-pointer"
      onClick={() => navigate(`/products/${product.id}`)}
    >
      {/* Image */}
      <div className="relative aspect-square overflow-hidden rounded-t-[24px]">
        <img
          src={product.image}
          alt={product.name}
          loading="lazy"
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        {discount > 0 && (
          <span className="absolute top-2 left-2 bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-lg">
            -{discount}%
          </span>
        )}
        {product.isBestSeller && (
          <span className="absolute top-2 right-2 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white text-xs font-bold px-2 py-0.5 rounded-lg">
            BEST SELLER
          </span>
        )}
        <button
          onClick={(e) => {
            e.stopPropagation();
            setIsFavorite(!isFavorite);
          }}
          className="absolute bottom-2 right-2 p-1.5 rounded-full bg-black/50 backdrop-blur-sm hover:bg-red-500/20 transition-colors"
        >
          <Heart className={`w-4 h-4 ${isFavorite ? 'text-red-500 fill-red-500' : 'text-white'}`} />
        </button>
      </div>

      {/* Content */}
      <div className="p-3">
        <h3 className="text-sm text-white font-medium line-clamp-2 mb-1.5 min-h-[2.5rem]">
          {truncateText(product.name, 50)}
        </h3>

        <div className="flex items-center gap-1 mb-2">
          <div className="flex items-center">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                className={`w-3 h-3 ${
                  i < Math.floor(product.rating)
                    ? 'text-yellow-400 fill-yellow-400'
                    : 'text-gray-600'
                }`}
              />
            ))}
          </div>
          <span className="text-xs text-gray-500">({product.reviewCount})</span>
          <span className="text-xs text-gray-600 ml-1">{formatNumber(product.soldCount)} terjual</span>
        </div>

        <div className="flex items-end justify-between">
          <div>
            <span className="text-[#00F0FF] font-bold text-sm">
              {formatPrice(product.price)}
            </span>
            {product.originalPrice && product.originalPrice > product.price && (
              <span className="text-gray-500 text-xs line-through ml-1.5">
                {formatPrice(product.originalPrice)}
              </span>
            )}
          </div>
          <button
            onClick={handleAddToCart}
            className="p-1.5 rounded-lg bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] hover:opacity-90 transition-opacity"
          >
            <ShoppingCart className="w-3.5 h-3.5 text-white" />
          </button>
        </div>
      </div>
    </div>
  );
}

function formatNumber(num: number): string {
  if (num >= 1000) {
    return (num / 1000).toFixed(1) + 'RB';
  }
  return num.toString();
}
