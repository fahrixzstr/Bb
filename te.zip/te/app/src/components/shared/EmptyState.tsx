import { Package, ShoppingCart, Target, Bell, Search, FileText } from 'lucide-react';

interface EmptyStateProps {
  type: 'cart' | 'order' | 'mission' | 'notification' | 'search' | 'product' | 'general';
  title?: string;
  description?: string;
  actionLabel?: string;
  onAction?: () => void;
}

const iconMap = {
  cart: ShoppingCart,
  order: FileText,
  mission: Target,
  notification: Bell,
  search: Search,
  product: Package,
  general: Package,
};

export default function EmptyState({ type, title, description, actionLabel, onAction }: EmptyStateProps) {
  const Icon = iconMap[type];

  const defaultTitles: Record<string, string> = {
    cart: 'Keranjang Kosong',
    order: 'Belum Ada Pesanan',
    mission: 'Belum Ada Misi',
    notification: 'Belum Ada Notifikasi',
    search: 'Tidak Ada Hasil',
    product: 'Produk Tidak Tersedia',
    general: 'Tidak Ada Data',
  };

  const defaultDescriptions: Record<string, string> = {
    cart: 'Yuk tambahkan produk ke keranjang Anda',
    order: 'Mulai berbelanja untuk melihat pesanan Anda',
    mission: 'Misi akan muncul di sini',
    notification: 'Notifikasi akan muncul di sini',
    search: 'Coba kata kunci lain',
    product: 'Produk akan segera tersedia',
    general: 'Data tidak ditemukan',
  };

  return (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      <div className="w-20 h-20 rounded-full bg-[#131B2D] border border-[#1C2A45] flex items-center justify-center mb-4">
        <Icon className="w-10 h-10 text-gray-500" />
      </div>
      <h3 className="text-white font-semibold mb-2">{title || defaultTitles[type]}</h3>
      <p className="text-gray-500 text-sm mb-4 max-w-xs">{description || defaultDescriptions[type]}</p>
      {actionLabel && onAction && (
        <button
          onClick={onAction}
          className="px-6 py-2.5 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white rounded-xl font-medium text-sm hover:opacity-90 transition-opacity"
        >
          {actionLabel}
        </button>
      )}
    </div>
  );
}
