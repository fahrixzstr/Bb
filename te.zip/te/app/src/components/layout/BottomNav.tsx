import { useLocation, useNavigate } from 'react-router-dom';
import { Home, ShoppingBag, Target, User } from 'lucide-react';
import { useTranslation } from 'react-i18next';

const navItems = [
  { key: 'home', label: 'Beranda', icon: Home, path: '/' },
  { key: 'products', label: 'Produk', icon: ShoppingBag, path: '/products' },
  { key: 'missions', label: 'Misi', icon: Target, path: '/missions' },
  { key: 'profile', label: 'Saya', icon: User, path: '/profile' },
];

export default function BottomNav() {
  const location = useLocation();
  const navigate = useNavigate();
  const { t } = useTranslation();

  const isActive = (path: string) => {
    if (path === '/') return location.pathname === '/';
    return location.pathname.startsWith(path);
  };

  const isAdminPage = location.pathname.startsWith('/admin');
  const isAuthPage = ['/login', '/register', '/forgot-password', '/verify-otp', '/vx-admin-login'].some(p => location.pathname.startsWith(p));

  if (isAdminPage || isAuthPage) return null;

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-[#080C14]/90 backdrop-blur-md border-t border-[#1C2A45] md:hidden">
      <div className="flex items-center justify-around h-16 pb-safe">
        {navItems.map((item) => {
          const active = isActive(item.path);
          const Icon = item.icon;
          return (
            <button
              key={item.key}
              onClick={() => navigate(item.path)}
              className={`flex flex-col items-center justify-center gap-1 w-16 h-full transition-all duration-200 active:scale-95 ${
                active ? 'text-[#00F0FF]' : 'text-gray-500'
              }`}
            >
              <Icon className={`w-5 h-5 ${active ? 'drop-shadow-[0_0_8px_rgba(0,240,255,0.5)]' : ''}`} />
              <span className={`text-[10px] font-medium ${active ? 'text-[#00F0FF]' : 'text-gray-500'}`}>
                {item.label}
              </span>
              {active && (
                <span className="absolute top-0 w-8 h-0.5 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] rounded-full" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
