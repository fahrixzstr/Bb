import { useNavigate, Outlet, useLocation } from 'react-router-dom';
import { useEffect } from 'react';
import { Search, Bell, LogOut, Menu } from 'lucide-react';
import { useStore } from '@/stores/useStore';
import AdminSidebar from './Sidebar';
import { useTranslation } from 'react-i18next';
import { getInitials } from '@/lib/utils';

export default function AdminLayout() {
  const navigate = useNavigate();
  const location = useLocation();
  const { t } = useTranslation();
  const { user, isAdmin, sidebarOpen, setSidebarOpen, reset } = useStore();

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
    if (!isAdmin) {
      navigate('/');
      return;
    }
  }, [user, isAdmin, navigate]);

  const handleLogout = () => {
    reset();
    navigate('/login');
  };

  const getBreadcrumb = () => {
    const paths = location.pathname.split('/').filter(Boolean);
    if (paths.length <= 1) return 'Dashboard';
    return paths[paths.length - 1].replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
  };

  if (!user || !isAdmin) return null;

  return (
    <div className="min-h-screen bg-[#080C14] text-white">
      <AdminSidebar />

      {/* Main Content */}
      <div className={`transition-all duration-300 ${sidebarOpen ? 'lg:ml-64' : 'lg:ml-20'}`}>
        {/* Topbar */}
        <header className="h-16 bg-[#080C14]/80 backdrop-blur-md border-b border-[#1C2A45] flex items-center justify-between px-6 sticky top-0 z-30">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="lg:hidden p-2 rounded-lg hover:bg-white/5"
            >
              <Menu className="w-5 h-5 text-gray-400" />
            </button>
            <span className="text-gray-400 text-sm capitalize">{getBreadcrumb()}</span>
          </div>

          <div className="flex items-center gap-4">
            {/* Search */}
            <div className="hidden md:flex items-center bg-[#131B2D] border border-[#1C2A45] rounded-lg px-3 py-1.5">
              <Search className="w-4 h-4 text-gray-500 mr-2" />
              <input
                type="text"
                placeholder="Search..."
                className="bg-transparent text-sm text-white placeholder-gray-500 outline-none w-48"
              />
            </div>

            {/* Notifications */}
            <button className="relative p-2 rounded-lg hover:bg-white/5 transition-colors">
              <Bell className="w-5 h-5 text-gray-400" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full" />
            </button>

            {/* Profile */}
            <div className="flex items-center gap-2">
              {user?.photoURL ? (
                <img src={user.photoURL} alt="" className="w-8 h-8 rounded-full object-cover border border-[#1C2A45]" />
              ) : (
                <div className="w-8 h-8 rounded-full bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] flex items-center justify-center text-white text-xs font-bold">
                  {getInitials(user?.displayName || 'A')}
                </div>
              )}
              <span className="hidden md:block text-sm text-gray-300">{user?.displayName || 'Admin'}</span>
              <button onClick={handleLogout} className="p-1.5 rounded-lg hover:bg-red-500/10 transition-colors ml-2">
                <LogOut className="w-4 h-4 text-red-400" />
              </button>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
