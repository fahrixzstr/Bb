import { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Search, ShoppingCart, Bell, User, LogIn, Menu, X } from 'lucide-react';
import { useStore } from '@/stores/useStore';
import { useTranslation } from 'react-i18next';
import { getInitials } from '@/lib/utils';

export default function AppBar() {
  const navigate = useNavigate();
  const location = useLocation();
  const { t } = useTranslation();
  const { user, isLoggedIn, cart, unreadCount, adminClicks, lastAdminClick, setAdminClicks, setLastAdminClick } = useStore();
  const [scrolled, setScrolled] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleLogoClick = () => {
    const now = Date.now();
    if (now - lastAdminClick > 3000) {
      setAdminClicks(1);
    } else {
      const newCount = adminClicks + 1;
      setAdminClicks(newCount);
      if (newCount >= 4) {
        navigate('/vx-admin-login');
        setAdminClicks(0);
        return;
      }
    }
    setLastAdminClick(now);
    navigate('/');
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery)}`);
      setSearchOpen(false);
      setSearchQuery('');
    }
  };

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const isAdminPage = location.pathname.startsWith('/admin');
  if (isAdminPage) return null;

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-[#080C14]/80 backdrop-blur-md shadow-lg border-b border-[#1C2A45]'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
        {/* Left - Logo */}
        <div className="flex items-center gap-3">
          <button
            className="flex items-center gap-2 group"
            onClick={handleLogoClick}
          >
            <div className="logo-icon">
              <span className="block h-1 bg-gradient-to-r from-[#00F0FF] to-[#0077FF] rounded-full w-full" />
              <span className="block h-1 bg-gradient-to-r from-[#00F0FF] to-[#0077FF] rounded-full w-3/4" />
              <span className="block h-1 bg-gradient-to-r from-[#00F0FF] to-[#0077FF] rounded-full w-1/2" />
            </div>
            <span className="text-white font-bold text-lg hidden sm:block group-hover:text-[#00F0FF] transition-colors">
              FAHRIXZ
            </span>
          </button>
        </div>

        {/* Center - Search Bar (Desktop) */}
        <div className="hidden md:flex flex-1 max-w-xl mx-8">
          <form onSubmit={handleSearch} className="relative w-full">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <input
              type="text"
              placeholder={t('search_placeholder')}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-full py-2 pl-10 pr-4 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF] focus:ring-1 focus:ring-[#00F0FF]/30 transition-all"
            />
          </form>
        </div>

        {/* Right - Actions */}
        <div className="flex items-center gap-2">
          {/* Mobile Search Toggle */}
          <button
            onClick={() => setSearchOpen(!searchOpen)}
            className="md:hidden p-2 rounded-lg hover:bg-white/5 transition-colors"
          >
            <Search className="w-5 h-5 text-gray-400" />
          </button>

          {/* Cart */}
          <button
            onClick={() => navigate('/cart')}
            className="relative p-2 rounded-lg hover:bg-white/5 transition-colors"
          >
            <ShoppingCart className="w-5 h-5 text-gray-400" />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] rounded-full text-xs text-white flex items-center justify-center animate-bounce-badge">
                {cartCount}
              </span>
            )}
          </button>

          {/* Notifications */}
          <button
            onClick={() => navigate('/notifications')}
            className="relative p-2 rounded-lg hover:bg-white/5 transition-colors"
          >
            <Bell className="w-5 h-5 text-gray-400" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full text-xs text-white flex items-center justify-center animate-bounce-badge">
                {unreadCount > 99 ? '99+' : unreadCount}
              </span>
            )}
          </button>

          {/* User / Login */}
          {isLoggedIn && user ? (
            <button
              onClick={() => navigate('/profile')}
              className="flex items-center gap-2 p-1 rounded-full hover:bg-white/5 transition-colors"
            >
              {user.photoURL ? (
                <img src={user.photoURL} alt="" className="w-8 h-8 rounded-full object-cover border border-[#1C2A45]" />
              ) : (
                <div className="w-8 h-8 rounded-full bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] flex items-center justify-center text-white text-xs font-bold">
                  {getInitials(user.displayName || 'U')}
                </div>
              )}
            </button>
          ) : (
            <button
              onClick={() => navigate('/login')}
              className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white rounded-full text-sm font-medium hover:opacity-90 transition-opacity"
            >
              <LogIn className="w-4 h-4" />
              <span className="hidden sm:inline">{t('login')}</span>
            </button>
          )}

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 rounded-lg hover:bg-white/5 transition-colors"
          >
            {mobileMenuOpen ? <X className="w-5 h-5 text-gray-400" /> : <Menu className="w-5 h-5 text-gray-400" />}
          </button>
        </div>
      </div>

      {/* Mobile Search */}
      {searchOpen && (
        <div className="md:hidden px-4 pb-3 animate-fade-in">
          <form onSubmit={handleSearch} className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <input
              type="text"
              placeholder={t('search_placeholder')}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              autoFocus
              className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-full py-2 pl-10 pr-4 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-[#00F0FF]"
            />
          </form>
        </div>
      )}

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#080C14]/95 backdrop-blur-md border-t border-[#1C2A45] animate-fade-in">
          <nav className="flex flex-col p-4 gap-2">
            <button onClick={() => { navigate('/'); setMobileMenuOpen(false); }} className="text-left px-4 py-3 text-gray-300 hover:bg-white/5 rounded-xl transition-colors">{t('products')}</button>
            <button onClick={() => { navigate('/missions'); setMobileMenuOpen(false); }} className="text-left px-4 py-3 text-gray-300 hover:bg-white/5 rounded-xl transition-colors">{t('missions')}</button>
            <button onClick={() => { navigate('/orders'); setMobileMenuOpen(false); }} className="text-left px-4 py-3 text-gray-300 hover:bg-white/5 rounded-xl transition-colors">{t('orders')}</button>
            <button onClick={() => { navigate('/wallet'); setMobileMenuOpen(false); }} className="text-left px-4 py-3 text-gray-300 hover:bg-white/5 rounded-xl transition-colors">{t('wallet')}</button>
            <button onClick={() => { navigate('/settings'); setMobileMenuOpen(false); }} className="text-left px-4 py-3 text-gray-300 hover:bg-white/5 rounded-xl transition-colors">{t('settings')}</button>
            <button onClick={() => { navigate('/customer-service'); setMobileMenuOpen(false); }} className="text-left px-4 py-3 text-gray-300 hover:bg-white/5 rounded-xl transition-colors">{t('customer_service')}</button>
          </nav>
        </div>
      )}
    </header>
  );
}
