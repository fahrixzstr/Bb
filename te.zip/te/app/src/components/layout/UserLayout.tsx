import { Outlet, useLocation } from 'react-router-dom';
import AppBar from './AppBar';
import BottomNav from './BottomNav';

export default function UserLayout() {
  const location = useLocation();
  // Hide bottom nav on certain pages if needed
  const hideBottomNavPaths = ['/checkout'];
  const showBottomNav = !hideBottomNavPaths.includes(location.pathname);

  return (
    <>
      <AppBar />
      <main className="min-h-screen">
        <Outlet />
      </main>
      {showBottomNav && <BottomNav />}
    </>
  );
}
