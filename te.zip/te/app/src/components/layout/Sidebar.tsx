import { useNavigate, useLocation } from 'react-router-dom';
import {
  LayoutDashboard, Package, ShoppingCart, Users, Target,
  Ticket, Heart, Calendar, BarChart3, Settings, Shield,
  Ban, FileText, MessageCircle, ChevronLeft, ChevronRight
} from 'lucide-react';
import { useStore } from '@/stores/useStore';
import { ADMIN_MENU } from '@/lib/constants';

const iconMap: Record<string, React.ElementType> = {
  LayoutDashboard, Package, ShoppingCart, Users, Target,
  Ticket, Heart, Calendar, BarChart3, Settings, Shield,
  Ban, FileText, MessageCircle,
};

export default function AdminSidebar() {
  const navigate = useNavigate();
  const location = useLocation();
  const { sidebarOpen, setSidebarOpen } = useStore();

  const isActive = (path: string) => {
    if (path === '/admin') return location.pathname === '/admin' || location.pathname === '/admin/';
    return location.pathname.startsWith(path);
  };

  return (
    <aside
      className={`fixed left-0 top-0 h-full bg-[#080C14] border-r border-[#1C2A45] z-40 transition-all duration-300 ${
        sidebarOpen ? 'w-64' : 'w-20'
      } hidden lg:block`}
    >
      {/* Toggle */}
      <button
        onClick={() => setSidebarOpen(!sidebarOpen)}
        className="absolute -right-3 top-6 w-6 h-6 bg-[#131B2D] border border-[#1C2A45] rounded-full flex items-center justify-center hover:bg-[#1C2A45] transition-colors"
      >
        {sidebarOpen ? <ChevronLeft className="w-3 h-3 text-gray-400" /> : <ChevronRight className="w-3 h-3 text-gray-400" />}
      </button>

      {/* Logo */}
      <div className="h-16 flex items-center px-4 border-b border-[#1C2A45]">
        <div className="logo-icon flex-shrink-0">
          <span className="block h-1 bg-gradient-to-r from-[#00F0FF] to-[#0077FF] rounded-full w-full" />
          <span className="block h-1 bg-gradient-to-r from-[#00F0FF] to-[#0077FF] rounded-full w-3/4" />
          <span className="block h-1 bg-gradient-to-r from-[#00F0FF] to-[#0077FF] rounded-full w-1/2" />
        </div>
        {sidebarOpen && (
          <span className="ml-3 text-white font-bold text-sm">FAHRIXZ</span>
        )}
      </div>

      {/* Menu */}
      <nav className="p-3 flex flex-col gap-1 overflow-y-auto h-[calc(100%-4rem)] scrollbar-hide">
        {ADMIN_MENU.map((item) => {
          const Icon = iconMap[item.icon] || Package;
          const active = isActive(item.path);
          return (
            <button
              key={item.key}
              onClick={() => navigate(item.path)}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-200 group ${
                active
                  ? 'bg-gradient-to-r from-[#7C3AED]/20 to-[#3B82F6]/20 text-white border-l-2 border-[#00F0FF]'
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
              title={!sidebarOpen ? item.label : undefined}
            >
              <Icon className={`w-5 h-5 flex-shrink-0 ${active ? 'text-[#00F0FF]' : 'group-hover:text-white'}`} />
              {sidebarOpen && <span className="text-sm font-medium">{item.label}</span>}
            </button>
          );
        })}
      </nav>
    </aside>
  );
}
