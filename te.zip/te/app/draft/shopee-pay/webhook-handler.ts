/**
 * ShopeePay Webhook Handler
 *
 * Endpoints:
 * - POST /webhooks/shopee/payment
 * - POST /webhooks/shopee/withdrawal
 * - POST /webhooks/shopee/refund
 */

interface ShopeeWebhookPayload {
  transactionId: string;
  orderId: string;
  status: 'success' | 'failed' | 'pending' | 'cancelled';
  amount: number;
  timestamp: string;
  signature: string;
}

export const handleShopeeWebhook = async (payload: ShopeeWebhookPayload) => {
  // TODO: Implementasi setelah mendapat API key ShopeePay
  // 1. Verify signature
  // 2. Update transaction status in Firestore
  // 3. Update order status
  // 4. Send notification to user
  // 5. Handle withdrawal status update
};
