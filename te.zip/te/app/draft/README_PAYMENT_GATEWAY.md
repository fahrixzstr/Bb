# Payment Gateway Integration Draft

Status: IN DEVELOPMENT

## Payment Providers Planned:
1. ShopeePay
2. Fastpay

## Files:
- `shopee-pay/webhook-handler.ts`: Handle incoming webhooks from ShopeePay
- `shopee-pay/payment-flow.md`: Documentation for ShopeePay payment flow
- `shopee-pay/api-routes.ts`: API routes for ShopeePay payment processing
- `fastpay/webhook-handler.ts`: Handle incoming webhooks from Fastpay
- `fastpay/payment-flow.md`: Documentation for Fastpay payment flow
- `fastpay/api-routes.ts`: API routes for Fastpay payment processing
- `shared/types.ts`: Shared TypeScript types
- `shared/webhook-validator.ts`: Validate webhook signatures
- `shared/payment-service.ts`: Abstract payment service layer

## Webhook Requirements:
- Verify webhook signature
- Handle payment success/failure/pending
- Update order status in Firestore
- Send notification to user
- Handle withdrawal requests
- Handle refund requests
