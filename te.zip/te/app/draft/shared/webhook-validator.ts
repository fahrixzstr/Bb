/**
 * Webhook Signature Validator
 *
 * Menyediakan fungsi validasi signature untuk masing-masing payment provider
 */

export const validateShopeeSignature = (
  payload: string,
  signature: string,
  secret: string
): boolean => {
  // TODO: Implement HMAC-SHA256 validation
  return true; // Placeholder
};

export const validateFastpaySignature = (
  payload: string,
  signature: string,
  secret: string
): boolean => {
  // TODO: Implement HMAC-SHA512 validation
  return true; // Placeholder
};
