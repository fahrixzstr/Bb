export interface PaymentTransaction {
  id: string;
  userId: string;
  type: 'payment' | 'withdrawal' | 'refund';
  provider: 'shopee' | 'fastpay';
  amount: number;
  status: 'pending' | 'processing' | 'success' | 'failed' | 'cancelled';
  orderId?: string;
  webhookPayload?: Record<string, unknown>;
  createdAt: string;
  updatedAt: string;
  processedAt?: string;
  failureReason?: string;
}

export interface WithdrawalRequest {
  id: string;
  userId: string;
  amount: number;
  fee: number;
  netAmount: number;
  method: string;
  accountNumber: string;
  accountName: string;
  status: 'pending' | 'processing' | 'success' | 'failed';
  provider?: 'shopee' | 'fastpay';
  providerTransactionId?: string;
  processedAt?: string;
  failureReason?: string;
  createdAt: string;
}

export interface WebhookConfig {
  provider: 'shopee' | 'fastpay';
  secretKey: string;
  endpoint: string;
  validateSignature(payload: unknown, signature: string): boolean;
}
