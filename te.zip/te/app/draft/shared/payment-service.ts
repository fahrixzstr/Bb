/**
 * Abstract Payment Service
 *
 * Layer abstraksi untuk integrasi payment gateway.
 * Provider-specific implementations go in their respective folders.
 */

import { db } from '../../src/lib/firebase';
import { collection, doc, setDoc, updateDoc, serverTimestamp } from 'firebase/firestore';

export abstract class PaymentService {
  abstract name: string;

  abstract createPayment(data: {
    amount: number;
    orderId: string;
    userId: string;
    description: string;
  }): Promise<{ paymentUrl: string; transactionId: string }>;

  abstract createWithdrawal(data: {
    amount: number;
    userId: string;
    accountNumber: string;
    accountName: string;
  }): Promise<{ transactionId: string; estimatedTime: string }>;

  abstract processWebhook(payload: unknown): Promise<void>;

  abstract checkStatus(transactionId: string): Promise<string>;
}

// Delay helper for payment gateway not ready
export const getWithdrawalDelayDays = (): number => {
  // Return 7 if payment gateway not integrated, 3 if integrated
  const isPaymentGatewayReady = false; // Toggle this when ready
  return isPaymentGatewayReady ? 3 : 7;
};
