// Stub module to replace Firebase when using tRPC backend
// All Firebase functionality has been migrated to tRPC APIs

export const auth = {
  currentUser: null,
  onAuthStateChanged: () => () => {},
  signInWithEmailAndPassword: async () => { throw new Error('Use tRPC auth instead'); },
  createUserWithEmailAndPassword: async () => { throw new Error('Use tRPC auth instead'); },
  signOut: async () => {},
  sendPasswordResetEmail: async () => {},
} as any;

export const db = {} as any;
export const storage = {} as any;

// Stub functions that might be imported
export function initializeApp() { return {}; }
export function getAuth() { return auth; }
export function getFirestore() { return db; }
export function getStorage() { return storage; }
export function doc() { return {}; }
export function getDoc() { return { exists: () => false, data: () => ({}) }; }
export function setDoc() { return Promise.resolve(); }
export function updateDoc() { return Promise.resolve(); }
export function deleteDoc() { return Promise.resolve(); }
export function collection() { return {}; }
export function query() { return {}; }
export function where() { return {}; }
export function orderBy() { return {}; }
export function limit() { return {}; }
export function getDocs() { return { docs: [] }; }
export function addDoc() { return Promise.resolve({ id: 'stub' }); }
export function onSnapshot() { return () => {}; }
export function ref() { return {}; }
export function uploadBytes() { return Promise.resolve(); }
export function getDownloadURL() { return Promise.resolve(''); }
export function deleteObject() { return Promise.resolve(); }
export function listAll() { return Promise.resolve({ items: [] }); }
export function getBytes() { return Promise.resolve(new Uint8Array()); }

export default {};
