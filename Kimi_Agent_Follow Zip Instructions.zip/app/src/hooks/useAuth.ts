import { useCallback, useEffect } from 'react';
import { useStore } from '@/stores/useStore';
import { trpc } from '@/providers/trpc';

export function useAuth() {
  const { setUser, setIsLoggedIn, setIsAdmin, setLoading, user, isLoggedIn, isAdmin } = useStore();

  const { data: userData, isLoading } = trpc.user.me.useQuery(undefined, {
    retry: false,
    refetchOnWindowFocus: false,
  });

  const logoutMutation = trpc.auth.logout.useMutation({
    onSuccess: () => {
      setUser(null);
      setIsLoggedIn(false);
      setIsAdmin(false);
      window.location.reload();
    },
  });

  const logout = useCallback(() => {
    logoutMutation.mutate();
  }, [logoutMutation]);

  useEffect(() => {
    setLoading(isLoading);

    if (!isLoading && userData) {
      setUser({
        uid: String(userData.id),
        email: userData.email || '',
        displayName: userData.name || 'User',
        photoURL: userData.avatar || null,
        phoneNumber: userData.phone || null,
        role: userData.role || 'user',
        saldo: parseFloat(userData.saldo?.toString() || '0'),
        referralCode: userData.referralCode || '',
      });
      setIsLoggedIn(true);
      setIsAdmin(userData.role === 'admin');
    } else if (!isLoading && !userData) {
      setUser(null);
      setIsLoggedIn(false);
      setIsAdmin(false);
    }
  }, [userData, isLoading, setUser, setIsLoggedIn, setIsAdmin, setLoading]);

  return {
    isLoading,
    user: userData ? {
      name: userData.name || 'User',
      email: userData.email || '',
      avatar: userData.avatar || '',
      role: userData.role || 'user',
      id: userData.id,
    } : null,
    logout,
    isLoggedIn,
    isAdmin,
  };
}
