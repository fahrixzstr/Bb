export type Theme = 'dark' | 'light';
export type Language = 'id' | 'en';

export type OrderStatus = 'pending' | 'processing' | 'shipped' | 'completed' | 'cancelled' | 'refund';
export type MissionStatus = 'available' | 'taken' | 'completed' | 'rejected' | 'claimed' | 'submitted' | 'processing' | 'expired';
export type MissionCategory = 'review' | 'registrasi' | 'download' | 'game' | 'survey' | 'pinjaman' | 'social_media' | 'voting' | 'google_maps';
export type TransactionType = 'topup' | 'withdraw' | 'reward' | 'purchase' | 'refund' | 'referral';
export type TransactionStatus = 'pending' | 'success' | 'failed' | 'cancelled';
export type PaymentMethod = 'dana' | 'gopay' | 'qris' | 'bank_transfer' | 'credit_card';
export type NotificationType = 'order' | 'mission' | 'promo' | 'system';
export type ProductCategory = 'subscription' | 'panel' | 'hosting' | 'voucher' | 'jasa' | 'digital' | 'other';

export interface User {
  uid: string;
  email: string;
  displayName: string | null;
  photoURL: string | null;
  phoneNumber?: string | null;
  username?: string;
  bio?: string;
  role?: 'user' | 'admin' | string;
  isGuest?: boolean;
  ktaVerified?: boolean;
  saldo?: number;
  referralCode?: string;
  linkedProviders?: string[];
  createdAt?: string;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  category: ProductCategory;
  subCategory?: string;
  image: string;
  images?: string[];
  rating: number;
  reviewCount: number;
  soldCount: number;
  stock: number;
  minOrder?: number;
  isBestSeller?: boolean;
  discount?: number;
  tags?: string[];
  variants?: ProductVariant[];
  createdAt?: string;
}

export interface ProductVariant {
  id: string;
  name: string;
  price: number;
  stock: number;
}

export interface CartItem {
  productId: string;
  name: string;
  price: number;
  quantity: number;
  image: string;
  category: string;
  variant?: string;
  selected?: boolean;
}

export interface Order {
  orderId: string;
  userId: string;
  status: OrderStatus;
  items: CartItem[];
  totalAmount: number;
  shippingAddress?: Address;
  paymentMethod: PaymentMethod;
  paymentStatus?: TransactionStatus;
  createdAt: string;
  updatedAt: string;
  voucherCode?: string;
  voucherDiscount?: number;
  coinDiscount?: number;
}

export interface Address {
  id?: string;
  fullName: string;
  phone: string;
  address: string;
  city: string;
  postalCode: string;
  isDefault?: boolean;
}

export interface Mission {
  missionId: string;
  title: string;
  description: string;
  category: MissionCategory;
  reward: number;
  status: MissionStatus;
  userId?: string;
  estimatedMinutes: number;
  requirements?: string[];
  steps?: string[];
  icon?: string;
  merchantName?: string;
  merchantIcon?: string;
  maxParticipants?: number;
  currentParticipants?: number;
  maxAttempts?: number;
  processingDays?: number;
  createdAt?: string;
  completedAt?: string;
}

export interface Transaction {
  transactionId: string;
  userId: string;
  type: TransactionType;
  amount: number;
  fee: number;
  netAmount: number;
  status: TransactionStatus;
  method: PaymentMethod;
  accountNumber?: string;
  description: string;
  merchantIcon?: string;
  createdAt: string;
  processedAt?: string;
}

export interface Wallet {
  userId: string;
  balance: number;
  coins: number;
  updatedAt: string;
}

export interface Notification {
  notificationId: string;
  title: string;
  body: string;
  type: NotificationType;
  read: boolean;
  createdAt: string;
  actionUrl?: string;
  imageUrl?: string;
}

export interface Voucher {
  voucherId: string;
  code: string;
  title: string;
  description: string;
  discountAmount: number;
  discountPercent?: number;
  minPurchase: number;
  maxDiscount?: number;
  expiryDate: string;
  category?: string;
  usageLimit?: number;
  usageCount: number;
  status: 'active' | 'expired' | 'used';
}

export interface Review {
  reviewId: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  productId: string;
  rating: number;
  text: string;
  images?: string[];
  variant?: string;
  helpful: number;
  createdAt: string;
}

export interface ChatMessage {
  messageId: string;
  sender: 'user' | 'ai' | 'admin';
  text: string;
  timestamp: string;
  type: 'text' | 'image' | 'file';
  read: boolean;
}

export interface SupportTicket {
  ticketId: string;
  userId: string;
  userName: string;
  status: 'waiting_admin' | 'in_progress' | 'resolved' | 'closed';
  issue: string;
  chatHistory: ChatMessage[];
  createdAt: string;
  assignedAdmin?: string | null;
}

export interface FAQ {
  faqId: string;
  question: string;
  answer: string;
  category: string;
  keywords: string[];
}

export interface CoinTransaction {
  transactionId: string;
  userId: string;
  type: 'earn' | 'redeem';
  amount: number;
  source: string;
  description: string;
  createdAt: string;
}

export interface AffiliateStats {
  userId: string;
  referralCode: string;
  totalReferrals: number;
  totalEarnings: number;
  pendingEarnings: number;
  history: ReferralHistory[];
}

export interface ReferralHistory {
  referredUserId: string;
  referredUserName: string;
  reward: number;
  status: 'pending' | 'completed';
  createdAt: string;
}

export interface Banner {
  bannerId: string;
  image: string;
  title: string;
  link: string;
  active: boolean;
}

export interface KTAData {
  ktaId: string;
  userId: string;
  websiteName: string;
  developerName: string;
  fullName: string;
  createdAt: string;
  expiresAt: string;
  status: 'active' | 'expired' | 'revoked';
  verified: boolean;
  imageUrl?: string;
  rejectionReason?: string;
}

export interface BlockedIP {
  ip: string;
  reason: string;
  blockedBy: string;
  blockedAt: string;
  expiresAt?: string;
  userId?: string;
  status: 'active' | 'unblocked';
}

export interface SecurityLog {
  logId: string;
  userId: string;
  action: string;
  ipAddress: string;
  deviceInfo: string;
  timestamp: string;
  location?: string;
}

export interface FlashSale {
  saleId: string;
  productId: string;
  productName: string;
  productImage: string;
  discountPrice: number;
  originalPrice: number;
  discount: number;
  sold: number;
  total: number;
  startTime: string;
  endTime: string;
  active: boolean;
}
