import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Wallet, AlertCircle } from 'lucide-react';
import { useStore } from '@/stores/useStore';
import { formatPrice } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';

const methods = [
  { key: 'dana', label: 'DANA', account: '08123456789' },
  { key: 'gopay', label: 'GoPay', account: '08123456789' },
  { key: 'bca', label: 'Transfer Bank BCA', account: '1234567890' },
  { key: 'bni', label: 'Transfer Bank BNI', account: '0987654321' },
];

export default function WithdrawPage() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [amount, setAmount] = useState('');
  const [selectedMethod, setSelectedMethod] = useState('dana');
  const [accountNumber, setAccountNumber] = useState('');
  const [processing, setProcessing] = useState(false);
  const { user } = useStore();

  const balance = user?.saldo || 0;
  const numAmount = Number(amount);
  const fee = 2500;
  const totalDeduction = numAmount + fee;
  const isValid = numAmount >= 50000 && numAmount > 0 && totalDeduction <= balance && accountNumber.length >= 5;

  const handleWithdraw = async () => {
    if (!isValid) return;
    setProcessing(true);
    setTimeout(() => {
      toast({ title: 'Penarikan Berhasil', description: 'Penarikan akan diproses dalam 1x24 jam' });
      setProcessing(false);
      navigate('/wallet');
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-[#080C14] text-white pt-16 pb-8">
      <div className="flex items-center gap-3 px-4 py-3 border-b border-[#1C2A45]">
        <button onClick={() => navigate(-1)}><ArrowLeft className="w-5 h-5 text-gray-400" /></button>
        <h1 className="text-lg font-bold">Tarik Saldo</h1>
      </div>

      <div className="px-4 py-4 max-w-lg mx-auto space-y-4">
        {/* Balance */}
        <div className="bg-gradient-to-br from-[#7C3AED] to-[#3B82F6] rounded-2xl p-5 text-center">
          <p className="text-white/70 text-sm mb-1">Saldo Tersedia</p>
          <p className="text-3xl font-bold text-white">{formatPrice(balance)}</p>
        </div>

        {/* Amount */}
        <div>
          <label className="text-sm text-gray-400 mb-2 block">Nominal Penarikan</label>
          <div className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500">Rp</span>
            <input
              type="number"
              value={amount}
              onChange={e => setAmount(e.target.value)}
              placeholder="50.000"
              className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl py-3 pl-12 pr-4 text-white text-lg focus:outline-none focus:border-[#00F0FF]"
            />
          </div>
          {numAmount > 0 && numAmount < 50000 && (
            <p className="text-xs text-red-400 mt-1 flex items-center gap-1">
              <AlertCircle className="w-3 h-3" /> Minimal penarikan Rp 50.000
            </p>
          )}
          {numAmount > 0 && totalDeduction > balance && (
            <p className="text-xs text-red-400 mt-1 flex items-center gap-1">
              <AlertCircle className="w-3 h-3" /> Saldo tidak mencukupi
            </p>
          )}
          <div className="flex gap-2 mt-2">
            {[50000, 100000, 200000].map(amt => (
              <button
                key={amt}
                onClick={() => setAmount(String(amt))}
                className="px-4 py-2 bg-[#131B2D] border border-[#1C2A45] rounded-lg text-xs text-gray-400 hover:border-[#00F0FF]"
              >
                Rp {amt.toLocaleString('id-ID')}
              </button>
            ))}
          </div>
        </div>

        {/* Method */}
        <div>
          <label className="text-sm text-gray-400 mb-2 block">Metode Penarikan</label>
          <div className="grid grid-cols-2 gap-2">
            {methods.map(m => (
              <button
                key={m.key}
                onClick={() => setSelectedMethod(m.key)}
                className={`p-3 rounded-xl border text-sm font-medium transition-colors ${
                  selectedMethod === m.key ? 'border-[#00F0FF] bg-[#00F0FF]/10 text-[#00F0FF]' : 'border-[#1C2A45] bg-[#131B2D] text-gray-400'
                }`}
              >
                {m.label}
              </button>
            ))}
          </div>
        </div>

        {/* Account Number */}
        <div>
          <label className="text-sm text-gray-400 mb-2 block">Nomor Rekening/E-Wallet</label>
          <input
            type="text"
            value={accountNumber}
            onChange={e => setAccountNumber(e.target.value)}
            placeholder="Masukkan nomor"
            className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl py-3 px-4 text-white focus:outline-none focus:border-[#00F0FF]"
          />
        </div>

        {/* Summary */}
        {numAmount > 0 && (
          <div className="bg-[#131B2D] rounded-xl p-4 border border-[#1C2A45] space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">Nominal</span>
              <span>{formatPrice(numAmount)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">Biaya Admin</span>
              <span>{formatPrice(fee)}</span>
            </div>
            <div className="flex justify-between text-sm font-semibold pt-2 border-t border-[#1C2A45]">
              <span>Total Dipotong</span>
              <span className="text-[#00F0FF]">{formatPrice(totalDeduction)}</span>
            </div>
          </div>
        )}

        {/* Submit */}
        <button
          onClick={handleWithdraw}
          disabled={!isValid || processing}
          className={`w-full py-4 rounded-xl font-semibold text-sm transition-all ${
            isValid && !processing
              ? 'bg-gradient-to-r from-[#00F0FF] to-[#7C3AED] text-white'
              : 'bg-gray-700 text-gray-500 cursor-not-allowed'
          }`}
        >
          {processing ? 'Memproses...' : 'Konfirmasi Penarikan'}
        </button>
      </div>
    </div>
  );
}
