import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useStore } from '@/stores/useStore';
import { LogIn, Mail, Lock, ArrowRight } from 'lucide-react';
import { toast } from 'sonner';

function getOAuthUrl() {
  const authUrl = new URL(`${import.meta.env.VITE_KIMI_AUTH_URL}/api/oauth/authorize`);
  authUrl.searchParams.set("client_id", import.meta.env.VITE_APP_ID);
  authUrl.searchParams.set("redirect_uri", `${window.location.origin}/api/oauth/callback`);
  authUrl.searchParams.set("response_type", "code");
  authUrl.searchParams.set("scope", "profile");
  authUrl.searchParams.set("state", btoa(window.location.pathname));
  return authUrl.toString();
}

export default function LoginPage() {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const { setUser, setIsLoggedIn, setIsAdmin } = useStore();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // For demo, just simulate login
    setTimeout(() => {
      setUser({
        uid: 'demo-user',
        email: email || 'demo@example.com',
        displayName: 'Demo User',
        role: 'user',
        photoURL: null,
        phoneNumber: null,
      });
      setIsLoggedIn(true);
      setIsAdmin(false);
      toast.success('Login berhasil!');
      navigate('/');
      setLoading(false);
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-[#080C14] text-white flex flex-col">
      <div className="flex-1 flex flex-col justify-center px-6 max-w-md mx-auto w-full">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-gradient-to-br from-[#FF6F00] to-[#FF8F00] rounded-2xl flex items-center justify-center mx-auto mb-4">
            <LogIn className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold">{t('login') || 'Masuk'}</h1>
          <p className="text-sm text-gray-500 mt-1">{t('welcome_guest') || 'Selamat datang di CariCuan'}</p>
        </div>

        {/* Form */}
        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder={t('email') || 'Email'}
                className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl py-3.5 pl-12 pr-4 text-white placeholder:text-gray-600 focus:outline-none focus:border-[#00F0FF]"
              />
            </div>
          </div>
          <div>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input
                type="password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder={t('password') || 'Password'}
                className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl py-3.5 pl-12 pr-4 text-white placeholder:text-gray-600 focus:outline-none focus:border-[#00F0FF]"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3.5 bg-gradient-to-r from-[#FF6F00] to-[#FF8F00] rounded-xl font-semibold text-white disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {loading ? 'Memuat...' : (t('login') || 'Masuk')}
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        {/* Divider */}
        <div className="flex items-center gap-3 my-6">
          <div className="flex-1 h-px bg-[#1C2A45]" />
          <span className="text-xs text-gray-500">{t('or') || 'ATAU'}</span>
          <div className="flex-1 h-px bg-[#1C2A45]" />
        </div>

        {/* OAuth */}
        <button
          onClick={() => { window.location.href = getOAuthUrl(); }}
          className="w-full py-3.5 bg-[#131B2D] border border-[#1C2A45] rounded-xl font-medium text-white hover:border-[#00F0FF] transition-colors flex items-center justify-center gap-2"
        >
          {t('google_login') || 'Lanjutkan dengan SSO'}
        </button>

        {/* Links */}
        <div className="text-center mt-6 space-y-2">
          <button onClick={() => navigate('/forgot-password')} className="text-sm text-[#00F0FF]">
            {t('forgot_password') || 'Lupa Password?'}
          </button>
          <p className="text-sm text-gray-500">
            Belum punya akun?{' '}
            <button onClick={() => navigate('/register')} className="text-[#00F0FF] font-medium">
              {t('register') || 'Daftar'}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}
