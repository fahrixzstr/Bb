import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useStore } from '@/stores/useStore';
import { trpc } from '@/providers/trpc';
import {
  ArrowLeft, Wallet, History, Gift, Clock, Users, Target,
  ChevronRight, Star, Download, FileText, Smartphone, MapPin, Vote
} from 'lucide-react';
import { formatPrice } from '@/lib/utils';

const categories = [
  { key: 'all', label: 'Semua' },
  { key: 'registrasi', label: 'Registrasi' },
  { key: 'review', label: 'Review' },
  { key: 'download', label: 'Download' },
  { key: 'game', label: 'Game' },
  { key: 'survey', label: 'Survey' },
  { key: 'pinjaman', label: 'Pinjaman' },
];

const tabs = [
  { key: 'available', label: 'Misi Tersedia' },
  { key: 'taken', label: 'Sudah Diambil' },
];

const statusConfig: Record<string, { label: string; color: string }> = {
  claimed: { label: 'Belum Dikerjakan', color: 'text-blue-400 bg-blue-400/10' },
  submitted: { label: 'Diproses', color: 'text-yellow-400 bg-yellow-400/10' },
  processing: { label: 'Diproses', color: 'text-yellow-400 bg-yellow-400/10' },
  completed: { label: 'Berhasil', color: 'text-green-400 bg-green-400/10' },
  rejected: { label: 'Ditolak', color: 'text-red-400 bg-red-400/10' },
  expired: { label: 'Kedaluwarsa', color: 'text-gray-400 bg-gray-400/10' },
};

const categoryIcons: Record<string, React.ElementType> = {
  review: Star,
  registrasi: FileText,
  download: Download,
  game: Smartphone,
  survey: FileText,
  pinjaman: Wallet,
  social_media: Smartphone,
  voting: Vote,
  google_maps: MapPin,
};

interface MissionDetailModalProps {
  mission: any;
  onClose: () => void;
}

function MissionDetailModal({ mission, onClose }: MissionDetailModalProps) {
  const navigate = useNavigate();
  const { user } = useStore();
  const utils = trpc.useUtils();

  const claimMutation = trpc.mission.claim.useMutation({
    onSuccess: () => {
      utils.mission.list.invalidate();
      utils.mission.myMissions.invalidate();
      onClose();
    },
  });

  const handleClaim = () => {
    if (!user) {
      navigate('/login');
      return;
    }
    claimMutation.mutate({ missionId: mission.id });
  };

  const requirements = (mission.requirements as string[]) || [];
  const steps = (mission.steps as string[]) || [];
  const proofFields = (mission.proofFields as Record<string, string>[]) || [];

  return (
    <div className="fixed inset-0 z-[100] flex items-end justify-center" onClick={onClose}>
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
      <div
        className="relative w-full max-w-lg bg-[#131B2D] rounded-t-2xl border-t border-[#1C2A45] max-h-[90vh] overflow-y-auto"
        onClick={e => e.stopPropagation()}
      >
        {/* Handle */}
        <div className="flex justify-center pt-3 pb-2">
          <div className="w-10 h-1 bg-[#1C2A45] rounded-full" />
        </div>

        {/* Header */}
        <div className="px-4 pb-3 border-b border-[#1C2A45]">
          <div className="flex items-center justify-between">
            <span className="text-xs text-gray-500">ID: MS-{mission.id}</span>
            <button onClick={onClose} className="text-gray-400">✕</button>
          </div>
          <div className="flex items-center gap-2 mt-2">
            <span className={`px-2 py-0.5 text-xs rounded-full ${statusConfig['claimed']?.color}`}>
              {statusConfig['claimed']?.label}
            </span>
          </div>
        </div>

        {/* Reward */}
        <div className="px-4 py-4">
          <div className="bg-gradient-to-br from-[#FF6F00]/20 to-[#FF8F00]/10 rounded-xl p-4 border border-[#FF6F00]/30">
            <p className="text-xs text-[#FF8F00] mb-1">Reward Misi</p>
            <p className="text-2xl font-bold text-[#FF6F00]">{formatPrice(parseFloat(mission.rewardAmount))}</p>
          </div>
        </div>

        {/* Metadata */}
        <div className="px-4 pb-4">
          <div className="grid grid-cols-3 gap-2">
            <div className="bg-[#080C14] rounded-lg p-2 text-center">
              <Clock className="w-4 h-4 text-gray-500 mx-auto mb-1" />
              <p className="text-xs font-medium">{mission.timeEstimate || 30} mnt</p>
            </div>
            <div className="bg-[#080C14] rounded-lg p-2 text-center">
              <Users className="w-4 h-4 text-gray-500 mx-auto mb-1" />
              <p className="text-xs font-medium">{mission.currentParticipants || 0}/{mission.maxParticipants || '-'}</p>
            </div>
            <div className="bg-[#080C14] rounded-lg p-2 text-center">
              <Target className="w-4 h-4 text-gray-500 mx-auto mb-1" />
              <p className="text-xs font-medium">Maks {mission.maxAttempts || 1}x</p>
            </div>
          </div>
        </div>

        {/* Info Banner */}
        <div className="px-4 pb-4">
          <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-3">
            <p className="text-xs text-blue-400">
              Hasil kerja diproses maksimal {mission.processingDays || 3} hari kerja setelah submit
            </p>
          </div>
        </div>

        {/* Requirements */}
        {requirements.length > 0 && (
          <div className="px-4 pb-4">
            <h3 className="text-sm font-semibold mb-2">Persyaratan</h3>
            <ol className="space-y-1.5">
              {requirements.map((req, i) => (
                <li key={i} className="text-xs text-gray-400 flex items-start gap-2">
                  <span className="text-[#00F0FF] font-medium">{i + 1}.</span>
                  {req}
                </li>
              ))}
            </ol>
          </div>
        )}

        {/* Steps */}
        {steps.length > 0 && (
          <div className="px-4 pb-4">
            <h3 className="text-sm font-semibold mb-2">Langkah Pengerjaan</h3>
            <ol className="space-y-1.5">
              {steps.map((step, i) => (
                <li key={i} className="text-xs text-gray-400 flex items-start gap-2">
                  <span className="text-[#FF6F00] font-medium">{i + 1}.</span>
                  {step}
                </li>
              ))}
            </ol>
          </div>
        )}

        {/* Footer */}
        <div className="sticky bottom-0 px-4 py-3 bg-[#131B2D] border-t border-[#1C2A45]">
          <div className="flex gap-2">
            <button
              onClick={handleClaim}
              disabled={claimMutation.isPending}
              className="flex-1 py-3 bg-gradient-to-r from-[#FF6F00] to-[#FF8F00] rounded-xl text-sm font-semibold text-white disabled:opacity-50"
            >
              {claimMutation.isPending ? 'Memproses...' : 'Ambil Misi'}
            </button>
            <button
              onClick={() => {
                navigator.share?.({ title: mission.title, text: `Dapatkan ${formatPrice(parseFloat(mission.rewardAmount))} dari misi "${mission.title}" di CariCuan!` });
              }}
              className="px-4 py-3 bg-[#080C14] border border-[#1C2A45] rounded-xl text-sm text-gray-400"
            >
              Bagikan
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function MissionsPage() {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const { user } = useStore();
  const [activeTab, setActiveTab] = useState('available');
  const [activeCategory, setActiveCategory] = useState('all');
  const [selectedMission, setSelectedMission] = useState<any>(null);

  const { data: availableMissions, isLoading: loadingAvailable } = trpc.mission.list.useQuery(
    activeTab === 'available' ? { category: activeCategory === 'all' ? undefined : activeCategory } : undefined
  );

  const { data: myMissionsData, isLoading: loadingTaken } = trpc.mission.myMissions.useQuery(
    activeTab === 'taken' ? undefined : undefined
  );

  const missions = activeTab === 'available'
    ? (availableMissions?.items || [])
    : (myMissionsData?.items?.map((item: any) => ({
        ...item.mission,
        userMissionStatus: item.userMission.status,
        submittedAt: item.userMission.submittedAt,
      })) || []);

  const balance = user?.saldo || 0;

  return (
    <div className="min-h-screen bg-[#080C14] text-white pb-8">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-[#080C14]/95 backdrop-blur-md px-4 py-3 border-b border-[#1C2A45]">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button onClick={() => navigate(-1)}><ArrowLeft className="w-5 h-5 text-gray-400" /></button>
            <h1 className="text-lg font-bold">Cari Cuan</h1>
          </div>
          <button onClick={() => navigate('/notifications')} className="relative">
            <div className="w-2 h-2 bg-red-500 rounded-full absolute -top-0.5 -right-0.5" />
          </button>
        </div>
      </div>

      {/* Ticker */}
      <div className="mx-4 mt-2 bg-gradient-to-r from-[#FF6F00]/20 to-[#FF8F00]/10 rounded-lg px-3 py-2 border border-[#FF6F00]/30">
        <p className="text-xs text-[#FF8F00] truncate">
          Rp 1.500 didapat <span className="font-semibold">User123</span> - Rp 5.000 didapat <span className="font-semibold">Anon99</span>
        </p>
      </div>

      {/* Balance Card */}
      <div className="mx-4 mt-3 bg-gradient-to-br from-[#1E88E5] to-[#1565C0] rounded-xl p-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-white/70 text-xs">Saldo Anda</p>
            <p className="text-2xl font-bold text-white mt-0.5">{formatPrice(balance)}</p>
          </div>
          <div className="flex gap-3">
            <button onClick={() => navigate('/wallet')} className="flex flex-col items-center gap-1">
              <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                <History className="w-5 h-5 text-white" />
              </div>
              <span className="text-[10px] text-white/80">Riwayat</span>
            </button>
            <button onClick={() => navigate('/wallet/withdraw')} className="flex flex-col items-center gap-1">
              <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                <Wallet className="w-5 h-5 text-white" />
              </div>
              <span className="text-[10px] text-white/80">Tarik</span>
            </button>
            <button onClick={() => navigate('/affiliate')} className="flex flex-col items-center gap-1">
              <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                <Gift className="w-5 h-5 text-white" />
              </div>
              <span className="text-[10px] text-white/80">Bonus</span>
            </button>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex mx-4 mt-4 bg-[#131B2D] rounded-xl p-1 border border-[#1C2A45]">
        {tabs.map(tab => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`flex-1 py-2 text-xs font-medium rounded-lg transition-colors ${
              activeTab === tab.key ? 'bg-[#1E88E5] text-white' : 'text-gray-500'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Category Filters */}
      <div className="flex gap-2 px-4 mt-3 overflow-x-auto pb-2">
        {categories.map(cat => (
          <button
            key={cat.key}
            onClick={() => setActiveCategory(cat.key)}
            className={`px-4 py-1.5 text-xs font-medium rounded-full whitespace-nowrap transition-colors ${
              activeCategory === cat.key ? 'bg-[#FF6F00] text-white' : 'bg-[#131B2D] text-gray-400 border border-[#1C2A45]'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Missions List */}
      <div className="px-4 mt-4 space-y-3">
        {(loadingAvailable || loadingTaken) ? (
          [...Array(3)].map((_, i) => (
            <div key={i} className="bg-[#131B2D] rounded-xl p-4 border border-[#1C2A45] animate-pulse">
              <div className="h-4 bg-[#1C2A45] rounded w-3/4" />
              <div className="h-3 bg-[#1C2A45] rounded w-1/2 mt-2" />
              <div className="h-3 bg-[#1C2A45] rounded w-2/3 mt-1" />
            </div>
          ))
        ) : missions.length === 0 ? (
          <div className="text-center py-16 text-gray-500">
            <Target className="w-12 h-12 mx-auto mb-3 text-gray-600" />
            <p className="text-sm">{t('no_missions') || 'Belum ada misi'}</p>
          </div>
        ) : (
          missions.map((mission: any) => {
            const Icon = categoryIcons[mission.category] || Target;
            const status = activeTab === 'taken'
              ? (mission.userMissionStatus || 'claimed')
              : 'available';

            return (
              <button
                key={mission.id}
                onClick={() => setSelectedMission(mission)}
                className="w-full bg-[#131B2D] rounded-xl p-4 border border-[#1C2A45] text-left transition-colors hover:border-[#1E88E5]/50"
              >
                {/* Status Badge */}
                {activeTab === 'taken' && statusConfig[status] && (
                  <div className="flex items-center justify-between mb-2">
                    <span className={`px-2 py-0.5 text-[10px] rounded-full ${statusConfig[status].color}`}>
                      {statusConfig[status].label}
                    </span>
                    {mission.submittedAt && (
                      <span className="text-[10px] text-gray-500">
                        {new Date(mission.submittedAt).toLocaleDateString('id-ID')}
                      </span>
                    )}
                  </div>
                )}

                <div className="flex items-start gap-3">
                  {/* Icon */}
                  <div className="w-12 h-12 rounded-xl bg-[#080C14] border border-[#1C2A45] flex items-center justify-center flex-shrink-0">
                    <Icon className="w-6 h-6 text-[#FF6F00]" />
                  </div>

                  <div className="flex-1 min-w-0">
                    <h3 className="text-sm font-semibold truncate">{mission.title}</h3>
                    <p className="text-xs text-gray-500 line-clamp-1 mt-0.5">{mission.description}</p>

                    {/* Reward */}
                    <div className="flex items-center gap-1.5 mt-2">
                      <Wallet className="w-3.5 h-3.5 text-[#FF6F00]" />
                      <span className="text-sm font-bold text-[#FF6F00]">{formatPrice(parseFloat(mission.rewardAmount))}</span>
                    </div>

                    {/* Meta */}
                    <div className="flex items-center gap-3 mt-2 text-[10px] text-gray-500">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {mission.timeEstimate || 30} mnt
                      </span>
                      <span className="flex items-center gap-1">
                        <Users className="w-3 h-3" />
                        {mission.currentParticipants || 0}/{mission.maxParticipants || '-'}
                      </span>
                      <span>Maks {mission.maxAttempts || 1}x</span>
                    </div>
                  </div>

                  <ChevronRight className="w-4 h-4 text-gray-600 flex-shrink-0 mt-1" />
                </div>
              </button>
            );
          })
        )}
      </div>

      {/* Mission Detail Modal */}
      {selectedMission && (
        <MissionDetailModal
          mission={selectedMission}
          onClose={() => setSelectedMission(null)}
        />
      )}
    </div>
  );
}
