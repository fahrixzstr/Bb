import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Shield, Lock, ArrowRight } from 'lucide-react';
import { useStore } from '@/stores/useStore';
import { toast } from 'sonner';

export default function AdminLoginPage() {
  const navigate = useNavigate();
  const { setUser, setIsLoggedIn, setIsAdmin } = useStore();
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    // Demo admin login
    setTimeout(() => {
      if (password === 'admin123') {
        setUser({
          uid: 'admin-user',
          email: 'admin@caricuan.id',
          displayName: 'Admin',
          role: 'admin',
          photoURL: null,
          phoneNumber: null,
        });
        setIsLoggedIn(true);
        setIsAdmin(true);
        toast.success('Admin Login Berhasil!');
        navigate('/admin');
      } else {
        toast.error('Password salah');
      }
      setLoading(false);
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-[#080C14] text-white flex items-center justify-center px-4">
      <div className="max-w-sm w-full">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-gradient-to-br from-red-500 to-orange-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Shield className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold">Admin Panel</h1>
          <p className="text-sm text-gray-500 mt-1">CariCuan Admin Login</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-4">
          <div className="relative">
            <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
            <input
              type="password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder="Password Admin"
              className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl py-3.5 pl-12 pr-4 text-white placeholder:text-gray-600 focus:outline-none focus:border-red-500"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3.5 bg-gradient-to-r from-red-500 to-orange-500 rounded-xl font-semibold text-white disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {loading ? 'Memuat...' : 'Login Admin'}
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        <button
          onClick={() => navigate('/')}
          className="w-full mt-4 text-sm text-gray-500 hover:text-gray-400"
        >
          Kembali ke Beranda
        </button>
      </div>
    </div>
  );
}
