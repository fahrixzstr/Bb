import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { ArrowLeft, Package, Clock, CheckCircle, XCircle } from 'lucide-react';
import { formatPrice } from '@/lib/utils';
import EmptyState from '@/components/shared/EmptyState';

const tabs = [
  { key: 'all', label: 'Semua' },
  { key: 'pending', label: 'Belum Bayar' },
  { key: 'processing', label: 'Proses' },
  { key: 'completed', label: 'Berhasil' },
  { key: 'refund', label: 'Refund' },
];

const statusColors: Record<string, string> = {
  pending: 'text-yellow-400 bg-yellow-400/10',
  processing: 'text-blue-400 bg-blue-400/10',
  shipped: 'text-purple-400 bg-purple-400/10',
  completed: 'text-green-400 bg-green-400/10',
  cancelled: 'text-red-400 bg-red-400/10',
  refund: 'text-gray-400 bg-gray-400/10',
};

const statusLabels: Record<string, string> = {
  pending: 'Belum Bayar',
  processing: 'Diproses',
  shipped: 'Dikirim',
  completed: 'Selesai',
  cancelled: 'Dibatalkan',
  refund: 'Refund',
};

export default function OrdersPage() {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const [activeTab, setActiveTab] = useState('all');

  // Demo orders data
  const [orders] = useState([
    {
      orderId: 'ORD-001',
      status: 'completed',
      items: [{ name: 'Canva Pro 1 Bulan', qty: 1, price: 25000, image: '/assets/media/products/canva.jpg' }],
      total: 25000,
      date: new Date().toISOString(),
    },
    {
      orderId: 'ORD-002',
      status: 'processing',
      items: [{ name: 'ChatGPT Plus', qty: 1, price: 185000, image: '/assets/media/products/chatgpt.jpg' }],
      total: 185000,
      date: new Date(Date.now() - 86400000).toISOString(),
    },
  ]);

  const filteredOrders = activeTab === 'all' ? orders : orders.filter(o => o.status === activeTab);

  return (
    <div className="min-h-screen bg-[#080C14] text-white">
      <div className="sticky top-0 z-50 bg-[#080C14]/95 backdrop-blur-md border-b border-[#1C2A45]">
        <div className="flex items-center gap-3 px-4 py-3">
          <button onClick={() => navigate(-1)}><ArrowLeft className="w-5 h-5 text-gray-400" /></button>
          <h1 className="text-lg font-bold">{t('my_orders') || 'Pesanan Saya'}</h1>
        </div>
        <div className="flex gap-1 px-4 pb-2 overflow-x-auto">
          {tabs.map(tab => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`px-4 py-1.5 text-xs font-medium rounded-full whitespace-nowrap transition-colors ${
                activeTab === tab.key ? 'bg-[#00F0FF] text-black' : 'bg-[#131B2D] text-gray-400'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <div className="px-4 py-4 space-y-3">
        {filteredOrders.length === 0 ? (
          <EmptyState type="order" title={t('no_orders') || 'Belum ada pesanan'} />
        ) : (
          filteredOrders.map(order => (
            <div key={order.orderId} className="bg-[#131B2D] rounded-xl p-4 border border-[#1C2A45]">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs text-gray-500">{order.orderId}</span>
                <span className={`px-2 py-0.5 text-xs rounded-full ${statusColors[order.status]}`}>
                  {statusLabels[order.status]}
                </span>
              </div>
              {order.items.map((item, idx) => (
                <div key={idx} className="flex items-center gap-3 mb-3">
                  <img src={item.image} alt={item.name} className="w-14 h-14 rounded-lg object-cover" />
                  <div>
                    <p className="text-sm font-medium">{item.name}</p>
                    <p className="text-xs text-gray-500">{item.qty}x {formatPrice(item.price)}</p>
                  </div>
                </div>
              ))}
              <div className="flex items-center justify-between pt-3 border-t border-[#1C2A45]">
                <span className="text-xs text-gray-500">
                  {new Date(order.date).toLocaleDateString('id-ID')}
                </span>
                <span className="text-sm font-semibold text-[#00F0FF]">{formatPrice(order.total)}</span>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
