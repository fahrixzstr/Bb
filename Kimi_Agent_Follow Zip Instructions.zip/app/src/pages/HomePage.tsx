import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useStore } from '@/stores/useStore';
import {
  Bot, Ticket, Target, Calendar, Heart, Globe,
  Server, Crown, Wrench, MoreHorizontal, ChevronRight, Zap
} from 'lucide-react';
import { QUICK_ACTIONS } from '@/lib/constants';
import ProductCard from '@/components/shared/ProductCard';
import { useEffect, useState, useRef } from 'react';
import { trpc } from '@/providers/trpc';

const quickIcons: Record<string, React.ElementType> = {
  Bot, Ticket, Target, Calendar, Heart, Globe, Server, Crown, Wrench, MoreHorizontal,
};

export default function HomePage() {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const { user, isLoggedIn } = useStore();
  const [currentBanner, setCurrentBanner] = useState(0);
  const [flashSaleTime, setFlashSaleTime] = useState({ hours: 4, minutes: 32, seconds: 15 });
  const earningsRef = useRef(0);

  const { data: productsData, isLoading: loadingProducts } = trpc.product.list.useQuery({ limit: 8 });
  const products = productsData?.items || [];

  const [totalEarnings] = useState(2584500);

  useEffect(() => {
    const timer = setInterval(() => {
      setFlashSaleTime(prev => {
        let { hours, minutes, seconds } = prev;
        seconds--;
        if (seconds < 0) { seconds = 59; minutes--; }
        if (minutes < 0) { minutes = 59; hours--; }
        if (hours < 0) { hours = 4; minutes = 32; seconds = 15; }
        return { hours, minutes, seconds };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const bannerTimer = setInterval(() => {
      setCurrentBanner(prev => (prev + 1) % 3);
    }, 5000);
    return () => clearInterval(bannerTimer);
  }, []);

  const formatTime = (n: number) => n.toString().padStart(2, '0');

  const bannerImages = [
    '/assets/media/banners/banner-1.jpg',
    '/assets/media/banners/banner-2.jpg',
    '/assets/media/banners/banner-3.jpg',
  ];

  const quickActions = [
    { icon: Target, label: t('missions') || 'Misi', path: '/missions', color: 'text-[#00F0FF]' },
    { icon: Ticket, label: 'Voucher', path: '/vouchers', color: 'text-orange-400' },
    { icon: Calendar, label: 'Events', path: '/events', color: 'text-purple-400' },
    { icon: Crown, label: 'Coins', path: '/coins', color: 'text-yellow-400' },
    { icon: Heart, label: t('favorites') || 'Favorit', path: '/favorites', color: 'text-red-400' },
    { icon: Globe, label: 'Affiliate', path: '/affiliate', color: 'text-green-400' },
    { icon: Server, label: 'Top Up', path: '/wallet', color: 'text-blue-400' },
    { icon: Wrench, label: 'CS', path: '/customer-service', color: 'text-gray-400' },
  ];

  return (
    <div className="min-h-screen bg-[#080C14] text-white pb-20">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-[#080C14]/95 backdrop-blur-md px-4 py-3">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-lg font-bold">
              {isLoggedIn ? `Hai, ${user?.displayName || 'User'}!` : 'CariCuan'}
            </h1>
            <p className="text-xs text-gray-500">{t('tagline') || 'Temukan produk terbaik dan dapatkan cuan!'}</p>
          </div>
          <button onClick={() => navigate('/search')} className="w-9 h-9 bg-[#131B2D] rounded-full flex items-center justify-center border border-[#1C2A45]">
            <MoreHorizontal className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Earnings Ticker */}
      <div className="mx-4 mt-2 bg-gradient-to-r from-[#FF6F00]/20 to-[#FF8F00]/10 rounded-lg px-3 py-2 border border-[#FF6F00]/30">
        <p className="text-xs text-[#FF8F00]">
          <span className="font-semibold">Rp {totalEarnings.toLocaleString('id-ID')}</span> didapatkan oleh user lain - Ayo mulai misi!
        </p>
      </div>

      {/* Banner Carousel */}
      <div className="mx-4 mt-4 relative rounded-2xl overflow-hidden aspect-[2/1]">
        <img src={bannerImages[currentBanner]} alt="Banner" className="w-full h-full object-cover transition-opacity duration-500" />
        <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex gap-1">
          {bannerImages.map((_, i) => (
            <div key={i} className={`w-2 h-2 rounded-full ${i === currentBanner ? 'bg-white' : 'bg-white/40'}`} />
          ))}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="px-4 mt-4">
        <div className="grid grid-cols-4 gap-3">
          {quickActions.map(action => (
            <button key={action.label} onClick={() => navigate(action.path)} className="flex flex-col items-center gap-1.5">
              <div className="w-12 h-12 rounded-xl bg-[#131B2D] border border-[#1C2A45] flex items-center justify-center">
                <action.icon className={`w-5 h-5 ${action.color}`} />
              </div>
              <span className="text-[10px] text-gray-400">{action.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Flash Sale */}
      <div className="px-4 mt-6">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-[#FF6F00]" />
            <h2 className="font-bold text-sm">Flash Sale</h2>
          </div>
          <div className="flex items-center gap-1 text-xs">
            <span className="bg-[#FF6F00] text-white px-1.5 py-0.5 rounded">{formatTime(flashSaleTime.hours)}</span>
            <span className="text-gray-500">:</span>
            <span className="bg-[#FF6F00] text-white px-1.5 py-0.5 rounded">{formatTime(flashSaleTime.minutes)}</span>
            <span className="text-gray-500">:</span>
            <span className="bg-[#FF6F00] text-white px-1.5 py-0.5 rounded">{formatTime(flashSaleTime.seconds)}</span>
          </div>
        </div>
      </div>

      {/* Products */}
      <div className="px-4 mt-6">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-bold text-sm">{t('featured_products') || 'Produk Unggulan'}</h2>
          <button onClick={() => navigate('/products')} className="text-xs text-[#00F0FF] flex items-center gap-0.5">
            {t('see_all') || 'Lihat Semua'} <ChevronRight className="w-3 h-3" />
          </button>
        </div>

        {loadingProducts ? (
          <div className="grid grid-cols-2 gap-3">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="bg-[#131B2D] rounded-xl p-3 border border-[#1C2A45] animate-pulse">
                <div className="aspect-square bg-[#1C2A45] rounded-lg" />
                <div className="h-3 bg-[#1C2A45] rounded mt-2" />
                <div className="h-3 bg-[#1C2A45] rounded mt-1 w-2/3" />
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {products.map(product => (
              <ProductCard key={product.id} product={product as any} />
            ))}
          </div>
        )}
      </div>

      {/* Missions Preview */}
      <div className="px-4 mt-6">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-bold text-sm">{t('missions') || 'Misi Cuan'}</h2>
          <button onClick={() => navigate('/missions')} className="text-xs text-[#00F0FF] flex items-center gap-0.5">
            {t('see_all') || 'Lihat Semua'} <ChevronRight className="w-3 h-3" />
          </button>
        </div>
        <div className="bg-gradient-to-br from-[#131B2D] to-[#0D1321] rounded-xl p-4 border border-[#1C2A45]">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-[#00F0FF]/10 flex items-center justify-center">
              <Target className="w-6 h-6 text-[#00F0FF]" />
            </div>
            <div>
              <h3 className="font-semibold text-sm">Cari Cuan Sekarang!</h3>
              <p className="text-xs text-gray-500">Selesaikan misi dan dapatkan reward</p>
            </div>
          </div>
          <button
            onClick={() => navigate('/missions')}
            className="mt-3 w-full py-2.5 bg-gradient-to-r from-[#FF6F00] to-[#FF8F00] rounded-lg text-sm font-semibold text-white"
          >
            {t('see_missions') || 'Lihat Misi'}
          </button>
        </div>
      </div>
    </div>
  );
}
