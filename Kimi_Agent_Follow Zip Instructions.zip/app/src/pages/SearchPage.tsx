import { useState, useMemo, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Search, Clock, TrendingUp } from 'lucide-react';
import ProductCard from '@/components/shared/ProductCard';
import type { Product } from '@/types';

const escapeHtml = (text: string): string => {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
};

export default function SearchPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const query = searchParams.get('q') || '';
  const [searchQuery, setSearchQuery] = useState(query);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [trendingSearches, setTrendingSearches] = useState<string[]>(['Canva', 'Netflix', 'ChatGPT', 'Spotify', 'VPS']);
  const [searchHistory, setSearchHistory] = useState<string[]>([]);

  useEffect(() => {
    // Fetch demo products
    const demoProducts: Product[] = [
      { id: '1', name: 'Canva Pro 1 Bulan', description: 'Akses Canva Pro', price: 25000, category: 'subscription', image: '/assets/media/products/canva.jpg', rating: 4.8, reviewCount: 120, soldCount: 500, stock: 100 },
      { id: '2', name: 'Netflix Premium', description: 'Netflix 1 Bulan', price: 45000, category: 'subscription', image: '/assets/media/products/netflix.jpg', rating: 4.7, reviewCount: 200, soldCount: 800, stock: 50 },
      { id: '3', name: 'ChatGPT Plus', description: 'ChatGPT Plus 1 Bulan', price: 185000, category: 'subscription', image: '/assets/media/products/chatgpt.jpg', rating: 4.9, reviewCount: 300, soldCount: 1200, stock: 30 },
      { id: '4', name: 'Spotify Premium', description: 'Spotify 1 Bulan', price: 15000, category: 'subscription', image: '/assets/media/products/spotify.jpg', rating: 4.6, reviewCount: 150, soldCount: 600, stock: 80 },
      { id: '5', name: 'VPS Server', description: 'VPS 1 Bulan', price: 75000, category: 'hosting', image: '/assets/media/products/vps.jpg', rating: 4.5, reviewCount: 80, soldCount: 200, stock: 20 },
      { id: '6', name: 'Steam Wallet', description: 'Steam Wallet IDR', price: 50000, category: 'voucher', image: '/assets/media/products/steam.jpg', rating: 4.8, reviewCount: 250, soldCount: 900, stock: 200 },
      { id: '7', name: 'YouTube Premium', description: 'YT Premium 1 Bulan', price: 12000, category: 'subscription', image: '/assets/media/products/youtube.jpg', rating: 4.4, reviewCount: 90, soldCount: 400, stock: 60 },
      { id: '8', name: 'Google Play', description: 'Google Play IDR', price: 50000, category: 'voucher', image: '/assets/media/products/googleplay.jpg', rating: 4.7, reviewCount: 180, soldCount: 700, stock: 150 },
    ];
    setProducts(demoProducts);
    setLoading(false);

    const history = localStorage.getItem('searchHistory');
    if (history) setSearchHistory(JSON.parse(history));
  }, []);

  const results = useMemo(() => {
    if (!searchQuery.trim()) return [];
    const q = searchQuery.toLowerCase();
    return products.filter(p => p.name.toLowerCase().includes(q) || p.description?.toLowerCase().includes(q));
  }, [searchQuery, products]);

  const handleSearch = (term: string) => {
    setSearchQuery(term);
    setSearchParams({ q: term });
    const newHistory = [term, ...searchHistory.filter(h => h !== term)].slice(0, 10);
    setSearchHistory(newHistory);
    localStorage.setItem('searchHistory', JSON.stringify(newHistory));
  };

  return (
    <div className="min-h-screen bg-[#080C14] text-white">
      <div className="sticky top-0 z-50 bg-[#080C14]/95 backdrop-blur-md px-4 py-3">
        <div className="flex items-center gap-3">
          <div className="flex-1 flex items-center gap-2 bg-[#131B2D] rounded-full px-4 py-2.5 border border-[#1C2A45]">
            <Search className="w-4 h-4 text-gray-500 flex-shrink-0" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleSearch(searchQuery)}
              placeholder="Cari produk, misi, atau kategori..."
              className="flex-1 bg-transparent text-sm outline-none placeholder:text-gray-600"
            />
          </div>
        </div>
      </div>

      {searchQuery.trim() ? (
        <div className="px-4 py-4">
          {loading ? (
            <div className="flex justify-center py-20"><div className="animate-spin w-8 h-8 border-2 border-[#00F0FF] border-t-transparent rounded-full" /></div>
          ) : results.length === 0 ? (
            <div className="text-center py-20 text-gray-500">Tidak ada hasil untuk &quot;{searchQuery}&quot;</div>
          ) : (
            <div className="grid grid-cols-2 gap-3">
              {results.map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      ) : (
        <div className="px-4 py-4 space-y-6">
          {searchHistory.length > 0 && (
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Clock className="w-4 h-4 text-gray-500" />
                <h2 className="text-sm font-semibold">Riwayat Pencarian</h2>
              </div>
              <div className="flex flex-wrap gap-2">
                {searchHistory.map(term => (
                  <button key={term} onClick={() => handleSearch(term)} className="px-3 py-1.5 bg-[#131B2D] rounded-full text-xs text-gray-400 border border-[#1C2A45]">
                    {term}
                  </button>
                ))}
              </div>
            </div>
          )}

          <div>
            <div className="flex items-center gap-2 mb-3">
              <TrendingUp className="w-4 h-4 text-[#00F0FF]" />
              <h2 className="text-sm font-semibold">Pencarian Populer</h2>
            </div>
            <div className="flex flex-wrap gap-2">
              {trendingSearches.map(term => (
                <button key={term} onClick={() => handleSearch(term)} className="px-3 py-1.5 bg-[#131B2D] rounded-full text-xs text-gray-400 border border-[#1C2A45] hover:border-[#00F0FF]">
                  {term}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
