import { useState, useEffect } from 'react';
import { db } from '@/lib/firebase';
import { doc, getDoc, collection, query, where, getDocs, limit } from 'firebase/firestore';
import { useNavigate, useParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { ArrowLeft, Star, ShoppingCart, MessageCircle, Heart, Share2, ChevronRight, Minus, Plus, Shield, Package } from 'lucide-react';
import { useStore } from '@/stores/useStore';
import { formatPrice, calculateDiscount, truncateText } from '@/lib/utils';
import ProductCard from '@/components/shared/ProductCard';

interface ProductDetail {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  category: string;
  image: string;
  images?: string[];
  rating: number;
  reviewCount: number;
  soldCount: number;
  stock: number;
  isBestSeller?: boolean;
  discount?: number;
  minOrder?: number;
  tags?: string[];
}

interface Review {
  reviewId: string;
  userId: string;
  userName: string;
  productId: string;
  rating: number;
  text: string;
  variant?: string;
  helpful?: number;
  createdAt: string;
}

const [product, setProduct] = useState<ProductDetail | null>(null);
const [relatedProducts, setRelatedProducts] = useState<ProductDetail[]>([]);
const [reviews, setReviews] = useState<Review[]>([]);
const [loading, setLoading] = useState(true);





export default function ProductDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { t } = useTranslation();
  const { addToCart } = useStore();
  const [isFavorite, setIsFavorite] = useState(false);
  const [quantity, setQuantity] = useState(1);
  const [selectedVariant, setSelectedVariant] = useState('1 Bulan');
  const [showVariantSheet, setShowVariantSheet] = useState(false);

  useEffect(() => {
    const fetchProductData = async () => {
      if (!id) return;
      setLoading(true);
      try {
        const productDoc = await getDoc(doc(db, 'products', id));
        if (productDoc.exists()) {
          setProduct({ id: productDoc.id, ...productDoc.data() } as ProductDetail);

          // Fetch related products
          const relatedQ = query(collection(db, 'products'), where('category', '==', productDoc.data().category), limit(5));
          const relatedSnap = await getDocs(relatedQ);
          const related = relatedSnap.docs
            .map(d => ({ id: d.id, ...d.data() } as ProductDetail))
            .filter(p => p.id !== id);
          setRelatedProducts(related);

          // Fetch reviews
          const reviewsQ = query(collection(db, 'reviews'), where('productId', '==', id), limit(10));
          const reviewsSnap = await getDocs(reviewsQ);
          setReviews(reviewsSnap.docs.map(d => ({ reviewId: d.id, ...d.data() } as Review)));
        }
      } catch (error) {
        console.error('Error fetching product:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchProductData();
  }, [id]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#080C14] flex items-center justify-center text-white">
        <div className="w-8 h-8 border-2 border-[#00F0FF] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-[#080C14] flex items-center justify-center text-white">
        <p>Produk tidak ditemukan</p>
      </div>
    );
  }

  const discount = calculateDiscount(product.originalPrice || 0, product.price);

  const handleAddToCart = () => {
    addToCart({
      productId: product.id,
      name: product.name,
      price: product.price,
      quantity,
      image: product.image,
      category: product.category,
      variant: selectedVariant,
    });
  };

  return (
    <div className="min-h-screen bg-[#080C14] text-white pb-24">
      {/* Image Gallery */}
      <div className="relative">
        <div className="aspect-square bg-[#131B2D]">
          <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
        </div>
        <button onClick={() => navigate(-1)} className="absolute top-4 left-4 p-2 rounded-full bg-black/50 backdrop-blur-sm">
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>
        <div className="absolute top-4 right-4 flex gap-2">
          <button onClick={() => setIsFavorite(!isFavorite)} className="p-2 rounded-full bg-black/50 backdrop-blur-sm">
            <Heart className={`w-5 h-5 ${isFavorite ? 'text-red-500 fill-red-500' : 'text-white'}`} />
          </button>
          <button className="p-2 rounded-full bg-black/50 backdrop-blur-sm">
            <Share2 className="w-5 h-5 text-white" />
          </button>
        </div>
      </div>

      {/* Product Info */}
      <div className="px-4 py-4">
        {/* Badges */}
        <div className="flex gap-2 mb-2">
          <span className="px-2 py-0.5 bg-[#00F0FF]/10 text-[#00F0FF] text-xs rounded-lg">{product.category}</span>
          {product.isBestSeller && (
            <span className="px-2 py-0.5 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white text-xs rounded-lg">BEST SELLER</span>
          )}
          {discount > 0 && (
            <span className="px-2 py-0.5 bg-red-500/10 text-red-400 text-xs rounded-lg">-{discount}%</span>
          )}
        </div>

        <h1 className="text-lg font-bold text-white mb-2">{product.name}</h1>

        {/* Price */}
        <div className="flex items-baseline gap-2 mb-2">
          <span className="text-2xl font-bold text-[#00F0FF]">{formatPrice(product.price)}</span>
          {product.originalPrice && (
            <span className="text-sm text-gray-500 line-through">{formatPrice(product.originalPrice)}</span>
          )}
        </div>

        {/* Rating */}
        <div className="flex items-center gap-3 mb-4">
          <div className="flex items-center gap-1">
            <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
            <span className="text-sm font-medium">{product.rating}</span>
          </div>
          <span className="text-sm text-gray-500">{product.reviewCount} {t('reviews')}</span>
          <span className="text-sm text-gray-500">{product.soldCount.toLocaleString('id-ID')}+ terjual</span>
        </div>

        {/* Variant Selector */}
        <div className="mb-4" onClick={() => setShowVariantSheet(true)}>
          <div className="flex items-center justify-between p-3 bg-[#131B2D] border border-[#1C2A45] rounded-xl cursor-pointer">
            <div>
              <p className="text-xs text-gray-500">{t('variant')}</p>
              <p className="text-sm text-white">{selectedVariant}</p>
            </div>
            <ChevronRight className="w-5 h-5 text-gray-500" />
          </div>
        </div>

        {/* Description */}
        <div className="mb-4">
          <h3 className="text-sm font-semibold text-white mb-2">{t('description')}</h3>
          <p className="text-sm text-gray-400 leading-relaxed">{product.description}</p>
        </div>

        {/* Guarantees */}
        <div className="flex gap-3 mb-6">
          <div className="flex items-center gap-1.5 text-xs text-gray-400">
            <Shield className="w-4 h-4 text-green-400" />
            Garansi
          </div>
          <div className="flex items-center gap-1.5 text-xs text-gray-400">
            <Package className="w-4 h-4 text-blue-400" />
            Pengiriman Otomatis
          </div>
        </div>

        {/* Reviews Section */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold text-white">{t('reviews')} ({product.reviewCount})</h3>
            <button className="text-xs text-[#00F0FF]">{t('see_all')}</button>
          </div>
          <div className="flex gap-2 mb-4">
            <span className="px-2 py-1 bg-[#131B2D] text-gray-400 text-xs rounded-lg">Semua</span>
            <span className="px-2 py-1 bg-[#131B2D] text-gray-400 text-xs rounded-lg">Dengan Foto</span>
            <span className="px-2 py-1 bg-[#131B2D] text-gray-400 text-xs rounded-lg">5 Bintang</span>
          </div>
          {reviews.slice(0, 5).map(review => (
            <div key={review.reviewId} className="border-b border-[#1C2A45] pb-3 mb-3">
              <div className="flex items-center gap-2 mb-1">
                <div className="w-7 h-7 rounded-full bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] flex items-center justify-center text-white text-xs font-bold">
                  {review.userName.charAt(0)}
                </div>
                <div>
                  <p className="text-sm text-white">{review.userName}</p>
                  <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className={`w-3 h-3 ${i < review.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-600'}`} />
                    ))}
                  </div>
                </div>
              </div>
              <p className="text-sm text-gray-400 mt-1">{review.text}</p>
              <p className="text-xs text-gray-600 mt-1">{review.variant}</p>
            </div>
          ))}
        </div>

        {/* Related Products */}
        <div>
          <h3 className="text-sm font-semibold text-white mb-3">{t('related_products')}</h3>
          <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-2">
            {relatedProducts.map(p => (
              <div key={p.id} className="flex-shrink-0 w-36" onClick={() => navigate(`/products/${p.id}`)}>
                <ProductCard product={p as any} />
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Sticky Bottom Action */}
      <div className="fixed bottom-0 left-0 right-0 bg-[#080C14] border-t border-[#1C2A45] p-3 z-40 flex items-center gap-3">
        <button
          onClick={() => navigate('/customer-service')}
          className="p-3 rounded-xl bg-[#131B2D] border border-[#1C2A45]"
        >
          <MessageCircle className="w-5 h-5 text-gray-400" />
        </button>
        <button
          onClick={handleAddToCart}
          className="flex-1 py-3 border border-[#00F0FF] text-[#00F0FF] rounded-xl font-medium text-sm flex items-center justify-center gap-2 hover:bg-[#00F0FF]/10 transition-colors"
        >
          <ShoppingCart className="w-4 h-4" />
          {t('add_to_cart')}
        </button>
        <button
          onClick={() => navigate('/checkout')}
          className="flex-1 py-3 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white rounded-xl font-medium text-sm hover:opacity-90 transition-opacity"
        >
          {t('buy_now')}
        </button>
      </div>

      {/* Variant Bottom Sheet */}
      {showVariantSheet && (
        <div className="fixed inset-0 z-50 flex items-end" onClick={() => setShowVariantSheet(false)}>
          <div className="absolute inset-0 bg-black/60" />
          <div className="relative w-full bg-[#131B2D] rounded-t-2xl p-4 animate-slide-up" onClick={e => e.stopPropagation()}>
            <div className="w-10 h-1 bg-gray-600 rounded-full mx-auto mb-4" />
            <div className="flex gap-3 mb-4">
              <img src={product.image} alt="" className="w-20 h-20 rounded-xl object-cover" />
              <div>
                <p className="text-[#00F0FF] font-bold">{formatPrice(product.price)}</p>
                <p className="text-sm text-gray-400">{t('stock')}: {product.stock}</p>
              </div>
            </div>
            <p className="text-sm text-gray-400 mb-2">{t('variant')}</p>
            <div className="flex gap-2 mb-4">
              {['1 Bulan', '3 Bulan', '6 Bulan', '1 Tahun'].map(v => (
                <button
                  key={v}
                  onClick={() => setSelectedVariant(v)}
                  className={`px-3 py-2 rounded-lg text-sm transition-colors ${
                    selectedVariant === v
                      ? 'bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white'
                      : 'bg-[#080C14] text-gray-400 border border-[#1C2A45]'
                  }`}
                >
                  {v}
                </button>
              ))}
            </div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm text-gray-400">{t('quantity')}</span>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-8 h-8 rounded-lg bg-[#080C14] border border-[#1C2A45] flex items-center justify-center"
                >
                  <Minus className="w-4 h-4 text-gray-400" />
                </button>
                <span className="text-white font-medium w-8 text-center">{quantity}</span>
                <button
                  onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                  className="w-8 h-8 rounded-lg bg-[#080C14] border border-[#1C2A45] flex items-center justify-center"
                >
                  <Plus className="w-4 h-4 text-gray-400" />
                </button>
              </div>
            </div>
            <button
              onClick={() => setShowVariantSheet(false)}
              className="w-full py-3 bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white rounded-xl font-medium"
            >
              {t('done')}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
