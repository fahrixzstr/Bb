import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useStore } from '@/stores/useStore';
import { UserPlus, Mail, Lock, User, ArrowRight } from 'lucide-react';
import { toast } from 'sonner';

export default function RegisterPage() {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const { setUser, setIsLoggedIn } = useStore();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      toast.error('Password tidak cocok');
      return;
    }
    setLoading(true);
    setTimeout(() => {
      setUser({
        uid: 'new-user',
        email: email || 'new@example.com',
        displayName: name || 'New User',
        role: 'user',
        photoURL: null,
        phoneNumber: null,
      });
      setIsLoggedIn(true);
      toast.success('Registrasi berhasil!');
      navigate('/');
      setLoading(false);
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-[#080C14] text-white flex flex-col">
      <div className="flex-1 flex flex-col justify-center px-6 max-w-md mx-auto w-full">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-gradient-to-br from-[#00F0FF] to-[#7C3AED] rounded-2xl flex items-center justify-center mx-auto mb-4">
            <UserPlus className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold">{t('register') || 'Daftar'}</h1>
          <p className="text-sm text-gray-500 mt-1">Buat akun baru untuk mulai mencari cuan</p>
        </div>

        <form onSubmit={handleRegister} className="space-y-4">
          <div className="relative">
            <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
            <input
              type="text"
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder={t('full_name') || 'Nama Lengkap'}
              className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl py-3.5 pl-12 pr-4 text-white placeholder:text-gray-600 focus:outline-none focus:border-[#00F0FF]"
            />
          </div>
          <div className="relative">
            <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
            <input
              type="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              placeholder={t('email') || 'Email'}
              className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl py-3.5 pl-12 pr-4 text-white placeholder:text-gray-600 focus:outline-none focus:border-[#00F0FF]"
            />
          </div>
          <div className="relative">
            <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
            <input
              type="password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder={t('password') || 'Password'}
              className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl py-3.5 pl-12 pr-4 text-white placeholder:text-gray-600 focus:outline-none focus:border-[#00F0FF]"
            />
          </div>
          <div className="relative">
            <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
            <input
              type="password"
              value={confirmPassword}
              onChange={e => setConfirmPassword(e.target.value)}
              placeholder={t('confirm_password') || 'Konfirmasi Password'}
              className="w-full bg-[#131B2D] border border-[#1C2A45] rounded-xl py-3.5 pl-12 pr-4 text-white placeholder:text-gray-600 focus:outline-none focus:border-[#00F0FF]"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3.5 bg-gradient-to-r from-[#00F0FF] to-[#7C3AED] rounded-xl font-semibold text-white disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {loading ? 'Memuat...' : (t('register') || 'Daftar')}
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        <p className="text-center mt-6 text-sm text-gray-500">
          Sudah punya akun?{' '}
          <button onClick={() => navigate('/login')} className="text-[#00F0FF] font-medium">
            {t('login') || 'Masuk'}
          </button>
        </p>
      </div>
    </div>
  );
}
