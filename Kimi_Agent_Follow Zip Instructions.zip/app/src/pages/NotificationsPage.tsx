import { useNavigate } from 'react-router-dom';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { ArrowLeft, Package, Target, Gift, Info } from 'lucide-react';
import { trpc } from '@/providers/trpc';

export default function NotificationsPage() {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const [markingAll, setMarkingAll] = useState(false);

  const { data, isLoading } = trpc.auth.me.useQuery(undefined, {
    retry: false,
  });

  const utils = trpc.useUtils();

  const typeConfig: Record<string, { icon: React.ElementType; bg: string }> = {
    order: { icon: Package, bg: 'bg-blue-500/10 text-blue-400' },
    mission: { icon: Target, bg: 'bg-green-500/10 text-green-400' },
    promo: { icon: Gift, bg: 'bg-orange-500/10 text-orange-400' },
    system: { icon: Info, bg: 'bg-gray-500/10 text-gray-400' },
  };

  // Use local state for demo notifications
  const [notifications] = useState([
    {
      notificationId: '1',
      title: t('mission_completed') || 'Mission Completed',
      body: 'Your mission "Rating Review PlayStore" has been approved. Reward: Rp 5,000',
      type: 'mission',
      read: false,
      createdAt: new Date().toISOString(),
    },
    {
      notificationId: '2',
      title: 'Welcome Bonus',
      body: 'Welcome to CariCuan! Complete your first mission to earn rewards.',
      type: 'system',
      read: true,
      createdAt: new Date(Date.now() - 86400000).toISOString(),
    },
    {
      notificationId: '3',
      title: 'New Mission Available',
      body: 'New survey mission available with reward up to Rp 6,000!',
      type: 'promo',
      read: false,
      createdAt: new Date(Date.now() - 172800000).toISOString(),
    },
  ]);

  const handleMarkAllAsRead = () => {
    setMarkingAll(true);
    setTimeout(() => setMarkingAll(false), 500);
  };

  return (
    <div className="min-h-screen bg-[#080C14] text-white pt-16 pb-8">
      <div className="flex items-center justify-between px-4 py-3 border-b border-[#1C2A45]">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate(-1)}><ArrowLeft className="w-5 h-5 text-gray-400" /></button>
          <h1 className="text-lg font-bold">{t('notifications') || 'Notifications'}</h1>
        </div>
        <button onClick={handleMarkAllAsRead} className="text-xs text-[#00F0FF]">
          {markingAll ? '...' : (t('mark_all_read') || 'Mark all read')}
        </button>
      </div>

      <div className="px-4 mt-4 space-y-2">
        {notifications.map(notif => {
          const config = typeConfig[notif.type] || typeConfig.system;
          const Icon = config.icon;
          return (
            <button
              key={notif.notificationId}
              className={`w-full flex items-start gap-3 p-4 rounded-xl transition-colors ${
                notif.read ? 'bg-[#080C14]' : 'bg-[#131B2D] border border-[#1C2A45]'
              }`}
            >
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${config.bg}`}>
                <Icon className="w-5 h-5" />
              </div>
              <div className="flex-1 text-left min-w-0">
                <div className="flex items-start justify-between gap-2">
                  <h3 className={`text-sm ${notif.read ? 'text-gray-400' : 'text-white font-medium'}`}>{notif.title}</h3>
                  {!notif.read && <span className="w-2 h-2 bg-[#00F0FF] rounded-full flex-shrink-0 mt-1" />}
                </div>
                <p className="text-xs text-gray-500 line-clamp-2 mt-0.5">{notif.body}</p>
                <p className="text-[10px] text-gray-600 mt-1">
                  {new Date(notif.createdAt).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
