import { z } from "zod";
import { eq, and, desc, sql } from "drizzle-orm";
import { createRouter, authedQuery } from "../middleware";
import { getDb } from "../queries/connection";
import * as schema from "@db/schema";

export const transactionRouter = createRouter({
  list: authedQuery
    .input(
      z.object({
        type: z.string().optional(),
        status: z.string().optional(),
        page: z.number().default(1),
        limit: z.number().default(20),
      }).optional()
    )
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const userId = ctx.user.id;
      const conditions = [eq(schema.transactions.userId, userId)];

      if (input?.type && input.type !== "all") {
        conditions.push(eq(schema.transactions.type, input.type as any));
      }
      if (input?.status && input.status !== "all") {
        conditions.push(eq(schema.transactions.status, input.status as any));
      }

      const items = await db
        .select()
        .from(schema.transactions)
        .where(and(...conditions))
        .limit(input?.limit || 20)
        .offset(((input?.page || 1) - 1) * (input?.limit || 20))
        .orderBy(desc(schema.transactions.createdAt));

      const countResult = await db
        .select({ count: sql<number>`count(*)` })
        .from(schema.transactions)
        .where(and(...conditions));

      return {
        items,
        total: countResult[0]?.count || 0,
        page: input?.page || 1,
      };
    }),

  create: authedQuery
    .input(
      z.object({
        type: z.enum(["topup", "withdraw", "reward", "purchase", "refund", "referral"]),
        amount: z.string(),
        fee: z.string().default("0"),
        description: z.string(),
        method: z.string().optional(),
        referenceId: z.string().optional(),
        merchantIcon: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const userId = ctx.user.id;
      const amount = parseFloat(input.amount);
      const fee = parseFloat(input.fee);
      const netAmount = amount - fee;

      const result = await db.insert(schema.transactions).values({
        userId,
        type: input.type,
        amount: input.amount,
        fee: input.fee,
        netAmount: netAmount.toString(),
        description: input.description,
        method: input.method,
        referenceId: input.referenceId,
        merchantIcon: input.merchantIcon,
        status: "pending",
      });

      return { success: true, id: Number(result[0]?.insertId) };
    }),

  updateStatus: authedQuery
    .input(
      z.object({
        id: z.number(),
        status: z.enum(["pending", "success", "failed", "cancelled"]),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();

      await db
        .update(schema.transactions)
        .set({
          status: input.status,
          processedAt: input.status === "success" ? new Date() : undefined,
        })
        .where(
          and(
            eq(schema.transactions.id, input.id),
            eq(schema.transactions.userId, ctx.user.id)
          )
        );

      // If reward success, update user saldo
      if (input.status === "success") {
        const txRows = await db
          .select()
          .from(schema.transactions)
          .where(eq(schema.transactions.id, input.id))
          .limit(1);

        const tx = txRows[0];
        if (tx && (tx.type === "reward" || tx.type === "referral" || tx.type === "topup")) {
          await db
            .update(schema.users)
            .set({
              saldo: sql`${schema.users.saldo} + ${tx.netAmount}`,
            })
            .where(eq(schema.users.id, ctx.user.id));
        } else if (tx && (tx.type === "withdraw" || tx.type === "purchase")) {
          await db
            .update(schema.users)
            .set({
              saldo: sql`${schema.users.saldo} - ${tx.amount}`,
            })
            .where(eq(schema.users.id, ctx.user.id));
        }
      }

      return { success: true };
    }),
});
