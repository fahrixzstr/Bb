import { z } from "zod";
import { eq, and, desc } from "drizzle-orm";
import { createRouter, authedQuery } from "../middleware";
import { getDb } from "../queries/connection";
import * as schema from "@db/schema";

export const orderRouter = createRouter({
  list: authedQuery
    .input(
      z.object({
        status: z.string().optional(),
        page: z.number().default(1),
        limit: z.number().default(20),
      }).optional()
    )
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const conditions = [eq(schema.orders.userId, ctx.user.id)];

      if (input?.status && input.status !== "all") {
        conditions.push(eq(schema.orders.status, input.status as any));
      }

      const items = await db
        .select()
        .from(schema.orders)
        .where(and(...conditions))
        .limit(input?.limit || 20)
        .offset(((input?.page || 1) - 1) * (input?.limit || 20))
        .orderBy(desc(schema.orders.createdAt));

      return { items };
    }),

  create: authedQuery
    .input(
      z.object({
        orderId: z.string(),
        productId: z.number(),
        quantity: z.number().default(1),
        variant: z.string().optional(),
        totalPrice: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();

      await db.insert(schema.orders).values({
        orderId: input.orderId,
        userId: ctx.user.id,
        productId: input.productId,
        quantity: input.quantity,
        variant: input.variant,
        totalPrice: input.totalPrice,
      });

      // Deduct saldo handled by transaction system

      return { success: true };
    }),

  detail: authedQuery
    .input(z.object({ orderId: z.string() }))
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const rows = await db
        .select()
        .from(schema.orders)
        .where(
          and(
            eq(schema.orders.orderId, input.orderId),
            eq(schema.orders.userId, ctx.user.id)
          )
        )
        .limit(1);
      return rows[0] || null;
    }),
});
