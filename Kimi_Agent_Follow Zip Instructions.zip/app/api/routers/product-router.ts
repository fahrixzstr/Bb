import { z } from "zod";
import { eq, and, desc, sql, like } from "drizzle-orm";
import { createRouter, publicQuery, authedQuery } from "../middleware";
import { getDb } from "../queries/connection";
import * as schema from "@db/schema";

export const productRouter = createRouter({
  list: publicQuery
    .input(
      z.object({
        category: z.string().optional(),
        search: z.string().optional(),
        page: z.number().default(1),
        limit: z.number().default(20),
      }).optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conditions: any[] = [];

      if (input?.category && input.category !== "all") {
        conditions.push(eq(schema.products.category, input.category));
      }
      if (input?.search) {
        conditions.push(like(schema.products.name, `%${input.search}%`));
      }

      const where = conditions.length > 0 ? and(...conditions) : undefined;

      const items = await db
        .select()
        .from(schema.products)
        .where(where)
        .limit(input?.limit || 20)
        .offset(((input?.page || 1) - 1) * (input?.limit || 20))
        .orderBy(desc(schema.products.createdAt));

      const countResult = await db
        .select({ count: sql<number>`count(*)` })
        .from(schema.products)
        .where(where);

      return {
        items,
        total: countResult[0]?.count || 0,
        page: input?.page || 1,
      };
    }),

  detail: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const rows = await db
        .select()
        .from(schema.products)
        .where(eq(schema.products.id, input.id))
        .limit(1);

      const product = rows[0] || null;

      if (!product) return null;

      const reviews = await db
        .select()
        .from(schema.reviews)
        .where(eq(schema.reviews.productId, input.id))
        .orderBy(desc(schema.reviews.createdAt))
        .limit(20);

      return { ...product, reviews };
    }),

  reviews: publicQuery
    .input(
      z.object({
        productId: z.number(),
        page: z.number().default(1),
        limit: z.number().default(10),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      const items = await db
        .select()
        .from(schema.reviews)
        .where(eq(schema.reviews.productId, input.productId))
        .limit(input.limit)
        .offset((input.page - 1) * input.limit)
        .orderBy(desc(schema.reviews.createdAt));

      return { items };
    }),

  createReview: authedQuery
    .input(
      z.object({
        productId: z.number(),
        rating: z.number().min(1).max(5),
        comment: z.string(),
        variant: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();

      await db.insert(schema.reviews).values({
        productId: input.productId,
        userId: ctx.user.id,
        userName: ctx.user.name || "User",
        userAvatar: ctx.user.avatar,
        rating: input.rating,
        comment: input.comment,
        variant: input.variant,
      });

      // Update product rating
      const allReviews = await db
        .select()
        .from(schema.reviews)
        .where(eq(schema.reviews.productId, input.productId));

      const avgRating =
        allReviews.reduce((sum, r) => sum + r.rating, 0) / allReviews.length;

      await db
        .update(schema.products)
        .set({
          rating: avgRating.toFixed(1),
          reviewCount: allReviews.length,
        })
        .where(eq(schema.products.id, input.productId));

      return { success: true };
    }),
});
