import { z } from "zod";
import { eq, sql } from "drizzle-orm";
import { createRouter, publicQuery, authedQuery } from "../middleware";
import { getDb } from "../queries/connection";
import * as schema from "@db/schema";

export const userRouter = createRouter({
  me: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const rows = await db
      .select()
      .from(schema.users)
      .where(eq(schema.users.id, ctx.user.id))
      .limit(1);
    return rows[0] || null;
  }),

  profile: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const rows = await db
        .select({
          id: schema.users.id,
          name: schema.users.name,
          email: schema.users.email,
          avatar: schema.users.avatar,
          referralCode: schema.users.referralCode,
          createdAt: schema.users.createdAt,
        })
        .from(schema.users)
        .where(eq(schema.users.id, input.id))
        .limit(1);
      return rows[0] || null;
    }),

  updateProfile: authedQuery
    .input(
      z.object({
        name: z.string().optional(),
        phone: z.string().optional(),
        avatar: z.string().optional(),
        bio: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();

      const updateData: Record<string, any> = {};
      if (input.name) updateData.name = input.name;
      if (input.phone) updateData.phone = input.phone;
      if (input.avatar) updateData.avatar = input.avatar;

      await db
        .update(schema.users)
        .set(updateData)
        .where(eq(schema.users.id, ctx.user.id));

      return { success: true };
    }),

  updateSaldo: authedQuery
    .input(
      z.object({
        amount: z.string(),
        operation: z.enum(["add", "subtract"]),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();

      if (input.operation === "add") {
        await db
          .update(schema.users)
          .set({
            saldo: sql`${schema.users.saldo} + ${input.amount}`,
          })
          .where(eq(schema.users.id, ctx.user.id));
      } else {
        await db
          .update(schema.users)
          .set({
            saldo: sql`${schema.users.saldo} - ${input.amount}`,
          })
          .where(eq(schema.users.id, ctx.user.id));
      }

      return { success: true };
    }),

  generateReferralCode: authedQuery.mutation(async ({ ctx }) => {
    const db = getDb();

    const code = Math.random().toString(36).substring(2, 8).toUpperCase();

    await db
      .update(schema.users)
      .set({ referralCode: code })
      .where(eq(schema.users.id, ctx.user.id));

    return { code };
  }),
});
