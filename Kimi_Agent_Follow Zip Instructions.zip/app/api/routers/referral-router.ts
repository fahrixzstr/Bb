import { z } from "zod";
import { eq, and, desc, sql } from "drizzle-orm";
import { createRouter, publicQuery, authedQuery } from "../middleware";
import { getDb } from "../queries/connection";
import * as schema from "@db/schema";

export const referralRouter = createRouter({
  stats: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const userId = ctx.user.id;

    // Get referral history
    const history = await db
      .select()
      .from(schema.referrals)
      .where(eq(schema.referrals.referrerId, userId))
      .orderBy(desc(schema.referrals.createdAt));

    const totalEarnings = history
      .filter((r) => r.status === "completed")
      .reduce((sum, r) => sum + parseFloat(r.rewardAmount), 0);

    const pendingEarnings = history
      .filter((r) => r.status === "pending")
      .reduce((sum, r) => sum + parseFloat(r.rewardAmount), 0);

    return {
      totalReferrals: history.length,
      totalEarnings,
      pendingEarnings,
      history,
    };
  }),

  withdraw: authedQuery
    .input(
      z.object({
        amount: z.string(),
        method: z.string(),
        accountNumber: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const userId = ctx.user.id;

      // Check available earnings
      const stats = await db
        .select()
        .from(schema.referrals)
        .where(
          and(
            eq(schema.referrals.referrerId, userId),
            eq(schema.referrals.status, "completed")
          )
        );

      const totalEarnings = stats.reduce(
        (sum, r) => sum + parseFloat(r.rewardAmount),
        0
      );

      const amount = parseFloat(input.amount);
      if (amount > totalEarnings) {
        throw new Error("Insufficient referral earnings");
      }

      // Create withdrawal transaction
      await db.insert(schema.transactions).values({
        userId,
        type: "withdraw",
        amount: input.amount,
        fee: "0",
        netAmount: input.amount,
        description: `Withdraw referral earnings to ${input.method}`,
        method: input.method,
        status: "pending",
      });

      // Deduct from user saldo
      await db
        .update(schema.users)
        .set({
          saldo: sql`${schema.users.saldo} - ${input.amount}`,
        })
        .where(eq(schema.users.id, userId));

      return { success: true };
    }),

  // Create referral (when a new user registers with a referral code)
  create: publicQuery
    .input(
      z.object({
        referralCode: z.string(),
        refereeId: z.number(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      // Find referrer by referral code
      const referrerRows = await db
        .select()
        .from(schema.users)
        .where(eq(schema.users.referralCode, input.referralCode))
        .limit(1);

      const referrer = referrerRows[0];
      if (!referrer) throw new Error("Invalid referral code");

      // Check if already referred
      const existing = await db
        .select()
        .from(schema.referrals)
        .where(eq(schema.referrals.refereeId, input.refereeId))
        .limit(1);

      if (existing.length > 0) {
        return { success: false, message: "Already referred" };
      }

      await db.insert(schema.referrals).values({
        referrerId: referrer.id,
        refereeId: input.refereeId,
        rewardAmount: "2000",
        status: "pending",
      });

      // Update referredBy on user
      await db
        .update(schema.users)
        .set({ referredBy: referrer.id })
        .where(eq(schema.users.id, input.refereeId));

      return { success: true };
    }),
});
