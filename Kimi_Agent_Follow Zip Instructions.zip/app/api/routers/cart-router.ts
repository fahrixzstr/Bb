import { z } from "zod";
import { eq, and } from "drizzle-orm";
import { createRouter, authedQuery } from "../middleware";
import { getDb } from "../queries/connection";
import * as schema from "@db/schema";

export const cartRouter = createRouter({
  list: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const items = await db
      .select()
      .from(schema.cartItems)
      .where(eq(schema.cartItems.userId, ctx.user.id))
      .orderBy(schema.cartItems.createdAt);
    return { items };
  }),

  add: authedQuery
    .input(
      z.object({
        productId: z.number(),
        name: z.string(),
        price: z.string(),
        quantity: z.number().default(1),
        image: z.string().optional(),
        variant: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();

      // Check if already in cart
      const existing = await db
        .select()
        .from(schema.cartItems)
        .where(
          and(
            eq(schema.cartItems.userId, ctx.user.id),
            eq(schema.cartItems.productId, input.productId)
          )
        )
        .limit(1);

      if (existing.length > 0) {
        await db
          .update(schema.cartItems)
          .set({
            quantity: existing[0].quantity + input.quantity,
          })
          .where(eq(schema.cartItems.id, existing[0].id));
      } else {
        await db.insert(schema.cartItems).values({
          userId: ctx.user.id,
          productId: input.productId,
          name: input.name,
          price: input.price,
          quantity: input.quantity,
          image: input.image,
          variant: input.variant,
        });
      }

      return { success: true };
    }),

  update: authedQuery
    .input(
      z.object({
        id: z.number(),
        quantity: z.number(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();

      if (input.quantity <= 0) {
        await db
          .delete(schema.cartItems)
          .where(
            and(
              eq(schema.cartItems.id, input.id),
              eq(schema.cartItems.userId, ctx.user.id)
            )
          );
      } else {
        await db
          .update(schema.cartItems)
          .set({ quantity: input.quantity })
          .where(
            and(
              eq(schema.cartItems.id, input.id),
              eq(schema.cartItems.userId, ctx.user.id)
            )
          );
      }

      return { success: true };
    }),

  remove: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();

      await db
        .delete(schema.cartItems)
        .where(
          and(
            eq(schema.cartItems.id, input.id),
            eq(schema.cartItems.userId, ctx.user.id)
          )
        );

      return { success: true };
    }),

  clear: authedQuery.mutation(async ({ ctx }) => {
    const db = getDb();

    await db
      .delete(schema.cartItems)
      .where(eq(schema.cartItems.userId, ctx.user.id));

    return { success: true };
  }),
});
