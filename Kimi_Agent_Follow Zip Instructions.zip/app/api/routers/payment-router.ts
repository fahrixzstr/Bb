import { z } from "zod";
import { eq, and } from "drizzle-orm";
import { createRouter, publicQuery, authedQuery } from "../middleware";
import { getDb } from "../queries/connection";
import * as schema from "@db/schema";

export const paymentRouter = createRouter({
  create: authedQuery
    .input(
      z.object({
        orderId: z.string(),
        amount: z.string(),
        paymentMethod: z.string(),
        customerDetails: z.record(z.string(), z.any()).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();

      // Skeleton - will be integrated with actual payment gateway
      const result = await db.insert(schema.payments).values({
        orderId: input.orderId,
        userId: ctx.user.id,
        amount: input.amount,
        paymentMethod: input.paymentMethod,
        status: "pending",
      });

      return {
        token: null,
        redirect_url: null,
        order_id: input.orderId,
        amount: input.amount,
        status: "pending" as const,
        paymentId: Number(result[0]?.insertId),
      };
    }),

  webhook: publicQuery
    .input(z.record(z.string(), z.any()))
    .mutation(async ({ input }) => {
      const db = getDb();

      // Skeleton webhook handler
      const orderId = input.order_id as string;
      const transactionStatus = input.transaction_status as string;

      if (orderId) {
        const status =
          transactionStatus === "capture" || transactionStatus === "settlement"
            ? "success"
            : transactionStatus === "deny" || transactionStatus === "cancel"
            ? "failed"
            : transactionStatus === "expire"
            ? "expired"
            : "pending";

        await db
          .update(schema.payments)
          .set({
            status: status as any,
            transactionId: input.transaction_id as string,
            paidAt: status === "success" ? new Date() : undefined,
          })
          .where(eq(schema.payments.orderId, orderId));
      }

      return { received: true, status: transactionStatus };
    }),

  status: authedQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const rows = await db
        .select()
        .from(schema.payments)
        .where(
          and(
            eq(schema.payments.id, input.id),
            eq(schema.payments.userId, ctx.user.id)
          )
        )
        .limit(1);
      return rows[0] || null;
    }),

  cancel: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();

      await db
        .update(schema.payments)
        .set({ status: "expired" as any })
        .where(
          and(
            eq(schema.payments.id, input.id),
            eq(schema.payments.userId, ctx.user.id)
          )
        );

      return { success: true };
    }),
});
