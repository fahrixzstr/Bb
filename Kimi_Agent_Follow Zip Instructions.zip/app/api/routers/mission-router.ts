import { z } from "zod";
import { eq, and, desc, sql } from "drizzle-orm";
import { createRouter, publicQuery, authedQuery } from "../middleware";
import { getDb } from "../queries/connection";
import * as schema from "@db/schema";

export const missionRouter = createRouter({
  // List missions with filters
  list: publicQuery
    .input(
      z.object({
        category: z.string().optional(),
        status: z.string().optional(),
        page: z.number().default(1),
        limit: z.number().default(20),
      }).optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      const filters: any[] = [];

      if (input?.category && input.category !== "all") {
        filters.push(eq(schema.missions.category, input.category as any));
      }
      if (input?.status) {
        filters.push(eq(schema.missions.status, input.status as any));
      } else {
        filters.push(eq(schema.missions.status, "active"));
      }

      const where = filters.length > 0 ? and(...filters) : undefined;

      const items = await db
        .select()
        .from(schema.missions)
        .where(where)
        .limit(input?.limit || 20)
        .offset(((input?.page || 1) - 1) * (input?.limit || 20))
        .orderBy(desc(schema.missions.createdAt));

      const countResult = await db
        .select({ count: sql<number>`count(*)` })
        .from(schema.missions)
        .where(where);

      return {
        items,
        total: countResult[0]?.count || 0,
        page: input?.page || 1,
        totalPages: Math.ceil((countResult[0]?.count || 0) / (input?.limit || 20)),
      };
    }),

  // Get single mission detail
  detail: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const rows = await db
        .select()
        .from(schema.missions)
        .where(eq(schema.missions.id, input.id))
        .limit(1);
      return rows[0] || null;
    }),

  // Claim a mission
  claim: authedQuery
    .input(z.object({ missionId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const userId = ctx.user.id;

      // Check if already claimed
      const existing = await db
        .select()
        .from(schema.userMissions)
        .where(
          and(
            eq(schema.userMissions.userId, userId),
            eq(schema.userMissions.missionId, input.missionId)
          )
        )
        .limit(1);

      if (existing.length > 0) {
        throw new Error("Mission already claimed");
      }

      // Get mission info
      const missionRows = await db
        .select()
        .from(schema.missions)
        .where(eq(schema.missions.id, input.missionId))
        .limit(1);

      const mission = missionRows[0];
      if (!mission) throw new Error("Mission not found");
      if (mission.status !== "active") throw new Error("Mission not active");

      if (
        mission.maxParticipants &&
        mission.currentParticipants >= mission.maxParticipants
      ) {
        throw new Error("Mission quota full");
      }

      // Create user mission
      await db.insert(schema.userMissions).values({
        userId,
        missionId: input.missionId,
        status: "claimed",
      });

      // Increment participant count
      await db
        .update(schema.missions)
        .set({
          currentParticipants: sql`${schema.missions.currentParticipants} + 1`,
        })
        .where(eq(schema.missions.id, input.missionId));

      return { success: true };
    }),

  // Submit mission proof
  submit: authedQuery
    .input(
      z.object({
        missionId: z.number(),
        proofData: z.record(z.string(), z.string()),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const userId = ctx.user.id;

      const result = await db
        .update(schema.userMissions)
        .set({
          status: "submitted",
          proofData: input.proofData as Record<string, string>,
          submittedAt: new Date(),
        })
        .where(
          and(
            eq(schema.userMissions.userId, userId),
            eq(schema.userMissions.missionId, input.missionId)
          )
        );

      return { success: true };
    }),

  // Get user's missions
  myMissions: authedQuery
    .input(
      z.object({
        status: z.string().optional(),
        page: z.number().default(1),
        limit: z.number().default(20),
      }).optional()
    )
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const userId = ctx.user.id;
      const conditions = [eq(schema.userMissions.userId, userId)];

      if (input?.status && input.status !== "all") {
        conditions.push(
          eq(schema.userMissions.status, input.status as any)
        );
      }

      const items = await db
        .select({
          userMission: schema.userMissions,
          mission: schema.missions,
        })
        .from(schema.userMissions)
        .leftJoin(
          schema.missions,
          eq(schema.userMissions.missionId, schema.missions.id)
        )
        .where(and(...conditions))
        .limit(input?.limit || 20)
        .offset(((input?.page || 1) - 1) * (input?.limit || 20))
        .orderBy(desc(schema.userMissions.createdAt));

      return { items };
    }),

  // Check mission status
  status: authedQuery
    .input(z.object({ missionId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const rows = await db
        .select()
        .from(schema.userMissions)
        .where(
          and(
            eq(schema.userMissions.userId, ctx.user.id),
            eq(schema.userMissions.missionId, input.missionId)
          )
        )
        .limit(1);
      return rows[0] || null;
    }),
});
