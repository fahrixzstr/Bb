import { authRouter } from "./auth-router";
import { missionRouter } from "./routers/mission-router";
import { transactionRouter } from "./routers/transaction-router";
import { productRouter } from "./routers/product-router";
import { referralRouter } from "./routers/referral-router";
import { paymentRouter } from "./routers/payment-router";
import { cartRouter } from "./routers/cart-router";
import { orderRouter } from "./routers/order-router";
import { userRouter } from "./routers/user-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  user: userRouter,
  mission: missionRouter,
  transaction: transactionRouter,
  product: productRouter,
  referral: referralRouter,
  payment: paymentRouter,
  cart: cartRouter,
  order: orderRouter,
});

export type AppRouter = typeof appRouter;
