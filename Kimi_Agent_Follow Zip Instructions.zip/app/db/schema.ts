import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  decimal,
  int,
  json,
  bigint,
} from "drizzle-orm/mysql-core";

// ── Users ──
export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 20 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  saldo: decimal("saldo", { precision: 12, scale: 2 }).default("0").notNull(),
  referralCode: varchar("referral_code", { length: 20 }).unique(),
  referredBy: bigint("referred_by", { mode: "number", unsigned: true }),
  ktaVerified: mysqlEnum("kta_verified", ["true", "false"]).default("false").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ── Missions ──
export const missions = mysqlTable("missions", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  category: mysqlEnum("category", [
    "registrasi",
    "review",
    "download",
    "game",
    "survey",
    "pinjaman",
    "social_media",
    "voting",
    "google_maps",
  ]).notNull(),
  rewardAmount: decimal("reward_amount", { precision: 12, scale: 2 }).notNull(),
  timeEstimate: int("time_estimate").default(30).notNull(),
  maxParticipants: int("max_participants"),
  currentParticipants: int("current_participants").default(0).notNull(),
  maxAttempts: int("max_attempts").default(1).notNull(),
  requirements: json("requirements").$type<string[]>(),
  steps: json("steps").$type<string[]>(),
  proofFields: json("proof_fields").$type<Record<string, string>[]>(),
  merchantIcon: varchar("merchant_icon", { length: 100 }),
  merchantName: varchar("merchant_name", { length: 100 }),
  status: mysqlEnum("status", ["active", "inactive", "expired"]).default("active").notNull(),
  processingDays: int("processing_days").default(3),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Mission = typeof missions.$inferSelect;
export type InsertMission = typeof missions.$inferInsert;

// ── User Missions ──
export const userMissions = mysqlTable("user_missions", {
  id: serial("id").primaryKey(),
  userId: bigint("user_id", { mode: "number", unsigned: true }).notNull(),
  missionId: bigint("mission_id", { mode: "number", unsigned: true }).notNull(),
  status: mysqlEnum("status", [
    "claimed",
    "submitted",
    "processing",
    "completed",
    "rejected",
    "expired",
  ]).default("claimed").notNull(),
  proofData: json("proof_data").$type<Record<string, string>>(),
  rejectionReason: text("rejection_reason"),
  submittedAt: timestamp("submitted_at"),
  reviewedAt: timestamp("reviewed_at"),
  rewardPaidAt: timestamp("reward_paid_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type UserMission = typeof userMissions.$inferSelect;
export type InsertUserMission = typeof userMissions.$inferInsert;

// ── Transactions ──
export const transactions = mysqlTable("transactions", {
  id: serial("id").primaryKey(),
  userId: bigint("user_id", { mode: "number", unsigned: true }).notNull(),
  type: mysqlEnum("type", ["topup", "withdraw", "reward", "purchase", "refund", "referral"]).notNull(),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  fee: decimal("fee", { precision: 12, scale: 2 }).default("0").notNull(),
  netAmount: decimal("net_amount", { precision: 12, scale: 2 }).notNull(),
  status: mysqlEnum("status", ["pending", "success", "failed", "cancelled"]).default("pending").notNull(),
  method: varchar("method", { length: 50 }),
  description: text("description"),
  referenceId: varchar("reference_id", { length: 255 }),
  merchantIcon: varchar("merchant_icon", { length: 100 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  processedAt: timestamp("processed_at"),
});

export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = typeof transactions.$inferInsert;

// ── Products ──
export const products = mysqlTable("products", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  price: decimal("price", { precision: 12, scale: 2 }).notNull(),
  originalPrice: decimal("original_price", { precision: 12, scale: 2 }),
  stock: int("stock").default(0).notNull(),
  images: json("images").$type<string[]>(),
  variants: json("variants").$type<{ id: string; name: string; price: number; stock: number }[]>(),
  rating: decimal("rating", { precision: 3, scale: 1 }).default("0").notNull(),
  reviewCount: int("review_count").default(0).notNull(),
  soldCount: int("sold_count").default(0).notNull(),
  category: varchar("category", { length: 50 }),
  tags: json("tags").$type<string[]>(),
  shippingEstimate: varchar("shipping_estimate", { length: 50 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Product = typeof products.$inferSelect;
export type InsertProduct = typeof products.$inferInsert;

// ── Reviews ──
export const reviews = mysqlTable("reviews", {
  id: serial("id").primaryKey(),
  productId: bigint("product_id", { mode: "number", unsigned: true }).notNull(),
  userId: bigint("user_id", { mode: "number", unsigned: true }).notNull(),
  userName: varchar("user_name", { length: 255 }),
  userAvatar: text("user_avatar"),
  rating: int("rating").notNull(),
  comment: text("comment"),
  variant: varchar("variant", { length: 100 }),
  images: json("images").$type<string[]>(),
  helpful: int("helpful").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Review = typeof reviews.$inferSelect;
export type InsertReview = typeof reviews.$inferInsert;

// ── Orders ──
export const orders = mysqlTable("orders", {
  id: serial("id").primaryKey(),
  orderId: varchar("order_id", { length: 100 }).notNull().unique(),
  userId: bigint("user_id", { mode: "number", unsigned: true }).notNull(),
  productId: bigint("product_id", { mode: "number", unsigned: true }).notNull(),
  quantity: int("quantity").default(1).notNull(),
  variant: varchar("variant", { length: 100 }),
  totalPrice: decimal("total_price", { precision: 12, scale: 2 }).notNull(),
  status: mysqlEnum("status", ["pending", "processing", "shipped", "completed", "cancelled", "refund"]).default("pending").notNull(),
  paymentStatus: mysqlEnum("payment_status", ["pending", "success", "failed"]).default("pending").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export type Order = typeof orders.$inferSelect;
export type InsertOrder = typeof orders.$inferInsert;

// ── Payments ──
export const payments = mysqlTable("payments", {
  id: serial("id").primaryKey(),
  orderId: varchar("order_id", { length: 255 }),
  userId: bigint("user_id", { mode: "number", unsigned: true }).notNull(),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  paymentMethod: varchar("payment_method", { length: 50 }),
  status: mysqlEnum("status", ["pending", "success", "failed", "expired"]).default("pending").notNull(),
  transactionId: varchar("transaction_id", { length: 255 }),
  snapToken: text("snap_token"),
  paidAt: timestamp("paid_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Payment = typeof payments.$inferSelect;
export type InsertPayment = typeof payments.$inferInsert;

// ── Referrals ──
export const referrals = mysqlTable("referrals", {
  id: serial("id").primaryKey(),
  referrerId: bigint("referrer_id", { mode: "number", unsigned: true }).notNull(),
  refereeId: bigint("referee_id", { mode: "number", unsigned: true }).notNull(),
  rewardAmount: decimal("reward_amount", { precision: 12, scale: 2 }).default("0").notNull(),
  status: mysqlEnum("status", ["pending", "completed"]).default("pending").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Referral = typeof referrals.$inferSelect;
export type InsertReferral = typeof referrals.$inferInsert;

// ── Notifications ──
export const notifications = mysqlTable("notifications", {
  id: serial("id").primaryKey(),
  userId: bigint("user_id", { mode: "number", unsigned: true }).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  body: text("body"),
  type: mysqlEnum("type", ["order", "mission", "promo", "system"]).notNull(),
  read: mysqlEnum("read", ["true", "false"]).default("false").notNull(),
  actionUrl: text("action_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

// ── Cart Items ──
export const cartItems = mysqlTable("cart_items", {
  id: serial("id").primaryKey(),
  userId: bigint("user_id", { mode: "number", unsigned: true }).notNull(),
  productId: bigint("product_id", { mode: "number", unsigned: true }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  price: decimal("price", { precision: 12, scale: 2 }).notNull(),
  quantity: int("quantity").default(1).notNull(),
  image: text("image"),
  variant: varchar("variant", { length: 100 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type CartItem = typeof cartItems.$inferSelect;
export type InsertCartItem = typeof cartItems.$inferInsert;
