import { getDb } from "../api/queries/connection";
import * as schema from "./schema";

async function seed() {
  const db = getDb();
  console.log("Seeding database...");

  // Seed missions
  const missionData: schema.InsertMission[] = [
    {
      title: "Rating Review PlayStore!",
      description: "Install aplikasi, beri rating 5 bintang, dan paste review yang diberikan. Screenshot bukti.",
      category: "review",
      rewardAmount: "5000",
      timeEstimate: 15,
      maxParticipants: 100,
      maxAttempts: 3,
      requirements: [
        "Install aplikasi dari PlayStore",
        "Beri rating 5 bintang",
        "Paste review yang diberikan",
        "Screenshot bukti rating dan review"
      ],
      steps: [
        "Klik link aplikasi di PlayStore",
        "Install aplikasi",
        "Buka aplikasi dan beri rating 5 bintang",
        "Paste review: 'Aplikasi sangat bagus dan bermanfaat!'",
        "Screenshot bukti"
      ],
      proofFields: [{ field: "screenshot", label: "Screenshot Rating" }],
      merchantIcon: "playstore",
      merchantName: "Google PlayStore",
      processingDays: 3,
    },
    {
      title: "Daftar SPinjam - Reward Besar!",
      description: "Daftar SPinjam/SPayLater melalui link referral. Upload bukti limit diterima.",
      category: "pinjaman",
      rewardAmount: "80000",
      timeEstimate: 30,
      maxParticipants: 50,
      maxAttempts: 1,
      requirements: [
        "Wajib akun Shopee aktif",
        "Minimal 1 transaksi di Shopee",
        "Upload bukti limit diterima"
      ],
      steps: [
        "Klik link referral SPinjam",
        "Isi data diri lengkap",
        "Tunggu approval",
        "Screenshot bukti limit"
      ],
      proofFields: [
        { field: "nama_lengkap", label: "Nama Lengkap" },
        { field: "no_hp", label: "No HP" },
        { field: "email", label: "Email" },
        { field: "screenshot_limit", label: "Screenshot Bukti Limit" }
      ],
      merchantIcon: "shopee",
      merchantName: "Shopee",
      processingDays: 7,
    },
    {
      title: "Survey Online - Pendapat Anda Berharga",
      description: "Isi survey online dari Dynata. Jawab pertanyaan dengan jujur.",
      category: "survey",
      rewardAmount: "6000",
      timeEstimate: 20,
      maxParticipants: 200,
      maxAttempts: 5,
      requirements: [
        "Isi survey dengan jujur",
        "Jangan asal klik",
        "Screenshot halaman terakhir survey"
      ],
      steps: [
        "Klik link survey",
        "Isi data demografi",
        "Jawab semua pertanyaan",
        "Screenshot halaman completion"
      ],
      proofFields: [{ field: "screenshot", label: "Screenshot Completion" }],
      merchantIcon: "survey",
      merchantName: "Dynata",
      processingDays: 2,
    },
    {
      title: "Follow Instagram @CariCuan",
      description: "Follow akun Instagram @CariCuan. Screenshot bukti follow.",
      category: "social_media",
      rewardAmount: "500",
      timeEstimate: 5,
      maxParticipants: 500,
      maxAttempts: 1,
      requirements: ["Akun Instagram aktif", "Screenshot bukti follow"],
      steps: [
        "Kunjungi Instagram @CariCuan",
        "Klik tombol Follow",
        "Screenshot bukti follow"
      ],
      proofFields: [{ field: "screenshot", label: "Screenshot Follow" }],
      merchantIcon: "instagram",
      merchantName: "Instagram",
      processingDays: 1,
    },
    {
      title: "Google Maps Review - Restoran",
      description: "Beri review di Google Maps untuk restoran yang ditentukan. Copy-paste review.",
      category: "google_maps",
      rewardAmount: "1500",
      timeEstimate: 10,
      maxParticipants: 100,
      maxAttempts: 2,
      requirements: [
        "Akun Google aktif",
        "Tulis review minimal 20 kata",
        "Screenshot bukti review"
      ],
      steps: [
        "Kunjungi lokasi di Google Maps",
        "Klik 'Tulis Ulasan'",
        "Paste review yang diberikan",
        "Screenshot bukti"
      ],
      proofFields: [
        { field: "nama_google", label: "Nama Google" },
        { field: "email_google", label: "Email Google" },
        { field: "screenshot", label: "Screenshot Review" }
      ],
      merchantIcon: "google_maps",
      merchantName: "Google Maps",
      processingDays: 2,
    },
    {
      title: "Registrasi Akun Baru",
      description: "Daftar akun baru melalui link referral. Verifikasi email.",
      category: "registrasi",
      rewardAmount: "5000",
      timeEstimate: 10,
      maxParticipants: 100,
      maxAttempts: 1,
      requirements: [
        "Email aktif (bukan email sementara)",
        "Verifikasi email",
        "Lengkapi profil"
      ],
      steps: [
        "Klik link registrasi",
        "Isi form dengan data valid",
        "Verifikasi email",
        "Lengkapi profil"
      ],
      proofFields: [
        { field: "email", label: "Email yang didaftarkan" },
        { field: "screenshot", label: "Screenshot Profil Lengkap" }
      ],
      merchantIcon: "globe",
      merchantName: "Website",
      processingDays: 3,
    },
    {
      title: "Voting Pilihan Anda",
      description: "Vote di polling yang tersedia. Pilih opsi sesuai preferensi.",
      category: "voting",
      rewardAmount: "1000",
      timeEstimate: 5,
      maxParticipants: 300,
      maxAttempts: 10,
      requirements: ["Vote dengan jujur", "Screenshot bukti vote"],
      steps: [
        "Buka halaman voting",
        "Pilih opsi",
        "Submit vote",
        "Screenshot bukti"
      ],
      proofFields: [{ field: "screenshot", label: "Screenshot Vote" }],
      merchantIcon: "vote",
      merchantName: "Voting",
      processingDays: 1,
    },
    {
      title: "Download & Install Aplikasi",
      description: "Download dan install aplikasi Android. Biarkan terpasang minimal 3 hari.",
      category: "download",
      rewardAmount: "3000",
      timeEstimate: 10,
      maxParticipants: 150,
      maxAttempts: 1,
      requirements: [
        "Download dari PlayStore",
        "Install dan buka aplikasi",
        "Biarkan terpasang minimal 3 hari",
        "TIDAK BOLEH uninstall dalam 3 hari"
      ],
      steps: [
        "Klik link PlayStore",
        "Download dan install",
        "Buka aplikasi",
        "Screenshot halaman utama aplikasi"
      ],
      proofFields: [{ field: "screenshot", label: "Screenshot Aplikasi" }],
      merchantIcon: "download",
      merchantName: "PlayStore",
      processingDays: 5,
    },
  ];

  for (const mission of missionData) {
    await db.insert(schema.missions).values(mission);
  }
  console.log(`✓ Seeded ${missionData.length} missions`);

  // Seed products
  const productData: schema.InsertProduct[] = [
    {
      name: "Canva Pro 1 Bulan",
      description: "Akses fitur premium Canva: background remover, brand kit, magic resize, dan masih banyak lagi.",
      price: "25000",
      originalPrice: "99000",
      stock: 100,
      images: ["/assets/media/products/canva.jpg"],
      rating: "4.8",
      reviewCount: 120,
      soldCount: 500,
      category: "subscription",
      tags: ["Sangat bagus", "Bagus", "Barang bagus", "Kemasan rapih"],
      shippingEstimate: "Instant",
    },
    {
      name: "Netflix Premium 1 Bulan",
      description: "Akun Netflix Premium 4K UHD. Support semua device.",
      price: "45000",
      originalPrice: "186000",
      stock: 50,
      images: ["/assets/media/products/netflix.jpg"],
      rating: "4.7",
      reviewCount: 200,
      soldCount: 800,
      category: "subscription",
      tags: ["Cepat", "Aman", "Terpercaya"],
      shippingEstimate: "1-5 menit",
    },
    {
      name: "ChatGPT Plus 1 Bulan",
      description: "Akses GPT-4, browsing, plugin, dan code interpreter.",
      price: "185000",
      originalPrice: "320000",
      stock: 30,
      images: ["/assets/media/products/chatgpt.jpg"],
      rating: "4.9",
      reviewCount: 300,
      soldCount: 1200,
      category: "subscription",
      tags: [" recommended", "Terbaik", "Fast delivery"],
      shippingEstimate: "1-10 menit",
    },
    {
      name: "Spotify Premium 1 Bulan",
      description: "Streaming musik tanpa iklan. Download lagu untuk offline.",
      price: "15000",
      originalPrice: "54990",
      stock: 80,
      images: ["/assets/media/products/spotify.jpg"],
      rating: "4.6",
      reviewCount: 150,
      soldCount: 600,
      category: "subscription",
      tags: ["Murah", "Cepat", "Aktif"],
      shippingEstimate: "Instant",
    },
    {
      name: "VPS Server 1 Bulan",
      description: "VPS KVM dengan SSD storage. Cocok untuk hosting, bot, dan development.",
      price: "75000",
      stock: 20,
      images: ["/assets/media/products/vps.jpg"],
      rating: "4.5",
      reviewCount: 80,
      soldCount: 200,
      category: "hosting",
      shippingEstimate: "5-15 menit",
    },
    {
      name: "Steam Wallet IDR",
      description: "Top up Steam Wallet untuk pembelian game dan item.",
      price: "50000",
      stock: 200,
      images: ["/assets/media/products/steam.jpg"],
      rating: "4.8",
      reviewCount: 250,
      soldCount: 900,
      category: "voucher",
      tags: ["Cepat", "Auto"],
      shippingEstimate: "1-5 menit",
    },
    {
      name: "YouTube Premium 1 Bulan",
      description: "Tonton video tanpa iklan. Background play dan download.",
      price: "12000",
      originalPrice: "59000",
      stock: 60,
      images: ["/assets/media/products/youtube.jpg"],
      rating: "4.4",
      reviewCount: 90,
      soldCount: 400,
      category: "subscription",
      shippingEstimate: "Instant",
    },
    {
      name: "Google Play Gift Card",
      description: "Voucher Google Play untuk pembelian app, game, dan in-app purchase.",
      price: "50000",
      stock: 150,
      images: ["/assets/media/products/googleplay.jpg"],
      rating: "4.7",
      reviewCount: 180,
      soldCount: 700,
      category: "voucher",
      shippingEstimate: "1-5 menit",
    },
    {
      name: "Domain .COM 1 Tahun",
      description: "Domain .COM dengan DNS management dan privacy protection.",
      price: "120000",
      stock: 50,
      images: ["/assets/media/products/domain.jpg"],
      rating: "4.6",
      reviewCount: 60,
      soldCount: 150,
      category: "hosting",
      shippingEstimate: "Instant",
    },
    {
      name: "Panel Pterodactyl",
      description: "Panel game server hosting dengan Pterodactyl. Support Minecraft, CS:GO, dll.",
      price: "35000",
      stock: 30,
      images: ["/assets/media/products/panel.jpg"],
      rating: "4.3",
      reviewCount: 45,
      soldCount: 100,
      category: "hosting",
      shippingEstimate: "5-10 menit",
    },
  ];

  for (const product of productData) {
    await db.insert(schema.products).values(product);
  }
  console.log(`✓ Seeded ${productData.length} products`);

  // Seed some reviews
  const reviewData: schema.InsertReview[] = [
    {
      productId: 1,
      userId: 1,
      userName: "Ahmad R.",
      rating: 5,
      comment: "Proses cepat banget! Langsung aktif. Recommended seller!",
      variant: "Canva Pro 1 Bulan",
      helpful: 12,
    },
    {
      productId: 1,
      userId: 2,
      userName: "Siti N.",
      rating: 5,
      comment: "Mantap! Sudah langganan disini terus. Gak pernah ada masalah.",
      variant: "Canva Pro 1 Bulan",
      helpful: 8,
    },
    {
      productId: 2,
      userId: 3,
      userName: "Budi S.",
      rating: 4,
      comment: "Netflix work dengan baik. Kualitas 4K mantap!",
      variant: "Netflix Premium",
      helpful: 15,
    },
  ];

  for (const review of reviewData) {
    await db.insert(schema.reviews).values(review);
  }
  console.log(`✓ Seeded ${reviewData.length} reviews`);

  console.log("✅ Seeding complete!");
}

seed().catch(console.error);
